package nbcu.framework.runner;

import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = { "src/test/resources/features" }, glue = { "nbcu.automation.ui.stepdefs",
		"nbcu.framework.hooks" }, tags = "@CREW_REQUEST and not @EMAIL_VALIDATION", plugin = { "pretty", "json:target/cucumber-reports/Cucumber.json",
				"rerun:target/cucumber-reports/rerun-reports/rerun.txt",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:" }, monochrome = true, publish = true)

public class RunCucumberTest extends AbstractTestNGCucumberTests {

	@DataProvider(parallel = true)
	public Object[][] scenarios() {
		return super.scenarios();
	}

}