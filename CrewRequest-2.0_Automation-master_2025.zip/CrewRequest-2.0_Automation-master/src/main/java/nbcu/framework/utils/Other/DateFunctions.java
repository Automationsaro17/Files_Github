package nbcu.framework.utils.Other;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class DateFunctions {
	
	/**
	 * To get current date with given date format 
	 * @param dateFormat - date format
	 * @return - current date
	 * @throws Exception
	 */
	public static String getCurrentDate(String dateFormat) throws Exception {
		String currentDate = "";
		try {
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(dateFormat);
			Date date = new Date();
			currentDate = fsimpleDateFormat.format(date);
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return currentDate;
	}

	/**
	 * To convert date string to date
	 * 
	 * @param dateString            - date string
	 * @param inputDateStringFormat - date format of date string
	 * @return - date
	 * @throws Exception
	 */
	public static Date convertDateStringToDate(String dateString, String inputDateStringFormat) throws Exception {
		Date convertedDate = null;
		try {
			convertedDate = new SimpleDateFormat(inputDateStringFormat).parse(dateString);
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return convertedDate;
	}
	
	/**
	 * Convert date string from one format to another format
	 * @param dateString - Date string
	 * @param fromFormat - current format
	 * @param toFormat - expected format
	 * @return - converted date string
	 * @throws Exception
	 */
	public static String convertDateStringToAnotherFormat(String dateString, String fromFormat, String toFormat) throws Exception {
		String convertedDate = "";
		try {
			Date currentDate = new SimpleDateFormat(fromFormat).parse(dateString);
			SimpleDateFormat toSimpledateFormat = new SimpleDateFormat(toFormat);
			convertedDate = toSimpledateFormat.format(currentDate);
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return convertedDate;
	}

	/**
	 * To generate add/subtract no of days from current date
	 * 
	 * @param dateFormat - date format
	 * @param days       - no of days to add or subtract
	 * @return
	 * @throws Exception
	 */
	public static String addOrMinusDateFromCurrentDate(String dateFormat, String days) throws Exception {
		String updatedDate = "";
		try {
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(dateFormat);
			Date currentDate = new Date();
			Calendar calender = Calendar.getInstance();
			calender.setTime(currentDate);
			calender.add(Calendar.DATE, Integer.parseInt(days));
			updatedDate = fsimpleDateFormat.format(calender.getTime());

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return updatedDate;

	}

	/**
	 * To generate add/subtract no of hours from current time
	 * 
	 * @param timeFormat - time format
	 * @param hours      - no of hours to add or subtract
	 * @return
	 * @throws Exception
	 */
	public static String addOrMinusTimeFromCurrentTime(String timeFormat, String hours) throws Exception {
		String updatedTime = "";
		try {
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(timeFormat);
			Date currentDate = new Date();
			Calendar calender = Calendar.getInstance();
			calender.setTime(currentDate);
			calender.add(Calendar.HOUR, Integer.parseInt(hours));
			updatedTime = fsimpleDateFormat.format(calender.getTime());

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return updatedTime;

	}
	
	/**
	 * To generate add/subtract no of days from given date
	 * @param inputDate - input date
	 * @param dateFormat
	 * @param days
	 * @return
	 * @throws Exception
	 */
	public static String addOrMinusDateFromGivenDate(String inputDate, String dateFormat, String days) throws Exception {
		String updatedDate = "";
		try {
			Date date=convertDateStringToDate(inputDate, dateFormat);
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(dateFormat);
			Calendar calender = Calendar.getInstance();
			calender.setTime(date);
			calender.add(Calendar.DATE, Integer.parseInt(days));
			updatedDate = fsimpleDateFormat.format(calender.getTime());

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return updatedDate;
	}
	
	/**
	 * To generate add/subtract no of hours from given time
	 * @param inputTime - input time
	 * @param timeFormat
	 * @param hours
	 * @return
	 * @throws Exception
	 */
	public static String addOrMinusTimeFromGivenTime(String inputTime, String timeFormat, String hours) throws Exception {
		String updatedTime = "";
		try {
			Date date=convertDateStringToDate(inputTime, timeFormat);
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(timeFormat);
			Calendar calender = Calendar.getInstance();
			calender.setTime(date);
			calender.add(Calendar.HOUR, Integer.parseInt(hours));
			updatedTime = fsimpleDateFormat.format(calender.getTime());

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return updatedTime;

	}
	
	public static List<String> getDateListBetweenDates(String startDate, String endDate, String dateFormat) throws Exception {
		List<String> dateList = new ArrayList<>();
		try {
			//Add from date to list
			dateList.add(startDate);
			
			//Add dates between from and to date
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(dateFormat);
			Date fromDate=convertDateStringToDate(startDate, dateFormat);
			Date toDate=convertDateStringToDate(endDate, dateFormat);
			Calendar cal = Calendar.getInstance();
			cal.setTime(fromDate);
			while (cal.getTime().before(toDate)) {
			    cal.add(Calendar.DATE, 1);
			    dateList.add(fsimpleDateFormat.format(cal.getTime()));
			}

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return dateList;

	}
	
	public static void main(String[] args) throws Exception {
		System.out.println(convertDateStringToAnotherFormat("18:30", "HH:mm", "hh:mm a"));
	}
}
