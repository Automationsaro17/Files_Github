package nbcu.automation.ui.constants.crewrequest;

import java.util.HashMap;

public class Constants {

	private static ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
		@Override
		protected HashMap<String, Object> initialValue() {
			return new HashMap<>();
		}
	};

	// To get crew request number
	public static String getRequestNumber() {
		return (String) constantMap.get().get("Request Number");
	}

	// To get default requester name
	public static String getDefaultRequesterName() {
		return (String) constantMap.get().get("Default Requester Name");
	}

	public static String getDefaultRequesterPhoneNumber() {
		return (String) constantMap.get().get("Default Requester Phone Number");
	}

	public static String getProducerName() {
		return (String) constantMap.get().get("Producer Name");
	}

	public static String getProducerPhoneNumber() {
		return (String) constantMap.get().get("Producer Phone Number");
	}

	public static String getIsOnsiteProducer() {
		return (String) constantMap.get().get("Is Onsite Producer");
	}

	public static String getSeniorProducerName() {
		return (String) constantMap.get().get("Senior Producer Name");
	}

	// To get Show Info
	public static String getShowUnit() {
		return (String) constantMap.get().get("Show Unit");
	}

	// To get business value
	public static String getBusinessValue() {
		return (String) constantMap.get().get("Business Value");
	}

	// To get budget code
	public static String getBudgetCode() {
		return (String) constantMap.get().get("Budget Code");
	}

	public static String getTalent() {
		return (String) constantMap.get().get("Talent Name");
	}

	public static String getProductionType() {
		return (String) constantMap.get().get("Production Type");
	}

	public static String getShootStatus() {
		return (String) constantMap.get().get("Shoot Status");
	}

	public static String getShootType() {
		return (String) constantMap.get().get("Shoot Type");
	}

	public static String getColorSpace() {
		return (String) constantMap.get().get("Color Space");
	}

	public static String getShootDescription() {
		return (String) constantMap.get().get("Shoot Description");
	}

	public static String getAudioNeeds() {
		return (String) constantMap.get().get("Audio Needs");
	}

	public static String getSpecialCondition() {
		return (String) constantMap.get().get("Special Condition");
	}

	public static String getTransmissionType() {
		return (String) constantMap.get().get("Tranmission Type");
	}

	public static String getIsDroneNeeded() {
		return (String) constantMap.get().get("Drone Needed");
	}

	public static String getIs360CamNeeded() {
		return (String) constantMap.get().get("360 Camera Needed");
	}

	public static String getIpadPrompter() {
		return (String) constantMap.get().get("Ipad Prompter Required");
	}

	public static String getSpecialGear() {
		return (String) constantMap.get().get("Special Gear");
	}

	public static String getBureauLocation() {
		return (String) constantMap.get().get("Bureau Location");
	}

	public static String getAddressLine1() {
		return (String) constantMap.get().get("Address Line1");
	}

	public static String getCity() {
		return (String) constantMap.get().get("City");
	}

	public static String getState() {
		return (String) constantMap.get().get("State");
	}

	public static String getZipCode() {
		return (String) constantMap.get().get("Zip Code");
	}

	public static String getCountry() {
		return (String) constantMap.get().get("Country");
	}

	public static String getRiskCategory() {
		return (String) constantMap.get().get("Risk Category");
	}

	public static String getRiskAssessment() {
		return (String) constantMap.get().get("Risk Assessment");
	}

	public static String getOtherHazards() {
		return (String) constantMap.get().get("Other Hazards");
	}

	public static String getEquipmentsForSafety() {
		return (String) constantMap.get().get("Safety Equipments");
	}

	public static String getRiskApprover() {
		return (String) constantMap.get().get("Risk Approver Name");
	}

	public static String getCameraOpsCount() {
		return (String) constantMap.get().get("Camera Ops Count");
	}

	public static String getAudioOpsCount() {
		return (String) constantMap.get().get("Audio Ops Count");
	}

	public static String getEstimatedCost() {
		return (String) constantMap.get().get("Estimated Cost");
	}

	public static String getPrimaryCameraType() {
		return (String) constantMap.get().get("Primary Camera Type");
	}

	public static String getMediaFormat() {
		return (String) constantMap.get().get("Media Format");
	}

	public static String getVideoSpecs() {
		return (String) constantMap.get().get("Video Specs");
	}

	// To get allocation resource count
	public static int getAllocation() {
		return (int) constantMap.get().get("Allocation");
	}

	// To get threshold percentage
	public static int getThresholdPercent() {
		return (int) constantMap.get().get("Threshold");
	}

	// To get actual resource count
	public static int getResourcesCount() {
		if (constantMap.get().containsKey("Resources Count"))
			return (int) constantMap.get().get("Resources Count");
		else
			return 0;
	}

	// To get number of shoot days
	public static int getShootDaysCount() {
		return (int) constantMap.get().get("Shoot Days Count");
	}

	// To get shoot start date
	public static String getShootStartDate() {
		return (String) constantMap.get().get("Shoot Start Date");
	}

	// To get shoot end date
	public static String getShootEndDate() {
		return (String) constantMap.get().get("Shoot End Date");
	}

	// To get shoot start time
	public static String getShootMeetTime() {
		return (String) constantMap.get().get("Shoot Meet Time");
	}

	// To get shoot start time
	public static String getShootStartTime() {
		return (String) constantMap.get().get("Shoot Start Time");
	}

	// To get shoot end time
	public static String getShootEndTime() {
		return (String) constantMap.get().get("Shoot End Time");
	}

	// To get time zone
	public static String getShootTimeZone() {
		return (String) constantMap.get().get("Shoot Time Zone");
	}

	// To get assignment slug
	public static String getAssignmentSlug() {
		return (String) constantMap.get().get("Assignment Slug");
	}

	// To get crew resource role
	public static String getCrewResourceRole(int resourceNumber) {
		return (String) constantMap.get().get("Resource Role_" + resourceNumber);
	}

	// To get crew resource name
	public static String getCrewResourceName(int resourceNumber) {
		return (String) constantMap.get().get("Resource Name_" + resourceNumber);
	}

	// To get crew resource phone
	public static String getCrewResourcePhone(int resourceNumber) {
		return (String) constantMap.get().get("Resource Phone_" + resourceNumber);
	}

	// To get crew resource email
	public static String getCrewResourceEmail(int resourceNumber) {
		return (String) constantMap.get().get("Resource Email_" + resourceNumber);
	}

	public static String getEmailToList() {
		return (String) constantMap.get().get("Email To List");
	}

	public static String getEmailCcList() {
		return (String) constantMap.get().get("Email CC List");
	}

	public static String getEmailSubject() {
		return (String) constantMap.get().get("Email Subject");
	}

	public static String getEmailBody() {
		return (String) constantMap.get().get("Email Body");
	}

	// To get requester notes
	public static String getRequesterNotes(int notesNumber) {
		return (String) constantMap.get().get("Requester Notes_" + notesNumber);
	}

	// To get fulfiller notes
	public static String getFulfillerNotes(int notesNumber) {
		return (String) constantMap.get().get("Fulfiller Notes_" + notesNumber);
	}

	public static String getRequesterNotesTime(int notesNumber) {
		return (String) constantMap.get().get("Requester Notes Time_" + notesNumber);
	}

	public static String getFulfillerNotesTime(int notesNumber) {
		return (String) constantMap.get().get("Fulfiller Notes Time_" + notesNumber);
	}

	// To get requester notes count
	public static int getRequesterNotesCount() {
		return (int) constantMap.get().get("Requester Notes Count");
	}

	// To set fulfiller notes count
	public static int getFulfillerNotesCount() {
		return (int) constantMap.get().get("Fulfiller Notes Count");
	}
	
	public static String getLogTime() {
		return (String) constantMap.get().get("Log Time");
	}

	// To set crew request Number
	public static void setRequestNumber(String requestNumber) {
		constantMap.get().put("Request Number", requestNumber);
	}

	// To set default requester name
	public static void setDefaultRequesterName(String defaultRequestorName) {
		constantMap.get().put("Default Requester Name", defaultRequestorName);
	}

	public static void setDefaultRequesterPhoneNumber(String defaultRequestorPhoneNumber) {
		constantMap.get().put("Default Requester Phone Number", defaultRequestorPhoneNumber);
	}

	public static void setProducerName(String producerName) {
		constantMap.get().put("Producer Name", producerName);
	}

	public static void setProducerPhoneNumber(String producerPhoneNumber) {
		constantMap.get().put("Producer Phone Number", producerPhoneNumber);
	}

	public static void setIsOnsiteProducer(String isOnsiteProducer) {
		constantMap.get().put("Is Onsite Producer", isOnsiteProducer);
	}

	public static void setSeniorProducerName(String seniorProducerName) {
		constantMap.get().put("Senior Producer Name", seniorProducerName);
	}

	// To set Show Info
	public static void setShowUnit(String showUnit) {
		constantMap.get().put("Show Unit", showUnit);
	}

	// To set business value
	public static void setBusinessValue(String businessValue) {
		constantMap.get().put("Business Value", businessValue);
	}

	// To set budget code
	public static void setBudgetCode(String budgetCode) {
		constantMap.get().put("Budget Code", budgetCode);
	}

	public static void setTalent(String talentName) {
		constantMap.get().put("Talent Name", talentName);
	}

	public static void setProductionType(String productionType) {
		constantMap.get().put("Production Type", productionType);
	}

	public static void setShootStatus(String shootStatus) {
		constantMap.get().put("Shoot Status", shootStatus);
	}

	public static void setShootType(String shootType) {
		constantMap.get().put("Shoot Type", shootType);
	}

	public static void setColorSpace(String colorSpace) {
		constantMap.get().put("Color Space", colorSpace);
	}

	public static void setShootDescription(String shootDescription) {
		constantMap.get().put("Shoot Description", shootDescription);
	}

	public static void setAudioNeeds(String audioNeeds) {
		constantMap.get().put("Audio Needs", audioNeeds);
	}

	public static void setSpecialCondition(String specialCondition) {
		constantMap.get().put("Special Condition", specialCondition);
	}

	public static void setTransmissionType(String transmissionType) {
		constantMap.get().put("Tranmission Type", transmissionType);
	}

	public static void setIsDroneNeeded(String isDroneNeeded) {
		constantMap.get().put("Drone Needed", isDroneNeeded);
	}

	public static void setIs360CamNeeded(String is360CamNeeded) {
		constantMap.get().put("360 Camera Needed", is360CamNeeded);
	}

	public static void setIpadPrompter(String isIpadPrompterRequired) {
		constantMap.get().put("Ipad Prompter Required", isIpadPrompterRequired);
	}

	public static void setSpecialGear(String specialGear) {
		constantMap.get().put("Special Gear", specialGear);
	}

	public static void setBureauLocation(String bureauLocation) {
		constantMap.get().put("Bureau Location", bureauLocation);
	}

	public static void setAddressLine1(String addressLine1) {
		constantMap.get().put("Address Line1", addressLine1);
	}

	public static void setCity(String city) {
		constantMap.get().put("City", city);
	}

	public static void setState(String state) {
		constantMap.get().put("State", state);
	}

	public static void setZipCode(String zipCode) {
		constantMap.get().put("Zip Code", zipCode);
	}

	public static void setCountry(String country) {
		constantMap.get().put("Country", country);
	}

	public static void setRiskCategory(String riskCategory) {
		constantMap.get().put("Risk Category", riskCategory);
	}

	public static void setRiskAssessment(String riskAssessment) {
		constantMap.get().put("Risk Assessment", riskAssessment);
	}

	public static void setOtherHazards(String otherHazards) {
		constantMap.get().put("Other Hazards", otherHazards);
	}

	public static void setEquipmentsForSafety(String equipmentForSafety) {
		constantMap.get().put("Safety Equipments", equipmentForSafety);
	}

	public static void setRiskApprover(String riskApprover) {
		constantMap.get().put("Risk Approver Name", riskApprover);
	}

	public static void setCameraOpsCount(String cameraOpsCount) {
		constantMap.get().put("Camera Ops Count", cameraOpsCount);
	}

	public static void setAudioOpsCount(String audioOpsCount) {
		constantMap.get().put("Audio Ops Count", audioOpsCount);
	}

	public static void setEstimatedCost(String estimatedCost) {
		constantMap.get().put("Estimated Cost", estimatedCost);
	}

	// To set allocation resource count
	public static void setAllocationCount(int allocation) {
		constantMap.get().put("Allocation", allocation);
	}

	// To set threshold percentage
	public static void setThresholdPercent(int threshold) {
		constantMap.get().put("Threshold", threshold);
	}

	// To set actual resource count
	public static void setShootDaysCount(int shootDaysCount) {
		constantMap.get().put("Shoot Days Count", shootDaysCount);
	}

	// To set number of shoot days
	public static void setResourceCount(int ResourcesCount) {
		constantMap.get().put("Resources Count", ResourcesCount);
	}

	// To set shoot start date
	public static void setShootStartDate(String shootStartDate) {
		constantMap.get().put("Shoot Start Date", shootStartDate);
	}

	// To set shoot end date
	public static void setShootEndDate(String shootEndDate) {
		constantMap.get().put("Shoot End Date", shootEndDate);
	}

	// To set shoot meet time
	public static void setShootMeetTime(String shootMeetTime) {
		constantMap.get().put("Shoot Meet Time", shootMeetTime);
	}

	// To set shoot start time
	public static void setShootStartTime(String shootStartTime) {
		constantMap.get().put("Shoot Start Time", shootStartTime);
	}

	// To set shoot end time
	public static void setShootEndTime(String shootEndTime) {
		constantMap.get().put("Shoot End Time", shootEndTime);
	}

	// To set crew resource role
	public static void setCrewResourceRole(int resourceNumber, String resourceRole) {
		constantMap.get().put("Resource Role_" + resourceNumber, resourceRole);
	}

	// To set crew resource name
	public static void setCrewResourceName(int resourceNumber, String resourceName) {
		constantMap.get().put("Resource Name_" + resourceNumber, resourceName);
	}

	// To set crew resource phone
	public static void setCrewResourcePhone(int resourceNumber, String resourcePhone) {
		constantMap.get().put("Resource Phone_" + resourceNumber, resourcePhone);
	}

	// To set crew resource email
	public static void setCrewResourceEmail(int resourceNumber, String resourceEmail) {
		constantMap.get().put("Resource Email_" + resourceNumber, resourceEmail);
	}

	// To set shoot end time
	public static void setShootTimeZone(String shootTimeZone) {
		constantMap.get().put("Shoot Time Zone", shootTimeZone);
	}

	// To set crew Assignment slug
	public static void setAssignmentSlug(String assignmentSlug) {
		constantMap.get().put("Assignment Slug", assignmentSlug);
	}

	public static void setPrimaryCameraType(String primaryCameraType) {
		constantMap.get().put("Primary Camera Type", primaryCameraType);
	}

	public static void setMediaFormat(String mediaFormat) {
		constantMap.get().put("Media Format", mediaFormat);
	}

	public static void setVideoSpecs(String videoSpecs) {
		constantMap.get().put("Video Specs", videoSpecs);
	}

	public static void setEmailToList(String emailToList) {
		constantMap.get().put("Email To List", emailToList);
	}

	public static void setEmailCcList(String emailCcList) {
		constantMap.get().put("Email CC List", emailCcList);
	}

	public static void setEmailSubject(String emailSubject) {
		constantMap.get().put("Email Subject", emailSubject);
	}

	public static void setEmailBody(String emailBody) {
		constantMap.get().put("Email Body", emailBody);
	}

	// To set requester notes count
	public static void setRequesterNotesCount(int count) {
		constantMap.get().put("Requester Notes Count", count);
	}

	// To set fulfiller notes count
	public static void setFulfillerNotesCount(int count) {
		constantMap.get().put("Fulfiller Notes Count", count);
	}

	// To set requester notes
	public static void setRequesterNotes(int notesNumber, String requesterNotes) {
		constantMap.get().put("Requester Notes_" + notesNumber, requesterNotes);
	}

	// To set fulfiller notes
	public static void setFulfillerNotes(int notesNumber, String fulfillerNotes) {
		constantMap.get().put("Fulfiller Notes_" + notesNumber, fulfillerNotes);
	}

	public static void setRequesterNotesTime(int notesNumber, String requesterNotesTime) {
		constantMap.get().put("Requester Notes Time_" + notesNumber, requesterNotesTime);
	}

	public static void setFulfillerNotesTime(int notesNumber, String fulfillerNotesTime) {
		constantMap.get().put("Fulfiller Notes Time_" + notesNumber, fulfillerNotesTime);
	}
	
	public static void setLogTime(String logTime) {
		constantMap.get().put("Log Time", logTime);
	}
}
