package nbcu.automation.ui.pages.crewrequest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.automation.ui.constants.crewrequest.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.Other.CommonUtils;

public class AdminDashboardPage {

	@FindBy(xpath = "//section[@class='body']//*[text()='Add']")
	WebElement addButton;

	@FindBy(xpath = "//*[@class='ant-tabs-nav-list']//*[text()='Shows']")
	WebElement showsMenuItem;

	@FindBy(xpath = "//*[text()=' Show Title ']//ancestor::table/parent::div/following::div[1]//td[1]//input")
	WebElement showUnitTextbox;

	@FindBy(xpath = "//*[text()=' Business ']//ancestor::table/parent::div/following::div[1]//td[2]//input")
	WebElement businessTextbox;

	@FindBy(xpath = "//*[text()=' Budget Code ']//ancestor::table/parent::div/following::div[1]//td[3]//input")
	WebElement budgetCodeTextbox;

	@FindBy(xpath = "//button[text()='Save ']")
	WebElement saveButton;

	@FindBy(xpath = "//input[@placeholder='Search']")
	WebElement searchTextbox;

	@FindBy(xpath = "//tbody/tr[2]/td[1]")
	WebElement firstShowTitleInTable;

	@FindBy(xpath = "//*[@class='ant-tabs-nav-list']//*[text()='Exec Dash']")
	WebElement execDashMenuItem;

	@FindBy(xpath = "//tr[2]//td[4]/button[text()=' Edit ']")
	WebElement execDashEditButton;
	
	@FindBy(xpath = "//tr[2]//td[4]/button[text()=' Delete ']")
	WebElement execDashDeleteButton;

	@FindBy(xpath = "//button//span[text()='OK']")
	WebElement areYouSureOKButton;
	
	@FindBy(xpath = "//nz-option-container//nz-option-item")
	List<WebElement> reminderList;
	
	@FindBy(xpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item | //nz-option-item ")
	List<WebElement> dropDownvalues;
	

	public AdminDashboardPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To fill show details to add a new Show
	 * 
	 * @param businessValue
	 * 
	 * @param budgetCodeValue
	 * 
	 * @throws Exception
	 */
	public void fillShowDetails(String businessValue, String budgetCodeValue) throws Exception {
		try {
            Constants.setShowUnit(CommonUtils.generateRandomString(10));
            Constants.setBusinessValue(businessValue+CommonUtils.generateRandomString(4));
            Constants.setBudgetCode(budgetCodeValue+CommonUtils.generateRandomString(4));
            
            
            //To click shows tab
			WebAction.click(showsMenuItem);

			//To click add show button
			Waits.waitForElement(addButton, WAIT_CONDITIONS.CLICKABLE);
			WebAction.click(addButton);

			Thread.sleep(1000);
			Waits.waitForElement(showUnitTextbox, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(showUnitTextbox, Constants.getShowUnit());

			Waits.waitForElement(businessTextbox, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(businessTextbox, Constants.getBusinessValue());

			Waits.waitForElement(budgetCodeTextbox, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(budgetCodeTextbox, Constants.getBudgetCode());

			Waits.waitForElement(saveButton, WAIT_CONDITIONS.CLICKABLE);
			WebAction.click(saveButton);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the show unit is present or not
	 * 
	 * @param showNameValue - show unit name
	 * @throws Exception 
	 */
	public void verifyShowIsPresent(String showNameValue) throws Exception {
		try {
			
			Waits.waitForElement(searchTextbox, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(searchTextbox, showNameValue);
			Thread.sleep(1000);
			WebAction.keyPress(searchTextbox, "ENTER");
			Waits.waitForElement(firstShowTitleInTable, WAIT_CONDITIONS.VISIBLE);
			Thread.sleep(1000);
			CommonValidations.verifyTextValue(firstShowTitleInTable, showNameValue, "Show is not present in admin tab");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * User deletes show unit
	 * 
	 * @param showNameValue
	 * @throws Exception
	 */
	public void deleteShowUnit(String showNameValue) throws Exception {
		try {
			Waits.waitForElement(searchTextbox, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(searchTextbox, showNameValue);
			searchTextbox.sendKeys(Keys.ENTER);
			WebAction.click(execDashDeleteButton);
			WebAction.click(areYouSureOKButton);
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To Fill details in executive dashboard
	 * 
	 * @param showUnitValue
	 * @param allocationValue
	 * @param thresholdValue
	 * @param recipients
	 * @throws Exception 
	 */
	public void fillExecDashDetailsInAdminDashboardPage(String showNameValue, String allocationValue,
			String thresholdValue, String remainderValue, String recipients) throws Exception {
		try {
			Constants.setAllocationCount(Integer.parseInt(allocationValue));
			Constants.setThresholdPercent(Integer.parseInt(thresholdValue));
			
			WebAction.click(execDashMenuItem);
			WebAction.sendKeys(searchTextbox, showNameValue);

			WebDriver driver = DriverFactory.getCurrentDriver();
			driver.findElement(
					By.xpath("//td[text()=' " + showNameValue + " ']//parent::tr//td[7]//button[text()=' Edit ']"))
					.click();

			driver.findElement(By.xpath("//td[text()=' " + showNameValue + " ']//parent::tr//td[3]//input"))
					.sendKeys(allocationValue);

			driver.findElement(By.xpath("//td[text()=' " + showNameValue + " ']//parent::tr//td[4]//input"))
					.sendKeys(thresholdValue); 

			WebElement reminder = driver.findElement(
					By.xpath("//td[text()=' " + showNameValue + " ']//parent::tr//td[5]//nz-select-arrow"));
			WebAction.click(reminder);

			switch (remainderValue) {
			case "10%":
				Waits.waitUntilElementSizeGreater(reminderList, 1);
				WebAction.click(reminderList.get(1));
				break;
			case "20%":
				Waits.waitUntilElementSizeGreater(reminderList, 2);
				WebAction.click(reminderList.get(2));
				break;
			case "30%":
				Waits.waitUntilElementSizeGreater(reminderList, 3);
				WebAction.click(reminderList.get(3));
				break;
			case "40%":
				Waits.waitUntilElementSizeGreater(reminderList, 4);
				WebAction.click(reminderList.get(4));
				break;
			case "50%":
				Waits.waitUntilElementSizeGreater(reminderList, 5);
				WebAction.click(reminderList.get(5));
				break;
			}
			String recipientsArray[] = recipients.split(",");
			for (int i = 0; i < recipientsArray.length; i++) {
				String name= recipientsArray[i];
				WebElement recipientsName = driver.findElement(By.xpath("//td[text()=' " + showNameValue + " ']//parent::tr//td[6]//input"));
				WebAction.sendKeys(recipientsName, name);
				Waits.waitUntilElementSizeGreater(dropDownvalues, 0);
				WebAction.click(dropDownvalues.get(0));
			}
			WebAction.click(saveButton);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
