
package nbcu.automation.ui.pages.crewrequest;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.crewrequest.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.automation.ui.validation.common.EmailValidation;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.Other.DateFunctions;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class CrewRequestFormPage {

	@FindBy(xpath = "//div[@class='title ng-star-inserted']/p[1]")
	WebElement formTitle;

	// Requester section

	@FindBy(xpath = "//div[contains(@data-component,'nbc-requester')]//p[@class='overflow-text']")
	List<WebElement> defaultRequesterNamesList;

	@FindBy(xpath = "//div[contains(@data-component,'nbc-requester')]//p[contains(@class,'subtext1')]")
	List<WebElement> defaultRequesterPhoneNumbersList;

	@FindBy(xpath = "//input[@placeholder='Add Requester(s) here...']")
	WebElement addRequestor;

	// Producer info Elements

	@FindBy(xpath = "//*[@forminputname='hasOnSiteProducer']//label[@label-value='true']")
	WebElement isOnsiteProducer_Yes;

	@FindBy(xpath = "//*[@forminputname='hasOnSiteProducer']//label[@label-value='false']")
	WebElement isOnsiteProducer_No;

	@FindBy(xpath = "//*[@formselectname='producerSameAsRequester']//*[@title='No']")
	WebElement producerSameAsRequestDropdown;

	@FindBy(xpath = "//*[@class='ant-select-item ant-select-item-option ng-star-inserted']/div")
	WebElement producerSameAsRequestDropdown_Yes;

	@FindBy(xpath = "//*[@formselectname='producerSameAsRequester']//input")
	List<WebElement> producerSameAsRequestInputBox;

	@FindBy(xpath = "//*[@forminputname='seniorApproved']//label[@label-value='true']")
	WebElement isApprovedSenior_Yes;

	@FindBy(xpath = "//*[@forminputname='seniorApproved']//label[@label-value='false']")
	WebElement isApprovedSenior_No;

	@FindBy(xpath = "//input[@placeholder='Add Approver here']")
	WebElement approverInputBox;

	// show info Elements

	@FindBy(xpath = "//input[@placeholder='Budget Code / Show Title' or @placeholder='Search Shows']")
	WebElement showTitle;

	@FindBy(xpath = "//*[@role='menuitem']/div")
	List<WebElement> SearchList;

	@FindBy(xpath = "//button[contains(@class,'addBtn')]")
	WebElement showTitleAddButton;

	@FindBy(xpath = "//div[contains(@data-component,'nbc-show')]//p[@class='overflow-text']")
	WebElement addedShowName;

	@FindBy(xpath = "//div[contains(@data-component,'nbc-show')]//p[contains(@class,'subtext1')]")
	WebElement addedBudgetCode;

	// Talent info Elements

	@FindBy(xpath = "//input[@placeholder='Search Talent']")
	WebElement searchTalent;

	@FindBy(xpath = "//div[contains(@data-component,'nbc-talent')]//p[@class='overflow-text']")
	WebElement addedTalentName;

	// Shoot details Elements

	@FindBy(xpath = "//span[text()='Shoot Details']")
	WebElement shootDetailsTitle;

	@FindBy(xpath = "//*[@placeholder='Production Type']//input")
	WebElement productionTypeDropDown;

	@FindBy(xpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item | //nz-option-item ")
	List<WebElement> dropDownvalues;

	String dropDownvaluesXpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item";

	@FindBy(xpath = "//span[contains(text(),'Tent')]")
	WebElement shootStatus_Tent;

	@FindBy(xpath = "//span[contains(text(),'Firm')]")
	WebElement shootStatus_Firm;

	@FindBy(xpath = "//*[@forminputname='editReqId']//input")
	WebElement editRequestId;

	@FindBy(xpath = "//*[@forminputname='assignmentSlug']//input")
	WebElement assignmentSlug;

	@FindBy(xpath = "//input[@placeholder='If Known or Existing']")
	WebElement ncxStoryName;

	@FindBy(xpath = "//*[@forminputname='shootDescription']//textarea")
	WebElement shootDescription;

	@FindBy(xpath = "//*[@forminputname='shootType']//*[contains(text(),'Tape')]")
	WebElement shootType_Tape;

	@FindBy(xpath = "//*[@forminputname='shootType']//*[contains(text(),'Live')]")
	WebElement shootType_Live;

	// Shoot specs Elements

	@FindBy(xpath = "//*[@forminputname='audioNeeds']//input")
	WebElement audioNeedsDropDown;

	@FindBy(xpath = "//*[@forminputname='specialConditions']//input")
	WebElement specialConditionsDropDown;

	@FindBy(xpath = "//*[@forminputname='transmissionType']//input")
	WebElement transmissionTypeDropDown;

	@FindBy(xpath = "//*[@forminputname='colorSpace']//label[@label-value='Log']")
	WebElement colorSpace_Log;

	@FindBy(xpath = "//*[@forminputname='colorSpace']//label[@label-value='Rec709']")
	WebElement colorSpace_Rec709;

	@FindBy(xpath = "//*[@forminputname='droneShoot']//label[@label-value='true']")
	WebElement droneShoot_Yes;

	@FindBy(xpath = "//*[@forminputname='droneShoot']//label[@label-value='false']")
	WebElement droneShoot_No;

	@FindBy(xpath = "//*[@forminputname='cam360']//label[@label-value='true']")
	WebElement camera360_Yes;

	@FindBy(xpath = "//*[@forminputname='cam360']//label[@label-value='false']")
	WebElement camera360_No;

	@FindBy(xpath = "//*[@forminputname='specialGear']//label[@label-value='true']")
	WebElement specialGear_Yes;

	@FindBy(xpath = "//*[@forminputname='specialGear']//label[@label-value='false']")
	WebElement specialGear_No;

	@FindBy(xpath = "//*[@forminputname='gearNotes']//textarea")
	WebElement specialGearNotes;

	@FindBy(xpath = "//*[@forminputname='iPadPrompter']//label[@label-value='true']")
	WebElement ipadPromotor_Yes;

	@FindBy(xpath = "//*[@forminputname='iPadPrompter']//label[@label-value='false']")
	WebElement ipadPromotor_No;

	// Location Elements
	@FindBy(xpath = "//*[@forminputname='addressLine1']//nz-select")
	WebElement selectLocationDropDown;

	@FindBy(xpath = "//input[@placeholder='Enter Apt, Suite or other notes']")
	WebElement addressNotes;

	@FindBy(xpath = "//*[@placeholder='Enter Address here']")
	WebElement addressLine1;

	@FindBy(xpath = "//*[@forminputname='city']//input")
	WebElement city;

	@FindBy(xpath = "//*[@forminputname='state']//input")
	WebElement stateDropDown;

	@FindBy(xpath = "//*[@forminputname='zip']//input")
	WebElement zipCode;

	@FindBy(xpath = "//*[@forminputname='country']//input")
	WebElement countryDropDown;

	// Date and time Elements

	@FindBy(xpath = "//*[@forminputname='shootDates']//input")
	List<WebElement> dates;

	@FindBy(xpath = "//*[@forminputname='numberOfDays']//input")
	WebElement daysInShoot;

	@FindBy(xpath = "//*[@placeholder='Select Time Zone']//input")
	WebElement timeZone;

	@FindBy(xpath = "//*[@forminputname='meetTime']//input")
	WebElement meetTime;

	@FindBy(xpath = "//*[@forminputname='rollTime']//input")
	WebElement startTime;

	@FindBy(xpath = "//*[@forminputname='endTime']//input")
	WebElement endTime;

	@FindBy(xpath = "//*[@forminputname='resourcesCamera']//input")
	WebElement cameraResource;

	@FindBy(xpath = "//*[@forminputname='resourcesAudio']//input")
	WebElement AudioResource;

	@FindBy(xpath = "//p[text()='Estimated Costs:']/following-sibling::p[1]")
	WebElement estimatedCost;

	// Submit button
	@FindBy(xpath = "//button[span[contains(text(),'Submit')]]")
	WebElement submitButton;

	// Save button
	@FindBy(xpath = "//button[span[contains(text(),'Save')]]")
	WebElement saveButton;

	// Publish button
	@FindBy(xpath = "//button[span[contains(text(),'Publish')]]")
	WebElement publishButton;

	// Cancel Request button
	@FindBy(xpath = "//button[span[contains(text(),'Cancel Request')]]")
	WebElement cancelRequestButton;

	// Confirm Cancellation button
	@FindBy(xpath = "//button[span[contains(text(),'Confirm Cancellation')]]")
	WebElement confirmCancellationButton;

	// Publish button
	@FindBy(xpath = "//button[span[contains(text(),'Send To Storm')]]")
	WebElement sendToStormButton;

	// Back button
	@FindBy(xpath = "//button[span[contains(text(),'Back')]]")
	WebElement backButton;
	
	@FindBy(xpath = "//button[span[text()='iNews Info']]")
	WebElement iNewsInfoButton;
	
	@FindBy(xpath = "//button[span[text()='Title']]")
	WebElement titleButton;
	
	@FindBy(xpath = "//button[span[text()='Copy']]")
	WebElement copyButton;

	// Submitted popup
	@FindBy(xpath = "//*[text()='Request Submitted']")
	WebElement submissionSuccessMessage;

	@FindBy(xpath = "//*[contains(text(),'Crew Request was updated successfully')]")
	WebElement updateSuccessMessage;

	@FindBy(xpath = "//*[contains(text(),'Published')]")
	WebElement publishSuccessMessage;

	@FindBy(xpath = "//*[contains(text(),'Cancellation Confirmed')]/following-sibling::div[1]")
	WebElement cancelSuccessMessage;

	@FindBy(xpath = "//span[i[*[@data-icon='close']]]")
	WebElement closeMessagePopup;

	// status change
	@FindBy(xpath = "//*[@label-value='Efforting']")
	WebElement effortingStatus;

	@FindBy(xpath = "//*[@label-value='ROFR']")
	WebElement rofrStatus;

	@FindBy(xpath = "//*[@label-value='Booked']")
	WebElement bookedStatus;

	// fulfiller shoot specs
	@FindBy(xpath = "//*[@forminputname='primaryCameraType']//nz-select")
	WebElement primaryCameraType;

	@FindBy(xpath = "//*[@forminputname='mediaFormat']//nz-select")
	WebElement mediaFormat;

	@FindBy(xpath = "//*[@forminputname='videoSpecs']//nz-select")
	WebElement videoSpecs;

	// Cancellation popup Elements
	@FindBy(xpath = "//*[contains(text(),'cancellation')]")
	WebElement cancellationAlertMessage;

	@FindBy(xpath = "//*[contains(text(),'Are you sure to want to send this assingment to STORM')]")
	WebElement sendToStormAlertMessage;

	@FindBy(xpath = "//button[span[text()='Yes']]")
	WebElement cancel_Yes;

	@FindBy(xpath = "//button[span[text()='No']]")
	WebElement cancel_No;

	@FindBy(xpath = "//button[span[text()='OK']]")
	WebElement sendToStorm_Ok;

	@FindBy(xpath = "//button[span[text()='CANCEL']]")
	WebElement sendToStorm_Cancel;

	// DJ shoot other section elements
	@FindBy(xpath = "//*[@forminputname='comments']//textarea")
	WebElement commentTextArea;

	// Risk assessment section Elements
	@FindBy(xpath = "//span[@class='ant-radio-button']/following::span[text()='Standard ']")
	WebElement standardOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='Filming on Roads']")
	WebElement filmingOnRoadsOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='HMI Lighting']")
	WebElement hmiLightingOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='Live Positions']")
	WebElement livePositionsOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='Long Working']")
	WebElement longWorkingOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='Structure & Access Equipment']")
	WebElement structureAccessEquipmentOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='Working Heights']")
	WebElement workingHeightsOption;

	@FindBy(xpath = "//span[@class='ant-radio-button']/following::span[text()='High ']")
	WebElement highOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='Aircraft']")
	WebElement aircraftOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='Emergencies & Disasters']")
	WebElement emergenciesDisastersOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='Filming on or Near Water']")
	WebElement filmingOnOrNearWaterOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='Riots & Civil Disturbances']")
	WebElement riotsCivilDisturbancesOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='Storm & Extreme Weather']")
	WebElement stormExtremeWeatherOption;

	@FindBy(xpath = "//*[text()=' Confirm which risk assessments apply: ']/ancestor::nz-form-item//span[text()='War Zones']")
	WebElement warZoneOption;

	@FindBy(xpath = "//form//*[text()='Risk Assessment']")
	WebElement riskAssessmentArea;

	@FindBy(xpath = "//textarea[@placeholder='Enter risk arrangements here']")
	WebElement riskArrangementsTextarea;

	@FindBy(xpath = "//input[@placeholder='Search Approver here...']")
	WebElement riskApproverInputBox;

	@FindBy(xpath = "//nz-auto-option[@role='menuitem']/div")
	List<WebElement> riskApproverMenuitem;

	@FindBy(xpath = "//*[@title='Add Resources']//input[@placeholder='Search Resources']")
	WebElement searchResourcesTextbox;

	String crewResourceEmailXpath = "//div[p[text()='<<Resource Name>>']]/ul//i[@nztype='mail']/following-sibling::span";

	String crewResourcePhoneXpath = "//div[p[text()='<<Resource Name>>']]/ul//i[@nztype='phone']/following-sibling::span";

	String crewResourceRoleXpath = "//div[p[text()='<<Resource Name>>']]/following-sibling::div[1]//form-select[@forminputname='role']";

	@FindBy(xpath = "//*[@class='title'][text()='Resource']//preceding-sibling::span | //*[@class='title'][text()='Resources']//preceding-sibling::span")
	WebElement resourcesCountLabel;

	@FindBy(xpath = "//*[text()=' # of Days In Shoot ']//ancestor::nz-form-item//nz-form-control//input")
	WebElement dayShootCountLabel;

	// Missing fields Elements
	@FindBy(xpath = "//*[text()='Missing Values']")
	WebElement missingFieldsPopup;

	@FindBy(xpath = "//*[@forminputname='hasOnSiteProducer']//div[contains(@class,'error')]")
	WebElement isThereOnsiteProducerError;

	@FindBy(xpath = "//*[@formselectname='producerSameAsRequester']//div[contains(@class,'error')]")
	WebElement producerSameAsRequestorError;

	@FindBy(xpath = "//input[@placeholder='Add Approver here']/../../../..//div[contains(@class,'error')]")
	WebElement seniorApproverError;

	@FindBy(xpath = "//input[@placeholder='Budget Code / Show Title' or @placeholder='Search Shows']/../../../..//div[contains(@class,'error')]")
	WebElement showUnitError;

	@FindBy(xpath = "//input[@placeholder='Budget Code']/../../../..//div[contains(@class,'error')]")
	WebElement budgetCodeError;

	@FindBy(xpath = "//input[@placeholder='Search Talent']/../../../..//div[contains(@class,'error')]")
	WebElement searchTalentError;

	@FindBy(xpath = "//*[@placeholder='Production Type']//div[contains(@class,'error')]")
	WebElement productionTypeError;

	@FindBy(xpath = "//*[@forminputname='primaryCameraType']//div[contains(@class,'error')]")
	WebElement primaryCameraTypeError;

	@FindBy(xpath = "//*[@forminputname='assignmentSlug']//div[contains(@class,'error')]")
	WebElement assignmentSlugError;

	@FindBy(xpath = "//*[@forminputname='shootDescription']//div[contains(@class,'error')]")
	WebElement shootDescriptionError;

	@FindBy(xpath = "//*[@forminputname='audioNeeds']//div[contains(@class,'error')]")
	WebElement audioNeedsError;

	@FindBy(xpath = "//*[@forminputname='specialConditions']//div[contains(@class,'error')]")
	WebElement specialConditionsError;

	@FindBy(xpath = "//*[@forminputname='transmissionType']//div[contains(@class,'error')]")
	WebElement transmissionTypeError;

	@FindBy(xpath = "//*[@forminputname='droneShoot']//div[contains(@class,'error')]")
	WebElement droneShootError;

	@FindBy(xpath = "//*[@forminputname='cam360']//div[contains(@class,'error')]")
	WebElement camera360Error;

	@FindBy(xpath = "//*[@forminputname='addressLine1']//div[contains(@class,'error')]")
	WebElement addressLine1Error;

	@FindBy(xpath = "//*[@forminputname='city']//div[contains(@class,'error')]")
	WebElement cityError;

	@FindBy(xpath = "//*[@forminputname='state']//div[contains(@class,'error')]")
	WebElement stateError;

	@FindBy(xpath = "//*[@forminputname='country']//div[contains(@class,'error')]")
	WebElement countryError;

	@FindBy(xpath = "//*[@forminputname='shootDates']//div[contains(@class,'error')]")
	WebElement shootDateError;

	@FindBy(xpath = "//*[@forminputname='timeZone']//div[contains(@class,'error')]")
	WebElement timeZoneError;

	@FindBy(xpath = "//*[@forminputname='meetTime']//div[contains(@class,'error')]")
	WebElement meetTimeError;

	@FindBy(xpath = "//*[@forminputname='rollTime']//div[contains(@class,'error')]")
	WebElement startTimeError;

	@FindBy(xpath = "//*[@forminputname='endTime']//div[contains(@class,'error')]")
	WebElement endTimeError;

	// section wise error
	String sectionIcon = "//*[@data-step='<<SectionName>>']/div/div[@class='ant-steps-item-icon']/span/i";

	// Send to storm
	@FindBy(xpath = "//strong[@class='success']")
	WebElement sendToStormSuccessMessageHeader;

	@FindBy(xpath = "//strong[@class='warning']")
	WebElement sendToStormFailureMessageHeader;

	@FindBy(xpath = "//p[contains(text(),'sent to STORM')]")
	WebElement sendToStormSuccessMessage;

	@FindBy(xpath = "//p[contains(text(),'sent to STORM')]/following-sibling::p/span[@class='warning']")
	List<WebElement> sendToStormLogMessages;

	@FindBy(xpath = "//p[contains(text(),'Budget Code does not exist')]")
	WebElement sendToStormFailureMessage;

	@FindBy(xpath = "//button[span[contains(text(),'Close')]]")
	WebElement closeSendToStormLogButton;

	// Tabs link
	@FindBy(xpath = "//div[text()='Notes']")
	WebElement notesTab;

	@FindBy(xpath = "//div[text()='Log']")
	WebElement logTab;
	
	//iNews Info drawer
	@FindBy(xpath = "//dt[text()='Production Type:']/following-sibling::dd[1]")
	WebElement productionTypeElement;
	
	@FindBy(xpath = "//dt[text()='CR #:']/following-sibling::dd[1]")
	WebElement crewRequestNumberElement;
	
	@FindBy(xpath = "//dt[text()='Show Unit:']/following-sibling::dd[1]")
	WebElement showUnitElement;
	
	@FindBy(xpath = "//dt[text()='Slug:']/following-sibling::dd[1]")
	WebElement slugElement;
	
	@FindBy(xpath = "//dt[text()='Time Zone:']/following-sibling::dd[1]")
	WebElement timeZoneElement;
	
	@FindBy(xpath = "//dt[text()='Meet Time:']/following-sibling::dd[1]")
	WebElement meetTimeElement;
	
	@FindBy(xpath = "//dt[text()='Contact:']/following-sibling::dd[1]")
	WebElement contactElement;
	
	@FindBy(xpath = "//dt[text()='Address:']/following-sibling::dd[1]")
	WebElement address;
	
	@FindBy(xpath = "//dt[text()='City:']/following-sibling::dd[1]")
	WebElement cityElement;
	
	@FindBy(xpath = "//dt[text()='State:']/following-sibling::dd[1]")
	WebElement stateElement;
	

	public CrewRequestFormPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify General Crew Request form page loaded
	 * 
	 * @param formName - Crew request form name
	 * @throws Exception
	 */
	public void verifyGeneralCrewRequestPageDisplayed(String formName) throws Exception {
		Waits.waitForElement(addRequestor, WAIT_CONDITIONS.CLICKABLE);
		switch (formName.toUpperCase()) {
		case "NBC NEWS CREW REQUEST":
			CommonValidations.verifyTextValue(formTitle, "NBC News Crew", "NBC News Crew form is not opened");
			break;
		case "CNBC CREW REQUEST":
			CommonValidations.verifyTextValue(formTitle, "CNBC Crew", "CNBC Crew form is not opened");
			break;
		case "TELEMUNDO NEWS CREW REQUEST":
			CommonValidations.verifyTextValue(formTitle, "Telemundo Crew", "Telemundo Crew form is not opened");
			break;
		case "DJ SHOOT CREW REQUEST":
			CommonValidations.verifyTextValue(formTitle, "Digital Journalist/DJ Shoot Crew",
					"Digital Journalist/DJ Shoot Crew form is not opened");
			break;
		case "NBC BREAKING NEWS CREW REQUEST":
			CommonValidations.verifyTextValue(formTitle, "Breaking News Crew", "Breaking News Crew form is not opened");
			break;
		case "NBC BUREAU CAMERA CREW REQUEST":
			CommonValidations.verifyTextValue(formTitle, "Bureau Camera Crew", "Bureau Camera Crew form is not opened");
			break;
		}
	}

	/**
	 * To fill additional requester section
	 * 
	 * @throws Exception
	 */
	public void addAdditionalRequestor(String additionalRequestor) throws Exception {
		try {

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill producer info section
	 * 
	 * @param producerSameasRequestor - Answer for 'Is there an on-site Producer?'
	 *                                question
	 * @param producerName            - provide producer name if answer for Is there
	 *                                an on-site Producer? question is selected as
	 *                                No
	 * @param isThereOnSiteProducer   - Answer for ' Has this been approved by your
	 *                                Senior?' question
	 * @param isApprovedByYourSenior  - Answer for ' Has this been approved by your
	 *                                Senior? ' question
	 * @param seniorApprover          - senior approver name
	 * @throws Exception
	 */
	public void fillProducerInfoSection(String producerSameasRequestor, String producerName,
			String isThereOnSiteProducer, String isApprovedByYourSenior, String seniorApprover) throws Exception {
		try {

			// To select 'Producer / Field Contact Same as Requester? ' value
			if (producerSameasRequestor.equalsIgnoreCase("YES")) {
				WebAction.click(producerSameAsRequestDropdown);
				WebAction.click(producerSameAsRequestDropdown_Yes);
			} else {
				WebAction.sendKeys(producerSameAsRequestInputBox.get(1), producerName);
				Waits.waitUntilElementSizeGreater(SearchList, 0);
				WebAction.click(SearchList.get(0));
			}

			// To fetch producer name and phone number and store in constants Map
			String producerDetails = WebAction.getAttribute(producerSameAsRequestInputBox.get(1), "value");
			String producerPhoneNumber = "";
			if (producerDetails.contains("(")) {
				String[] producerArray = producerDetails.split("(");
				producerName = producerArray[0].trim();
				producerPhoneNumber = producerArray[1].substring(0, producerArray[0].length() - 1).trim();
			} else {
				producerName = producerDetails.trim();
			}
			Constants.setProducerName(producerName);
			Constants.setProducerPhoneNumber(producerPhoneNumber);

			// To select 'Is there an on-site Producer?' value
			Constants.setIsOnsiteProducer(isThereOnSiteProducer);
			if (isThereOnSiteProducer.equalsIgnoreCase("YES")) {
				WebAction.click(isOnsiteProducer_Yes);

				// To select ' Has this been approved by your Senior? ' value
				if (isApprovedByYourSenior.equalsIgnoreCase("YES"))
					WebAction.click(isApprovedSenior_Yes);
				else
					WebAction.click(isApprovedSenior_No);

			} else {
				WebAction.click(isOnsiteProducer_No);
			}

			// To enter senior approver name
			WebAction.sendKeys(approverInputBox, seniorApprover);
			Waits.waitUntilElementSizeGreater(SearchList, 0);
			Thread.sleep(2000);
			WebAction.click(SearchList.get(0));
			Thread.sleep(1000);
			Constants.setSeniorProducerName(WebAction.getAttribute(approverInputBox, "value"));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill show info section
	 * 
	 * @param budgetCode - budget code of the show
	 * @throws Exception
	 */
	public void fillShowInfoSection(String showTitleText) throws Exception {
		try {
			// To fetch default requester name and phone number
			String defaultRequestorName = WebAction.getText(defaultRequesterNamesList.get(0));
			String defaultRequestorPhoneNumber = WebAction.getText(defaultRequesterPhoneNumbersList.get(0));

			// To set values in Constants Map
			Constants.setDefaultRequesterName(defaultRequestorName);
			Constants.setDefaultRequesterPhoneNumber(defaultRequestorPhoneNumber);

			// To select show unit
			Constants.setShowUnit(showTitleText);
			Waits.waitForElement(showTitle, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(showTitle, showTitleText);
			Waits.waitUntilElementSizeGreater(SearchList, 0);
			WebAction.click(SearchList.get(0));

			// To set values in Constants Map
			Constants.setShowUnit(WebAction.getText(addedShowName));
			Constants.setBudgetCode(WebAction.getText(addedBudgetCode));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill talent name
	 * 
	 * @param talentname - talent name
	 * @throws Exception
	 */
	public void fillTalenSection(String talentname) throws Exception {
		try {
			Waits.waitForElement(searchTalent, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(searchTalent, talentname);
			Waits.waitUntilElementSizeGreater(SearchList, 0);
			WebAction.click(SearchList.get(0));

			// To set values in Constants Map
			Constants.setTalent(WebAction.getText(addedTalentName));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill shoot details in WHAT section
	 * 
	 * @param productionTypeValue - Production Type
	 * @param shootStatus         - Shoot Status. Firm or Tent
	 * @param shootType           - Shoot Type. Tape or Live
	 * @param attachEditRequestId - edit request id. it is optional field
	 * @param assignmentSlugValue - Assignment slug
	 * @param ncxStoryNameValue   - ncx story name. it is optional fields
	 * @param shootDescValue      - shoot description
	 * @throws Exception
	 */
	public void fillShootDetails(String productionTypeValue, String shootStatus, String shootType,
			String attachEditRequestId, String assignmentSlugValue, String ncxStoryNameValue, String shootDescValue)
			throws Exception {
		try {
			WebAction.scrollIntoView(shootDetailsTitle);

			// To select Production type
			if (productionTypeValue != null) {
				Constants.setProductionType(productionTypeValue);
				boolean valuePresent = false;
				Thread.sleep(1000);
				WebAction.clickUsingJs(productionTypeDropDown);
				WebAction.sendKeys(productionTypeDropDown, productionTypeValue);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(productionTypeValue)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception(
							"'" + productionTypeValue + "' value is not present in the production type drop down");
			}

			// To Select shoot status
			if (shootStatus != null) {
				Constants.setShootStatus(shootStatus);
				if (shootStatus.equalsIgnoreCase("FIRM"))
					WebAction.click(shootStatus_Firm);
				else
					WebAction.click(shootStatus_Tent);
			}

			// To Select shoot type
			if (shootType != null) {
				Constants.setShootType(shootType);
				if (shootType.equalsIgnoreCase("Tape"))
					WebAction.click(shootType_Tape);
				else
					WebAction.click(shootType_Live);
			}

			// To enter Edit Request Id. It is optional field
			if (attachEditRequestId != null)
				WebAction.sendKeys(editRequestId, attachEditRequestId);

			// To enter assignment slug
			Constants.setAssignmentSlug(assignmentSlugValue);
			WebAction.sendKeys(assignmentSlug, assignmentSlugValue);
			Constants.setAssignmentSlug(assignmentSlugValue);

			// To select ncx story
			if (ncxStoryNameValue != null) {
				WebAction.sendKeys(ncxStoryName, ncxStoryNameValue);
				Waits.waitUntilElementSizeGreater(SearchList, 0);
				WebAction.click(SearchList.get(0));
			}

			// To enter shoot description
			Constants.setShootDescription(shootDescValue);
			WebAction.click(shootDescription);
			WebAction.sendKeys(shootDescription, shootDescValue);

			Thread.sleep(2000);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill shoot specs in WHAT section
	 * 
	 * @param audioNeedsValue        - audio needs drop down
	 * @param specialConditionsValue - special condition drop down
	 * @param transmissionTypeValue  - transmission type drop down
	 * @param droneShootvalue        - Is this a Drone Shoot?
	 * @param camera360Value         - Are you using a 360 Cam?
	 * @param specialGearValue       - Special Gear
	 * @throws Exception
	 */
	public void fillShootSpecs(String audioNeedsValue, String specialConditionsValue, String transmissionTypeValue,
			String primaryCameraTypeValue, String colorSpaceValue, String droneShootvalue, String camera360Value,
			String ipadPromotorValue, String specialGearValue, String specialGearNotesValue) throws Exception {
		try {
			WebAction.scrollIntoView(transmissionTypeDropDown);

			// To select audio needs
			if (audioNeedsValue != null) {
				Constants.setAudioNeeds(audioNeedsValue);
				boolean valuePresent = false;
				WebAction.click(audioNeedsDropDown);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(audioNeedsValue)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}

				if (valuePresent == false)
					throw new Exception("'" + audioNeedsValue + "' value is not present in the audio needs drop down");
			}

			// To select special conditions
			if (specialConditionsValue != null) {
				Constants.setSpecialCondition(specialConditionsValue);
				boolean valuePresent = false;
				WebAction.click(specialConditionsDropDown);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(specialConditionsValue)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception("'" + specialConditionsValue
							+ "' value is not present in the special conditions drop down");
			}

			// To select transmission type
			if (transmissionTypeValue != null) {
				Constants.setTransmissionType(transmissionTypeValue);
				boolean valuePresent = false;
				WebAction.click(transmissionTypeDropDown);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				Thread.sleep(2000);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(transmissionTypeValue)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception(
							"'" + transmissionTypeValue + "' value is not present in the transmission type drop down");
			}

			// To select primary camera type
			if (primaryCameraTypeValue != null) {
				Constants.setPrimaryCameraType(primaryCameraTypeValue);
				boolean valuePresent = false;
				WebAction.click(primaryCameraType);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(primaryCameraTypeValue)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}

				if (valuePresent == false)
					throw new Exception("'" + primaryCameraTypeValue
							+ "' value is not present in the primary camera type drop down");
			}

			// To select color space value
			if (colorSpaceValue != null) {
				Constants.setColorSpace(colorSpaceValue);
				if (colorSpaceValue.equalsIgnoreCase("LOG"))
					WebAction.click(colorSpace_Log);
				else
					WebAction.click(colorSpace_Rec709);
			}

			// To select drone shoot value
			if (droneShootvalue != null) {
				Constants.setIsDroneNeeded(droneShootvalue);
				if (droneShootvalue.equalsIgnoreCase("YES"))
					WebAction.click(droneShoot_Yes);
				else
					WebAction.click(droneShoot_No);
			}

			// To select 360 cam value
			if (camera360Value != null) {
				Constants.setIs360CamNeeded(camera360Value);
				if (camera360Value.equalsIgnoreCase("YES"))
					WebAction.click(camera360_Yes);
				else
					WebAction.click(camera360_No);
			}

			// To select ipad promotor
			if (ipadPromotorValue != null) {
				Constants.setIpadPrompter(ipadPromotorValue);
				if (ipadPromotorValue.equalsIgnoreCase("YES"))
					WebAction.click(ipadPromotor_Yes);
				else
					WebAction.click(ipadPromotor_No);
			}

			// To select special gear value. It is optional field
			if (specialGearValue != null) {
				Constants.setSpecialGear(specialGearValue);
				if (specialGearValue.equalsIgnoreCase("YES")) {
					WebAction.click(specialGear_Yes);
					WebAction.click(specialGearNotes);
					WebAction.sendKeys(specialGearNotes, specialGearNotesValue);
				} else
					WebAction.click(specialGear_No);
			}

			Thread.sleep(2000);

			// To store camera ops and audio ops count in Constants map
			if (WebAction.isDisplayed(cameraResource)) {
				Constants.setCameraOpsCount(WebAction.getAttribute(cameraResource, "value"));
				Constants.setAudioOpsCount(WebAction.getAttribute(AudioResource, "value"));
			}

			// Estimated cost wont be displayed for DJ shoot and Bureau Camera
			if (WebAction.isDisplayed(estimatedCost))
				Constants.setEstimatedCost(WebAction.getText(estimatedCost));
			else
				Constants.setEstimatedCost("");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill location in WHERE section
	 * 
	 * @param location          - Location
	 * @param addressNotesvalue - address notes
	 * @throws Exception
	 */
	public void fillLocation(String location, String addressLine1Value, String addressNotesvalue, String cityValue,
			String stateValue, String zipCodevalue, String countryValue, String riskAssessmentCategoryValue,
			String riskAssessmentTypeValue, String riskArrangementsValue, String riskApproverValue) throws Exception {
		try {

			WebAction.scrollIntoView(addressLine1);

			// To select location
			if (location != null) {
				Constants.setBureauLocation(location);
				boolean valuePresent = false;
				WebAction.click(selectLocationDropDown);

				// WebAction.sendKeys(selectLocationDropDown, location);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(location)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception("'" + location + "' value is not present in the location drop down");
			}

			// To enter address line 1
			if (addressLine1Value != null) {
				WebAction.sendKeys(addressLine1, addressLine1Value);
			}

			// To fill address notes. It is optional field
			if (addressNotesvalue != null)
				WebAction.sendKeys(addressNotes, addressNotesvalue);

			// To enter city
			if (cityValue != null) {
				WebAction.sendKeys(city, cityValue);
			}

			// To select state
			if (stateValue != null) {
				WebAction.click(stateDropDown);
				boolean valuePresent = false;
				WebAction.sendKeys(stateDropDown, stateValue);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(stateValue)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}

				if (valuePresent == false)
					throw new Exception("'" + location + "' value is not present in the location drop down");
			}

			// To enter zip code
			if (zipCodevalue != null) {
				WebAction.sendKeys(zipCode, zipCodevalue);
			}

			// To select country
			if (countryValue != null) {
				List<WebElement> countryDropdownTitleList = countryDropDown
						.findElements(By.xpath("../following-sibling::nz-select-item"));
				if (countryDropdownTitleList.size() == 0) {
					WebAction.click(countryDropDown);
					boolean valuePresent = false;
					WebAction.sendKeys(countryDropDown, countryValue);
					Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
					for (WebElement ele : dropDownvalues) {
						if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(countryValue)) {
							WebAction.scrollIntoView(ele);
							WebAction.click(ele);
							valuePresent = true;
							break;
						}
					}
					if (valuePresent == false)
						throw new Exception("'" + countryValue + "' value is not present in the country drop down");
				}
			}

			// To set location values in Constants Map
			Constants.setAddressLine1(WebAction.getAttribute(addressLine1, "value"));
			Constants.setCity(WebAction.getAttribute(city, "value"));
			Constants.setState(
					WebAction.getAttribute(stateDropDown.findElement(By.xpath("../../nz-select-item")), "title"));
			Constants.setZipCode(WebAction.getAttribute(zipCode, "value"));
			Constants.setCountry(
					WebAction.getAttribute(countryDropDown.findElement(By.xpath("../../nz-select-item")), "title"));

			// To select Risk Assessment category
			if (riskAssessmentCategoryValue != null) {
				WebAction.scrollIntoView(riskAssessmentArea);
				Constants.setRiskCategory(riskAssessmentCategoryValue);
				Constants.setRiskAssessment(riskAssessmentTypeValue);
				if (riskAssessmentCategoryValue.trim().equals("Standard")) {
					WebAction.click(standardOption);
					switch (riskAssessmentTypeValue.toUpperCase()) {
					case "FILMING ON ROADS":
						WebAction.click(filmingOnRoadsOption);
						break;

					case "HMI LIGHTING":
						WebAction.click(hmiLightingOption);
						break;

					case "LIVE POSITIONS":
						WebAction.click(livePositionsOption);
						break;

					case "LONG WORKING":
						WebAction.click(longWorkingOption);
						break;

					case "STRUCTURE & ACCESS EQUIPMENT":
						WebAction.click(structureAccessEquipmentOption);
						break;

					case "WORKING HEIGHTS":
						WebAction.click(workingHeightsOption);
						break;
					}
				} else if (riskAssessmentCategoryValue.trim().equals("High")) {
					WebAction.click(highOption);

					switch (riskAssessmentTypeValue.toUpperCase()) {
					case "AIRCRAFT":
						WebAction.click(aircraftOption);
						break;

					case "EMERGENCIES & DISASTERS":
						WebAction.click(emergenciesDisastersOption);
						break;

					case "FILMING ON OR NEAR WATER":
						WebAction.click(filmingOnOrNearWaterOption);
						break;

					case "RIOTS & CIVIL DISTURBANCES":
						WebAction.click(riotsCivilDisturbancesOption);
						break;

					case "STORM & EXTREME WEATHER":
						WebAction.click(stormExtremeWeatherOption);
						break;

					case "WAR ZONES":
						WebAction.click(warZoneOption);
						break;
					}
				}
			}

			// To enter Risk Arrangements
			if (riskArrangementsValue != null) {
				Constants.setEquipmentsForSafety(riskArrangementsValue);
				WebAction.sendKeys(riskArrangementsTextarea, riskArrangementsValue);
			}

			// To select Risk Approver
			if (riskApproverValue != null) {
				WebAction.click(riskApproverInputBox);
				WebAction.sendKeys(riskApproverInputBox, riskApproverValue);
				Waits.waitUntilElementSizeGreater(riskApproverMenuitem, 0);
				WebAction.click(riskApproverMenuitem.get(0));
			}

			// To set location values in Constants Map

			Constants.setRiskApprover(riskApproverValue);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To generate date based on input. Date should like CurrebDate+1,
	 * CurrentDate-2, etc.,
	 * 
	 * @param date   - date
	 * @param format - date format
	 * @throws Exception
	 */
	public String generateDate(String date, String format) throws Exception {
		String updateddate = "";
		try {
			if (date.trim() != null) {
				if (date.toUpperCase().contains("CURRENTDATE")) {
					String days = date.replaceAll("[a-zA-Z]", "").trim();
					if (days.length() == 0) {
						days = "0";
					}
					updateddate = DateFunctions.addOrMinusDateFromCurrentDate(format, days);
				} else
					throw new Exception("Please provide date in valid format");
			} else
				throw new Exception("Date is empty");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return updateddate;
	}

	/**
	 * To generate time based on input. Time should like CurrentTime+1,
	 * CurrentTime-2, etc.,
	 * 
	 * @param time   - time
	 * @param format - time format
	 * @return
	 * @throws Exception
	 */
	public String generateTime(String time, String format) throws Exception {
		String updatedTime = "";
		try {
			if (time.trim() != null) {
				if (time.toUpperCase().contains("CURRENTTIME")) {
					String hours = time.replaceAll("[a-zA-Z]", "").trim();
					if (hours.length() == 0) {
						hours = "0";
					}
					updatedTime = DateFunctions.addOrMinusTimeFromCurrentTime(format, hours);
				} else
					updatedTime = time;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return updatedTime;
	}

	public int daysBetween(Date d1, Date d2) {
		return (int) ((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
	}

	/**
	 * 
	 * @param location
	 * @param addressNotesvalue
	 * @throws Exception
	 */
	public void fillDateAndTime(String StartDate, String endDate, String timeZoneValue, String meetTimeValue,
			String startTimeValue, String endTimeValue) throws Exception {
		try {
			WebAction.scrollIntoView(timeZone);

			// To fill Start Date
			if (StartDate != null) {
				WebAction.click(dates.get(0));
				String shootStartDate = generateDate(StartDate, "MM-dd-yyyy");
				WebAction.sendKeys(dates.get(0), shootStartDate);
				Constants.setShootStartDate(shootStartDate);
			}

			// To fill end Date
			if (endDate != null) {
				WebAction.click(dates.get(1));
				String shootEndDate = generateDate(endDate, "MM-dd-yyyy");
				WebAction.sendKeys(dates.get(1), shootEndDate);
				WebAction.scrollIntoView(assignmentSlug);
				WebAction.click(assignmentSlug);
				Constants.setShootEndDate(shootEndDate);
			}

			// To fetch # of days in shoot
			String numberDaysinShoot = "1";
			if (WebAction.isDisplayed(daysInShoot)) {
				numberDaysinShoot = WebAction.getAttribute(daysInShoot, "value");
				System.out.println("Shoot days:" + numberDaysinShoot);
				Constants.setShootDaysCount(Integer.parseInt(numberDaysinShoot));
			}

			// To fill time zone
			WebAction.scrollIntoView(timeZone);
			boolean valuePresent = false;
			WebAction.click(timeZone);
			WebAction.sendKeys(timeZone, timeZoneValue);
			Constants.setShootTimeZone(timeZoneValue);
			Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
			for (WebElement ele : dropDownvalues) {
				if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(timeZoneValue)) {
					WebAction.click(ele);
					valuePresent = true;
					break;
				}
			}
			if (valuePresent == false)
				throw new Exception("'" + timeZoneValue + "' value is not present in the time zone drop down");

			// To fill meet time
			if (meetTimeValue != null) {
				Constants.setShootMeetTime(generateTime(meetTimeValue, "hh:mm a"));
				WebAction.sendKeys(meetTime, generateTime(meetTimeValue, "hh:mm a"));
			}

			// To fill start time
			if (startTimeValue != null) {
				Constants.setShootStartTime(generateTime(startTimeValue, "hh:mm a"));
				WebAction.click(startTime);
				WebAction.sendKeys(startTime, generateTime(startTimeValue, "hh:mm a"));
			}

			// To fill end time
			if (endTimeValue != null) {
				// To set roll and start time for NBC breaking new
				if ((meetTimeValue==null) && (startTimeValue == null)) {
					meetTimeValue = DateFunctions.convertDateStringToAnotherFormat(
							WebAction.getAttribute(meetTime, "value"), "h:m a", "hh:mm a");
					startTimeValue = DateFunctions.convertDateStringToAnotherFormat(
							WebAction.getAttribute(startTime, "value"), "h:m a", "hh:mm a");
					Constants.setShootMeetTime(meetTimeValue);
					Constants.setShootStartTime(startTimeValue);
				}

				Constants.setShootEndTime(generateTime(endTimeValue, "hh:mm a"));
				WebAction.click(endTime);
				WebAction.sendKeys(endTime, generateTime(endTimeValue, "hh:mm a"));
			}

			WebAction.scrollIntoView(assignmentSlug);
			WebAction.click(assignmentSlug);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click submit button
	 * 
	 * @param buttonName - button name like submit, cancel, discard changes, etc.,
	 * @throws Exception
	 */
	public void clickButton(String buttonName) throws Exception {
		try {
			switch (buttonName.toUpperCase()) {
			case "SUBMIT":
				WebAction.click(submitButton);
				Constants.setLogTime(DateFunctions.getCurrentDate("h:mma"));
				break;
			case "PUBLISH":
				WebAction.click(publishButton);
				Constants.setLogTime(DateFunctions.getCurrentDate("h:mma"));
				break;
			case "CANCEL REQUEST":
				WebAction.click(cancelRequestButton);
				Constants.setLogTime(DateFunctions.getCurrentDate("h:mma"));
				break;
			case "CONFIRM CANCELLATION":
				WebAction.click(confirmCancellationButton);
				Constants.setLogTime(DateFunctions.getCurrentDate("h:mma"));
				break;
			case "SAVE":
				WebAction.click(saveButton);
				Constants.setLogTime(DateFunctions.getCurrentDate("h:mma"));
				break;
			case "SEND TO STORM":
				WebAction.click(sendToStormButton);
				break;
			case "BACK":
				WebAction.click(backButton);
				break;
			case "INEWS INFO":
				WebAction.click(iNewsInfoButton);
				break;
			case "TITLE":
				WebAction.click(titleButton);
				break;
			case "COPY":
				WebAction.click(copyButton);
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify success submission message is displayed
	 * 
	 * @throws Exception
	 */
	public void verifyFormSuccessMessage(String status) throws Exception {
		try {
			switch (status.toUpperCase()) {
			case "SUBMITTED":
				Waits.waitForElement(submissionSuccessMessage, WAIT_CONDITIONS.VISIBLE);
				CommonValidations.verifyTextValue(submissionSuccessMessage, "Request Submitted",
						"Crew request is not submitted successfully");
				break;
			case "UPDATED":
				Waits.waitForElement(updateSuccessMessage, WAIT_CONDITIONS.VISIBLE);
				CommonValidations.verifyTextValue(updateSuccessMessage, "Request was updated successfully",
						"Crew request is not updated successfully");
				break;
			case "PUBLISHED":
				Waits.waitForElement(publishSuccessMessage, WAIT_CONDITIONS.VISIBLE);
				CommonValidations.verifyTextValue(publishSuccessMessage, "Published",
						"Crew request is not published successfully");
				break;
			case "SUBMITTED FOR CANCELLATION":
				Waits.waitForElement(cancelSuccessMessage, WAIT_CONDITIONS.VISIBLE);
				CommonValidations.verifyTextValue(cancelSuccessMessage, "submitted for Cancellation",
						"Crew request is not submitted for cancellation");
				break;
			case "CANCELLED":
				Waits.waitForElement(cancelSuccessMessage, WAIT_CONDITIONS.VISIBLE);
				CommonValidations.verifyTextValue(cancelSuccessMessage, "Cancelled", "Crew request is not cancelled");
				break;
			}

			// To close the update popup
			if (WebAction.isDisplayed(closeMessagePopup))
				WebAction.click(closeMessagePopup);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To change status of the form. Applicable only for fulfiller login
	 * 
	 * @param status - status to change
	 * @throws Exception
	 */
	public void statusUpdate(String status) throws Exception {
		try {
			switch (status.toUpperCase()) {
			case "EFFORTING":
				WebAction.scrollIntoView(effortingStatus);
				WebAction.click(effortingStatus);
				break;
			case "ROFR":
				WebAction.scrollIntoView(rofrStatus);
				WebAction.click(rofrStatus);
				break;
			case "BOOKED":
				WebAction.scrollIntoView(bookedStatus);
				WebAction.click(bookedStatus);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To add resources in filfullment section
	 * 
	 * @param resourceName
	 * @throws Exception
	 */
	public void addResourcesFulfillmentSection(DataTable dataTable) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			List<Map<String, String>> resourceNames = CucumberUtils.getValuesFromDataTableAsList(dataTable);
			Constants.setResourceCount(resourceNames.size());
			for (int i = 0; i < resourceNames.size(); i++) {
				String resourceName = resourceNames.get(i).get("Resource Name");
				Constants.setCrewResourceName(i + 1, resourceName);
				Waits.waitForElement(searchResourcesTextbox, WAIT_CONDITIONS.CLICKABLE);
				WebAction.sendKeys_WithTimeGap(searchResourcesTextbox, resourceNames.get(i).get("Resource Name"));
				Waits.waitUntilElementSizeGreater(SearchList, 0);
				WebAction.click(SearchList.get(0));

				// resource phone
				String resourcePhone = WebAction.getText(driver
						.findElement(By.xpath(crewResourcePhoneXpath.replace("<<Resource Name>>", resourceName))));
				Constants.setCrewResourceEmail(i + 1, resourcePhone);

				// resource email
				String resourceEmail = WebAction.getText(driver
						.findElement(By.xpath(crewResourceEmailXpath.replace("<<Resource Name>>", resourceName))));
				Constants.setCrewResourceEmail(i + 1, resourceEmail);

				// resource role
				String resourceRole = WebAction.getText(
						driver.findElement(By.xpath(crewResourceRoleXpath.replace("<<Resource Name>>", resourceName))));
				Constants.setCrewResourceEmail(i + 1, resourceRole);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill shoot specs. It is applicable only for fulfiller login
	 * 
	 * @param primaryCameraType - Primary Camera Type drop down
	 * @param mediaFormat       - media format drop down
	 * @param videoSpecs        - video specs drop down
	 * @throws Exception
	 */
	public void fillFulfillmentSection(String primaryCameraTypeValue, String mediaFormatValue, String videoSpecsValue)
			throws Exception {
		try {
			WebAction.scrollIntoView(mediaFormat);

			// To select Primary camera type
			if (primaryCameraTypeValue != null) {
				Constants.setPrimaryCameraType(primaryCameraTypeValue);
				boolean valuePresent = false;
				WebAction.scrollIntoView(primaryCameraType);
				WebAction.click(primaryCameraType);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(primaryCameraTypeValue)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception("'" + primaryCameraTypeValue
							+ "' value is not present in the primary camera type drop down");
			}
			// To select media format
			if (mediaFormatValue != null) {
				Constants.setMediaFormat(mediaFormatValue);
				boolean valuePresent = false;
				WebAction.click(mediaFormat);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(mediaFormatValue)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}

				if (valuePresent == false)
					throw new Exception("'" + mediaFormatValue + "' value is not present in the media type drop down");
			}
			// To select video specs
			if (videoSpecsValue != null) {
				Constants.setVideoSpecs(videoSpecsValue);
				boolean valuePresent = false;
				WebAction.click(videoSpecs);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(videoSpecsValue)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}

				if (valuePresent == false)
					throw new Exception("'" + videoSpecsValue + "' value is not present in the video specs drop down");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify cancel request/confirm cancellation/send to storm alert message
	 * 
	 * @param alertMessage - expected alert message
	 * @throws Exception
	 */
	public void verifyAlertMessage(String action, String alertMessage) throws Exception {
		try {
			if (action.equalsIgnoreCase("CANCELLED"))
				CommonValidations.verifyTextValue(cancellationAlertMessage, alertMessage,
						action + " alert message is not matched");
			else if (action.equalsIgnoreCase("SEND TO STORM"))
				CommonValidations.verifyTextValue(sendToStormAlertMessage, alertMessage,
						action + " alert message is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click yes/No in the cancel/send to storm alert message
	 * 
	 * @param confirmation - Yes/No
	 * @throws Exception
	 */
	public void confirmationInAlertmessage(String confirmation) throws Exception {
		try {
			if (confirmation.equalsIgnoreCase("YES"))
				WebAction.click(cancel_Yes);
			else if (confirmation.equalsIgnoreCase("NO"))
				WebAction.click(cancel_No);
			else if (confirmation.equalsIgnoreCase("OK"))
				WebAction.click(sendToStorm_Ok);
			else if (confirmation.equalsIgnoreCase("CANCEL"))
				WebAction.click(sendToStorm_Cancel);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill comment in OTHER section
	 * 
	 * @param commentText - comment for this form
	 * @throws Exception
	 */
	public void fillComment(String commentText) throws Exception {
		try {
			Waits.waitForElement(commentTextArea, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(commentTextArea, commentText);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify 'missing field' error pop up
	 * 
	 * @throws Exception
	 */
	public void verifyOverallMissingFieldErrorPopup() throws Exception {
		try {
			Waits.waitForElement(missingFieldsPopup, WAIT_CONDITIONS.VISIBLE);
			WebAction.click(closeMessagePopup);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify application all section is incomplete
	 * 
	 * @param sectionName - section name
	 * @throws Exception
	 */
	public void verifySectionNameHighlightedInRedColor(String sectionName) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String sectionIconXpath = "";
			switch (sectionName.toUpperCase()) {
			case "WHO":
				sectionIconXpath = sectionIcon.replace("<<SectionName>>", "who");
				break;
			case "WHAT":
				sectionIconXpath = sectionIcon.replace("<<SectionName>>", "what");
				break;
			case "WHERE":
				sectionIconXpath = sectionIcon.replace("<<SectionName>>", "where");
				break;
			case "WHEN":
				sectionIconXpath = sectionIcon.replace("<<SectionName>>", "when");
				break;
			}

			CommonValidations.verifyAttributeValue(driver.findElement(By.xpath(sectionIconXpath)), "nztype", "close");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify producer info section missing field error message
	 * 
	 * @param producerSameasRequestorErrorMessage - producer same as requester error
	 *                                            message
	 * @param isThereOnSiteProducerErrorMeesage   -is there on-site producer error
	 *                                            message
	 * @param seniorApproverErrorMessage          - senior approver error message
	 * @throws Exception
	 */
	public void verifyProducerInfoMissingFieldError(String producerSameasRequestorErrorMessage,
			String isThereOnSiteProducerErrorMeesage, String seniorApproverErrorMessage) throws Exception {
		try {
			CommonValidations.verifyTextValue(producerSameAsRequestorError, producerSameasRequestorErrorMessage,
					"'Producer same as requestor' error message is not matched");
			CommonValidations.verifyTextValue(isThereOnsiteProducerError, isThereOnSiteProducerErrorMeesage,
					"'Is there onsite producer' error message is not matched");
			CommonValidations.verifyTextValue(seniorApproverError, seniorApproverErrorMessage,
					"'Senior approver' error message is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify show info section missing field error message
	 * 
	 * @param showUnitErrorMessage - show unit error message
	 * @throws Exception
	 */
	public void verifyShowInfoMissingFieldError(String showUnitErrorMessage, String budgetCodeErrorMessage)
			throws Exception {
		try {
			CommonValidations.verifyTextValue(showUnitError, showUnitErrorMessage,
					"Show unit error message is not matched");
			if (budgetCodeErrorMessage != null)
				CommonValidations.verifyTextValue(budgetCodeError, budgetCodeErrorMessage,
						"Budget code error message is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify talent section missing field error message
	 * 
	 * @param talentErrorMessage
	 * @throws Exception
	 */
	public void verifyTalentMissingFieldError(String talentErrorMessage) throws Exception {
		try {
			CommonValidations.verifyTextValue(searchTalentError, talentErrorMessage,
					"Search talent error message is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify shoot details section missing field error message
	 * 
	 * @param productionTypeErrorMessage - production type error message
	 * @param assignmentSlugErrorMessage
	 * @param shootDescErrorMessage
	 * @throws Exception
	 */
	public void verifyShootDetailsMissingFieldError(String productionTypeErrorMessage,
			String assignmentSlugErrorMessage, String shootDescErrorMessage) throws Exception {
		try {
			if (productionTypeErrorMessage != null)
				CommonValidations.verifyTextValue(productionTypeError, productionTypeErrorMessage,
						"Production Type error message is not matched");
			if (assignmentSlugErrorMessage != null)
				CommonValidations.verifyTextValue(assignmentSlugError, assignmentSlugErrorMessage,
						"Assignment Slug error message is not matched");
			CommonValidations.verifyTextValue(shootDescriptionError, shootDescErrorMessage,
					"Shoot Description error message is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify shoot specs section missing field error message
	 * 
	 * @param audioNeedsErrorMessage        - audio needs error message
	 * @param specialConditionsErrorMessage - special conditions error message
	 * @param transmissionTypeErrorMessage  - transmission type error message
	 * @param droneShootErrorMessage        - drone shoot error message
	 * @param cam360ErrorMessage            - camera 360 error message
	 * @throws Exception
	 */
	public void verifyShootSpecsMissingFieldError(String audioNeedsErrorMessage, String specialConditionsErrorMessage,
			String transmissionTypeErrorMessage, String primaryCameraTypeErrorMessage, String droneShootErrorMessage,
			String cam360ErrorMessage) throws Exception {
		try {
			if (audioNeedsErrorMessage != null)
				CommonValidations.verifyTextValue(audioNeedsError, audioNeedsErrorMessage,
						"Audio Needs error message is not matched");
			if (specialConditionsErrorMessage != null)
				CommonValidations.verifyTextValue(specialConditionsError, specialConditionsErrorMessage,
						"Special Conditions error message is not matched");
			CommonValidations.verifyTextValue(transmissionTypeError, transmissionTypeErrorMessage,
					"Transmission Type error message is not matched");
			if (primaryCameraTypeErrorMessage != null)
				CommonValidations.verifyTextValue(primaryCameraTypeError, primaryCameraTypeErrorMessage,
						"Primary Camera Type error message is not matched");
			CommonValidations.verifyTextValue(droneShootError, droneShootErrorMessage,
					"Drone shoot error message is not matched");
			if (cam360ErrorMessage != null)
				CommonValidations.verifyTextValue(camera360Error, cam360ErrorMessage,
						"360 Camera error message is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify location section missing field error message
	 * 
	 * @param addressLine1ErrorMessage - Address line 1 error message
	 * @param cityErrorMessage         - city error message
	 * @param stateErrorMessage        - state error message
	 * @param countryErrorMessage      - country error message
	 * @throws Exception
	 */
	public void verifyLocationMissingFieldError(String addressLine1ErrorMessage, String cityErrorMessage,
			String stateErrorMessage, String countryErrorMessage) throws Exception {
		try {
			CommonValidations.verifyTextValue(addressLine1Error, addressLine1ErrorMessage,
					"Address line 1 error message is not matched");
			CommonValidations.verifyTextValue(cityError, cityErrorMessage, "City error message is not matched");
			CommonValidations.verifyTextValue(stateError, stateErrorMessage, "State error message is not matched");
			CommonValidations.verifyTextValue(countryError, countryErrorMessage,
					"Country error message is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify date and time section missing field error message
	 * 
	 * @param dateErrorMessage      - date error message
	 * @param timeZoneErrorMessage  - time zone error message
	 * @param meetTimeErrorMessage  - meet time error message
	 * @param startTimeErrorMessage - start time error message
	 * @param endTimeErrorMessage   - end time error message
	 * @throws Exception
	 */
	public void verifyDateAndTimeMissingFieldError(String dateErrorMessage, String timeZoneErrorMessage,
			String meetTimeErrorMessage, String startTimeErrorMessage, String endTimeErrorMessage) throws Exception {
		try {
			if (dateErrorMessage != null)
				CommonValidations.verifyTextValue(shootDateError, dateErrorMessage,
						"Shoot date error message is not matched");
			CommonValidations.verifyTextValue(timeZoneError, timeZoneErrorMessage,
					"Time Zone error message is not matched");
			if (meetTimeErrorMessage != null)
				CommonValidations.verifyTextValue(meetTimeError, meetTimeErrorMessage,
						"Meet Time error message is not matched");
			if (startTimeErrorMessage != null)
				CommonValidations.verifyTextValue(startTimeError, startTimeErrorMessage,
						"Start Time error message is not matched");
			if (endTimeErrorMessage != null)
				CommonValidations.verifyTextValue(endTimeError, endTimeErrorMessage,
						"End Time error message is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify storm success message
	 * 
	 * @throws Exception
	 */
	public void verifyStormSuccessMessage() throws Exception {
		try {
			// To close the update popup
			if (WebAction.isDisplayed(closeMessagePopup))
				WebAction.click(closeMessagePopup);

			Waits.waitForElement(sendToStormSuccessMessageHeader, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyTextValue(sendToStormSuccessMessageHeader, "success",
					"Send to storm success message is not displayed");
			CommonValidations.verifyTextValue(sendToStormSuccessMessage,
					"The request (" + Constants.getRequestNumber() + ") has been sent to STORM.",
					"Send to storm success message is mismatched");
			WebAction.click(closeSendToStormLogButton);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To validate storm failure message
	 * 
	 * @throws Exception
	 */
	public void verifyStormBudgetCodeFailureMessage() throws Exception {
		try {
			// To close the update popup
			if (WebAction.isDisplayed(closeMessagePopup))
				WebAction.click(closeMessagePopup);

			Waits.waitForElement(sendToStormFailureMessageHeader, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyTextValue(sendToStormFailureMessageHeader, "Send to STORM Failed!",
					"'Send to STORM failed!' message is not displayed");
			CommonValidations.verifyTextValue(sendToStormFailureMessage,
					Constants.getRequestNumber() + "-Budget Code does not exist in STORM",
					"Send to storm failure message is mismatched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify SSO not found in storm error
	 * 
	 * @throws Exception
	 */
	public void verifySsoNotFoundFailureMessage() throws Exception {
		try {
			// To close the update popup
			if (WebAction.isDisplayed(closeMessagePopup))
				WebAction.click(closeMessagePopup);

			Waits.waitForElement(sendToStormFailureMessageHeader, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyTextValue(sendToStormFailureMessageHeader, "Failed Assignments seen!",
					"'Failed Assignments seen!' message is not displayed");
			for (WebElement logMessage : sendToStormLogMessages) {
				CommonValidations.verifyTextValue(logMessage, "SSO not found in STORM",
						"SSO not found in STORM error message is not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Notes/Logs tab
	 * 
	 * @param tabName
	 * @throws Exception
	 */
	public void selectTab(String tabName) throws Exception {
		try {
			if (tabName.equalsIgnoreCase("NOTES"))
				WebAction.click(notesTab);
			else if (tabName.equalsIgnoreCase("LOG"))
				WebAction.click(logTab);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To validate iNews info section
	 * @param formName
	 * @throws Throwable
	 */
	public void verifyINewsInfoSection(String formName) throws Throwable {
		try {
			// To verify production type
			String expectedProductionType = "";
			if (formName.toUpperCase().contains("CNBC"))
				expectedProductionType = "CNBC Crew";
			else if (formName.toUpperCase().contains("TELEMUNDO"))
				expectedProductionType = "Telemundo Crew";
			else if (formName.toUpperCase().contains("DJ SHOOT"))
				expectedProductionType = "Digital Journalist";
			else if (formName.toUpperCase().contains("BREAKING NEWS"))
				expectedProductionType = "Breaking News";
			else if (formName.toUpperCase().contains("BUREAU CAMERA"))
				expectedProductionType = "Bureau Camera";
			else
				expectedProductionType = "General Crew Request";

			CommonValidations.verifyTextValue(productionTypeElement, expectedProductionType,
					"Production Type in iNews Info is not correct");

			// To verify crew request number
			String expectedCrewRequestNumber = Constants.getRequestNumber();
			CommonValidations.verifyTextValue(crewRequestNumberElement, expectedCrewRequestNumber,
					"Crew request number in iNews Info is not correct");

			// To verify show unit
			String expectedShowUnit = Constants.getShowUnit();
			CommonValidations.verifyTextValue(showUnitElement, expectedShowUnit,
					"Show unit in iNews Info is not correct");

			// To verify slug
			String expectedAssigmentSlug = Constants.getAssignmentSlug();
			CommonValidations.verifyTextValue(slugElement, expectedAssigmentSlug,
					"Assignment slug in iNews Info is not correct");

			// To verify time zone
			String expectedTimeZone = Constants.getShootTimeZone();
			expectedTimeZone = expectedTimeZone.substring(expectedTimeZone.indexOf("(") + 1,
					expectedTimeZone.indexOf(")"));
			CommonValidations.verifyTextValue(slugElement, expectedAssigmentSlug,
					"Time zone in iNews Info is not correct");

			// To verify meet time
			String expectedMeetTime = "";
			if (formName.toUpperCase().contains("DJ SHOOT"))
				expectedMeetTime = "12:00 PM";
			else
				expectedMeetTime = Constants.getShootMeetTime();
			CommonValidations.verifyTextValue(meetTimeElement, expectedMeetTime,
					"Meet time in iNews Info is not correct");

			// To verify contact
			if (!formName.toUpperCase().contains("BUREAU CAMERA")) {
				String expectedRequesterName = Constants.getDefaultRequesterName();
				String expectedRequesterPhoneNumber = Constants.getDefaultRequesterPhoneNumber();
				CommonValidations.verifyTextValue(contactElement, expectedRequesterName,
						"Producer name in contact section of iNews info is not correct");
				CommonValidations.verifyTextValue(contactElement, expectedRequesterPhoneNumber,
						"Producer phone number in contact section of iNews info is not correct");
			}

			// To verify Address line1
			String expectedAddressLine1 = Constants.getAddressLine1();
			CommonValidations.verifyTextValue(address, expectedAddressLine1,
					"Address line1 in iNews Info is not correct");

			// To verify city
			String expectedCity = Constants.getCity();
			CommonValidations.verifyTextValue(cityElement, expectedCity, "City in iNews Info is not correct");

			// To verify state
			String expectedState = EmailValidation.getStateCode(Constants.getState());
			CommonValidations.verifyTextValue(stateElement, expectedState, "State in iNews Info is not correct");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To verify iNews Info copy functionality
	 * @param formName
	 * @throws Throwable
	 */
	public void verifyINewsInfoCopiedContent(String formName) throws Throwable {
		try {
			Toolkit toolkit = Toolkit.getDefaultToolkit();
			Clipboard clipboard = toolkit.getSystemClipboard();
			String actualCopedText = (String) clipboard.getData(DataFlavor.stringFlavor);
			System.out.println("String from Clipboard:" + actualCopedText);

			// expected 1st Line
			String expectedFirstLine = Constants.getShowUnit() + " - " + Constants.getAssignmentSlug();
			Assert.assertTrue(actualCopedText.contains(expectedFirstLine),
					"First line of copied content in iNews Info is not matched. Expected Line '" + expectedFirstLine
							+ "' and actual content is '" + actualCopedText + "'");

			// expected 2nd Line

			// Production type
			String expectedProductionType = "";
			if (formName.toUpperCase().contains("CNBC"))
				expectedProductionType = "CNBC Crew";
			else if (formName.toUpperCase().contains("TELEMUNDO"))
				expectedProductionType = "Telemundo Crew";
			else if (formName.toUpperCase().contains("DJ SHOOT"))
				expectedProductionType = "Digital Journalist";
			else if (formName.toUpperCase().contains("BREAKING NEWS"))
				expectedProductionType = "Breaking News";
			else if (formName.toUpperCase().contains("BUREAU CAMERA"))
				expectedProductionType = "Bureau Camera";
			else
				expectedProductionType = "General Crew Request";
			// Meet Time
			String expectedMeetTime = "";
			if (formName.toUpperCase().contains("DJ SHOOT"))
				expectedMeetTime = "12:00 PM";
			else
				expectedMeetTime = Constants.getShootMeetTime();

			// Time zone
			String expectedTimeZone = Constants.getShootTimeZone();
			expectedTimeZone = expectedTimeZone.substring(expectedTimeZone.indexOf("(") + 1,
					expectedTimeZone.indexOf(")"));
			
			//Phone number
			String producerPhoneNumber = Constants.getDefaultRequesterPhoneNumber();
			producerPhoneNumber=producerPhoneNumber.substring(0, 3)+"-"+producerPhoneNumber.substring(3, 6)+"-"+producerPhoneNumber.substring(6);

			String expectedSecondLine = expectedMeetTime + " " + expectedTimeZone + " meet "
					+ Constants.getDefaultRequesterName() + " (" + producerPhoneNumber + ") at "
					+ Constants.getAddressLine1() + " " + Constants.getCity() + " "
					+ EmailValidation.getStateCode(Constants.getState()) + " for " + expectedProductionType;
			Assert.assertTrue(actualCopedText.contains(expectedSecondLine),
					"Second line of copied content in iNews Info is not matched. Expected Line '" + expectedSecondLine
							+ "' and actual content is '" + actualCopedText + "'");

			// expected 3rd Line
			String expectedLastLine = Constants.getRequestNumber();
			Assert.assertTrue(actualCopedText.contains(expectedLastLine),
					"Last line of copied content in iNews Info is not matched. Expected Line '" + expectedLastLine
							+ "' and actual content is '" + actualCopedText + "'");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To verify title section details
	 * @param formName
	 * @throws Throwable
	 */
	public void verifyTitleSection(String formName) throws Throwable {
		try {
			// To verify production type
			String expectedProductionType = "";
			if (formName.toUpperCase().contains("CNBC"))
				expectedProductionType = "CNBC Crew";
			else if (formName.toUpperCase().contains("TELEMUNDO"))
				expectedProductionType = "Telemundo Crew";
			else if (formName.toUpperCase().contains("DJ SHOOT"))
				expectedProductionType = "Digital Journalist";
			else if (formName.toUpperCase().contains("BREAKING NEWS"))
				expectedProductionType = "Breaking News";
			else if (formName.toUpperCase().contains("BUREAU CAMERA"))
				expectedProductionType = "Bureau Camera";
			else
				expectedProductionType = "General Crew Request";

			CommonValidations.verifyTextValue(productionTypeElement, expectedProductionType,
					"Production Type in iNews Info is not correct");

			// To verify crew request number
			String expectedCrewRequestNumber = Constants.getRequestNumber();
			CommonValidations.verifyTextValue(crewRequestNumberElement, expectedCrewRequestNumber,
					"Crew request number in iNews Info is not correct");

			// To verify show unit
			String expectedShowUnit = Constants.getShowUnit();
			CommonValidations.verifyTextValue(showUnitElement, expectedShowUnit,
					"Show unit in iNews Info is not correct");

			// To verify slug
			String expectedAssigmentSlug = Constants.getAssignmentSlug();
			CommonValidations.verifyTextValue(slugElement, expectedAssigmentSlug,
					"Assignment slug in iNews Info is not correct");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To verify Title copy functionality
	 * @param formName
	 * @throws Throwable
	 */
	public void verifyTitleCopiedContent(String formName) throws Throwable {
		try {
			Toolkit toolkit = Toolkit.getDefaultToolkit();
			Clipboard clipboard = toolkit.getSystemClipboard();
			String actualCopedText = (String) clipboard.getData(DataFlavor.stringFlavor);
			System.out.println("String from Clipboard:" + actualCopedText);

			// expected 1st Line
			String expectedFirstLine = Constants.getShowUnit() + " - " + Constants.getAssignmentSlug();
			Assert.assertTrue(actualCopedText.contains(expectedFirstLine),
					"First line of copied content in title is not matched. Expected Line '" + expectedFirstLine
							+ "' and actual content is '" + actualCopedText + "'");

			// expected last Line
			String expectedLastLine = Constants.getRequestNumber();
			Assert.assertTrue(actualCopedText.contains(expectedLastLine),
					"Last line of copied content in title is not matched. Expected Line '" + expectedLastLine
							+ "' and actual content is '" + actualCopedText + "'");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}
