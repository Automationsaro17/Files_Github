package nbcu.automation.ui.pages.crewrequest;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.automation.ui.constants.crewrequest.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.factory.DriverFactory;

public class ExecutiveDashboardPage {

	@FindBy(xpath = "//input[@placeholder='Select One']")
	WebElement SelectOneSuggestionbox;

	@FindBy(xpath = "//*[@role='menuitem']/div")
	List<WebElement> SearchList;

	@FindBy(xpath = "//*[@class='ant-progress-circle']//following-sibling::span")
	WebElement allocationPercentage;

	@FindBy(xpath = "//div[@class='section']/p[text()='Allocated']//following-sibling::h2")
	WebElement allocationValueSection;

	@FindBy(xpath = "//div[@class='section']/p[text()='Booked']//following-sibling::h2")
	WebElement bookedValueSection;

	@FindBy(xpath = "//*[@class='ant-progress-circle-path ng-star-inserted']")
	WebElement allocationPercentageProgressCircle;

	@FindBy(xpath = "//span[text()=' Collapse ']")
	WebElement collapseButton;

	public ExecutiveDashboardPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To select show unit in executive dashboard
	 * 
	 * @throws Exception
	 */
	public void selectShowUnit() throws Exception {
		String showUnit = Constants.getShowUnit();
		try {
			System.out.println("Show Unit:"+showUnit);
			Waits.waitForElement(SelectOneSuggestionbox, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(SelectOneSuggestionbox, showUnit);
			Waits.waitUntilElementSizeGreater(SearchList, 0);
			WebAction.click(SearchList.get(0));
			Thread.sleep(2000);
		} catch (Exception e) {
			Thread.sleep(1000);
			WebAction.click(SearchList.get(0));
			WebAction.keyPress(SelectOneSuggestionbox, "ENTER");
		}
	}

	/**
	 * To verify resource allocation is reached the threshold percentage
	 * 
	 * @throws Exception
	 */
	public void verifiyResourceAllocationReachedThreshold() throws Exception {
		try {
			int totalResourcesCount = Constants.getResourcesCount() * Constants.getShootDaysCount();
			int allocationCount = Constants.getAllocation();
			int expectedThresholdpercentage = Constants.getThresholdPercent();

			Waits.waitForElement(allocationPercentage, WAIT_CONDITIONS.VISIBLE);

			// To verify allocation count in resource section
			int actualTotalResourceValue = Integer
					.parseInt(WebAction.getText(allocationValueSection).toString().trim());
			CommonValidations.verifytextValue(actualTotalResourceValue, allocationCount, "Total allocated resource count is not matching");

			// To verify booked count in resource section
			int actualTotalResourceBooked = Integer.parseInt(WebAction.getText(bookedValueSection).toString().trim());
			CommonValidations.verifytextValue(actualTotalResourceBooked, totalResourcesCount, "Total booked/efforting resouce count is not matching");

			// To verify threshold set in admin page is matches with resource allocation
			System.out.println("Resource count:"+totalResourcesCount);
			System.out.println("Allocation count:"+allocationCount);
			int actualResourceAllocationPercent = (int)(((double)totalResourcesCount/allocationCount) * 100);
			System.out.println(actualResourceAllocationPercent);
			System.out.println(expectedThresholdpercentage);
			if (actualResourceAllocationPercent < expectedThresholdpercentage)
				Assert.assertTrue(false,
						"Resource allocation to show unit is not reached threshold. So add few more resources in request to reach threshold");

			// To verify allocation percentage in exec dashboard is reached threshold
			// percentage
			int actualThresholdPercentage = Integer
					.parseInt(WebAction.getText(allocationPercentage).replaceAll("%", "").trim());
			if (actualThresholdPercentage < expectedThresholdpercentage)
				Assert.assertTrue(false,
						"Allocation percentage in executive dashboard is not reached threshold percentage");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	/**
	 * To verify the allocation circle color in executive dashboard
	 * 
	 * @param color - color of the circle
	 * @throws Exception
	 */
	public void verifyAllocationCircleColor(String color) throws Exception {
		try {
			Waits.waitForElement(allocationPercentageProgressCircle, WAIT_CONDITIONS.VISIBLE);
			Thread.sleep(2000);
			CommonValidations.verifyCssValueOfWebElement(allocationPercentageProgressCircle, "Stroke", color);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
