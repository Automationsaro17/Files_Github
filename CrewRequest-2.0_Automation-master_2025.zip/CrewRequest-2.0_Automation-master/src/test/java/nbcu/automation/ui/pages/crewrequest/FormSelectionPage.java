
package nbcu.automation.ui.pages.crewrequest;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;

public class FormSelectionPage {

	@FindBy(xpath = "//h2[text()='What Kind of Request is this?']")
	WebElement formSelectionHeader;

	@FindBy(xpath = "//button[span[contains(text(),'NBC News Crew Request')]]")
	WebElement newsCrewRequest;
	
	@FindBy(xpath = "//button[span[contains(text(),'CNBC Crew Request')]]")
	WebElement cnbcCrewRequest;
	
	@FindBy(xpath = "//button[span[contains(text(),'Telemundo News Crew Request')]]")
	WebElement telemundoCrewRequest;

	@FindBy(xpath = "//*[span[contains(text(),' Digital Journalist/DJ Shoot ')]]")
	WebElement djShootCrewRequest;

	@FindBy(xpath = "//button[span[contains(text(),'NBC Breaking News')]]")
	WebElement breakingNewsCrewRequest;

	@FindBy(xpath = "//button[span[contains(text(),'NBC Bureau Camera')]]")
	WebElement bureauCameraCrewRequest;

	public FormSelectionPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify form selection page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyFormSelectionPageDisplayed() throws Exception {
		Waits.waitForElement(formSelectionHeader, WAIT_CONDITIONS.VISIBLE);
	}

	/**
	 * To select given form from crew request
	 * 
	 * @throws Exception
	 */
	public void selectCrewRequestForm(String formName) throws Exception {
		try {
			WebAction.scrollIntoView(newsCrewRequest);
			switch (formName.toUpperCase()) {
			case "NBC NEWS CREW REQUEST":
				WebAction.click(newsCrewRequest);
				break;
			case "CNBC CREW REQUEST":
				WebAction.click(cnbcCrewRequest);
				break;
			case "TELEMUNDO NEWS CREW REQUEST":
				WebAction.click(telemundoCrewRequest);
				break;
			case "DJ SHOOT CREW REQUEST":
				WebAction.click(djShootCrewRequest);
				break;
			case "NBC BREAKING NEWS CREW REQUEST":
				WebAction.click(breakingNewsCrewRequest);
				break;
			case "NBC BUREAU CAMERA CREW REQUEST":
				WebAction.click(bureauCameraCrewRequest);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
