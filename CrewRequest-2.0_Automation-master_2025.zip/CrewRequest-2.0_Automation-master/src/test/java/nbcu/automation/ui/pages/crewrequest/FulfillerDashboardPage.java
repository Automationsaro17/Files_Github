package nbcu.automation.ui.pages.crewrequest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.automation.ui.constants.crewrequest.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;

public class FulfillerDashboardPage {

	// crew icon
	@FindBy(xpath = "//*[text()='Crew']/preceding-sibling::i")
	WebElement crewIcon;

	// Dashboard Elements
	@FindBy(xpath = "//a[contains(text(),'News Dashboard')]")
	WebElement newsDashboard;

	@FindBy(xpath = "//a[contains(text(),'CNBC Dashboard')]")
	WebElement cnbcDashboard;

	@FindBy(xpath = "//a[contains(text(),'Digital Dashboard')]")
	WebElement digitalDashboard;

	@FindBy(xpath = "//a[contains(text(),'Telemundo Dashboard')]")
	WebElement telemundoDashboard;

	@FindBy(xpath = "//span[text()='News Dashboard']")
	WebElement newsDashboardTitle;

	@FindBy(xpath = "//span[text()='CNBC Dashboard']")
	WebElement cnbcDashboardTitle;

	@FindBy(xpath = "//span[text()='Telemundo Dashboard']")
	WebElement telemundoDashboardTitle;

	@FindBy(xpath = "//span[text()='Digital Dashboard']")
	WebElement digitalDashboardTitle;

	@FindBy(xpath = "//span[text()='Request Center']")
	WebElement executiveDashboardTitle;
	
	//Dashboard toggle filter
	
	@FindBy(xpath = "//button[contains(@class,'has-no-value-toggle-o')]")
	WebElement toggleFilter;
	

	// Dashboard Table Element
	@FindBy(xpath = "//input[@placeholder='Search']")
	WebElement searchTextBox;

	@FindBy(xpath = "//tr[contains(@class,'ant-table-row')]")
	List<WebElement> fulfillerTableRows;

	String findRequestById = "//a[text()='<<RequestId>>']";

	// Fulfiller table tabs Elements
	@FindBy(xpath = "//li[contains(text(),'Fulfilled')]")
	WebElement fulfilledTab;

	@FindBy(xpath = "//li[contains(text(),'Cancelled')]")
	WebElement cancelledTab;

	@FindBy(xpath = "//li[contains(text(),'Active')]")
	WebElement activeTab;

	@FindBy(xpath = "//a[contains(text(),'Executive Dashboard')]")
	WebElement executiveDashboard;

	@FindBy(xpath = "//a[text()='Admin']")
	WebElement adminMenuItem;

	@FindBy(xpath = "//span[text()='My Requests']//preceding-sibling::button")
	WebElement myRequestIcon;
	
	//Executive Dashboard
	@FindBy(xpath = "//section[@class='body']//*[text()='Add']")
	WebElement addButton;

	public FulfillerDashboardPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify fulfiller dashboard page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyCrewDashboardPageDisplayed() throws Exception {
		Waits.waitForElement(crewIcon, WAIT_CONDITIONS.CLICKABLE);
	}

	/**
	 * To select executive dashboard
	 * 
	 * @throws Exception
	 */
	public void openExecutiveDashboard() throws Exception {
		WebAction.click(crewIcon);
		WebAction.click(executiveDashboard);
		Waits.waitForElement(executiveDashboardTitle, WAIT_CONDITIONS.VISIBLE);
	}

	/**
	 * To open dashboard page based on form name
	 * 
	 * @param formName
	 * @throws Exception
	 */
	public void openDashboard(String formName) throws Exception {
		String dashboardName = "";
		try {
			// To find dashboard page based on form name
			switch (formName.toUpperCase()) {
			case "NBC NEWS CREW REQUEST":
			case "NBC BREAKING NEWS":
			case "NBC BUREAU CAMERA":
				dashboardName = "News Dashboard";
				break;
			case "CNBC CREW REQUEST":
				dashboardName = "CNBC Dashboard";
				break;
			case "TELEMUNDO NEWS CREW REQUEST":
				dashboardName = "Telemundo Dashboard";
				break;
			case "DJ SHOOT CREW REQUEST":
				dashboardName = "Digital Dashboard";
				break;
			case "EXECUTIVE DASHBOARD":
				dashboardName = "Executive Dashboard";
				break;
			}

			WebAction.click(crewIcon);

			// To click dashboard
			switch (dashboardName) {
			case "News Dashboard":
				WebAction.click(newsDashboard);
				Waits.waitForElement(newsDashboardTitle, WAIT_CONDITIONS.VISIBLE);
				break;
			case "CNBC Dashboard":
				WebAction.click(cnbcDashboard);
				Waits.waitForElement(cnbcDashboardTitle, WAIT_CONDITIONS.VISIBLE);
				break;
			case "Telemundo Dashboard":
				WebAction.click(telemundoDashboard);
				Waits.waitForElement(telemundoDashboardTitle, WAIT_CONDITIONS.VISIBLE);
				break;
			case "Digital Dashboard":
				WebAction.click(digitalDashboard);
				Waits.waitForElement(digitalDashboardTitle, WAIT_CONDITIONS.VISIBLE);
				break;
			case "Executive Dashboard":
				WebAction.click(executiveDashboard);
				Waits.waitForElement(executiveDashboardTitle, WAIT_CONDITIONS.VISIBLE);
				break;
			default:
				WebAction.click(newsDashboard);
				Waits.waitForElement(newsDashboardTitle, WAIT_CONDITIONS.VISIBLE);
				break;
			}
			
			WebAction.mouseOver(toggleFilter);
			Thread.sleep(500);
			

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To search the request in fulfiller table
	 * 
	 * @throws Exception
	 */
	public void searchRequest() throws Exception {
		try {
			String requestNumber = Constants.getRequestNumber();
			WebAction.click(searchTextBox);
			Waits.waitUntilElementSizeGreater(fulfillerTableRows, 0);
			WebAction.sendKeys(searchTextBox, requestNumber);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void verifyRequestInfulfillerDashboard(String formName) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String requestNumber = Constants.getRequestNumber();

			Waits.waitForElement(By.xpath(findRequestById.replace("<<RequestId>>", requestNumber)),
					WAIT_CONDITIONS.CLICKABLE);

			// To check form name
			if (formName.toUpperCase().equalsIgnoreCase("NBC NEWS CREW REQUEST"))
				formName = "General Crew Request";
			else if (formName.toUpperCase().equalsIgnoreCase("CNBC CREW REQUEST"))
				formName = "CNBC Crew";
			else if (formName.toUpperCase().equalsIgnoreCase("TELEMUNDO NEWS CREW REQUEST"))
				formName = "Telemundo Crew";
			else if (formName.toUpperCase().equalsIgnoreCase("DJ SHOOT CREW REQUEST"))
				formName = "Digital Journalist";
			else if (formName.toUpperCase().equalsIgnoreCase("NBC BREAKING NEWS CREW REQUEST"))
				formName = "Breaking News";
			else if (formName.toUpperCase().equalsIgnoreCase("NBC BUREAU CAMERA CREW REQUEST"))
				formName = "Bureau Camera";

			WebElement actualFormNameElement = driver.findElement(
					By.xpath(findRequestById.replace("<<RequestId>>", requestNumber) + "/preceding-sibling::div[1]"));
			String actualFormName = WebAction.getText(actualFormNameElement).trim();
			if (!(actualFormName.equalsIgnoreCase(formName)))
				throw new Exception("Form name is not correct.Expected form name is '" + formName
						+ "' and actual form name is '" + actualFormName + "'");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify status background color
	 * 
	 * @param typeOfCss
	 * @param status
	 * @param expectedColor
	 * @throws Exception
	 */
	public void verifyStatusBackgroundColor(String typeOfCss, String status, String expectedColor) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String requestNumber = Constants.getRequestNumber();

			String statusXpath = findRequestById.replace("<<RequestId>>", requestNumber)
					+ "/../following-sibling::td[1]//nz-tag";
			WebElement statusElement = driver.findElement(By.xpath(statusXpath));
			String actualStatus = WebAction.getText(statusElement).trim();
			if (!(actualStatus.equalsIgnoreCase(status))) {
				throw new Exception("Status of the request is not correct. Expected status is '" + status
						+ "' and actual status is '" + actualStatus + "'");
			}
			CommonValidations.verifyCssValueOfWebElement(statusElement, typeOfCss, expectedColor);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click edit link of the request
	 * 
	 * @throws Exception
	 */
	public void clickEditLink() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String requestNumber = Constants.getRequestNumber();
			Waits.waitForElement(By.xpath(findRequestById.replace("<<RequestId>>", requestNumber)),
					WAIT_CONDITIONS.CLICKABLE);

			// To click edit link
			String editLinkXpath = findRequestById.replace("<<RequestId>>", requestNumber)
					+ "/../following-sibling::td[//a[text()='Edit']]//a";

			Waits.waitForElement(By.xpath(editLinkXpath), WAIT_CONDITIONS.CLICKABLE);
			WebAction.click(driver.findElement(By.xpath(editLinkXpath)));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To View the crew request
	 * @throws Exception
	 */
	public void clickViewLink() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String requestNumber = Constants.getRequestNumber();

			// To click view link
			String editLinkXpath = findRequestById.replace("<<RequestId>>", requestNumber);
			Waits.waitForElement(By.xpath(editLinkXpath), WAIT_CONDITIONS.CLICKABLE);
			WebAction.click(driver.findElement(By.xpath(editLinkXpath)));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select given tab in the fulfiller table
	 * 
	 * @param tabName - tab name
	 * @throws Exception
	 */
	public void selectTabInFulfillerTable(String tabName) throws Exception {
		try {
			switch (tabName.toUpperCase()) {
			case "ACTIVE":
				WebAction.click(activeTab);
				break;
			case "FULFILLED":
				WebAction.click(fulfilledTab);
				break;
			case "CANCELLED":
				WebAction.click(cancelledTab);
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click menu item
	 * 
	 * @param menuItemName : crew, admin
	 * @throws Exception
	 */
	public void clickMenuItem(String menuItemName) throws Exception {
		try {
			switch (menuItemName.toUpperCase()) {
			case "CREW":
				WebAction.click(crewIcon);
				break;
			case "ADMIN":
				WebAction.click(adminMenuItem);
				WebAction.mouseOver(addButton);
				break;
			case "MY REQUESTS":
				WebAction.click(myRequestIcon);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}
