package nbcu.automation.ui.pages.crewrequest;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.automation.ui.constants.crewrequest.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.Other.DateFunctions;

public class LogPage {

	@FindBy(xpath = "//p[@class='date']")
	WebElement logDate;

	@FindBy(xpath = "//div[@class='logTime']/div")
	List<WebElement> logTime;

	@FindBy(xpath = "//p[@class='status']")
	List<WebElement> logStatus;

	@FindBy(xpath = "//p[@class='status']/following-sibling::p[contains(@class,'notes')]")
	List<WebElement> logComment;

	@FindBy(xpath = "//p[@class='status']/following-sibling::p[@class='name']")
	List<WebElement> logName;

	// Profile icons
	@FindBy(xpath = "//nz-avatar[i[*[@data-icon='user']]]")
	WebElement profileIcon;

	@FindBy(xpath = "//button[contains(text(),'Logout')]/preceding-sibling::p/strong")
	WebElement loggedInUserName;

	public LogPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	public void verifyLogDetails(String status) throws Exception {
		try {
			// To verify log date
			CommonValidations.verifyTextValue(logDate, DateFunctions.getCurrentDate("MM/dd/yyyy"),
					"Log Date is incorrect");

			// To verify log time
			CommonValidations.verifyTextValue(logTime.get(0), Constants.getLogTime(), "Log Time is incorrect");

			// To verify log status
			CommonValidations.verifyTextValue(logStatus.get(0), status, "Request status is incorrect");

			// To verify log message
			String logMessage = "";
			switch (status.toUpperCase()) {
			case "NEW":
				logMessage = "New Crew Request is submitted";
				break;
			case "REVISED":
				logMessage = "Changed Requester Section";
				break;
			case "EFFORTING":
			case "ROFR":
			case "BOOKED":
				logMessage = "Added Fulfillment Section";
				break;
			case "CONFIRM CANCELLATION":
				logMessage = "Request is moved to Cancelled Confirmation Status";
				break;
			case "CANCELLED":
				logMessage = "Request is moved to Cancelled Status";
				break;
			}

			CommonValidations.verifyTextValue(logComment.get(0), logMessage, "Log message is incorrect");

			// To verify log user name
			WebAction.click(profileIcon);
			String userName = WebAction.getText(loggedInUserName);
			CommonValidations.verifyTextValue(logName.get(0), userName, "Log user is incorrect");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

}
