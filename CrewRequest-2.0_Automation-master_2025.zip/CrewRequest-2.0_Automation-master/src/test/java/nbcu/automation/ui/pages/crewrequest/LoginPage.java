package nbcu.automation.ui.pages.crewrequest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.encryption.PasswordEncryption;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class LoginPage {

	@FindBy(id = "username")
	WebElement userName;

	@FindBy(id = "password")
	WebElement password;

	@FindBy(id = "submitBtn")
	WebElement submitButton;

	public LoginPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To open producer dashboard application
	 * 
	 * @throws Exception
	 */
	public void openApplication(String applicationName) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String environment = "", applicationUrl = "";
		try {
			// Fetch the application url based on application and environment
			environment = ConfigFileReader.getProperty("Environment");
			switch (environment.toUpperCase()) {
			case "QA":
				applicationUrl = ConfigFileReader.getProperty("Prodreq-App-Url_Qa");
				break;
			case "STAGE":
				applicationUrl = ConfigFileReader.getProperty("Prodreq-App-Url_Stage");
				break;
			case "PROD":
				applicationUrl = ConfigFileReader.getProperty("Prodreq-App-Url_Prod");
				break;
			}

			// Launch the application
			driver.get(applicationUrl);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


	/**
	 * To login into application
	 * 
	 * @throws Exception
	 */
	public void loginIntoApplication(String role) throws Exception {
		String userNameText = "", passwordText = "";
		try {
			if (WebAction.isDisplayed(userName)) {
				switch (role.toUpperCase()) {
				case "PRODUCER":
					userNameText = ConfigFileReader.getProperty("Producer-Username");
					passwordText = ConfigFileReader.getProperty("Producer-Password");
					break;
				case "FULFILLER":
					userNameText = ConfigFileReader.getProperty("Crew-Fulfiller-Username");
					passwordText = ConfigFileReader.getProperty("Crew-Fulfiller-Password");
					break;
				}
				WebAction.clear(userName);
				WebAction.sendKeys(userName, userNameText);
				String descryptedPassword = PasswordEncryption.decrypt(passwordText);
				WebAction.sendKeys(password, descryptedPassword);
				WebAction.click(submitButton);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To close existing driver and open ie browser
	 * @throws Exception
	 */
	public void openStormApplicationBrowser() throws Exception {
		try {
			DriverFactory.cleanDrivers();
			DriverFactory.initDriver(ConfigFileReader.getProperty("Application-Type"), "ie");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}
