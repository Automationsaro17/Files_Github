package nbcu.automation.ui.pages.crewrequest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.automation.ui.constants.crewrequest.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;

public class MyRequestPage {

	// Forms page button
	@FindBy(xpath = "//button[span[contains(text(),'New Request')]]")
	WebElement formsButton;

	// My request rows
	@FindBy(xpath = "//tr[contains(@class,'trCls')]")
	List<WebElement> myRequestRows;

	// to retrieve status by request id
	String findRequestById = "//td[p[a[text()='<<RequestId>>']]]";
	
	//to view request link
	String viewRequestId = "//a[text()='<<RequestId>>']";

	@FindBy(xpath = "//nz-avatar[i[*[@data-icon='user']]]")
	WebElement profileIcon;

	@FindBy(xpath = "//button[contains(text(),'Logout')]")
	WebElement logOutButton;

	@FindBy(xpath = "//*[contains(text(),'You have been logged out of this application')]")
	WebElement logOutMessage;

	@FindBy(xpath = "//input[@placeholder='Search']")
	WebElement searchTextBox;

	public MyRequestPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify my requests page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyMyRequestsPageDisplayed() throws Exception {
		Waits.waitForElement(formsButton, WAIT_CONDITIONS.CLICKABLE);
	}

	/**
	 * To click + button
	 * 
	 * @throws Exception
	 */
	public void clickFormsButton() throws Exception {
		WebAction.click(formsButton);
	}

	/**
	 * To verify submitted request is present in the my request page
	 * 
	 * @param formName - form name
	 * @throws Exception
	 */
	public void verifyCrewRequestInmyRequestPage(String formName, String status) throws Exception {
		String requestNumber = "";
		try {
			// To check form name
			if (formName.toUpperCase().equalsIgnoreCase("NBC NEWS CREW REQUEST"))
				formName = "General Crew Request";
			else if (formName.toUpperCase().equalsIgnoreCase("CNBC CREW REQUEST"))
				formName = "CNBC Crew";
			else if (formName.toUpperCase().equalsIgnoreCase("TELEMUNDO NEWS CREW REQUEST"))
				formName = "Telemundo Crew";
			else if (formName.toUpperCase().equalsIgnoreCase("DJ SHOOT CREW REQUEST"))
				formName = "Digital Journalist";
			else if (formName.toUpperCase().equalsIgnoreCase("NBC BREAKING NEWS CREW REQUEST"))
				formName = "Breaking News";
			else if (formName.toUpperCase().equalsIgnoreCase("NBC BUREAU CAMERA CREW REQUEST"))
				formName = "Bureau Camera";

			for (WebElement row : myRequestRows) {
				if ((WebAction.getText(row.findElement(By.xpath("td[1]/p[1]"))).equalsIgnoreCase("CREW REQUEST"))
						&& (WebAction.getText(row.findElement(By.xpath("td[1]/p[2]"))).equalsIgnoreCase(formName))
						&& (WebAction.getText(row.findElement(By.xpath("td[3]/nz-tag"))).equalsIgnoreCase(status))) {
					requestNumber = WebAction.getText(row.findElement(By.xpath("td[2]/p/a")));
					Constants.setRequestNumber(requestNumber);
					break;
				}
			}
			if (requestNumber.isEmpty())
				throw new Exception("Submitted " + formName + "is not present in my request table");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify background color of status in my request page
	 * 
	 * @param typeValueCSS  - type of css like background color, font family, etc.,
	 * @param status        - status of the request
	 * @param expectedColor - expected color of the status
	 * @throws Exception
	 */
	public void verifyStatusBackgroundColor(String typeOfCss, String status, String expectedColor) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String requestNumber = Constants.getRequestNumber();
			System.out.println("Req Number:" + requestNumber);


			String statusXpath = findRequestById.replace("<<RequestId>>", requestNumber)
					+ "/following-sibling::td[1]/nz-tag";
			WebElement statusElement = driver.findElement(By.xpath(statusXpath));
			String actualStatus = WebAction.getText(statusElement).trim();
			if (!(actualStatus.equalsIgnoreCase(status))) {
				throw new Exception("Status of the request is not correct. Expected status is '" + status
						+ "' and actual status is '" + actualStatus + "'");
			}
			CommonValidations.verifyCssValueOfWebElement(statusElement, typeOfCss, expectedColor);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To logout of the application
	 * 
	 * @throws Exception
	 */
	public void logOut() throws Exception {
		WebAction.click(profileIcon);
		WebAction.click(logOutButton);
		WebAction.switchToFrame("header");
		Waits.waitForElement(logOutMessage, WAIT_CONDITIONS.VISIBLE);
		WebAction.switchToDefaultContent();
	}

	/**
	 * To search the request in requester table
	 * 
	 * @throws Exception
	 */
	public void searchRequest() throws Exception {
		try {
			String requestNumber = Constants.getRequestNumber();
			WebAction.click(searchTextBox);
			Waits.waitUntilElementSizeGreater(myRequestRows, 0);
			WebAction.sendKeys(searchTextBox, requestNumber);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click edit link of the request
	 * 
	 * @throws Exception
	 */
	public void clickEditLink() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String requestNumber = Constants.getRequestNumber();
			Waits.waitForElement(By.xpath(findRequestById.replace("<<RequestId>>", requestNumber)),
					WAIT_CONDITIONS.CLICKABLE);

			// To click edit link
			String editLinkXpath = findRequestById.replace("<<RequestId>>", requestNumber)
					+ "/following-sibling::td[a[text()='Edit']]/a";
			Waits.waitForElement(By.xpath(editLinkXpath), WAIT_CONDITIONS.CLICKABLE);
			WebAction.click(driver.findElement(By.xpath(editLinkXpath)));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To view crew request
	 * @throws Exception
	 */
	public void clickViewLink() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String requestNumber = Constants.getRequestNumber();

			// To click view link
			String editLinkXpath = viewRequestId.replace("<<RequestId>>", requestNumber);
			Waits.waitForElement(By.xpath(editLinkXpath), WAIT_CONDITIONS.CLICKABLE);
			WebAction.click(driver.findElement(By.xpath(editLinkXpath)));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
