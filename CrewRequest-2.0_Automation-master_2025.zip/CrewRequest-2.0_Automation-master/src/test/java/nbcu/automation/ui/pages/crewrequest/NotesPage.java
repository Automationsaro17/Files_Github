package nbcu.automation.ui.pages.crewrequest;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.crewrequest.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.Other.DateFunctions;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class NotesPage {

	// Notes page button
	@FindBy(xpath = "//p[text()='Requester Notes']")
	WebElement requesterNotesTitle;

	@FindBy(xpath = "//*[@placeholder='Add Notes here.....']")
	WebElement notesTextBox;

	@FindBy(xpath = "//span[contains(text(),'Submit')]")
	WebElement submitButton;

	@FindBy(xpath = "//p[text()='Requester Notes']/following-sibling::div[1]//div[@role='tab']")
	WebElement requesterNotesDate;

	@FindBy(xpath = "//p[text()='Requester Notes']/following-sibling::div[1]//button[@nztype='primary']")
	List<WebElement> requesterNotesTime;

	@FindBy(xpath = "//p[text()='Requester Notes']/following-sibling::div[1]//p[@class='comments']")
	List<WebElement> requesterNotesElements;

	@FindBy(xpath = "//p[text()='Requester Notes']/following-sibling::div[1]//div[@class='user-row']//label")
	List<WebElement> requesterNotesUserName;

	@FindBy(xpath = "//p[text()='Requester Notes']/following-sibling::div[1]//button[contains(@class,'editButton')]")
	List<WebElement> requesterNotesEditButton;

	@FindBy(xpath = "//p[text()='Requester Notes']/following-sibling::div[1]//button[contains(@class,'deleteButton')]")
	List<WebElement> requesterNotesDeleteButton;

	@FindBy(xpath = "//p[text()='Fulfillment Notes']/following-sibling::div[1]//div[@role='tab']")
	WebElement fulfillmentNotesDate;

	@FindBy(xpath = "//p[text()='Fulfillment Notes']/following-sibling::div[1]//button[@nztype='primary']")
	List<WebElement> fulfillmentNotesTime;

	@FindBy(xpath = "//p[text()='Fulfillment Notes']/following-sibling::div[1]//p[@class='comments']")
	List<WebElement> fulfillmentNotesElements;

	@FindBy(xpath = "//p[text()='Fulfillment Notes']/following-sibling::div[1]//button[contains(@class,'editButton')]")
	List<WebElement> fulfillmentNotesEditButton;

	@FindBy(xpath = "//p[text()='Fulfillment Notes']/following-sibling::div[1]//button[contains(@class,'deleteButton')]")
	List<WebElement> fulfillmentNotesDeleteButton;

	@FindBy(xpath = "//p[text()='Fulfillment Notes']/following-sibling::div[1]//div[@class='user-row']//label")
	List<WebElement> fulfillmentNotesUserName;

	@FindBy(xpath = "//*[text()='Note Updated']")
	WebElement noteUpdateMessage;

	// Profile icons
	@FindBy(xpath = "//nz-avatar[i[*[@data-icon='user']]]")
	WebElement profileIcon;

	@FindBy(xpath = "//button[contains(text(),'Logout')]/preceding-sibling::p/strong")
	WebElement loggedInUserName;

	public NotesPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify notes page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyNotesPageDisplayed() throws Exception {
		Waits.waitForElement(requesterNotesTitle, WAIT_CONDITIONS.VISIBLE);
	}

	/**
	 * To add requester/fulfiller notes
	 * 
	 * @param requesterNotes - Requester/Fulfiller notes
	 * @return
	 * @throws Exception
	 */
	public void addNotes(String noteType, DataTable dateTable) throws Exception {
		try {
			List<Map<String, String>> notesList = CucumberUtils.getValuesFromDataTableAsList(dateTable);
			if (noteType.equalsIgnoreCase("REQUESTER"))
				Constants.setRequesterNotesCount(notesList.size());
			else
				Constants.setFulfillerNotesCount(notesList.size());
			for (int i = 0; i < notesList.size(); i++) {
				String note = notesList.get(i).get("Notes");
				if (noteType.equalsIgnoreCase("REQUESTER"))
					Constants.setRequesterNotes(i + 1, note);
				else
					Constants.setFulfillerNotes(i + 1, note);
				WebAction.sendKeys(notesTextBox, note);
				WebAction.click(submitButton);
				String currentTime = DateFunctions.getCurrentDate("h:mma");
				if (noteType.equalsIgnoreCase("REQUESTER"))
					Constants.setRequesterNotesTime(i + 1, currentTime);
				else
					Constants.setFulfillerNotesTime(i + 1, currentTime);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify requester notes added correctly
	 * 
	 * @param requesterNotes
	 * @throws Exception
	 */
	public void verifyRequesterNotesAdded() throws Exception {
		try {
			int count = Constants.getRequesterNotesCount();
			for (int i = 0; i < Constants.getRequesterNotesCount(); i++) {
				String requesterNotes = Constants.getRequesterNotes(count);

				WebAction.click(profileIcon);
				String userName = WebAction.getText(loggedInUserName);

				// To validate date under requester notes tab
				String currentDate = DateFunctions.getCurrentDate("MM/dd/yyyy");
				CommonValidations.verifyTextValue(requesterNotesDate, currentDate,
						"Requester note '" + requesterNotes + "' is not present under date '" + currentDate + "'");

				// To validate time under requester notes tab
				String expectedTime = Constants.getRequesterNotesTime(count);
				CommonValidations.verifyTextValue(requesterNotesTime.get(i), expectedTime,
						"Requester note '" + requesterNotes + "' added/updated time is not correct");

				// To validate added requester note
				CommonValidations.verifyTextValue(requesterNotesElements.get(i), requesterNotes,
						"Requester note '" + requesterNotes + "' is not present under Requester notes section");

				// To Validate notes added user name
				CommonValidations.verifyTextValue(requesterNotesUserName.get(i), userName,
						"Requester name '" + userName + "' is not correct for note '" + requesterNotes
								+ "' under requester notes section");
				count--;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify fulfillment notes added correctly
	 * 
	 * @throws Exception
	 */
	public void verifyFulfillerNotesAdded() throws Exception {
		try {
			int count = Constants.getFulfillerNotesCount();

			WebAction.click(profileIcon);
			String userName = WebAction.getText(loggedInUserName);

			for (int i = 0; i < Constants.getFulfillerNotesCount(); i++) {
				String fulfillerNotes = Constants.getFulfillerNotes(count);

				// To validate date under requester notes tab
				String currentDate = DateFunctions.getCurrentDate("MM/dd/yyyy");
				CommonValidations.verifyTextValue(fulfillmentNotesDate, currentDate,
						"Fulfiller note '" + fulfillerNotes + "' is not present under date '" + currentDate + "'");

				// To validate time under requester notes tab
				String expectedTime = Constants.getFulfillerNotesTime(count);
				CommonValidations.verifyTextValue(fulfillmentNotesTime.get(i), expectedTime,
						"Fulfiller note '" + fulfillerNotes + "' added/updated time is not correct");

				// To validate added requester note
				CommonValidations.verifyTextValue(fulfillmentNotesElements.get(i), fulfillerNotes,
						"Fulfiller note '" + fulfillerNotes + "' is not present under fulfillment notes section");

				// To Validate notes added user name
				CommonValidations.verifyTextValue(fulfillmentNotesUserName.get(i), userName,
						"Fulfiller name '" + userName + "' is not correct for note '" + fulfillerNotes
								+ "' under fulfillment notes section");
				count--;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To update existing notes
	 * 
	 * @param noteType - Requester/Fulfiller
	 * @throws Exception
	 */
	public void editNotes(String noteType) throws Exception {
		try {
			if (noteType.equalsIgnoreCase("REQUESTER")) {
				int count = Constants.getRequesterNotesCount();
				for (int i = 0; i < Constants.getRequesterNotesCount() - 1; i++) {
					WebAction.click(requesterNotesEditButton.get(i));
					String UpdatedNote = Constants.getRequesterNotes(count) + "-Updated";
					Constants.setRequesterNotes(count, UpdatedNote);
					WebAction.sendKeys(notesTextBox, UpdatedNote);
					WebAction.click(submitButton);
					Constants.setRequesterNotesTime(count, DateFunctions.getCurrentDate("h:mma"));
					Waits.waitForElement(noteUpdateMessage, WAIT_CONDITIONS.VISIBLE);
					count--;
				}
			} else {
				int count = Constants.getFulfillerNotesCount();
				for (int i = 0; i < Constants.getFulfillerNotesCount() - 1; i++) {
					WebAction.click(fulfillmentNotesEditButton.get(i));
					String UpdatedNote = Constants.getFulfillerNotes(count) + "-Updated";
					Constants.setFulfillerNotes(count, UpdatedNote);
					WebAction.sendKeys(notesTextBox, UpdatedNote);
					WebAction.click(submitButton);
					Constants.setFulfillerNotesTime(count, DateFunctions.getCurrentDate("h:mma"));
					Waits.waitForElement(noteUpdateMessage, WAIT_CONDITIONS.VISIBLE);
					count--;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To delete requester/fulfillment notes
	 * 
	 * @param noteType - requester/fulfillment
	 * @throws Exception
	 */
	public void deleteNotes(String noteType) throws Exception {
		try {
			if (noteType.equalsIgnoreCase("REQUESTER")) {
				int count = Constants.getRequesterNotesCount();
				WebAction.click(requesterNotesDeleteButton.get(0));
				Constants.setRequesterNotes(count, "");
				Constants.setRequesterNotesTime(count, "");
				Constants.setRequesterNotesCount(count - 1);

			} else {
				int count = Constants.getFulfillerNotesCount();
				WebAction.click(fulfillmentNotesDeleteButton.get(0));
				Constants.setFulfillerNotes(count, "");
				Constants.setFulfillerNotesTime(count, "");
				Constants.setFulfillerNotesCount(count - 1);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify requester/fulfiller note is deleted
	 * 
	 * @param noteType
	 * @throws Exception
	 */
	public void verifyNotesDeleted(String noteType) throws Exception {
		try {
			if (noteType.equalsIgnoreCase("REQUESTER")) {
				Assert.assertEquals(requesterNotesElements.size(), Constants.getRequesterNotesCount(),
						"Requester note is not deleted");
				verifyRequesterNotesAdded();
			} else {
				Assert.assertEquals(fulfillmentNotesElements.size(), Constants.getFulfillerNotesCount(),
						"Fulfillment note is not deleted");
				verifyFulfillerNotesAdded();
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
