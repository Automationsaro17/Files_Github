package nbcu.automation.ui.pages.storm;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.automation.ui.constants.crewrequest.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.Other.DateFunctions;

public class StormHomePage {

	// Home page frames
	@FindBy(id = "oFrame")
	WebElement parentFrame;

	@FindBy(id = "Title")
	WebElement titleFrame;

	@FindBy(id = "Contents")
	WebElement contentsFrame;

	@FindBy(name = "Menu")
	WebElement menuFrame;

	@FindBy(name = "Details")
	WebElement detailsFrame;

	@FindBy(name = "ResTbl")
	WebElement messageFrame;

	@FindBy(id = "JobElementsList")
	WebElement jobDetailsFrame;

	@FindBy(id = "JobElementDetails")
	WebElement jobElementDetailsFrame;

	// Side Menus Elements
	@FindBy(xpath = "//*[@id='Requests']/a")
	WebElement requestsLink;

	@FindBy(xpath = "//a[text()='General Request']")
	WebElement generalRequestLink;

	@FindBy(xpath = "//a[text()='Find request']")
	WebElement findRequestLink;

	// Content Elements
	@FindBy(id = "ProdReqNumber")
	WebElement prodReqNumberTextBox;

	@FindBy(xpath = "//td[text()='Request not found.']")
	WebElement requestNotFoundMessage;

	@FindBy(name = "Search")
	WebElement searchButton;

	// Request Details
	@FindBy(xpath = "//span[@id='BaseDate']/b/u")
	WebElement requestDate;

	@FindBy(xpath = "//span[starts-with(text(),'ProdReq #')]")
	WebElement requestNumber;

	@FindBy(xpath = "//span[@id='Dates']")
	WebElement requestDateRange;

	@FindBy(id = "CostObjectName")
	WebElement showUnit;

	// Resource Details
	@FindBy(xpath = "//table[@id='JobElementsTable']/tbody/tr")
	List<WebElement> resourceRows;

	@FindBy(id = "lblStartDate")
	WebElement startDate;

	@FindBy(id = "StartTime")
	WebElement startTime;

	@FindBy(id = "EndTime")
	WebElement endTime;

	@FindBy(id = "TimeZoneId")
	WebElement timeZone;

	@FindBy(id = "PersonalComboText")
	WebElement resourceName;

	@FindBy(id = "JEComment")
	WebElement assignmentSlug;

	public StormHomePage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify storm home page is loaded
	 * 
	 * @throws Exception
	 */
	public void verifyStormHomePageLoaded() throws Exception {
		try {
			WebAction.switchToFrame(contentsFrame);
			WebAction.switchToFrame(menuFrame);
			Waits.waitForElement(requestsLink, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click link in the side menu
	 * 
	 * @param linkType
	 * @throws Exception
	 */
	public void clickLink(String linkType) throws Exception {
		try {
			switch (linkType.toUpperCase()) {
			case "REQUESTS":
				WebAction.click(requestsLink);
				break;
			case "GENERAL REQUEST":
				WebAction.click(generalRequestLink);
				break;
			case "FIND REQUEST":
				WebAction.click(findRequestLink);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To enter prod request number and click search button
	 * 
	 * @throws Exception
	 */
	public void seachProdReqNumber() throws Exception {
		try {
			WebAction.switchToDefaultContent();
			WebAction.switchToFrame(contentsFrame);
			WebAction.switchToFrame(detailsFrame);
			Waits.waitForElement(prodReqNumberTextBox, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(prodReqNumberTextBox, Constants.getRequestNumber());
			// WebAction.sendKeys(prodReqNumberTextBox, "CR202271851");
			WebAction.click(searchButton);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify there is record in the storm application
	 * 
	 * @throws Exception
	 */
	public void verifyRecordPresent() throws Exception {
		try {
			boolean requestFountCheck = WebAction.isDisplayed(requestNumber);
			Assert.assertTrue(requestFountCheck, "Request is not found in the storm application");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify record is not present in the storm
	 * 
	 * @throws Exception
	 */
	public void verifyRecordNotPresent() throws Exception {
		try {
			WebAction.switchToFrame(messageFrame);
			boolean requestNotFountCheck = WebAction.isDisplayed(requestNotFoundMessage);
			Assert.assertTrue(requestNotFountCheck, "Request is present in the storm application");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify request details in the storm application
	 * 
	 * @throws Exception
	 */
	public void verifyRequestDetails() throws Exception {
		try {
			CommonValidations.verifyTextValue(requestDate, Constants.getShootStartDate().replace("-", "/"),
					"Request Date in storm application is not correct");
			CommonValidations.verifyTextValue(requestNumber, Constants.getRequestNumber(),
					"Request Number in storm application is not correct");
			String expectedRequestDateRange = Constants.getShootStartDate().replace("-", "/") + " - "
					+ Constants.getShootEndDate().replace("-", "/");
			CommonValidations.verifyTextValue(requestDateRange, expectedRequestDateRange,
					"Request Date Range in storm application is not correct");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify total resource record count in storm application
	 * 
	 * @throws Exception
	 */
	public void verifyResourceRecordCount() throws Exception {
		try {
			// To verify record count
			WebAction.switchToFrame(jobDetailsFrame);

			int shootDaysCount = Constants.getShootDaysCount();
			int resourceCount = Constants.getResourcesCount();

			int expectedResourceRecordCount = shootDaysCount * resourceCount;
			int actualResourceRecordCount = resourceRows.size();

			CommonValidations.verifytextValue(actualResourceRecordCount, expectedResourceRecordCount,
					"Number resource record in storm application is not matching with expected count");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * 
	 * @throws Exception
	 */
	public List<LinkedHashMap<String, String>> fetchResourceDetails() throws Exception {
		List<LinkedHashMap<String, String>> actualResourceDetails = new ArrayList<LinkedHashMap<String, String>>();
		try {
			for (int i = 0; i < resourceRows.size(); i++) {
				WebAction.click(resourceRows.get(i));
				WebAction.switchToDefaultContent();
				WebAction.switchToFrame(contentsFrame);
				WebAction.switchToFrame(detailsFrame);
				WebAction.switchToFrame(jobElementDetailsFrame);

				LinkedHashMap<String, String> resourceDetails = new LinkedHashMap<String, String>();
				Waits.waitForElement(startDate, WAIT_CONDITIONS.CLICKABLE);
				resourceDetails.put("Start Date", WebAction.getAttribute(startDate, "value"));
				resourceDetails.put("Start Time", WebAction.getAttribute(startTime, "value"));
				resourceDetails.put("End Time", WebAction.getAttribute(endTime, "value"));
				resourceDetails.put("Time Zone", WebAction.getSelectedValueFromDropdowm(timeZone));
				resourceDetails.put("Resource Name", WebAction.getAttribute(resourceName, "value"));
				resourceDetails.put("Assignment slug", WebAction.getText(assignmentSlug));
				actualResourceDetails.add(resourceDetails);

				WebAction.switchToDefaultContent();
				WebAction.switchToFrame(contentsFrame);
				WebAction.switchToFrame(detailsFrame);
				WebAction.switchToFrame(jobDetailsFrame);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return actualResourceDetails;
	}

	/**
	 * To verify resource details in storm application
	 * 
	 * @throws Exception
	 */
	public void verifyResourceDetails() throws Exception {
		try {

			// Expected values
			List<String> expectedShootDates = DateFunctions.getDateListBetweenDates(
					Constants.getShootStartDate().replace("-", "/"), Constants.getShootEndDate().replace("-", "/"),
					"MM/dd/yyyy");
			String expectedShootStartTime = DateFunctions.addOrMinusTimeFromGivenTime(Constants.getShootStartTime(),
					"hh:mm a", "-1");
			String expectedShootEndTime = DateFunctions.addOrMinusTimeFromGivenTime(Constants.getShootEndTime(),
					"hh:mm a", "1");
			String expectedAssignmentSlug = Constants.getAssignmentSlug();
			String timeZone = Constants.getShootTimeZone();
			String expectedTimeZone = timeZone.substring(timeZone.indexOf("(") + 1, timeZone.indexOf(")"));

			// Actual values
			List<LinkedHashMap<String, String>> actualResourceDetails = fetchResourceDetails();
			System.out.println(actualResourceDetails);

			for (int i = 0; i < Constants.getResourcesCount(); i++) {
				String expectedResourceName = Constants.getCrewResourceName(i + 1);
				for (int j = 0; j < expectedShootDates.size(); j++) {
					String expectedShootdate = expectedShootDates.get(j);
					boolean resourceRecoundFound = false;
					for (int z = 0; z < actualResourceDetails.size(); z++) {
						if ((actualResourceDetails.get(j).get("Resource Name").toLowerCase()
								.contains(expectedResourceName.toLowerCase()))
								&& (actualResourceDetails.get(j).get("startDate")
										.equalsIgnoreCase(expectedShootdate))) {
							resourceRecoundFound = true;
							break;
						}
					}
					if (resourceRecoundFound) {
						if (actualResourceDetails.get(j).get("Start Time").equalsIgnoreCase(expectedShootStartTime)) {
							if (actualResourceDetails.get(j).get("End Time").equalsIgnoreCase(expectedShootEndTime)) {
								if (actualResourceDetails.get(j).get("Time Zone").equalsIgnoreCase(expectedTimeZone)) {
									if (actualResourceDetails.get(j).get("Assignment Slug")
											.equalsIgnoreCase(expectedAssignmentSlug)) {
										// do nothing
									} else
										Assert.assertTrue(false, "Storm record for '" + expectedResourceName
												+ "' resource and date '" + expectedShootdate
												+ "' is found. But assignment slug is not matching. Expected assignment slug is '"
												+ expectedAssignmentSlug + "' and Actual assignment slug is '"
												+ actualResourceDetails.get(j).get("Assignment Slug") + "'");
								} else
									Assert.assertTrue(false, "Storm record for '" + expectedResourceName
											+ "' resource and date '" + expectedShootdate
											+ "' is found. But time zone is not matching. Expected time zone is '"
											+ expectedTimeZone + "' and Actual time zone is '"
											+ actualResourceDetails.get(j).get("Time Zone") + "'");
							} else
								Assert.assertTrue(false,
										"Storm record for '" + expectedResourceName + "' resource and date '"
												+ expectedShootdate
												+ "' is found. But end time is not matching. Expected end time is '"
												+ expectedShootEndTime + "' and Actual end time is '"
												+ actualResourceDetails.get(j).get("End Time") + "'");
						} else
							Assert.assertTrue(false,
									"Storm record for '" + expectedResourceName + "' resource and date '"
											+ expectedShootdate
											+ "' is found. But start time is not matching. Expected start time is '"
											+ expectedShootStartTime + "' and Actual start time is '"
											+ actualResourceDetails.get(j).get("Start Time") + "'");
					} else {
						Assert.assertTrue(false, "Storm record for '" + expectedResourceName + "' resource and date '"
								+ expectedShootdate + "' is missing");
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Verify resource record is empty
	 * 
	 * @throws Exception
	 */
	public void verifyResourceRecordIsEmpty() throws Exception {
		try {
			int actualResourceRecordCount = resourceRows.size();
			if (actualResourceRecordCount != 0)
				Assert.assertTrue(false, "Resource records are present in the storm application");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
