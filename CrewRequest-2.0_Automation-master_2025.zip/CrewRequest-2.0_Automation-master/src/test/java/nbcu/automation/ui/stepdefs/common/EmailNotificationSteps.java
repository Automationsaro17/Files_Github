package nbcu.automation.ui.stepdefs.common;

import io.cucumber.java.en.Then;
import nbcu.automation.ui.validation.common.EmailValidation;

public class EmailNotificationSteps {

	@Then("verify email notification is received for {string} with {string} status")
	public void verifyEmailReceived(String formName, String status) throws Exception {
		EmailReader.readEmailList(formName, status);
	}
	
	@Then("verify email notification {string} list for {string} with {string} status")
	public void verifyEmailToAndCcList(String emailListType, String formName, String status) throws Throwable {
		if(emailListType.equalsIgnoreCase("TO"))
			EmailValidation.verifyEmailToList(formName, status);
		else
			EmailValidation.verifyEmailCCList(formName, status);
	}
	
	@Then("verify email notification {string} for {string} with {string} status")
	public void verifyEmailSubject(String emailSubjectOrBody, String formName, String status) throws Throwable {
		if(emailSubjectOrBody.equalsIgnoreCase("SUBJECT"))
			EmailValidation.verifyEmailSubject(formName);
		else
			EmailValidation.verifyEmailContent(formName, status);
	}
}
