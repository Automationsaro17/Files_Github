package nbcu.automation.ui.stepdefs.common;

import io.cucumber.java.en.Given;
import nbcu.automation.ui.pages.crewrequest.FulfillerDashboardPage;
import nbcu.automation.ui.pages.crewrequest.LoginPage;
import nbcu.automation.ui.pages.crewrequest.MyRequestPage;

public class LoginPageSteps {

	LoginPage loginPage = new LoginPage();
	MyRequestPage myRequestPage = new MyRequestPage();
	FulfillerDashboardPage fulfillerPage = new FulfillerDashboardPage();

	@Given("user opens {string} application")
	public void openProdReqApp(String applicationName) throws Exception {
		loginPage.openApplication(applicationName);
	}

	@Given("user logins with {string} role")
	public void loginIntoProdReqApp(String role) throws Exception {
		loginPage.loginIntoApplication(role);
		if (role.equalsIgnoreCase("PRODUCER"))
			myRequestPage.verifyMyRequestsPageDisplayed();
		else if(role.equalsIgnoreCase("FULFILLER"))
			fulfillerPage.verifyCrewDashboardPageDisplayed();
	}
}
