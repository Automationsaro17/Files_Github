package nbcu.automation.ui.stepdefs.crewrequest;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.constants.crewrequest.Constants;
import nbcu.automation.ui.pages.crewrequest.AdminDashboardPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class AdminDashboardPageSteps {

	AdminDashboardPage adminDashboardPage = new AdminDashboardPage();

	@When("user enter details to add a New Show")
	public void fillNewShowDetailsToAdd( DataTable dataTable) throws Exception {
		adminDashboardPage.fillShowDetails(
				CucumberUtils.getValuesFromDataTable(dataTable, "Business"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Budget Code"));
	}
	
	@Then("user delete the show unit")
	public void deleteShowUnit() throws Exception {
		adminDashboardPage.deleteShowUnit(Constants.getShowUnit());
	}
	
	@Then("verify the show unit is added")
	public void verifyShowIsPresent() throws Exception {
		adminDashboardPage.verifyShowIsPresent(Constants.getShowUnit());
	}
	
	@And("user enters Exec Dash details")
	public void fillExecDashDetails(DataTable dataTable) throws Exception {
		adminDashboardPage.fillExecDashDetailsInAdminDashboardPage(Constants.getShowUnit(),
				CucumberUtils.getValuesFromDataTable(dataTable, "Allocation"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Threshold"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Reminder"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Recipients"));
	}
	
}
