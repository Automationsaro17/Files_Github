package nbcu.automation.ui.stepdefs.crewrequest;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.constants.crewrequest.Constants;
import nbcu.automation.ui.pages.crewrequest.AdminDashboardPage;
import nbcu.automation.ui.pages.crewrequest.CrewRequestFormPage;
import nbcu.automation.ui.pages.crewrequest.FulfillerDashboardPage;
import nbcu.automation.ui.pages.crewrequest.LoginPage;
import nbcu.automation.ui.pages.crewrequest.NotesPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class CrewRequestFormPageSteps {

	CrewRequestFormPage generalCrewRequestPage = new CrewRequestFormPage();
	FulfillerDashboardPage fulfillerDashboardPage = new FulfillerDashboardPage();
	AdminDashboardPage adminDashboardPage = new AdminDashboardPage();
	LoginPage loginPage = new LoginPage();
	NotesPage notesPage = new NotesPage();

	@When("user enters producer info in WHO section")
	public void fillProducerInfoInWhoSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.fillProducerInfoSection(
				CucumberUtils.getValuesFromDataTable(dataTable, "Producer / Field Contact Same as Requester?"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Producer Name"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Is there an on-site Producer?"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Has this been approved by your Senior?"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Senior Producer / Approver"));
	}

	@When("user enters talent info in WHAT section")
	public void fillTalentInfoInWhatSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.fillTalenSection(CucumberUtils.getValuesFromDataTable(dataTable, "Talent"));
	}

	@When("user enters shoot details in WHAT section")
	public void fillShootDetailsInWhatSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.fillShootDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Production Type"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Shoot Status"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Shoot Type"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Attach Edit Request Id"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Assignment Slug"),
				CucumberUtils.getValuesFromDataTable(dataTable, "NCX Story Name"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Shoot Description"));
	}

	@When("user enters shoot specs in WHAT section")
	public void fillShootSpecsInWhatSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.fillShootSpecs(CucumberUtils.getValuesFromDataTable(dataTable, "Audio Needs"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Special Conditions"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Transmission Type"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Primary Camera Type"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Color Space"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Drone Shoot"),
				CucumberUtils.getValuesFromDataTable(dataTable, "360 camera"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Ipad Promoter"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Special Gear"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Special Gear Notes"));
	}

	@When("user enters location info in WHERE section")
	public void fillLocationInfoInWhereSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.fillLocation(CucumberUtils.getValuesFromDataTable(dataTable, "Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Address Line 1"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Address Notes"),
				CucumberUtils.getValuesFromDataTable(dataTable, "City"),
				CucumberUtils.getValuesFromDataTable(dataTable, "State"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Zip Code"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Country"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Risk Assessment Category"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Risk Assessment Type"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Risk Arrangements"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Risk Approver"));
	}

	@When("user enter comment in OTHER section")
	public void commentInOtherSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.fillComment(CucumberUtils.getValuesFromDataTable(dataTable, "Comment"));
	}

	@When("user enters date and time info in WHEN section")
	public void fillDateAndTimeInWhenSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.fillDateAndTime(CucumberUtils.getValuesFromDataTable(dataTable, "Start Date"),
				CucumberUtils.getValuesFromDataTable(dataTable, "End Date"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Time Zone"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Meet Time"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Start Time"),
				CucumberUtils.getValuesFromDataTable(dataTable, "End Time"));
	}

	@When("user clicks on {string} button")
	public void clickButton(String buttonName) throws Exception {
		generalCrewRequestPage.clickButton(buttonName);
	}

	@Then("verify request is {string} successfully")
	public void verifySumissionMessage(String status) throws Exception {
		generalCrewRequestPage.verifyFormSuccessMessage(status);
	}

	@When("user enters shoot specs in FULFILLMENT section")
	public void fillShootSpecsInFulfillmentsection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.fillFulfillmentSection(
				CucumberUtils.getValuesFromDataTable(dataTable, "Primary Camera Type"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Media Format"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Video Specs"));
	}

	@Then("user changes status to {string}")
	public void updateStatus(String status) throws Exception {
		generalCrewRequestPage.statusUpdate(status);
	}

	@When("verify {string} alert message")
	public void verifyAlertMessage(String action, DataTable dataTable) throws Exception {
		String alertMessage = "";
		if (action.equalsIgnoreCase("CANCEL REQUEST"))
			alertMessage = CucumberUtils.getValuesFromDataTable(dataTable, "Cancel Request Alert Message");
		else if (action.equalsIgnoreCase("SEND TO STORM"))
			alertMessage = CucumberUtils.getValuesFromDataTable(dataTable, "Send To Storm Alert Message");
		else
			alertMessage = CucumberUtils.getValuesFromDataTable(dataTable, "Confirm Cancellation Alert Message");
		generalCrewRequestPage.verifyAlertMessage(action, alertMessage);
	}

	@When("click {string} on {string} alert message")
	public void confirmationInAletMessage(String option, String cancelStatus) throws Exception {
		generalCrewRequestPage.confirmationInAlertmessage(option);
	}

	@Then("verify missing fields error popup is displayed")
	public void verifyMissingFieldsPopup() throws Exception {
		generalCrewRequestPage.verifyOverallMissingFieldErrorPopup();
	}

	@Then("verify application highlights below section as incomplete")
	public void verifyApplicationHighlightsAsIncomplete(DataTable dataTable) throws Exception {
		List<Map<String, String>> sectionNames = CucumberUtils.getValuesFromDataTableAsList(dataTable);
		for (int i = 0; i < sectionNames.size(); i++) {
			generalCrewRequestPage.verifySectionNameHighlightedInRedColor(sectionNames.get(i).get("section"));
		}
	}

	@Then("Verify error message is displayed for all mandatory fields of producer info in WHO section")
	public void verifyProducerInfoMissingFieldErrorInWhoSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.verifyProducerInfoMissingFieldError(
				CucumberUtils.getValuesFromDataTable(dataTable, "Producer / Field Contact Same as Requester? Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Is there an on-site Producer? Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Senior Producer / Approver Error"));
	}

	@Then("Verify error message is displayed for all mandatory fields of show info in WHAT section")
	public void verifyShowInfoMissingFieldErrorInWhatSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.verifyShowInfoMissingFieldError(
				CucumberUtils.getValuesFromDataTable(dataTable, "Show Unit Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Budget Code Error"));
	}

	@Then("Verify error message is displayed for all mandatory fields of talent info in WHAT section")
	public void verifyTalentMissingFieldErrorInWhatSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage
				.verifyTalentMissingFieldError(CucumberUtils.getValuesFromDataTable(dataTable, "Search Talent Error"));
	}

	@Then("Verify error message is displayed for all mandatory fields of shoot details in WHAT section")
	public void verifyShootDetailsMissingFieldErrorInWhatSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.verifyShootDetailsMissingFieldError(
				CucumberUtils.getValuesFromDataTable(dataTable, "Production Type Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Assignment Slug Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Shoot Description Error"));
	}

	@Then("Verify error message is displayed for all mandatory fields of shoot specs in WHAT section")
	public void verifyShootSpecsMissingFieldErrorInWhatSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.verifyShootSpecsMissingFieldError(
				CucumberUtils.getValuesFromDataTable(dataTable, "Audio Needs Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Special Conditions Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Transmission Type Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Primary Camera Type Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Drone Shoot Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Camera 360 Error"));
	}

	@Then("Verify error message is displayed for all mandatory fields of location info in WHERE section")
	public void verifyLocationMissingFieldErrorInWhatSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.verifyLocationMissingFieldError(
				CucumberUtils.getValuesFromDataTable(dataTable, "Address Line1 Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "City Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "State Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Country Error"));
	}

	@Then("Verify error message is displayed for all mandatory fields of date and time info in WHEN section")
	public void verifyDateAndTimeMissingFieldErrorInWhatSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.verifyDateAndTimeMissingFieldError(
				CucumberUtils.getValuesFromDataTable(dataTable, "Shoot Date Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Time zone Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Meet Time Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Start Time Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "End Time Error"));
	}

	@Then("user enters show details in WHAT section")
	public void fillShowIDetailsnWhatSection() throws Exception {
		generalCrewRequestPage.fillShowInfoSection(Constants.getShowUnit());
	}

	@When("user enters show info in WHAT section")
	public void fillShowInfoInWhatSection(DataTable dataTable) throws Exception {
		generalCrewRequestPage.fillShowInfoSection(CucumberUtils.getValuesFromDataTable(dataTable, "Show Unit"));
	}

	@When("user add resources in FULFILLMENT section")
	public void addResources(DataTable dataTable) throws Exception {
		generalCrewRequestPage.addResourcesFulfillmentSection(dataTable);

	}

	@Then("verify storm {string} message is displayed")
	public void verifySendToStormMessage(String message) throws Exception {
		if (message.toUpperCase().contains("SUCCESS"))
			generalCrewRequestPage.verifyStormSuccessMessage();
		else if (message.toUpperCase().contains("BUDGET CODE ERROR"))
			generalCrewRequestPage.verifyStormBudgetCodeFailureMessage();
		else if (message.toUpperCase().contains("SSO NOT FOUND ERROR"))
			generalCrewRequestPage.verifySsoNotFoundFailureMessage();
		loginPage.openStormApplicationBrowser();

	}

	@Then("user clicks {string} tab")
	public void clickTabInRequestScreen(String tabName) throws Exception {
		generalCrewRequestPage.selectTab(tabName);
		if (tabName.equalsIgnoreCase("NOTES"))
			notesPage.verifyNotesPageDisplayed();
	}

	@Then("verify {string} section details of {string}")
	public void verifyINewsInfoSection(String sectionName, String formName) throws Throwable {
		if (sectionName.equalsIgnoreCase("INEWS INFO"))
			generalCrewRequestPage.verifyINewsInfoSection(formName);
		else
			generalCrewRequestPage.verifyTitleSection(formName);
	}
	
	@Then("verify copied content of {string} section")
	public void verifyCopiedContent(String sectionName, DataTable params) throws Throwable {
		if (sectionName.equalsIgnoreCase("INEWS INFO"))
			generalCrewRequestPage.verifyINewsInfoCopiedContent(CucumberUtils.getValuesFromDataTable(params, "Form Name"));
		else
			generalCrewRequestPage.verifyTitleCopiedContent(CucumberUtils.getValuesFromDataTable(params, "Form Name"));
	}

}
