package nbcu.automation.ui.stepdefs.crewrequest;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.crewrequest.ExecutiveDashboardPage;

public class ExecutiveDashboardPageSteps {

	ExecutiveDashboardPage executiveDashboardPage=new ExecutiveDashboardPage();
	
	@When("user selects show unit in executive dashboard page")
	public void selectShowUnit() throws Exception {
		executiveDashboardPage.selectShowUnit();
	}
	
	@Then("verify resource allocation is reached threshold percentage")
	public void verifiyThresholdReached() throws Exception {
		executiveDashboardPage.verifiyResourceAllocationReachedThreshold();
	}
	
	@Then("verify allocation percentage is displayed in {string} color")
	public void verifyAllocationCircleColor(String color) throws Exception {
		executiveDashboardPage.verifyAllocationCircleColor(color);
	}
	
}
