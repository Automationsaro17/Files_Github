package nbcu.automation.ui.stepdefs.crewrequest;

import io.cucumber.java.en.Given;
import nbcu.automation.ui.pages.crewrequest.CrewRequestFormPage;
import nbcu.automation.ui.pages.crewrequest.FormSelectionPage;
import nbcu.automation.ui.pages.crewrequest.LoginPage;

public class FormSelectionPageSteps {

	FormSelectionPage formSelectionPage = new FormSelectionPage();
	CrewRequestFormPage generalCrewRequestPage=new CrewRequestFormPage();
	LoginPage loginPage=new LoginPage();
	
	@Given("user selects {string} form")
	public void selectForm(String formName) throws Exception {
		formSelectionPage.selectCrewRequestForm(formName);
		generalCrewRequestPage.verifyGeneralCrewRequestPageDisplayed(formName);
	}
}
