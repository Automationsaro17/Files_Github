package nbcu.automation.ui.stepdefs.crewrequest;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.crewrequest.FulfillerDashboardPage;

public class FulfillerDashboardPageSteps {

	FulfillerDashboardPage fulfillerPage=new FulfillerDashboardPage();
	
	@Given("user opens fulfiller dashboard for {string} form")
	public void openDashboard(String formName) throws Exception {
		fulfillerPage.openDashboard(formName);
	}
	
	@Given("user opens executive dashboard")
	public void openExecutiveDashboard() throws Exception {
		fulfillerPage.openExecutiveDashboard();
	}
	 
	@When("user searches request in fulfiller dashboard")
	public void searchRequestInFulfillerDashboard() throws Exception {
		fulfillerPage.searchRequest();
	}
	
	@Then("verify {string} is present in fulfiller dashboard")
	public void verifyRequestIsPresnt(String formName) throws Exception {
		fulfillerPage.verifyRequestInfulfillerDashboard(formName);
	}
	
	@Then("verify {string} of {string} status is {string} in fullfiller dashboard")
	public void verifyStatusColor(String cssType, String status, String expectedColor) throws Exception {
		fulfillerPage.verifyStatusBackgroundColor(cssType, status, expectedColor);
	}
	
	@Then("user opens {string} tab in fulfiller table")
	public void openFulfillerTableTab(String tabName) throws Exception {
		fulfillerPage.selectTabInFulfillerTable(tabName);
	}
	
	@When("user clicks on {string} menu")
	public void clickMenuItem(String menuItemName) throws Exception {
		fulfillerPage.clickMenuItem(menuItemName);
	}
}
