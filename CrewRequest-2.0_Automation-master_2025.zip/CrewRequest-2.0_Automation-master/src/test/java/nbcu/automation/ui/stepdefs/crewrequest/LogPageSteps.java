package nbcu.automation.ui.stepdefs.crewrequest;

import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.crewrequest.LogPage;

public class LogPageSteps {

	LogPage logsPage = new LogPage();

	@When("verify logs are displayed correctly for {string} status")
	public void addNotes(String status) throws Exception {
		logsPage.verifyLogDetails(status);
	}
}
