package nbcu.automation.ui.stepdefs.crewrequest;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import nbcu.automation.ui.pages.crewrequest.FormSelectionPage;
import nbcu.automation.ui.pages.crewrequest.FulfillerDashboardPage;
import nbcu.automation.ui.pages.crewrequest.MyRequestPage;

public class MyRequestPageSteps {

	MyRequestPage myRequestPage = new MyRequestPage();
	FormSelectionPage formSelectionPage = new FormSelectionPage();
	FulfillerDashboardPage fulfillerPage = new FulfillerDashboardPage();

	@Given("user clicks on forms link")
	public void openFormsPage() throws Exception {
		myRequestPage.clickFormsButton();
		formSelectionPage.verifyFormSelectionPageDisplayed();
	}

	@Then("verify submitted {string} is present in my request page with {string} status")
	public void verifySubmittedRequestInMyRequestTable(String formName, String status) throws Exception {
		myRequestPage.verifyCrewRequestInmyRequestPage(formName, status);
	}

	@Then("verify {string} of {string} status is {string} in my request page")
	public void verifyStatusColor(String cssType, String status, String expectedColor) throws Exception {
		myRequestPage.verifyStatusBackgroundColor(cssType, status, expectedColor);
	}

	@Then("user logs out from application")
	public void logout() throws Exception {
		myRequestPage.logOut();
	}

	@Given("user searches request in my request page")
	public void searchRequest() throws Exception {
		myRequestPage.searchRequest();
	}

	@Given("user click {string} link of the request in {string}")
	public void clickEditLink(String action, String pageName) throws Exception {
		if (action.equalsIgnoreCase("EDIT")) {
			if (pageName.toUpperCase().contains("MY REQUEST"))
				myRequestPage.clickEditLink();
			else
				fulfillerPage.clickEditLink();
		} else {
			if (pageName.toUpperCase().contains("MY REQUEST"))
				myRequestPage.clickViewLink();
			else
				fulfillerPage.clickViewLink();
		}

	}
}
