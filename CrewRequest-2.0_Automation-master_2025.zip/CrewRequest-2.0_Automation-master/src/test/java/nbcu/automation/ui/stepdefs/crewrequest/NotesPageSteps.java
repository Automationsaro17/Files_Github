package nbcu.automation.ui.stepdefs.crewrequest;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.crewrequest.NotesPage;

public class NotesPageSteps {

	NotesPage notesPage = new NotesPage();

	@When("user adds {string} notes")
	public void addNotes(String noteType, DataTable dataTable) throws Exception {
		notesPage.addNotes(noteType, dataTable);
	}

	@Then("verify {string} notes are {string} in the request")
	public void verifyNotes(String noteType, String action) throws Exception {
		if (noteType.equalsIgnoreCase("REQUESTER"))
			notesPage.verifyRequesterNotesAdded();
		else
			notesPage.verifyFulfillerNotesAdded();
	}

	@When("user {string} {string} notes")
	public void editAndDeleteNotes(String noteAction, String noteType) throws Exception {
		if (noteAction.equalsIgnoreCase("EDITS"))
			notesPage.editNotes(noteType);
		else
			notesPage.deleteNotes(noteType);
	}
	
	@Then("verify {string} notes is deleted")
	public void verifyNoteIsDeleted(String noteType) throws Exception {
		notesPage.verifyNotesDeleted(noteType);
	}
}
