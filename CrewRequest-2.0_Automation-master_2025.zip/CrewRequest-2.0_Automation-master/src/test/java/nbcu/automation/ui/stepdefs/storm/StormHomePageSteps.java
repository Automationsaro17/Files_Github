package nbcu.automation.ui.stepdefs.storm;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.storm.StormHomePage;

public class StormHomePageSteps {

	StormHomePage stormHomepage = new StormHomePage();
	
	@Given("verify storm home page is loaded")
	public void verifyStormHomePageLoaded() throws Exception {
		stormHomepage.verifyStormHomePageLoaded();
	}
	
	@Given("user clicks {string} link")
	public void clickFindRequest(String linkType) throws Exception {
		stormHomepage.clickLink(linkType);
	}

	@When("user enters the crew request number and clicks on search button")
	public void searchRequest() throws Exception {
		stormHomepage.seachProdReqNumber();
	}

	@Then("verify records are present in storm application")
	public void verifyRecordIsPresent() throws Exception {
		stormHomepage.verifyRecordPresent();
	}
	
	@Then("verify records are not present in storm application")
	public void verifyRecordIsNotPresent() throws Exception {
		stormHomepage.verifyRecordNotPresent();
	}

	@Then("verify {string} details in storm application")
	public void verifyRequestResourcesDetails(String details) throws Exception {
		if (details.equalsIgnoreCase("REQUEST"))
			stormHomepage.verifyRequestDetails();
		else if(details.equalsIgnoreCase("RESOURCE")) {
			stormHomepage.verifyResourceRecordCount();
			stormHomepage.verifyResourceDetails();
		}
	}
	
	@Then("verify resource details is empty in storm application")
	public void verifyRequestResourcesRecordIsEmpty() throws Exception {
		stormHomepage.verifyResourceRecordIsEmpty();
	}
}
