package nbcu.automation.ui.stepdefs.storm;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import nbcu.automation.ui.pages.storm.StormLoginPage;

public class StormLoginPageSteps {
	
	StormLoginPage stormLoginPage = new StormLoginPage();
	
	@Given("user launches {string} application")
	public void openProdReqApp(String applicationName) throws Exception {
		stormLoginPage.openApplication(applicationName);
	}

	@And("user logins into {string} application")
	public void loginIntoProdReqApp(String role) throws Exception {
		stormLoginPage.loginIntoApplication(role);
	}

}
