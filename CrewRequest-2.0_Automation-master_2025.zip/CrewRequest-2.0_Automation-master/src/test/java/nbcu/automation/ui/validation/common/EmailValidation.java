package nbcu.automation.ui.validation.common;

import java.util.Arrays;

import org.testng.Assert;

import nbcu.automation.ui.constants.crewrequest.Constants;
import nbcu.framework.utils.Other.DateFunctions;
import nbcu.framework.utils.propertyfilereader.EmailConfigReader;

public class EmailValidation {

	/**
	 * To fetch regional email address
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static String findRegionalEmail() throws Throwable {
		String regionEmailList = "";
		try {
			String bureauLocation = Constants.getBureauLocation();
			switch (bureauLocation.toUpperCase()) {
			case "CHICAGO BUREAU":
				regionEmailList = EmailConfigReader.getProperty("MidWest-Region");
				break;
			case "HOUSTON BUREAU":
			case "MEXICO CITY BUREAU":
			case "MIAMI BUREAU":
			case "TELEMUNDO CENTER":
				regionEmailList = EmailConfigReader.getProperty("South-Region");
				break;
			case "LONDON BUREAU":
			case "MOSCOW BUREAU":
				regionEmailList = EmailConfigReader.getProperty("INTLEurope-Region");
				break;
			case "LOS ANGELES BUREAU":
				regionEmailList = EmailConfigReader.getProperty("West-Region");
				break;
			case "NEW YORK BUREAU":
				regionEmailList = EmailConfigReader.getProperty("NorthEast-Region");
				break;
			case "WASHINGTON DC BUREAU":
			case "WHITE HOUSE":
				regionEmailList = EmailConfigReader.getProperty("Washington-Region");
				break;
			}

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw new Exception("Error in fetching regional email ids");
		}
		return regionEmailList;
	}

	/**
	 * To fetch news/CNBC/Telemundo/Digital CC list
	 * 
	 * @param formName      - Crew request form name
	 * @param requestStatus - crew request status
	 * @return - Email CC list
	 * @throws Throwable
	 */
	public static String fetchCcList(String formName, String requestStatus) throws Throwable {
		String emailCcList = "";
		try {

			// Adding news/DJ/CNBC/TELEMUNDO DL
			if (formName.toUpperCase().contains("TELEMUNDO"))
				emailCcList = emailCcList + EmailConfigReader.getProperty("Telemundo") + ",";
			else if (formName.toUpperCase().contains("CNBC"))
				emailCcList = emailCcList + EmailConfigReader.getProperty("CNBC") + ",";
			else if (formName.toUpperCase().contains("DJ"))
				emailCcList = emailCcList + EmailConfigReader.getProperty("DigitalJournalist") + ",";
			else {
				emailCcList = emailCcList + EmailConfigReader.getProperty("News") + ",";

				// If crew status is NEW/REVISED/CONFIRM CANCELLATION and prod date is more than
				// 24 hrs, then remove News CC list
				if ((requestStatus.equalsIgnoreCase("NEW")) || (requestStatus.equalsIgnoreCase("REVISED"))
						|| (requestStatus.equalsIgnoreCase("CONFIRM CANCELLATION"))) {
					System.out.println(Constants.getShootStartDate());
					System.out.println(DateFunctions.getCurrentDate("MM-dd-yyyy"));
					if (!(formName.toUpperCase().contains("BREAKING NEWS"))) {
						if (!(Constants.getShootStartDate().equals(DateFunctions.getCurrentDate("MM-dd-yyyy")))) {
							emailCcList = emailCcList.replace(EmailConfigReader.getProperty("News") + ",", "");
						}
					}
				}
			}

			// Adding regional DL
			if (formName.startsWith("NBC"))
				emailCcList = emailCcList + findRegionalEmail() + ",";

			// Adding drone DL
			if (!formName.toUpperCase().contains("BUREAU CAMERA")) {
				if (Constants.getIsDroneNeeded().equalsIgnoreCase("yes")) {
					emailCcList = emailCcList + EmailConfigReader.getProperty("Drone") + ",";
					if (!(Constants.getCountry().equalsIgnoreCase("UNITED STATES OF AMERICA")))
						emailCcList = emailCcList + EmailConfigReader.getProperty("Drone-INTL") + ",";
				}
			}

			// Adding producer and senior producer email if status is Efforting, ROFR,
			// Booked and Cancelled
			if (!((requestStatus.equalsIgnoreCase("NEW")) || (requestStatus.equalsIgnoreCase("REVISED"))
					|| (requestStatus.equalsIgnoreCase("CONFIRM CANCELLATION")))) {
				if (formName.toUpperCase().contains("BUREAU CAMERA"))
					emailCcList = EmailConfigReader.getProperty("Producer") + "," + emailCcList;
				else
					emailCcList = EmailConfigReader.getProperty("Producer") + ","
							+ EmailConfigReader.getProperty("SeniorProducer") + "," + emailCcList;
			}

			// Remove extra comma in the end
			emailCcList = emailCcList.substring(0, emailCcList.length() - 1);

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw new Exception("Error in fetching CC email list");
		}
		return emailCcList;
	}

	/**
	 * To fetch news/CNBC/Telemundo/Digital To list
	 * 
	 * @param formName      - Crew request form name
	 * @param requestStatus - Crew request status
	 * @return - Email To list
	 * @throws Throwable
	 */
	public static String fetchToList(String formName, String requestStatus) throws Throwable {
		String emailToList = "";
		try {
			// If status is NEW/REVISED/CONFIRM CANCELLATION, then To list will contain
			// producer and senior producer email ids
			if ((requestStatus.equalsIgnoreCase("NEW")) || (requestStatus.equalsIgnoreCase("REVISED"))
					|| (requestStatus.equalsIgnoreCase("CONFIRM CANCELLATION"))) {
				if (formName.toUpperCase().contains("BUREAU CAMERA"))
					emailToList = EmailConfigReader.getProperty("Producer");
				else
					emailToList = EmailConfigReader.getProperty("Producer") + ","
							+ EmailConfigReader.getProperty("SeniorProducer");
			}
			// else To list will contains Crew resources email ids
			else {
				int crewResourceCount = Constants.getResourcesCount();
				for (int i = 0; i < crewResourceCount; i++) {
					emailToList = emailToList + Constants.getCrewResourceEmail(i + 1) + ",";
					emailToList = emailToList.substring(0, emailToList.length() - 1);
				}
			}
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw new Exception("Error in fetching TO email list");
		}
		return emailToList;
	}

	/**
	 * To validate email To list
	 * 
	 * @param requestStatus - Crew request status
	 * @throws Throwable
	 */
	public static void verifyEmailToList(String formName, String requestStatus) throws Throwable {
		try {
			String expectedToList = fetchToList(formName, requestStatus);
			String actualToList = Constants.getEmailToList();
			System.out.println("Expected Email To List:" + expectedToList);
			System.out.println("Actual Email To List:" + actualToList);
			Assert.assertEquals(actualToList, expectedToList, "Expected email To list is '" + expectedToList
					+ "'. But actual email To list is '" + actualToList + "'");
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To validate email CC list
	 * 
	 * @param requestStatus
	 * @throws Throwable
	 */
	public static void verifyEmailCCList(String formName, String requestStatus) throws Throwable {
		try {
			String expectedCcList = fetchCcList(formName, requestStatus);
			String actualCcList = Constants.getEmailCcList();
			System.out.println("Expected Email CC List:" + expectedCcList);
			System.out.println("Actual Email CC List:" + actualCcList);

			String[] expectedCcListArray = expectedCcList.split(",");
			String[] actualCcListArray = actualCcList.split(",");
			Arrays.sort(expectedCcListArray);
			Arrays.sort(actualCcListArray);
			Assert.assertEquals(actualCcListArray, expectedCcListArray, "Expected email CC list is '" + expectedCcList
					+ "'. But actual email CC list is '" + actualCcList + "'");

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Validate email subject
	 * 
	 * @param formName - crew request form name
	 * @throws Throwable
	 */
	public static void verifyEmailSubject(String formName) throws Throwable {
		try {
			String subject = Constants.getEmailSubject();

			// Validate starting tag
			if (formName.startsWith("CNBC")) {
				if (!subject.startsWith("[CNBC Crew]"))
					Assert.assertTrue(false, "Email subject for " + formName + " has not started with '[CNBC Crew]'");
			} else if (formName.startsWith("DJ")) {
				if (!subject.startsWith("[Digital Crew]"))
					Assert.assertTrue(false,
							"Email subject for " + formName + " has not started with '[Digital Crew]'");
			} else if (formName.startsWith("Telemundo")) {
				if (!subject.startsWith("[Telemundo Crew]"))
					Assert.assertTrue(false,
							"Email subject for " + formName + " has not started with '[Telemundo Crew]'");
			} else {
				if (!subject.startsWith("[NBC Crew]"))
					Assert.assertTrue(false, "Email subject for " + formName + " has not started with '[NBC Crew]'");
			}

			// Validate shoot start date
			System.out.println(Constants.getShootStartDate());
			String shootStartDate = DateFunctions.convertDateStringToAnotherFormat(Constants.getShootStartDate(),
					"MM-dd-yyyy", "EEE yyyy-MM-dd");
			if (!subject.contains(shootStartDate))
				Assert.assertTrue(false, "Email subject does not contain shoot start date '" + shootStartDate + "'");

			// Validate time zone
			String timeZone = Constants.getShootTimeZone();
			timeZone = timeZone.substring(0, timeZone.indexOf("(")).trim();
			if (!subject.contains(timeZone))
				Assert.assertTrue(false, "Email subject does not contain shoot time zone '" + timeZone + "'");

			// Validate show info
			String showName = Constants.getShowUnit();
			if (!subject.contains(showName))
				Assert.assertTrue(false, "Email subject does not contain show name '" + showName + "'");

			// Validate assignment slug
			String assignmentSlug = Constants.getAssignmentSlug();
			if (!subject.contains(assignmentSlug))
				Assert.assertTrue(false, "Email subject does not contain assignment slug '" + assignmentSlug + "'");

			// Validate city
			String city = Constants.getCity();
			if (!subject.contains(city))
				Assert.assertTrue(false, "Email subject does not contain city '" + city + "'");

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To validate meet info section of email body
	 * 
	 * @param emailBody - email body
	 * @throws Throwable
	 */
	public static void verifyMeetInfoSection(String formName, String emailBody) throws Throwable {
		try {
			String expectedDates = "", expectedMeetTime = "", expectedMeetAddress = "";

			// To validates Dates in meet info section
			String shootStartDate = "", shootEndDate = "";
			if (formName.toUpperCase().contains("BREAKING NEWS"))
				shootStartDate = DateFunctions.getCurrentDate("EEE yyyy-MM-dd");
			else
				shootStartDate = DateFunctions.convertDateStringToAnotherFormat(Constants.getShootStartDate(),
						"MM-dd-yyyy", "EEE yyyy-MM-dd");

			if (formName.toUpperCase().contains("BREAKING NEWS"))
				shootEndDate = DateFunctions.getCurrentDate("EEE yyyy-MM-dd");
			else
				shootEndDate = DateFunctions.convertDateStringToAnotherFormat(Constants.getShootEndDate(), "MM-dd-yyyy",
						"EEE yyyy-MM-dd");

			String timeZone = Constants.getShootTimeZone();
			timeZone = timeZone.substring(0, timeZone.indexOf("(")).trim();
			expectedDates = "Date(s) : " + shootStartDate + " " + timeZone + " - " + shootEndDate + " " + timeZone;
			if (shootStartDate.equals(DateFunctions.getCurrentDate("EEE yyyy-MM-dd")))
				expectedDates = expectedDates + " *shoot starts within 24hrs*";

			if (!emailBody.contains(expectedDates))
				Assert.assertTrue(false, "Dates field value '" + expectedDates
						+ "' is not present in meet info section of the email body");

			// To Validate Meet Time in meet info section
			if (!formName.toUpperCase().contains("DJ SHOOT")) {
				String rollTime = Constants.getShootMeetTime();
				String startTime = Constants.getShootStartTime();

				System.out.println("Roll time:" + rollTime);
				System.out.println("Start time:" + startTime);
				System.out.println("Time zone:" + timeZone);
				String expectedRollTime = rollTime + " " + timeZone;
				String[] expectedRollTimeArray = emailBody.split("Meet Time :");
				if (!expectedRollTimeArray[1].trim().toLowerCase().startsWith(expectedRollTime.toLowerCase()))
					Assert.assertTrue(false, "Meet time field value '" + expectedMeetTime
							+ "' is not present in meet info section of the email body");

				String expectedStartTime = startTime + " " + timeZone;
				String[] expectedStartTimeArray = emailBody.split("Roll Time");
				if (!expectedStartTimeArray[1].trim().toLowerCase().startsWith(": " + expectedStartTime.toLowerCase()))
					Assert.assertTrue(false, "Meet time field value '" + expectedStartTime
							+ "' is not present in meet info section of the email body");
			}

			// To Validate meet address in meet info section
			String addressLine1 = Constants.getAddressLine1();
			String city = Constants.getCity();
			String state = getStateCode(Constants.getState());
			String zipCode = Constants.getZipCode();
			String country = Constants.getCountry();
			expectedMeetAddress = "Meet Address : " + addressLine1 + ", " + city + ", " + state + " " + zipCode + ", "
					+ country;
			if (!emailBody.contains(expectedMeetAddress))
				Assert.assertTrue(false, "Meet address field value '" + expectedMeetAddress
						+ "' is not present in meet info section of the email body");

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To get US state code
	 * 
	 * @param state - US state
	 * @return - State code
	 * @throws Throwable
	 */
	public static String getStateCode(String state) throws Throwable {
		String stateCode = "";
		try {
			switch (state) {
			case "Illinois":
				stateCode = "IL";
				break;
			case "Texas":
				stateCode = "TX";
				break;
			case "California":
				stateCode = "CA";
				break;
			case "Florida":
				stateCode = "FL";
				break;
			case "New York":
				stateCode = "NY";
				break;
			case "District of Columbia":
				stateCode = "DC";
				break;
			default:
				stateCode = state;
				break;
			}

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
		return stateCode;
	}

	/**
	 * To verify shoot info section in requester email body
	 * 
	 * @param emailBody
	 * @throws Throwable
	 */
	public static void verifyRequesterShootInfoSection(String formName, String emailBody) throws Throwable {
		try {
			// Verify resources field
			String cameraResourceCount = "", audioResourceCount = "";
			if (formName.toUpperCase().contains("BUREAU CAMERA")) {
				cameraResourceCount = "0";
				audioResourceCount = "0";
			} else {
				cameraResourceCount = Constants.getCameraOpsCount();
				audioResourceCount = Constants.getAudioOpsCount();
			}
			String expectedResources = "Resources : Camera " + cameraResourceCount + " Audio " + audioResourceCount
					+ " Utilities 0";
			if (!emailBody.contains(expectedResources))
				Assert.assertTrue(false, "Resources field value '" + expectedResources
						+ "' is not present in shoot info section of the email body");

			// Verify production type field
			String expectedProductionType = "";
			if (formName.toUpperCase().contains("BREAKING NEWS"))
				expectedProductionType = "Production Type : BREAKING NEWS";
			else if (formName.toUpperCase().contains("BUREAU CAMERA"))
				expectedProductionType = "Production Type :";
			else
				expectedProductionType = "Production Type : " + Constants.getProductionType();

			if (!emailBody.contains(expectedProductionType))
				Assert.assertTrue(false, "Production Type field value '" + expectedProductionType
						+ "' is not present in shoot info section of the email body");

			// Verify shoot description field
			String expectedShootDescription = "Shoot Description : " + Constants.getShootDescription();
			if (!emailBody.contains(expectedShootDescription))
				Assert.assertTrue(false, "Shoot Description field value '" + expectedShootDescription
						+ "' is not present in shoot info section of the email body");

			// Verify special gear field
			String expectedSpecialGear = "";
			if (Constants.getSpecialGear() == null)
				expectedSpecialGear = "Special Gear : no";
			else
				expectedSpecialGear = "Special Gear : " + Constants.getSpecialGear();
			if (!emailBody.toLowerCase().contains(expectedSpecialGear.toLowerCase()))
				Assert.assertTrue(false, "Special Gear field value '" + expectedSpecialGear
						+ "' is not present in shoot info section of the email body");

			// Verify drone shoot field
			String expectedDroneShoot = "";
			if (Constants.getIsDroneNeeded() == null)
				expectedDroneShoot = "No";
			else
				expectedDroneShoot = Constants.getIsDroneNeeded();
			String[] emailBodyArray = emailBody.split("Drone Shoot :");

			if (!emailBodyArray[1].trim().toLowerCase().startsWith(expectedDroneShoot.toLowerCase()))
				Assert.assertTrue(false, "Drone shoot field value '" + expectedDroneShoot
						+ "' is not present in shoot info section of the email body");

			// Verify 360 cam field
			if(!formName.toUpperCase().contains("TELEMUNDO")) {
			String expected360Cam = "";
			if (Constants.getIs360CamNeeded() == null)
				expected360Cam = "360 Cam : No";
			else
				expected360Cam = "360 Cam : " + Constants.getIs360CamNeeded();

			if (!emailBody.toLowerCase().contains(expected360Cam.toLowerCase()))
				Assert.assertTrue(false, "360 camera field value '" + expected360Cam
						+ "' is not present in shoot info section of the email body");
			}

			// Verify audio needs field
			String expectedAudioNeeds = "";
			if (formName.toUpperCase().contains("BREAKING NEWS"))
				expectedAudioNeeds = "Audio Needs : 1-2 Audio Sources";
			else if (formName.toUpperCase().contains("BUREAU CAMERA"))
				expectedAudioNeeds = "Audio Needs :";
			else
				expectedAudioNeeds = "Audio Needs : " + Constants.getAudioNeeds();
			if (!emailBody.contains(expectedAudioNeeds))
				Assert.assertTrue(false, "Audio needs field value '" + expectedAudioNeeds
						+ "' is not present in shoot info section of the email body");

			// Verify special conditions field
			String expectedSpecialConditions = "";
			if (formName.toUpperCase().contains("BREAKING NEWS"))
				expectedSpecialConditions = "Special Conditions : Time constraints";
			else if (formName.toUpperCase().contains("BUREAU CAMERA"))
				expectedSpecialConditions = "Special Conditions :";
			else
				expectedSpecialConditions = "Special Conditions : " + Constants.getSpecialCondition();
			if (!emailBody.contains(expectedSpecialConditions))
				Assert.assertTrue(false, "Special conditions field value '" + expectedSpecialConditions
						+ "' is not present in shoot info section of the email body");

			// Verify transmission type field
			String expectedTransmissionType = "";
			if (formName.toUpperCase().contains("BUREAU CAMERA"))
				expectedTransmissionType = "Transmission Type :";
			else
				expectedTransmissionType = "Transmission Type : " + Constants.getTransmissionType();
			if (!emailBody.toLowerCase().contains(expectedTransmissionType.toLowerCase()))
				Assert.assertTrue(false, "Transmission type field value '" + expectedTransmissionType
						+ "' is not present in shoot info section of the email body");

			// Verify budget code field
			String expectedBudgetCode = "Budget Code : " + Constants.getBudgetCode();
			if (!emailBody.contains(expectedBudgetCode))
				Assert.assertTrue(false, "Budget code field value '" + expectedBudgetCode
						+ "' is not present in shoot info section of the email body");

			// Verify estimated cost field
			String expectedEstimatedCost = "";
			if (formName.toUpperCase().contains("BUREAU CAMERA"))
				expectedEstimatedCost = "Estimated Cost : $0";
			else
				expectedEstimatedCost = "Estimated Cost : " + Constants.getEstimatedCost();
			if (!emailBody.contains(expectedEstimatedCost))
				Assert.assertTrue(false, "Budget code field value '" + expectedBudgetCode
						+ "' is not present in shoot info section of the email body");

			if (formName.toUpperCase().contains("DJ SHOOT")) {
				// Validate shoot type
				String expectedShootType = "ShootType : " + Constants.getShootType();
				if (!emailBody.toLowerCase().contains(expectedShootType.toLowerCase()))
					Assert.assertTrue(false, "Shoot type field value '" + expectedShootType
							+ "' is not present in shoot info section of the email body");

				// Validate primary camera type
				String expectedPrimaryCameraType = "Primary Camera Type : " + Constants.getPrimaryCameraType();
				if (!emailBody.toLowerCase().contains(expectedPrimaryCameraType.toLowerCase()))
					Assert.assertTrue(false, "Primary camera type field value '" + expectedPrimaryCameraType
							+ "' is not present in shoot info section of the email body");

				// Validate primary camera type
				String expectedColorSpace = "Color Space : " + Constants.getColorSpace();
				if (!emailBody.toLowerCase().contains(expectedColorSpace.toLowerCase()))
					Assert.assertTrue(false, "Color space type field value '" + expectedColorSpace
							+ "' is not present in shoot info section of the email body");
			}

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify requester info in email body
	 * 
	 * @param emailBody
	 * @throws Throwable
	 */
	public static void verifyRequesterInfoSection(String formName, String emailBody) throws Throwable {
		try {
			// Verify requester field
			String expectedRequesterName = "Requester : " + Constants.getDefaultRequesterName();// +"
																								// "+Constants.getDefaultRequesterPhoneNumber();
			if (!emailBody.contains(expectedRequesterName))
				Assert.assertTrue(false, "Requester field value '" + expectedRequesterName
						+ "' is not present in requester info section of the email body");

			// Verify producer field
			String expectedProducerName = "";
			if (formName.toUpperCase().contains("BUREAU CAMERA"))
				expectedProducerName = "Producer/Field Contact :";
			else
				expectedProducerName = "Producer/Field Contact : " + Constants.getProducerName() + " "
						+ Constants.getProducerPhoneNumber();
			if (!emailBody.contains(expectedProducerName))
				Assert.assertTrue(false, "Producer/Field Contact field value '" + expectedRequesterName
						+ "' is not present in requester info section of the email body");

			// Verify Sr.Producer field
			String expectedSeniorProducerName = "";
			if (formName.toUpperCase().contains("BUREAU CAMERA"))
				expectedSeniorProducerName = "Sr. Producer :";
			else
				expectedSeniorProducerName = "Sr. Producer : " + Constants.getSeniorProducerName();
			if (!emailBody.contains(expectedSeniorProducerName))
				Assert.assertTrue(false, "Senior producer field value '" + expectedSeniorProducerName
						+ "' is not present in requester info section of the email body");
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify risk assessment section
	 * 
	 * @param emailBody
	 * @throws Throwable
	 */
	public static void verifyRiskAssessmentInfoSection(String emailBody) throws Throwable {
		try {
			// Verify risk category field
			String expectedRiskcategory = "Category: " + Constants.getRiskCategory();
			if (!emailBody.contains(expectedRiskcategory))
				Assert.assertTrue(false, "Risk category field value '" + expectedRiskcategory
						+ "' is not present in risk assessment section of the email body");

			// Verify risk field
			String expectedRiskAssessment = "Which standard risk assessment(s) apply: "
					+ Constants.getRiskAssessment();
			if (!emailBody.contains(expectedRiskAssessment))
				Assert.assertTrue(false, "Which standard risk assessment(s) apply field value '"
						+ expectedRiskAssessment + "' is not present in risk assessment section of the email body");

			// Verify equipment required field
			String expectedequipment = "Arrangments, procedure or equipment required for safety: "
					+ Constants.getEquipmentsForSafety();
			if (!emailBody.contains(expectedequipment))
				Assert.assertTrue(false, "Arrangments, procedure or equipment required for safety field value '"
						+ expectedequipment + "' is not present in risk assessment section of the email body");

			// Verify risk approver field
			String expectedRiskApprover = "Approver: " + Constants.getRiskApprover();
			if (!emailBody.contains(expectedRiskApprover))
				Assert.assertTrue(false, "Risk approver field value '" + expectedRiskApprover
						+ "' is not present in risk assessment section of the email body");
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify email footer section
	 * 
	 * @param emailBody - actual email body
	 * @param formName  - form name
	 * @param status    - request status
	 * @throws Throwable
	 */
	public static void verifyEmailFooterSection(String emailBody, String formName, String status) throws Throwable {
		String expectedFooterContent = "";
		try {
			if (formName.toUpperCase().contains("DJ")) {
				if ((status.equalsIgnoreCase("NEW")) || (status.equalsIgnoreCase("REVISED")))
					expectedFooterContent = EmailConfigReader.getProperty("Digital-Footer-Requester");
				else
					expectedFooterContent = EmailConfigReader.getProperty("Digital-Footer-Fulfiller");
			} else if (formName.toUpperCase().contains("TELEMUNDO")) {
				if ((status.equalsIgnoreCase("NEW")) || (status.equalsIgnoreCase("REVISED")))
					expectedFooterContent = EmailConfigReader.getProperty("Telemundo-Footer-Requester");
				else
					expectedFooterContent = EmailConfigReader.getProperty("Telemundo-Footer-Fulfiller");
			} else if (formName.toUpperCase().contains("CNBC")) {
				if ((status.equalsIgnoreCase("NEW")) || (status.equalsIgnoreCase("REVISED")))
					expectedFooterContent = EmailConfigReader.getProperty("Cnbc-Footer-Requester");
				else
					expectedFooterContent = EmailConfigReader.getProperty("Cnbc-Footer-Fulfiller");
			} else {
				if ((status.equalsIgnoreCase("NEW")) || (status.equalsIgnoreCase("REVISED")))
					expectedFooterContent = EmailConfigReader.getProperty("News-Footer-Requester");
				else
					expectedFooterContent = EmailConfigReader.getProperty("News-Footer-Fulfiller");
			}

			if (!emailBody.replace("ï¿½muleï¿½", "\"mule\"").contains(expectedFooterContent))
				Assert.assertTrue(false,
						"Footer section '" + expectedFooterContent + "' is not present in the email body");

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static void verifyTeamInfoSection(String formName, String emailBody) throws Throwable {
		try {
			// Verify producer contact
			if (!formName.toUpperCase().contains("BUREAU CAMERA")) {
				String expectedProducerContact = "Producer/Field Contact : " + Constants.getProducerName() + " "
						+ Constants.getProducerPhoneNumber();
				if (!emailBody.contains(expectedProducerContact))
					Assert.assertTrue(false, "Producer/Field Contact field value '" + expectedProducerContact
							+ "' is not present in team info section of the email body");

				// Verify expected on-site producer message
				String producerOnsiteMessage = "(Note: Producer on site)";
				if (Constants.getIsOnsiteProducer() != null) {
					if (Constants.getIsOnsiteProducer().equalsIgnoreCase("YES")) {
						if (!emailBody.contains(producerOnsiteMessage))
							Assert.assertTrue(false,
									"'Note: Producer on site' message is not present next to Producer/Field Contact field");
					}
				}
			}

			// Verify crew resources
			int crewResourceCount = Constants.getResourcesCount();
			if (crewResourceCount != 0) {
				String expectedResourceDetail = "";
				for (int i = 0; i < crewResourceCount; i++) {
					expectedResourceDetail = Constants.getCrewResourceRole(i + 1) + ": "
							+ Constants.getCrewResourceName(i + 1) + " | " + Constants.getCrewResourcePhone(i + 1)
							+ " | " + Constants.getCrewResourceEmail(i + 1);
					if (!emailBody.contains(expectedResourceDetail)) {
						Assert.assertTrue(false, "Crew Resource '" + expectedResourceDetail
								+ "' is not present in team info section of the email body");
					}
				}
			}

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify fulfillment shoot info section
	 * 
	 * @param emailBody
	 * @throws Throwable
	 */
	public static void verifyFulfillmentShootInfoSection(String formName, String emailBody) throws Throwable {
		try {
			// Verify production type field
			String expectedProductionType = "";
			if (formName.toUpperCase().contains("BREAKING NEWS"))
				expectedProductionType = "Type : BREAKING NEWS";
			else if (formName.toUpperCase().contains("BUREAU CAMERA"))
				expectedProductionType = "Type :";
			else
				expectedProductionType = "Type : " + Constants.getProductionType();

			if (!emailBody.contains(expectedProductionType))
				Assert.assertTrue(false, "Production Type field value '" + expectedProductionType
						+ "' is not present in shoot info section of the email body");

			// Verify shoot description field
			String expectedShootDescription = "Description : " + Constants.getShootDescription();
			if (!emailBody.contains(expectedShootDescription))
				Assert.assertTrue(false, "Shoot Description field value '" + expectedShootDescription
						+ "' is not present in shoot info section of the email body");

			// Verify special gear field
			String expectedSpecialGear = "";
			if (Constants.getSpecialGear() == null)
				expectedSpecialGear = "Special Gear : no";
			else
				expectedSpecialGear = "Special Gear : " + Constants.getSpecialGear();

			if (!emailBody.toLowerCase().contains(expectedSpecialGear.toLowerCase()))
				Assert.assertTrue(false, "Special Gear field value '" + expectedSpecialGear
						+ "' is not present in shoot info section of the email body");

			// Verify drone shoot field
			String expectedDroneShoot = "";
			if (Constants.getIsDroneNeeded() == null)
				expectedDroneShoot = "No";
			else
				expectedDroneShoot = Constants.getIsDroneNeeded();
			String[] emailBodyArray = emailBody.split("Drone Shoot :");

			if (!emailBodyArray[1].trim().toLowerCase().startsWith(expectedDroneShoot.toLowerCase()))
				Assert.assertTrue(false, "Drone shoot field value '" + expectedDroneShoot
						+ "' is not present in shoot info section of the email body");

			// Verify budget code field
			String expectedBudgetCode = "Budget Code : " + Constants.getBudgetCode();
			if (!emailBody.contains(expectedBudgetCode))
				Assert.assertTrue(false, "Budget code field value '" + expectedBudgetCode
						+ "' is not present in shoot info section of the email body");

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify tech info section
	 * 
	 * @param emailBody
	 * @throws Throwable
	 */
	public static void verifyTechInfoSection(String emailBody) throws Throwable {
		try {
			// Verify primary camera type
			String expectedPrimaryCameraType = "";
			if (Constants.getPrimaryCameraType() == null)
				expectedPrimaryCameraType = "Primary Camera :";
			else
				expectedPrimaryCameraType = "Primary Camera : " + Constants.getPrimaryCameraType();
			if (!emailBody.contains(expectedPrimaryCameraType))
				Assert.assertTrue(false, "Primary Camera Type field value '" + expectedPrimaryCameraType
						+ "' is not present in tech info section of the email body");

			// Verify media format
			String expectedMediaFormat = "";
			if (Constants.getMediaFormat() == null)
				expectedMediaFormat = "Media Format :";
			else
				expectedMediaFormat = "Media Format : " + Constants.getMediaFormat();
			if (!emailBody.contains(expectedMediaFormat))
				Assert.assertTrue(false, "Media Format field value '" + expectedMediaFormat
						+ "' is not present in tech info section of the email body");

			// Verify video specs
			String expectedVideoSpecs = "";
			if (Constants.getVideoSpecs() != null) {
				expectedVideoSpecs = Constants.getVideoSpecs();
				String[] emailBodyArray = emailBody.split("Video Specs :");

				if (!emailBodyArray[1].trim().toLowerCase().startsWith(expectedVideoSpecs.toLowerCase()))
					Assert.assertTrue(false, "Video specs field value '" + expectedVideoSpecs
							+ "' is not present in tech info section of the email body");
			}

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify requester email body
	 * 
	 * @param formName
	 * @param status
	 * @throws Throwable
	 */
	public static void verifyRequesterEmail(String formName, String status) throws Throwable {
		try {
			String emailBody = Constants.getEmailBody();

			// To verify meet info
			verifyMeetInfoSection(formName, emailBody);

			// To verify shoot info
			verifyRequesterShootInfoSection(formName, emailBody);

			// To verify requester info
			verifyRequesterInfoSection(formName, emailBody);

			// To verify Risk Assessment section
			if (!(Constants.getCountry().equalsIgnoreCase("United States of America")))
				verifyRiskAssessmentInfoSection(emailBody);

			// To verify email footer section
			verifyEmailFooterSection(emailBody, formName, status);
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static void verifyFulfillmentEmail(String formName, String status) throws Throwable {
		try {
			String emailBody = Constants.getEmailBody();

			// To verify meet info
			verifyMeetInfoSection(formName, emailBody);

			// To verify team info
			verifyTeamInfoSection(formName, emailBody);

			// To verify shoot info
			verifyFulfillmentShootInfoSection(formName, emailBody);

			// To verify Risk Assessment section
			if (!(Constants.getCountry().equalsIgnoreCase("United States of America")))
				verifyRiskAssessmentInfoSection(emailBody);

			// To verify tech info
			verifyTechInfoSection(emailBody);

			// To verify email footer section
			verifyEmailFooterSection(emailBody, formName, status);
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static void verifyEmailContent(String formName, String status) throws Throwable {
		try {
			if ((status.equalsIgnoreCase("NEW")) || (status.equalsIgnoreCase("REVISED")))
				verifyRequesterEmail(formName, status);
			else
				verifyFulfillmentEmail(formName, status);
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}
}
