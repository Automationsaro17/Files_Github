package nbcu.framework.hooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import nbcu.framework.utils.report.ExtentReportUtils;

public class CucumberAnnotations {

	/**
	 * To initialize the web driver before each scenario
	 * @throws Exception
	 */
	@Before
	public void beforeScenario() throws Exception {
		DriverFactory.initDriver(ConfigFileReader.getProperty("Application-Type"), ConfigFileReader.getProperty("Browser-Type"));
	}

	/**
	 * To close the web driver after each scenario
	 * @param scenario
	 */
	@After
	public void AfterScenario(Scenario scenario) {
		if(scenario.isFailed()) {
			byte[] src=ExtentReportUtils.captureScreenshot();
			scenario.attach(src, "image/png", "Failure screen shot");
		}
		DriverFactory.cleanDrivers();
	}
}
