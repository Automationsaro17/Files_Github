package nbcu.framework.runner;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import nbcu.framework.utils.report.EmailHelper;

@CucumberOptions(features = { "src/test/resources/features" }, glue = { "nbcu.automation.ui.stepdefs",
		"nbcu.framework.hooks" }, tags = "@GT_REPLATFORM and @REGRESSION", plugin = { "pretty",
				"json:target/cucumber-reports/Cucumber.json", "rerun:target/cucumber-reports/rerun-reports/rerun.txt",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:" }, monochrome = true, publish = true)

public class RunCucumberTest extends AbstractTestNGCucumberTests {

	@DataProvider(parallel = true)
	public Object[][] scenarios() {
		return super.scenarios();
	}

	@AfterSuite(alwaysRun = true)
	public void afterSuite() throws Exception {
		// To send automation report via email
		if (ConfigFileReader.getProperty("Email-Report").equalsIgnoreCase("YES"))
			EmailHelper.sendEmail();

	}
}