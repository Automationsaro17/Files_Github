package nbcu.framework.utils.report;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import nbcu.framework.factory.DriverFactory;

public class ExtentReportUtils {
	
	/**
	 * To capture failure screen shot
	 * @return
	 */
	public static byte[] captureScreenshot() {
		byte[] src;
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			TakesScreenshot ts = (TakesScreenshot) driver;
			src = ts.getScreenshotAs(OutputType.BYTES);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return src;
	}

}
