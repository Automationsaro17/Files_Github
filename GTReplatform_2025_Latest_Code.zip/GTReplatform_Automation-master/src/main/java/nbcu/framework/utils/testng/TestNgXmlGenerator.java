package nbcu.framework.utils.testng;

import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import org.apache.commons.io.FileUtils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.List;

public class TestNgXmlGenerator {

    /**
     * To update parallel instance count in testng.xml file
     *
     * @throws Exception
     */
    public static void updateTextNgXml() throws Exception {
        try {
            //To read testNG xml file and convert to list of string
            File testNgXmlFile = new File(System.getProperty("user.dir") + "/testNG.xml");
            List<String> testNgXmlString = FileUtils.readLines(testNgXmlFile);

            //To update testNG mxl file
            BufferedWriter bw = new BufferedWriter(new FileWriter(testNgXmlFile));
            for (String line : testNgXmlString) {
                String threadCount = ConfigFileReader.getProperty("Parallel-Instance");
                if (line.contains("data-provider-thread-count"))
                    line = line.replaceAll("\\d+", threadCount);
                bw.write(line);
                bw.newLine();
            }
            bw.flush();
            bw.close();

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public static void main(String[] args) throws Exception {
        updateTextNgXml();
    }
}
