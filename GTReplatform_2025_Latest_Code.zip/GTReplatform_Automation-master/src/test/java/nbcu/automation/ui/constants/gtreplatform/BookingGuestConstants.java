package nbcu.automation.ui.constants.gtreplatform;

import java.util.concurrent.ConcurrentHashMap;

public class BookingGuestConstants {

	private static final ThreadLocal<ConcurrentHashMap<String, Object>> constantMap = new ThreadLocal<ConcurrentHashMap<String, Object>>() {
		@Override
		protected ConcurrentHashMap<String, Object> initialValue() {
			return new ConcurrentHashMap<>();
		}
	};

	// Guest Name
	public static void setGuestName(String guestName) {
		constantMap.get().put("Guest Name", guestName);
	}

	public static String getGuestName() {
		return (String) constantMap.get().get("Guest Name");
	}

	// Existing Topic Name
	public static void setExistingTopicCount(int topicCount) {
		constantMap.get().put("Existing Topic Count", topicCount);
	}

	public static int getExistingTopicCount() {
		return (int) constantMap.get().get("Existing Topic Count");
	}

	// Topic Name
	public static void setTopicName(String topicName) {
		constantMap.get().put("Topic Name", topicName);
	}

	public static String getTopicName() {
		return (String) constantMap.get().get("Topic Name");
	}

	// Topic start time
	public static void setTopicStartTime(String topicStartTime) {
		constantMap.get().put("Topic Start Name", topicStartTime);
	}

	public static String getTopicStartTime() {
		return (String) constantMap.get().get("Topic Start Name");
	}

	// Topic end time
	public static void setTopicEndTime(String topicEndTime) {
		constantMap.get().put("Topic End Name", topicEndTime);
	}

	public static String getTopicEndTime() {
		return (String) constantMap.get().get("Topic End Name");
	}

	// Topic notes
	public static void setTopicNotes(String topicNotes) {
		constantMap.get().put("Topic Notes", topicNotes);
	}

	public static String getTopicNotes() {
		return (String) constantMap.get().get("Topic Notes");
	}

	// Show date
	public static void setShowDate(String showDate) {
		constantMap.get().put("Show Date", showDate);
	}

	public static String getShowDate() {
		return (String) constantMap.get().get("Show Date");
	}

	// Show time
	public static void setShowTime(String showTime) {
		constantMap.get().put("Show Time", showTime);
	}

	public static String getShowTime() {
		return (String) constantMap.get().get("Show Time");
	}

	// Event type
	public static void setEventType(String eventType) {
		constantMap.get().put("Event Type", eventType);
	}

	public static String getEventType() {
		return (String) constantMap.get().get("Event Type");
	}

	// Show name
	public static void setShowName(String showName) {
		constantMap.get().put("Show Name", showName);
	}

	public static String getShowName() {
		return (String) constantMap.get().get("Show Name");
	}

	// Show type
	public static void setShowType(String showType) {
		constantMap.get().put("Show Type", showType);
	}

	public static String getShowType() {
		return (String) constantMap.get().get("Show Type");
	}

	// Call status
	public static void setCallStatus(String showCallStatus) {
		constantMap.get().put("Show Call Status", showCallStatus);
	}

	public static String getCallStatus() {
		return (String) constantMap.get().get("Show Call Status");
	}

	// Booker called for
	public static void setBookerCalledForName(String calledFor) {
		constantMap.get().put("Called For", calledFor);
	}

	public static String getBookerCalledForName() {
		return (String) constantMap.get().get("Called For");
	}

	// Call out date
	public static void setCallOutDate(String calledOutDate) {
		constantMap.get().put("Call Out Date", calledOutDate);
	}

	public static String getCallOutDate() {
		return (String) constantMap.get().get("Call Out Date");
	}

	// Call out time
	public static void setCallOutTime(String calledOutTime) {
		constantMap.get().put("Call Out Time", calledOutTime);
	}

	public static String getCallOutTime() {
		return (String) constantMap.get().get("Call Out Time");
	}

	// Call out notes
	public static void setCallOutNotes(String calledNotes) {
		constantMap.get().put("Call Out Notes", calledNotes);
	}

	public static String getCallOutNotes() {
		return (String) constantMap.get().get("Call Out Notes");
	}

	// Default booking time
	public static void setDefaultBookingTime(String bookingTime) {
		constantMap.get().put("Default Booking Time", bookingTime);
	}

	public static String getDefaultBookingTime() {
		return (String) constantMap.get().get("Default Booking Time");
	}

	// Booker for
	public static void setBookedFor(String bookedFor) {
		constantMap.get().put("Booked For", bookedFor);
	}

	public static String getBookedFor() {
		return (String) constantMap.get().get("Booked For");
	}

	// Booking date
	public static void setBookingDate(String bookingDate) {
		constantMap.get().put("Booking Date", bookingDate);
	}

	public static String getBookingDate() {
		return (String) constantMap.get().get("Booking Date");
	}

	// Recurring booking dates
	public static void setRecurringBookingDates(int i, String bookingDate) {
		constantMap.get().put("Recurring Booking Date_" + i, bookingDate);
	}

	public static String getRecurringBookingDates(int i) {
		return (String) constantMap.get().get("Recurring Booking Date_" + i);
	}

	// Recurring booking dates count
	public static void setRecurringBookingDatesCount(String size) {
		constantMap.get().put("Recurring Booking Days Count", size);
	}

	public static String getRecurringBookingDatesCount() {
		return (String) constantMap.get().get("Recurring Booking Days Count");
	}

	// Booking time
	public static void setBookingTime(String bookingTime) {
		constantMap.get().put("Booking Time", bookingTime);
	}

	public static String getBookingTime() {
		return (String) constantMap.get().get("Booking Time");
	}

	// Booking notes
	public static void setBookingNotes(String bookingNotes) {
		constantMap.get().put("Booking Notes", bookingNotes);
	}

	public static String getBookingNotes() {
		return (String) constantMap.get().get("Booking Notes");
	}

	// Recurring booking days
	public static void setRecurringBookingDays(String days) {
		constantMap.get().put("Recurring Booking Days", days);
	}

	public static String getRecurringBookingDays() {
		return (String) constantMap.get().get("Recurring Booking Days");
	}

	// Recurring booking end date
	public static void setRecurringBookingEndDate(String endDate) {
		constantMap.get().put("Recurring Booking End Date", endDate);
	}

	public static String getRecurringBookingEndDate() {
		return (String) constantMap.get().get("Recurring Booking End Date");
	}

	// studio type
	public static void setStudioType(String studioType) {
		constantMap.get().put("Studio Type", studioType);
	}

	public static String getStudioType() {
		return (String) constantMap.get().get("Studio Type");
	}

	// Studio
	public static void setStudio(String studio) {
		constantMap.get().put("Studio", studio);
	}

	public static String getStudio() {
		return (String) constantMap.get().get("Studio");
	}

	// Studio state
	public static void setStudioState(String studioState) {
		constantMap.get().put("Studio State", studioState);
	}

	public static String getStudioState() {
		return (String) constantMap.get().get("Studio State");
	}

	// Booking url
	public static void setBookingUrl(String bookingUrl) {
		constantMap.get().put("Booking Url", bookingUrl);
	}

	public static String getBookingUrl() {
		return (String) constantMap.get().get("Booking Url");
	}

	// booking email alert count
	public static void setEmailAlertCount(String emailAlertCount) {
		constantMap.get().put("Email Alert Count", emailAlertCount);
	}

	public static String getEmailAlertCount() {
		return (String) constantMap.get().get("Email Alert Count");
	}

	// booking email alert email address
	public static void setEmailAlert(int number, String emailAddress) {
		constantMap.get().put("Email Alert_" + number, emailAddress);
	}

	public static String getEmailAlert(int number) {
		return (String) constantMap.get().get("Email Alert_" + number);
	}

	// custom email notification
	public static void setAllCustomEmailNotification(String customNotification) {
		constantMap.get().put("All Custom Notification", customNotification);
	}

	public static String getAllCustomEmailNotification() {
		return (String) constantMap.get().get("All Custom Notification");
	}

	public static void setShowNameCustomNotification(String customNotification) {
		constantMap.get().put("Show Name Custom Notification", customNotification);
	}

	public static String getShowNameCustomNotification() {
		return (String) constantMap.get().get("Show Name Custom Notification");
	}

	public static void setTopicCustomNotification(String customNotification) {
		constantMap.get().put("Topic Custom Notification", customNotification);
	}

	public static String getTopicCustomNotification() {
		return (String) constantMap.get().get("Topic Custom Notification");
	}

	public static void setStudioCustomNotification(String customNotification) {
		constantMap.get().put("Studio Custom Notification", customNotification);
	}

	public static String getStudioCustomNotification() {
		return (String) constantMap.get().get("Studio Custom Notification");
	}

	public static void setMakeUpCustomNotification(String customNotification) {
		constantMap.get().put("MakeUp Custom Notification", customNotification);
	}

	public static String getMakeUpCustomNotification() {
		return (String) constantMap.get().get("MakeUp Custom Notification");
	}

	public static void setCarCustomNotification(String customNotification) {
		constantMap.get().put("Car Custom Notification", customNotification);
	}

	public static String getCarCustomNotification() {
		return (String) constantMap.get().get("Car Custom Notification");
	}

	// Booking cancellation reason
	public static void setBookingCancellationReason(String cancelReason) {
		constantMap.get().put("Cancellation Reason", cancelReason);
	}

	public static String getBookingCancellationReason() {
		return (String) constantMap.get().get("Cancellation Reason");
	}

	// Weekly booking count
	public static void setWeeklyBookingCount(String weeklyCount) {
		constantMap.get().put("Booking Weekly Count", weeklyCount);
	}

	public static String getWeeklyBookingCount() {
		return (String) constantMap.get().get("Booking Weekly Count");
	}

	// Monthly booking count
	public static void setMonthlyBookingCount(String monthlyCount) {
		constantMap.get().put("Booking Monthly Count", monthlyCount);
	}

	public static String getMonthlyBookingCount() {
		return (String) constantMap.get().get("Booking Monthly Count");
	}

	// booking cancellation date
	public static void setBookingCancellationDate(String cancellationDate) {
		constantMap.get().put("Booking Cancellation Date", cancellationDate);
	}

	public static String getBookingCancellationDate() {
		return (String) constantMap.get().get("Booking Cancellation Date");
	}

	// booking cancellation time
	public static void setBookingCancellationTime(String cancellationTime) {
		constantMap.get().put("Booking Cancellation Time", cancellationTime);
	}

	public static String getBookingCancellationTime() {
		return (String) constantMap.get().get("Booking Cancellation Time");
	}

	// reactivate booking date
	public static void setReactivateBookingDate(String reactivateBookingDate) {
		constantMap.get().put("Reactivate Booking Date", reactivateBookingDate);
	}

	public static String getReactivateBookingDate() {
		return (String) constantMap.get().get("Reactivate Booking Date");
	}

	// reactivate booking time
	public static void setReactivateBookingTime(String reactivateBookingTime) {
		constantMap.get().put("Reactivate Booking Time", reactivateBookingTime);
	}

	public static String getReactivateBookingTime() {
		return (String) constantMap.get().get("Reactivate Booking Time");
	}

	/* duplicate booking constants */
	// Is duplicate booking
	public static void setIsDuplicateBooking(String duplicateBooking) {
		constantMap.get().put("Is Duplicate Booking", duplicateBooking);
	}

	public static String getIsDuplicateBooking() {
		return (String) constantMap.get().get("Is Duplicate Booking");
	}

	// Duplicate booking show date
	public static void setDuplicateBookingShowDate(String showDate) {
		constantMap.get().put("Duplicate Booking Show Date", showDate);
	}

	public static String getDuplicateBookingShowDate() {
		return (String) constantMap.get().get("Duplicate Booking Show Date");
	}

	// Duplicate booking show time
	public static void setDuplicateBookingShowTime(String showTime) {
		constantMap.get().put("Duplicate Booking Show Time", showTime);
	}

	public static String getDuplicateBookingShowTime() {
		return (String) constantMap.get().get("Duplicate Booking Show Time");
	}

	// Duplicate topic start time
	public static void setDuplicateBookingTopicStartTime(String topicStartTime) {
		constantMap.get().put("Duplicate Booking Topic Start Name", topicStartTime);
	}

	public static String getDuplicateBookingTopicStartTime() {
		return (String) constantMap.get().get("Duplicate Booking Topic Start Name");
	}

	// Duplicate booking topic end time
	public static void setDuplicateBookingTopicEndTime(String topicEndTime) {
		constantMap.get().put("Duplicate Booking Topic End Name", topicEndTime);
	}

	public static String getDuplicateBookingTopicEndTime() {
		return (String) constantMap.get().get("Duplicate Booking Topic End Name");
	}

}
