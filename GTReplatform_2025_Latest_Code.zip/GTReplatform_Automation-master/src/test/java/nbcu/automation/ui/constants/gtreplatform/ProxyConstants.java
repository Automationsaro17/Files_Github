package nbcu.automation.ui.constants.gtreplatform;

import java.util.HashMap;

public class ProxyConstants {

	private static final ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
		@Override
		protected HashMap<String, Object> initialValue() {
			return new HashMap<>();
		}
	};

	// Proxy Profile DisplayName
	public static void setDisplayName(String addDisplayName) {
		constantMap.get().put("DisplayName", addDisplayName);
	}

	public static String getDisplayName() {
		return (String) constantMap.get().get("DisplayName");
	}

	// Proxy Profile Full Name(Both First Name + Last Name)
	public static void setFullName(String profileName) {
		constantMap.get().put("FullName", profileName);
	}

	public static String getFullName() {
		return (String) constantMap.get().get("FullName");
	}

	// Proxy Profile First Name
	public static void setFirstName(String profileFirstName) {
		constantMap.get().put("FirstName", profileFirstName);
	}

	public static String getFirstName() {
		return (String) constantMap.get().get("FirstName");
	}

	// Proxy Profile Last Name
	public static void setLastName(String profileLastName) {
		constantMap.get().put("LastName", profileLastName);
	}

	public static String getLastName() {
		return (String) constantMap.get().get("LastName");
	}

	// Proxy Second Profile DisplayName
	public static void secondProfileDisplayName(String addDisplayName) {
		constantMap.get().put("DisplayName", addDisplayName);
	}

	public static String getSecondProfileDisplayName() {
		return (String) constantMap.get().get("DisplayName");
	}

	// Proxy Second Profile Full Name
	public static void setsecondProfileFullName(String secondprofileFullName) {
		constantMap.get().put("SecondProfileFullName", secondprofileFullName);
	}

	public static String getsecondProfileFullName() {
		return (String) constantMap.get().get("SecondProfileFullName");
	}

	// Proxy Second Profile FirstName
	public static void setsecondProfileFirstName(String secondProfileFirstName) {
		constantMap.get().put("SecondProfileFirstName", secondProfileFirstName);
	}

	public static String getsecondProfileFirstName() {
		return (String) constantMap.get().get("SecondProfileFirstName");
	}

	// Proxy Second Profile LastName
	public static void setsecondProfileLastName(String secondProfileLastName) {
		constantMap.get().put("SecondProfileLastName", secondProfileLastName);
	}

	public static String getsecondProfileLastName() {
		return (String) constantMap.get().get("SecondProfileLastName");
	}
	
	// Proxy Lead Profile Updated Expertise value
	public static void setExpertise(String leadProfileExpertise) {
		constantMap.get().put("Updated Expertise", leadProfileExpertise);
	}
	
	public static String getExpertise() {
		return (String) constantMap.get().get("Updated Expertise");
	}
	
	public static void setAffiliatedCompanies(String companyName) {
	constantMap.get().put("AffiliatedCompanyName",companyName);
	}
	
	public static String getAffilifatedCompanies() {
		return (String)constantMap.get().get("AffiliatedCompanyName");
	}
	
	public static void setProxyJobNotes(String jobNotesInput) {
		constantMap.get().put("ProxyProfileJobNotes", jobNotesInput);
	}
	
	public static String getProxyJobNotes() {
		return (String) constantMap.get().get("ProxyProfileJobNotes");
	}
	
	// To get CompanyPhone0
		public static String getProxyPhone0() {
			return (String) constantMap.get().get("Proxy PhoneNo0");
		}

		// To set CompanyPhone0
		public static void setProxyPhone0(String proxyPhoneNo0) {
			constantMap.get().put("Proxy PhoneNo0", proxyPhoneNo0);
		}

		// To get CompanyPhone1
		public static String getProxyPhone1() {
			return (String) constantMap.get().get("Proxy PhoneNo1");
		}

		// To set CompanyPhone1
		public static void setProxyPhone1(String proxyPhoneNo1) {
			constantMap.get().put("Proxy PhoneNo1", proxyPhoneNo1);
		}

		// To get CompanyPhone2
		public static String getProxyPhone2() {
			return (String) constantMap.get().get("Proxy PhoneNo2");
		}

		// To set CompanyPhone2
		public static void setProxyPhone2(String proxyPhoneNo2) {
			constantMap.get().put("Proxy PhoneNo2", proxyPhoneNo2);
		}

		// To get CompanyPhone3
		public static String getProxyPhone3() {
			return (String) constantMap.get().get("Proxy PhoneNo3");
		}

		// To set CompanyPhone3
		public static void setProxyPhone3(String proxyPhoneNo3) {
			constantMap.get().put("Proxy PhoneNo3", proxyPhoneNo3);
		}
		
		// To get CompanyEmail0
		public static String getProxyEmail0() {
			return (String) constantMap.get().get("Proxy Email0");
		}

		// To set CompanyEmail0
		public static void setProxyEmail0(String proxyEmail0) {
			constantMap.get().put("Proxy Email0", proxyEmail0);
		}

		// To get CompanyEmail1
		public static String getProxyEmail1() {
			return (String) constantMap.get().get("Proxy Email1");
		}

		// To set CompanyEmail1
		public static void setProxyEmail1(String proxyEmail1) {
			constantMap.get().put("Proxy Email1", proxyEmail1);
		}

		// To get CompanyEmail2
		public static String getProxyEmail2() {
			return (String) constantMap.get().get("Proxy Email2");
		}

		// To set CompanyEmail2
		public static void setProxyEmail2(String proxyEmail2) {
			constantMap.get().put("Proxy Email2", proxyEmail2);
		}

		// To get CompanyEmail3
		public static String getProxyEmail3() {
			return (String) constantMap.get().get("Proxy Email3");
		}

		// To set CompanyEmail3
		public static void setProxyEmail3(String proxyEmail3) {
			constantMap.get().put("Proxy Email3", proxyEmail3);
		}
		
		
		
		// To get CompanyTwitter
		public static String getProxyTwitter() {
			return (String) constantMap.get().get("Proxy Twitter");
		}

		// To set CompanyTwitter
		public static void setProxyTwitter(String proxyTwitter) {
			constantMap.get().put("Proxy Twitter", proxyTwitter);
		}

		// To get CompanyTwitter
		public static String getProxyLinkedIn() {
			return (String) constantMap.get().get("Proxy LinkedIn");
		}

		// To set CompanyTwitter
		public static void setProxyLinkedIn(String proxyLinkedIn) {
			constantMap.get().put("Proxy LinkedIn", proxyLinkedIn);
		}

		// To get CompanyTwitter
		public static String getProxyVideo() {
			return (String) constantMap.get().get("Proxy Video");
		}

		// To set CompanyTwitter
		public static void setProxyVideo(String proxyVideo) {
			constantMap.get().put("Proxy Video", proxyVideo);
		}

		// To get CompanyTwitter
		public static String getProxyWebsite() {
			return (String) constantMap.get().get("Proxy Website");
		}

		// To set CompanyTwitter
		public static void setProxyWebsite(String proxyWebsite) {
			constantMap.get().put("Proxy Website", proxyWebsite);
		}
		
		
		
		
		
		


		public static String getProxyAddressField1() {
			return (String) constantMap.get().get("Proxy AdField1");
		}

		// To set CompanyTwitter
		public static void setProxyField1(String proxyAdField1) {
			constantMap.get().put("Proxy AdField1", proxyAdField1);
		}

		public static String getProxyAddressField2() {
			return (String) constantMap.get().get("Proxy AdField2");
		}

		// To set CompanyTwitter
		public static void setProxyField2(String proxyAdField2) {
			constantMap.get().put("Proxy AdField2", proxyAdField2);
		}

		public static String getProxyCity() {
			return (String) constantMap.get().get("Proxy City");
		}

		public static void setAddressCityField(String proxyCity) {
			constantMap.get().put("Proxy City", proxyCity);
		}

		public static String getProxyState() {
			return (String) constantMap.get().get("Proxy State");
		}

		public static void setAddressStateField(String proxyState) {
			constantMap.get().put("Proxy State", proxyState);
		}

		public static String getProxyZip() {
			return (String) constantMap.get().get("Proxy Zip");
		}

		public static void setAddressZipField(String proxyZip) {
			constantMap.get().put("Proxy Zip", proxyZip);
		}

		public static String getProxyCountry() {
			return (String) constantMap.get().get("Proxy Country");
		}

		public static void setAddressCountryField(String proxyCountry) {
			constantMap.get().put("Proxy Country", proxyCountry);
		}


		// To get CompanyAlerts
		public static String getProxyAlerts() {
			return (String) constantMap.get().get("Proxy Alerts");
		}

		// To set CompanyAlerts
		public static void setProxyAlerts(String proxyAlerts) {
			constantMap.get().put("Company Alerts", proxyAlerts);
		}

		
	public static void setGuestContacts(String guestContactName) {
		constantMap.get().put("ContactCard Name", guestContactName);
	}
	
	public static String getGuestContacts() {
		return (String) constantMap.get().get("ContactCard Name");
	}
		
		
	
	
	public static void setJobStartDate(String jobDate) {
		constantMap.get().put("Job Start Date", jobDate);
	}
	
	public static String getJobStartDate() {
		return (String)constantMap.get().get("Job Start Date");
	}
		
	
	
	public static void setJobTitle(String jobTitle) {
		constantMap.get().put("Job Title", jobTitle);
}
	
	public static String getJobTitle() {
		return (String)constantMap.get().get("Job Title");
	}
	
	
	public static void setJobCategory(String jobCategory) {
		constantMap.get().put("Job Category", jobCategory);
}
	
	public static String getJobCategory() {
		return (String)constantMap.get().get("Job Category");
	}

	
	public static void setJobOrganization(String jobOrganization) {
		constantMap.get().put("Job Organization", jobOrganization);
}
	
	public static String getJobOrganization() {
		return (String)constantMap.get().get("Job Organization");
	}
	
	
	public static void setJobDepartment(String jobDepartment) {
		constantMap.get().put("Job Department", jobDepartment);
}
	
	public static String getJobDepartment() {
		return (String)constantMap.get().get("Job Department");
	}

	public static void setJobNotes(String jobNotes) {
		constantMap.get().put("Job Notes", jobNotes);
}
	
	public static String getJobNotes() {
		return (String)constantMap.get().get("Job Notes");
	}

	public static void setGuestJobTitleInTheCard(String compName) {
		constantMap.get().put("Guest Job Title", compName);
}
	
	public static String getGuestJobTitleInTheCard() {
		return (String)constantMap.get().get("Guest Job Title");
	}
	
	
	public static void setGuestOrgDivision(String orgORdivision) {
		constantMap.get().put("OrgAndDivision", orgORdivision);
}
	public static String getGuestOrgDivision() {
		return (String)constantMap.get().get("OrgAndDivision");
	}
	
	
	
	
	
	
	
	
}
