package nbcu.automation.ui.constants.ncx;

import java.util.HashMap;

public class NCXProfileConstants {

	private static ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
		@Override
		protected HashMap<String, Object> initialValue() {
			return new HashMap<>();
		}
	};

	// To get and set first name
	public static String getFirstName() {
		return (String) constantMap.get().get("First Name");
	}

	public static void setFirstName(String firstName) {
		constantMap.get().put("First Name", firstName);
	}

	// To get and set last name
	public static String getLastName() {
		return (String) constantMap.get().get("Last Name");
	}

	public static void setLastName(String lastName) {
		constantMap.get().put("Last Name", lastName);
	}

	// To get and set email id
	public static String getEmailId() {
		return (String) constantMap.get().get("Email Id");
	}

	public static void setEmailId(String emailId) {
		constantMap.get().put("Email Id", emailId);
	}

	// To get and set job title
	public static String getJobTitle() {
		return (String) constantMap.get().get("Job Title");
	}

	public static void setJobTitle(String jobTitle) {
		constantMap.get().put("Job Title", jobTitle);
	}

	// To get and set company name
	public static String getCompanyName() {
		return (String) constantMap.get().get("Company Name");
	}

	public static void setCompanyName(String companyName) {
		constantMap.get().put("Company Name", companyName);
	}

	// To get and set business unit
	public static String getBusinessUnit() {
		return (String) constantMap.get().get("Business Unit");
	}

	public static void setBusinessUnit(String businessUnit) {
		constantMap.get().put("Business Unit", businessUnit);
	}
}
