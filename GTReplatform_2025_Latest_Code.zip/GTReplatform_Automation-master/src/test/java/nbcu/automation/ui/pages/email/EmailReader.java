package nbcu.automation.ui.pages.email;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeMultipart;

import org.testng.Assert;

import nbcu.automation.ui.constants.email.EmailConstants;
import nbcu.automation.ui.constants.gtreplatform.BookingGuestConstants;
import nbcu.automation.ui.constants.gtreplatform.GuestProfileConstants;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class EmailReader {

	/**
	 * To read email content
	 * 
	 * @param store
	 * @throws NumberFormatException
	 * @throws Exception
	 */
	public static void verifyEmailReceived(String emailReceived, String bookingType)
			throws NumberFormatException, Exception {
		Store store = null;
		String userName = "";
		boolean emailCheck = false;
		try {
			// To fetch guest name
			String expectedGuestName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();

			// To fetch studio
			String expectedStudio = BookingGuestConstants.getStudio();

			// To fetch topic
			String expectedTopicName = BookingGuestConstants.getTopicName();

			// To fetch show name
			String expectedShowName = BookingGuestConstants.getShowName();

			// To fetch show date
			String showDate = BookingGuestConstants.getShowDate();

			// To fetch show time
			String showTime = DateFunctions.convertDateStringToAnotherFormat(BookingGuestConstants.getShowTime(),
					"HH:mm", "hh:mm:ss a");

			// To fetch gmail host, user name and password from config.properties
			String host = ConfigFileReader.getProperty("Gmail-Host");
			userName = ConfigFileReader.getProperty("Gmail-UserName");
			String password = ConfigFileReader.getProperty("Gmail-Password");

			Folder emailFolder = null;
			String subject = "", toList = "", ccList = "", emailBody = "";

			// create properties
			Properties properties = new Properties();

			properties.put("mail.imap.host", host);
			properties.put("mail.imap.port", "993");
			properties.put("mail.pop3.starttls.enable", "true");

			Session emailSession = Session.getDefaultInstance(properties);

			// create the pop3 store object and connect to the pop3 server
			store = emailSession.getStore("imaps");

			store.connect(host, userName, password);

			outer: for (int waitCount = 0; waitCount < 2; waitCount++) {
				// wait for 10 seconds
				Thread.sleep(10000);

				// create the folder object and open it
				emailFolder = store.getFolder("INBOX");
				emailFolder.open(Folder.READ_WRITE);

				// retrieve the messages from the folder in an array and print it
				Message[] messages = emailFolder.getMessages();
				System.out.println("messages.length---" + messages.length);

				// Sorting messages newest to oldest
				// Sort messages from recent to oldest
				/*
				 * Arrays.sort(messages, (m1, m2) -> { try { return
				 * m2.getSentDate().compareTo(m1.getSentDate()); } catch (MessagingException e)
				 * { throw new RuntimeException(e); } });
				 */

				for (int i = messages.length - 1; i >= messages.length - 10; i--) {
					Message message = messages[i];
					System.out.println("---------------------------------");
					System.out.println("Email Number " + (i + 1));
					subject = message.getSubject();

					if (message.getRecipients(Message.RecipientType.TO) != null) {
						for (Address address : message.getRecipients(Message.RecipientType.TO)) {
							toList = toList + address.toString() + ",";
						}
						toList = toList.substring(0, toList.length() - 1);
					}

					if (message.getRecipients(Message.RecipientType.CC) != null) {
						for (Address address : message.getRecipients(Message.RecipientType.CC)) {
							ccList = ccList + address.toString() + ",";
						}
						ccList = ccList.substring(0, ccList.length() - 1);
					}

					emailBody = getTextFromMessage(message);

					// To check email is present
					emailCheck = checkEmailIsPresent(emailBody, bookingType, expectedShowName, expectedGuestName,
							showDate, showTime, expectedStudio, expectedTopicName);

					if (emailCheck) {
						System.out.println("Subject:" + subject.replace("  ", " "));
						System.out.println("To List:" + toList);
						System.out.println("CC List:" + ccList);
						System.out.println("Email Body:" + emailBody);

						// store email subject, to, cc and body
						EmailConstants.setEmailSubject(subject.replace("  ", " "));
						EmailConstants.setEmailToList(toList);
						EmailConstants.setEmailCcList(ccList);
						EmailConstants.setEmailBody(emailBody);
						break outer;
					} else {
						subject = "";
						toList = "";
						ccList = "";
						emailBody = "";
					}
				}
			}

			// Close email folder
			emailFolder.close(false);
			// close the store and folder objects
			store.close();

			// if email received is yes and email is not received , then throw error
			if (emailReceived.trim().equalsIgnoreCase("RECEIVED"))
				Assert.assertTrue(emailCheck,
						"Booking confirmation email of guest '" + expectedGuestName + "' for show '" + expectedShowName
								+ "' and show time '" + showDate + " " + showTime + "' is not received");
			else
				Assert.assertFalse(emailCheck,
						"Booking confirmation email of guest '" + expectedGuestName + "' for show '" + expectedShowName
								+ "' and show time '" + showDate + " " + showTime + "' is received");

		} catch (MessagingException e) {
			store.close();
			e.printStackTrace();
			throw new Exception("Failed to connect email account -" + userName);
		} catch (Exception e) {
			store.close();
			e.printStackTrace();
			throw new Exception("Failed to connect email account -" + userName);
		}
	}

	/**
	 * To read email body
	 * 
	 * @param message
	 * @return
	 * @throws MessagingException
	 * @throws IOException
	 */
	private static String getTextFromMessage(Message message) throws MessagingException, IOException {
		String result = "";
		if (message.isMimeType("text/plain")) {
			result = message.getContent().toString();
		} else if (message.isMimeType("multipart/*")) {
			MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
			result = getTextFromMimeMultipart(mimeMultipart);
		} else if (message.isMimeType("text/html")) {
			String html = (String) message.getContent();
			result = org.jsoup.Jsoup.parse(html).text();
		}
		return result;
	}

	/**
	 * To read multi part email body
	 * 
	 * @param mimeMultipart
	 * @return
	 * @throws MessagingException
	 * @throws IOException
	 */
	private static String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws MessagingException, IOException {
		String result = "";
		int count = mimeMultipart.getCount();
		for (int i = 0; i < count; i++) {
			BodyPart bodyPart = mimeMultipart.getBodyPart(i);
			if (bodyPart.isMimeType("text/plain")) {
				result = result + "\n" + bodyPart.getContent();
				break; // without break same text appears twice in my tests
			} else if (bodyPart.isMimeType("text/html")) {
				String html = (String) bodyPart.getContent();
				result = result + "\n" + org.jsoup.Jsoup.parse(html).text();
			} else if (bodyPart.getContent() instanceof MimeMultipart) {
				result = result + getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent());
			}
		}
		return result;
	}

	private static boolean checkEmailIsPresent(String emailBody, String bookingType, String expectedShowName,
			String expectedGuestName, String showDate, String showTime, String expectedStudio, String expectedTopicName)
			throws MessagingException, IOException {
		boolean emailCheck = false;
		try {
			if ((bookingType.equalsIgnoreCase("NEW BOOKING")) || (bookingType.equalsIgnoreCase("EDITED BOOKING"))) {
				if ((emailBody.toLowerCase().contains(expectedShowName.toLowerCase()))
						&& (emailBody.toLowerCase().contains(expectedGuestName.toLowerCase()))
						&& (emailBody.toLowerCase().contains(showDate))
						&& (emailBody.toLowerCase().contains(showTime.toLowerCase()))
						&& (emailBody.toLowerCase().contains(expectedStudio.toLowerCase()))
						&& (emailBody.toLowerCase().contains(expectedTopicName.toLowerCase()))) {
					emailCheck = true;
				}

			} else if (bookingType.equalsIgnoreCase("CANCEL BOOKING")) {
				if ((emailBody.toLowerCase().contains(expectedShowName.toLowerCase()))
						&& (emailBody.toLowerCase().contains(expectedGuestName.toLowerCase()))
						&& (emailBody.toLowerCase().contains(showDate))
						&& (emailBody.toLowerCase().contains("cancelled"))) {
					emailCheck = true;
				}
			} else if (bookingType.equalsIgnoreCase("DUPLICATE BOOKING")) {
				showTime = DateFunctions.convertDateStringToAnotherFormat(BookingGuestConstants.getDuplicateBookingShowTime(),
						"HH:mm", "hh:mm:ss a");
				if ((emailBody.toLowerCase().contains(expectedShowName.toLowerCase()))
						&& (emailBody.toLowerCase().contains(expectedGuestName.toLowerCase()))
						&& (emailBody.toLowerCase().contains(showDate))
						&& (emailBody.toLowerCase().contains(showTime.toLowerCase()))
						&& (emailBody.toLowerCase().contains(expectedTopicName.toLowerCase()))
						&& (emailBody.toLowerCase().contains("duplicate booking alert"))) {
					emailCheck = true;
				}
			} else
				Assert.assertTrue(false, "Enter valid booking type for email check");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return emailCheck;
	}

	public static void main(String[] args) throws Exception {

		/*
		 * String host = "imap.gmail.com"; String mailStoreType = "imap"; String
		 * username = "mag459new@gmail.com"; String password = "ednkpqmqnwiiyxfs";
		 */

		verifyEmailReceived("received", "NEW BOOKING");

	}
}
