package nbcu.automation.ui.pages.gtreplatform;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.automation.ui.constants.gtreplatform.BookerProfileConstants;
import nbcu.automation.ui.constants.ncx.NCXProfileConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class BookerProfileEditPage {

	// Drop down value xpath
	String dropDownvaluesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropDownvalues;

	// Buttons
	@FindBy(xpath = "//button[span[text()='Update']]")
	WebElement updateButton;

	@FindBy(xpath = "//button[span[text()='Cancel']]")
	WebElement cancelButton;

	// Name section
	@FindBy(id = "BasicInfo_firstName")
	WebElement firstNameTextBox;

	@FindBy(id = "BasicInfo_lastName")
	WebElement lastNameTextBox;

	// Job Info
	@FindBy(id = "BasicInfo_jobTitle")
	WebElement jobTitleTextBox;

	@FindBy(id = "BasicInfo_company")
	WebElement jobCompanyTextBox;

	@FindBy(id = "BasicInfo_businessUnit")
	WebElement jobBusinessUnitTextBox;

	@FindBy(id = "BasicInfo_location")
	WebElement jobLocationTextBox;

	// Work email
	@FindBy(id = "Contact_Email_0_email")
	WebElement workEmailTextBox1;

	@FindBy(id = "Contact_Email_1_email")
	WebElement workEmailTextBox2;

	@FindBy(id = "Contact_Email_2_email")
	WebElement workEmailTextBox3;

	@FindBy(id = "Contact_Email_3_email")
	WebElement workEmailTextBox4;

	// division selector
	@FindBy(xpath = "//span[@class='ant-select-selection-item']")
	WebElement divisionDropdown;

	// View selector check box
	@FindBy(xpath = "//div[@id='BasicInfo_viewSelector']//input[@value='B']")
	WebElement bookedGuestViewCheckBox;

	@FindBy(xpath = "//div[@id='BasicInfo_viewSelector']//input[@value='S']")
	WebElement segmentViewCheckBox;

	public BookerProfileEditPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify booker profile view page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyBookerProfileEditPageLoaded() throws Exception {
		try {
			Waits.waitForElement(updateButton, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify name, job info and work email are disabled
	 * 
	 * @throws Exception
	 */
	public void verifyNameJobDetailsFieldsDisabled() throws Exception {
		try {
			CommonValidations.verifyAttributeValue(firstNameTextBox, "class", "disabled",
					"First name text box is enabled in booker profile edit page");
			CommonValidations.verifyAttributeValue(lastNameTextBox, "class", "disabled",
					"Last name text box is enabled in booker profile edit page");
			CommonValidations.verifyAttributeValue(jobTitleTextBox, "class", "disabled",
					"Job title text box is enabled in booker profile edit page");
			CommonValidations.verifyAttributeValue(jobCompanyTextBox, "class", "disabled",
					"Job company name text box is enabled in booker profile edit page");
			CommonValidations.verifyAttributeValue(jobBusinessUnitTextBox, "class", "disabled",
					"Job business unit text box is enabled in booker profile edit page");
			CommonValidations.verifyAttributeValue(jobLocationTextBox, "class", "disabled",
					"Job location text box is enabled in booker profile edit page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify name details in booker profile edit page
	 * 
	 * @throws Exception
	 */
	public void verifyBookerProfileNameDetails() throws Exception {
		try {
			CommonValidations.verifyAttributeValue(firstNameTextBox, "value", NCXProfileConstants.getFirstName(),
					"First name in booker profile edit page is not matched with NCX");
			CommonValidations.verifyAttributeValue(lastNameTextBox, "value", NCXProfileConstants.getLastName(),
					"Last name in booker profile edit page is not matched with NCX");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify job details in booker profile edit page
	 * 
	 * @throws Exception
	 */
	public void verifyBookerProfileJobDetails() throws Exception {
		try {
			CommonValidations.verifyAttributeValue(jobTitleTextBox, "value", NCXProfileConstants.getJobTitle(),
					"Job title in booker profile edit page is not matched with NCX");
			CommonValidations.verifyAttributeValue(jobCompanyTextBox, "value", NCXProfileConstants.getCompanyName(),
					"Job company name in booker profile edit page is not matched with NCX");
			String actualBusinessUnit = WebAction.getAttribute(jobBusinessUnitTextBox, "value").replace(" ", "");
			String expectedBusiString = NCXProfileConstants.getBusinessUnit().replace(" ", "");
			Assert.assertTrue(actualBusinessUnit.contains(expectedBusiString),
					"Job business unit in booker profile edit page is not matched with NCX");
			CommonValidations.verifyAttributeValue(jobLocationTextBox, "value", "",
					"Job location in booker profile edit page is not matched with NCX");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify work email id in booker profile edit page
	 * 
	 * @throws Exception
	 */
	public void verifyBookerProfileWorkEmail() throws Exception {
		try {
			CommonValidations.verifyAttributeValue(workEmailTextBox1, "value", NCXProfileConstants.getEmailId(),
					"Work email in booker profile edit page is not matched with NCX");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To change the default division
	 * 
	 * @throws Exception
	 */
	public void changeDivisionSelector() throws Exception {
		try {
			WebAction.click(divisionDropdown);
			if (WebAction.getAttribute(divisionDropdown, "title").equalsIgnoreCase("CNBC")) {
				BookerProfileConstants.setDefaultDivisionName("MSNBC");
				WebAction.nonEnterebaleSelectDropDown(dropDownvaluesXpath, "MSNBC",
						"MSNBC value is not present in the division drop down");
			} else if (WebAction.getAttribute(divisionDropdown, "title").equalsIgnoreCase("MSNBC")) {
				BookerProfileConstants.setDefaultDivisionName("CNBC");
				WebAction.nonEnterebaleSelectDropDown(dropDownvaluesXpath, "CNBC",
						"CNBC value is not present in the division drop down");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To change view selector
	 * 
	 * @throws Exception
	 */
	public void changeViewSelector() throws Exception {
		try {
			if (WebAction.isSelected(bookedGuestViewCheckBox)) {
				BookerProfileConstants.setDefaultViewName("SEGMENT");
				WebAction.clickUsingJs(segmentViewCheckBox);
			} else {
				BookerProfileConstants.setDefaultViewName("BOOKED");
				WebAction.clickUsingJs(bookedGuestViewCheckBox);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click update or cancel button
	 * 
	 * @throws Exception
	 */
	public void clickUpdateOrCancelButton(String buttonName) throws Exception {
		try {
			if (buttonName.equalsIgnoreCase("UPDATE"))
				WebAction.click(updateButton);
			else if (buttonName.equalsIgnoreCase("CANCEL"))
				WebAction.click(cancelButton);
			else
				Assert.assertTrue(false, "Please provide valid button name in booker profile edit page");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To update email address for email notification validation
	 * 
	 * @throws Exception
	 */
	public void updateEmailAddress() throws Exception {
		try {
			System.out.println();
			boolean emailPresent = false;
			String emailNotificationAddress = ConfigFileReader.getProperty("Gmail-UserName");

			// fetch email address
			String email1 = WebAction.getAttribute(workEmailTextBox1, "value");
			String email2 = WebAction.getAttribute(workEmailTextBox2, "value");
			String email3 = WebAction.getAttribute(workEmailTextBox3, "value");
			String email4 = WebAction.getAttribute(workEmailTextBox4, "value");

			if ((email1 != null) && (!email1.isEmpty())) {
				BookerProfileConstants.setEmail1(email1);
				if (email1.equalsIgnoreCase(emailNotificationAddress))
					emailPresent = true;
			}
			if ((email2 != null) && (!email2.isEmpty())) {
				BookerProfileConstants.setEmail2(email2);
				if (email2.equalsIgnoreCase(emailNotificationAddress))
					emailPresent = true;
			}
			if ((email3 != null) && (!email3.isEmpty())) {
				BookerProfileConstants.setEmail3(email3);
				if (email3.equalsIgnoreCase(emailNotificationAddress))
					emailPresent = true;
			}
			if ((email4 != null) && (!email4.isEmpty())) {
				BookerProfileConstants.setEmail4(email4);
				if (email4.equalsIgnoreCase(emailNotificationAddress))
					emailPresent = true;
			}

			// Update email Address
			if (emailPresent == false) {
				if ((BookerProfileConstants.getEmail1() == null) || (BookerProfileConstants.getEmail1().isEmpty())) {
					if (WebAction.isEnabled(workEmailTextBox1)) {
						WebAction.sendKeys(workEmailTextBox1, emailNotificationAddress);
						BookerProfileConstants.setEmail1(emailNotificationAddress);
					}
				} else if ((BookerProfileConstants.getEmail2() == null)
						|| (BookerProfileConstants.getEmail2().isEmpty())) {
					if (WebAction.isEnabled(workEmailTextBox2)) {
						WebAction.sendKeys(workEmailTextBox2, emailNotificationAddress);
						BookerProfileConstants.setEmail2(emailNotificationAddress);
					}
				} else if ((BookerProfileConstants.getEmail3() == null)
						|| (BookerProfileConstants.getEmail3().isEmpty())) {
					if (WebAction.isEnabled(workEmailTextBox3)) {
						WebAction.sendKeys(workEmailTextBox3, emailNotificationAddress);
						BookerProfileConstants.setEmail3(emailNotificationAddress);
					}
				} else {
					if (WebAction.isEnabled(workEmailTextBox4)) {
						WebAction.sendKeys(workEmailTextBox4, emailNotificationAddress);
						BookerProfileConstants.setEmail4(emailNotificationAddress);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
