package nbcu.automation.ui.pages.gtreplatform;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.automation.ui.constants.ncx.NCXProfileConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;

public class BookerProfileViewPage {
	
	//Booker profile header details
	@FindBy(xpath = "//li[contains(@class,'name')]")
	List<WebElement> headerBookerProfileNameElement;
	
	@FindBy(xpath = "//li[contains(@class,'title')]")
	List<WebElement> headerBookerProfileTitleElement;
	
	@FindBy(xpath = "//li[contains(@class,'businessUnit')]")
	List<WebElement> headerBookerProfileBusinessUnitElement;
	
	@FindBy(xpath = "//li[contains(@class,'division')]")
	List<WebElement> headerBookerProfileDivisionElement;
	
	//Booker profile button
	@FindBy(xpath = "//li[span[text()='Copy']]")
	List<WebElement> copyButton;
	
	@FindBy(xpath = "//li[span[text()='Edit']]")
	List<WebElement> editButton;
	
	// Copy clipboard message
	@FindBy(xpath = "//span[text()='Profile link was copied to your clipboard.']")
	WebElement copyClipboradMessage;
	
	//Booker profile job info
	@FindBy(xpath = "//td[div[text()='Job Title']]/following-sibling::td[1]/div")
	WebElement jobTitleElement;
	
	@FindBy(xpath = "//td[div[text()='Org / Company ']]/following-sibling::td[1]/div")
	WebElement jobCompanyNameElement;
	
	@FindBy(xpath = "//td[div[text()='Business Unit']]/following-sibling::td[1]/div")
	WebElement jobBusinessUnitElement;
	
	@FindBy(xpath = "//td[div[text()='Location']]/following-sibling::td[1]/div")
	WebElement jobLocationElement;
	
	@FindBy(xpath = "//td[div[text()='Work']]/following-sibling::td[1]/div")
	WebElement workEmailElement;



	public BookerProfileViewPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify booker profile view page loaded
	 * @throws Exception
	 */
	public void verifyBookerProfileViewPageLoaded() throws Exception {
		try {
			Waits.waitForElement(editButton.get(0), WAIT_CONDITIONS.CLICKABLE);
			Thread.sleep(1000);
			Waits.waitForElement(copyButton.get(0), WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To verify edit and copy buttons are displayed
	 * @throws Exception
	 */
	public void verifyButtons() throws Exception {
		try {
			Assert.assertTrue(editButton.size()>0, "Edit button is not displayed in booker profile view page");
			Assert.assertTrue(copyButton.size()>0, "Copy button is not displayed in booker profile view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To verify booker profile header details
	 * @throws Exception
	 */
	public void verifyHeaderSection() throws Exception {
		try {
			CommonValidations.verifyTextValue(headerBookerProfileNameElement.get(0), NCXProfileConstants.getFirstName()+" "+NCXProfileConstants.getLastName(), "Booker name is header is not matching with NCX");
			CommonValidations.verifyTextValue(headerBookerProfileTitleElement.get(0), NCXProfileConstants.getJobTitle(), "Booker job title is header is not matching with NCX");
			CommonValidations.verifyTextValue(headerBookerProfileBusinessUnitElement.get(0), NCXProfileConstants.getBusinessUnit(), "Booker business unit is header is not matching with NCX");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To verify booker job info section
	 * @throws Exception
	 */
	public void verifyJobInfoSection() throws Exception {
		try {
			CommonValidations.verifyTextValue(jobTitleElement, NCXProfileConstants.getJobTitle(), "Booker job title is not matching with NCX");
			CommonValidations.verifyTextValue(jobCompanyNameElement, NCXProfileConstants.getCompanyName(), "Booker job company name is not matching with NCX");
			CommonValidations.verifyTextValue(jobBusinessUnitElement,NCXProfileConstants.getBusinessUnit() , "Booker job business unit is not matching with NCX");
			CommonValidations.verifyTextValue(jobLocationElement,"NA" , "Booker job location is not matching with NCX");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To verify booker contact info section
	 * @throws Exception
	 */
	public void verifyContactInfoSection() throws Exception {
		try {
			CommonValidations.verifyTextValue(workEmailElement, NCXProfileConstants.getEmailId(), "Booker email contact is not matching with NCX");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To click Edit/Copy button
	 * @throws Exception
	 */
	public void clickEditOrCopyButton(String buttonName) throws Exception {
		try {
			if (buttonName.equalsIgnoreCase("EDIT")) {
				Waits.waitForElement(editButton.get(0), WAIT_CONDITIONS.CLICKABLE);
				Thread.sleep(3000);
				WebAction.click(editButton.get(0));
			}
			else if (buttonName.equalsIgnoreCase("COPY"))
				WebAction.click(copyButton.get(0));
			else
				Assert.assertTrue(false, "Please provide valid button name in booker profile view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify copy clipboard message is displayed
	 * @throws Exception
	 */
	public void verifyCopyClipBoardMessage() throws Exception {
		try {
			Waits.waitForElement(copyClipboradMessage, WAIT_CONDITIONS.VISIBLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To verify copied booker profile link
	 * @throws Exception
	 */
	public void verifyCopiedBookerProfileLink() throws Exception {
		try {
			String expectedUrl = WebAction.getCurrentUrl();
			
			//To fetch copied url
			Toolkit toolkit = Toolkit.getDefaultToolkit();
		    Clipboard clipboard = toolkit.getSystemClipboard();
		    String actualUrl = (String) clipboard.getData(DataFlavor.stringFlavor);
		    
		    Assert.assertEquals(actualUrl, expectedUrl, "Copied booker profile url is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}
