package nbcu.automation.ui.pages.gtreplatform;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.text.WordUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.gtreplatform.AdminConstants;
import nbcu.automation.ui.constants.gtreplatform.BookerProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.BookingGuestConstants;
import nbcu.automation.ui.constants.gtreplatform.GuestProfileConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.others.DateFunctions.DATECOMPARECONDITIONS;
import nbcu.framework.utils.others.DateFunctions.TIMEZONES;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

@SuppressWarnings("deprecation")
public class BookingEditPage {

	// Search and add guest profile elements
	@FindBy(xpath = "//button[@data-trigger='add-booking']/span")
	WebElement bookingFormIcon;

	@FindBy(xpath = "//div[@class='ant-drawer-wrapper-body']")
	WebElement guestSearchRHDrawer;

	@FindBy(xpath = "//div[@class='ant-drawer-title']")
	WebElement guestRhDrawerTitle;

	@FindBy(xpath = "//input[@class='ant-input']")
	WebElement searchGuestTextBox;

	@FindBy(xpath = "//div[@class='styles__content__kfLJV']//span[@class='ant-radio']/input")
	List<WebElement> guestProfileRadioButtons;

	String guestProfileRadioButtonsXpath = "//div[@class='styles__content__kfLJV']//span[@class='ant-radio']/input";

	@FindBy(xpath = "//li[contains(@class,'line1')]/span")
	List<WebElement> guestProfileNameList;

	@FindBy(xpath = "//span[text()='Add Guest']")
	WebElement addGuestBtn;

	// Guest profile header elements
	//@FindBy(xpath = "//li[contains(@class,'name')]")
	@FindBy(xpath = "//li[contains(@class,'name')]/button")
	WebElement guestName_Header;

	@FindBy(xpath = "//li[contains(@class,'name')]//span")
	WebElement contributorTickMark_Header;

	@FindBy(xpath = "//li[contains(@class,'title')]")
	WebElement guestJobTitle_Header;

	@FindBy(xpath = "//li[contains(@class,'company')]")
	WebElement guestCompany_Header;

	// form tab
	@FindBy(xpath = "//li[span[text()='Form']]")
	WebElement formTab;

	// Details section elements
	@FindBy(xpath = "//input[@placeholder='Show Date']")
	WebElement showDateField;

	@FindBy(xpath = "//input[@placeholder='Show Date']/../span[contains(@class,'clear')]")
	WebElement showDateClear;

	@FindBy(id = "show")
	WebElement showDropDown;

	@FindBy(xpath = "//input[@placeholder='Show Time']")
	WebElement showTimeTextBox;

	@FindBy(xpath = "//input[@placeholder='Show Time']/following-sibling::span[contains(@class,'clear')]")
	WebElement showTimeTextBoxClear;

	@FindBy(xpath = "//*[@id='event']/../following-sibling::span")
	WebElement eventTypeDropDownDefaultValueElement;

	@FindBy(id = "event")
	WebElement eventTypeDropDown;

	// Topis/segments elements

	@FindBy(id = "topic")
	WebElement topicDropDown;

	@FindBy(xpath = "//button[span[text()='New']]")
	WebElement addTopicButton;

	// Drop down value xpath
	String dropDownValuesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropDownvalues;

	// Topics RH drawer elements
	@FindBy(xpath = "//div[@class='ant-drawer-title' and text()='Topic Creation']")
	WebElement topicRhDrawerHeader;

	@FindBy(id = "title")
	WebElement topicNameTextBox;

	@FindBy(xpath = "//div[label[text()='Start Time']]/following-sibling::div[1]//input[@placeholder='Select Time']")
	WebElement topicStartTimeTextBox;

	@FindBy(xpath = "//div[label[text()='End Time']]/following-sibling::div[1]//input[@placeholder='Select Time']")
	WebElement topicEndTimeTextBox;

	@FindBy(id = "notes")
	WebElement topicNotesTextBox;

	@FindBy(xpath = "//div[contains(@class,'topicCreator')]//div[5]/button[span[text()='Add Topic' or text()='Add Segment']]")
	WebElement addTopicButtonInRhDrawer;

	// Topic parking lot elements

	String addedTopicListXpath = "//div[contains(@class,'topicCreated_')]/div[contains(@class,'topic')]";

	@FindBy(xpath = "//div[contains(@class,'topic')]//div[contains(@class,'title')]")
	List<WebElement> addedTopicName;

	@FindBy(xpath = "//div[contains(@class,'topic')]//div[contains(@class,'time')]")
	List<WebElement> addedTopicTime;

	@FindBy(xpath = "//div[contains(@class,'topic')]//div[contains(@class,'notes')]")
	List<WebElement> addedTopicNotes;

	@FindBy(xpath = "//div[contains(@data-component,'topic')]/button[span[@aria-label='edit']]")
	List<WebElement> topicEditIcon;

	@FindBy(xpath = "//div[contains(@data-component,'topic')]/button[span[@aria-label='delete']]")
	List<WebElement> topicDeleteIcon;

	@FindBy(xpath = "//button[span[@aria-label='close']]")
	WebElement closeTopicRhDrawer;

	@FindBy(xpath = "//span[input[@id='topic']]/following::span[1]")
	WebElement topicsNameInDropDownField;

	@FindBy(xpath = "//button[span[@aria-label='arrow-up']]")
	WebElement upArrow;

	@FindBy(id = "topic")
	WebElement TopicsOrSegmentsDropDown;

	// Booking type icons
	@FindBy(xpath = "//button[span[text()='Call Out']]")
	WebElement callOutButton;

	@FindBy(xpath = "//button[span[text()='Booking']]")
	WebElement bookingButton;

	// Call out elements
	@FindBy(id = "call_calledBy")
	WebElement calledByTextBox;

	@FindBy(xpath = "//input[@placeholder='Find booker here']")
	WebElement calledForDropDown;

	@FindBy(id = "call_status")
	WebElement callStatusDropDown;

	@FindBy(id = "call_notes")
	WebElement callNotesTextBox;

	// booking form elements
	@FindBy(xpath = "//span[text()='Booking Form']")
	WebElement bookingFormHeader;

	@FindBy(id = "booking_bookedBy")
	WebElement bookedByTextBox;

	@FindBy(xpath = "//input[@placeholder='Find booker here']")
	WebElement bookedForTextBox;

	@FindBy(xpath = "//input[@placeholder='Select Date']")
	WebElement bookingDateTextBox;

	@FindBy(xpath = "//div[input[@placeholder='Select Date']]/span[contains(@class,'clear')]")
	WebElement clearBookingDate;

	@FindBy(xpath = "//div[label[@for='booking_bookedTime' or @for='call_callTime']]/following-sibling::div//input[@placeholder='Select Time']")
	WebElement bookingTimeTextBox;

	@FindBy(xpath = "//div[label[@for='booking_bookedTime' or @for='call_callTime']]/following-sibling::div//span[contains(@class,'clear')]")
	WebElement clearBookingTime;

	@FindBy(id = "booking_notes")
	WebElement bookingTechnicalNotes;

	// Recurring booking elements
	@FindBy(xpath = "//button[span[contains(text(),'Recurring Booking')]]")
	WebElement recurreingBookingButton;

	@FindBy(xpath = "//div[*[@title='End Date']]/following-sibling::div//input")
	WebElement recurreingBookingEndDateTextBox;

	@FindBy(xpath = "//span[text()='Sunday']/preceding-sibling::span/input")
	WebElement recurreingBookingSundayCheckBox;

	@FindBy(xpath = "//span[text()='Monday']/preceding-sibling::span/input")
	WebElement recurreingBookingMondayCheckBox;

	@FindBy(xpath = "//span[text()='Tuesday']/preceding-sibling::span/input")
	WebElement recurreingBookingTuesdayCheckBox;

	@FindBy(xpath = "//span[text()='Wednesday']/preceding-sibling::span/input")
	WebElement recurreingBookingWednesdayCheckBox;

	@FindBy(xpath = "//span[text()='Thursday']/preceding-sibling::span/input")
	WebElement recurreingBookingThursdayCheckBox;

	@FindBy(xpath = "//span[text()='Friday']/preceding-sibling::span/input")
	WebElement recurreingBookingFridayCheckBox;

	@FindBy(xpath = "//span[text()='Saturday']/preceding-sibling::span/input")
	WebElement recurreingBookingSaturdayCheckBox;

	// Booking studio elements
	@FindBy(xpath = "//div[@id='booking_studioType']//span[text()='Registered']")
	WebElement registeredStudioType;

	@FindBy(xpath = "//div[@id='booking_studioType']//span[text()='Other']")
	WebElement otherStudioType;

	@FindBy(id = "booking_studio")
	WebElement studioDropDown;

	@FindBy(xpath = "//input[@id='booking_studio_state']/../..")
	WebElement studioStateDropDown;

	@FindBy(id = "booking_otherStudio")
	WebElement otherStudioTextBox;

	// Email communication elements
	@FindBy(xpath = "//span[text()='Email Communication']")
	WebElement emailCommunicationHeader;

	@FindBy(xpath = "//h3[text()='Alerts']")
	WebElement alertHeader;

	@FindBy(xpath = "//input[@placeholder='Add email addresses here...']")
	WebElement alertTextBox;

	@FindBy(xpath = "//span[@aria-label='plus-circle']")
	WebElement addAlertIcon;

	@FindBy(xpath = "//div[contains(@data-component,'email-list')]/ul/li")
	List<WebElement> addedAlertEmailCount;

	String addedAlertEmailCountXpath = "//div[contains(@data-component,'email-list')]/ul/li";

	@FindBy(xpath = "//div[contains(@data-component,'email-list')]/ul/li/button")
	List<WebElement> alertEmailDeleteIcon;

	// Custom notifications
	@FindBy(xpath = "//input[@value='All']")
	WebElement allCheckBox;

	@FindBy(xpath = "//input[@value='Showname']")
	WebElement showNameCheckBox;

	@FindBy(xpath = "//input[@value='Topic']")
	WebElement topicCheckBox;

	@FindBy(xpath = "//input[@value='StudioOrOther']")
	WebElement studioOrOtherCheckBox;

	@FindBy(xpath = "//input[@value='Makeup']")
	WebElement makeUpCheckBox;

	@FindBy(xpath = "//input[@value='Car']")
	WebElement carCheckBox;

	// button elements
	@FindBy(xpath = "//button[span[text()='Submit']]")
	WebElement submitButton;

	@FindBy(xpath = "//button[span[text()='Update']]")
	WebElement updateButton;

	@FindBy(xpath = "//button[span[text()='Cancel']]")
	WebElement cancelButton;

	// Booking success popup elements
	@FindBy(xpath = "//span[@class='ant-modal-confirm-title']")
	WebElement bookingCallPlacedSuccessPopup;

	@FindBy(xpath = "//div[@class='ant-modal-confirm-btns']//span[text()='OK']")
	WebElement okButtonInSuccessPopup;

	// Duplicate booking elements
	@FindBy(xpath = "//header[contains(text(),'Duplicate Booking')]")
	WebElement duplicateBookingPopUpHeaderElement;

	@FindBy(xpath = "//p[contains(@class,'title')]")
	WebElement duplicateBookingTitleElement;

	@FindBy(xpath = "//div[contains(@class,'show')]/p")
	List<WebElement> duplicateBookingShowDetails;

	@FindBy(xpath = "//p[contains(@class,'disclaimer')]")
	WebElement duplicateBookingDisClaimerElement;

	@FindBy(xpath = "//header[contains(text(),'Duplicate Booking')]/following-sibling::footer/button/span[text()='Cancel']")
	WebElement duplicateBookingCancelButton;

	@FindBy(xpath = "//header[contains(text(),'Duplicate Booking')]/following-sibling::footer/button/span[text()='Exclude']")
	WebElement duplicateBookingExcludeButton;

	@FindBy(xpath = "//header[contains(text(),'Duplicate Booking')]/following-sibling::footer/button/span[text()='Ok']")
	WebElement duplicateBookingOkButton;

	@FindBy(xpath = "//div[@class='ant-message-custom-content ant-message-info']/span[contains(text(),'excluded')]")
	WebElement excludeInfoMessageElement;

	public BookingEditPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify booking edit page is loaded
	 **/
	public void verifyBookingEditPageLoaded() throws Exception {
		try {
			Waits.waitForElement(showDateField, WAIT_CONDITIONS.CLICKABLE);
			Thread.sleep(5000);
			} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Click "Booking Form" icon in header
	 **/
	public void clickBookingIcon() throws Exception {
		try {
			boolean isPresent = WebAction.isDisplayed(bookingFormIcon);
			if (isPresent) {
				WebAction.click(bookingFormIcon);
				Waits.waitForElement(guestSearchRHDrawer, WAIT_CONDITIONS.VISIBLE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Verify Guest Search RH drawer opened
	 **/
	public void verifyGuestRhDrawer() throws Exception {
		try {
			Waits.waitForElement(searchGuestTextBox, WAIT_CONDITIONS.CLICKABLE);
			CommonValidations.verifyTextValue(guestRhDrawerTitle, "Guest Search",
					"Guest Search RH drawer is not displayed");
			Waits.waitForElement(searchGuestTextBox, WAIT_CONDITIONS.CLICKABLE);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To search and add guest profile in guest RH
	 * 
	 * @throws Exception
	 **/
	public void searchAndAddGuestProfile(String guestName) throws Exception {
		try {
			// search guest profile
			String searchText = "";
			WebAction.click(searchGuestTextBox);
			if (GuestProfileConstants.getDisplayName() != null) {
				guestName = GuestProfileConstants.getDisplayName();
				searchText = guestName.split("_")[1];
			} else if (GuestProfileConstants.getFullName() != null) {
				guestName = GuestProfileConstants.getFullName();
				searchText = guestName.split("_")[1];
			} else
				searchText = guestName;
			WebAction.sendKeys_WithTimeGap(searchGuestTextBox, searchText);

			// select guest profile
			System.out.println("Radio Button size is greater than " + guestProfileRadioButtons.size());
			Waits.waitUntilElementSizeGreater(By.xpath(guestProfileRadioButtonsXpath), 0);
			for (int i = 0; i < guestProfileNameList.size(); i++) {
				if (WebAction.getText(guestProfileNameList.get(i)).equalsIgnoreCase(guestName)) {
					WebAction.clickUsingJs(guestProfileRadioButtons.get(i));
					break;
				}
			}

			// click add guest button
			WebAction.click(addGuestBtn);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select and add guest profile
	 * 
	 * @throws Exception
	 **/
	public void verifyGuestRhDrawerClosed() throws Exception {
		try {
			Waits.waitForElement(guestName_Header, WAIT_CONDITIONS.VISIBLE);
			Assert.assertFalse(WebAction.isDisplayed(guestRhDrawerTitle), "Guest RH drawer is not closed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Verify the Guest Name, job title, company and contributor in header
	 **/
	public void verifyGuestProfileDetailsInHeader(String fieldName) {
		try {
			switch (fieldName.toUpperCase()) {
			case "NAME":
				String expectedGuestName = "";
				if (GuestProfileConstants.getDisplayName() != null)
					expectedGuestName = GuestProfileConstants.getDisplayName();
				else
					expectedGuestName = GuestProfileConstants.getFullName();
				CommonValidations.verifyTextValue(guestName_Header, expectedGuestName,
						"Guest profile name in header is not matching");
				break;
			case "CONTRIBUTOR ICON":
				if (GuestProfileConstants.getContributors() != null) {
					Assert.assertTrue(WebAction.isDisplayed(contributorTickMark_Header),
							"Contributor tick mark icon is not displayed");
					CommonValidations.verifyColorOfElement(contributorTickMark_Header, "color", "yellow");
				}
				break;
			case "JOB TITLE":
				if (GuestProfileConstants.getPrimaryJobTitle() != null)
					CommonValidations.verifyTextValue(guestJobTitle_Header, GuestProfileConstants.getPrimaryJobTitle(),
							"Guest profile primary job in header is not matching");
				break;
			case "COMPANY":
				if (GuestProfileConstants.getPrimaryCompany() != null)
					CommonValidations.verifyTextValue(guestCompany_Header, GuestProfileConstants.getPrimaryCompany(),
							"Guest profile primary company in header is not matching");
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Verify Form page is displayed by default
	 **/
	public void verifyFormTabSelectedByDefault() {
		try {
			Assert.assertTrue(WebAction.isDisplayed(formTab), "Form tab is not displayed in booking edit page");
			CommonValidations.verifyColorOfElement(formTab, "color", "blue");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Verify event type drop down default value
	 * 
	 * @throws Exception
	 **/
	public void verifyEventTypeDefaultValue(String expectedValue) throws Exception {
		try {
			Waits.waitForElement(eventTypeDropDown, WAIT_CONDITIONS.CLICKABLE);
			Waits.waitUntilAttributeValueChanges(eventTypeDropDownDefaultValueElement, "title", expectedValue);
			CommonValidations.verifyAttributeValue(eventTypeDropDownDefaultValueElement, "title", expectedValue,
					"Event type drop down default value is not displayed as " + expectedValue);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Verify Topics/Segment option id disabled
	 **/
	public void verifyTopicsOrSegmentsFieldDisableByDefault() throws Exception {
		try {
			Assert.assertFalse(WebAction.isEnabled(topicDropDown),
					"Topic drop down is enabled by default in booking edit page");
			Assert.assertFalse(WebAction.isEnabled(addTopicButton),
					"Add topic button is enabled by default in booking edit page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill show details of call out/booking
	 * 
	 * @param showDate  - show date
	 * @param showName  - show name
	 * @param showTime  - show time
	 * @param eventType - event type
	 * @throws Exception
	 */
	public void fillShowDetails(String isDuplicateBooking, String showDate, String showName, String showTime,
			String eventType) throws Exception {
		try {
			// To set duplicate booking or not
			if (isDuplicateBooking == null || isDuplicateBooking.equalsIgnoreCase("No"))
				BookingGuestConstants.setIsDuplicateBooking("No");
			else
				BookingGuestConstants.setIsDuplicateBooking("Yes");

			// To book guest from segment view. So user does not change date, time, show and
			// segments details
			if ((WebAction.getAttribute(showDateField, "value")
					.equalsIgnoreCase(DateFunctions.getCurrentDateAndTimeByTimeZone("MM/dd/yyyy", TIMEZONES.EST)))
					&& showDate == null) {
				BookingGuestConstants
						.setShowDate(DateFunctions.getCurrentDateAndTimeByTimeZone("MM/dd/yyyy", TIMEZONES.EST));
				BookingGuestConstants.setShowName(AdminConstants.getShowName());
				BookingGuestConstants.setShowTime(AdminConstants.getScheduleStartTime());
				BookingGuestConstants.setEventType("LIVE");
			}
			// To book guest by selecting date, show, type and event type
			else {
				// Select show date
				if (showDate.toUpperCase().contains("CURRENTDATE"))
					showDate = generateDate(showDate, "MM/dd/yyyy");

				if (isDuplicateBooking == null || isDuplicateBooking.equalsIgnoreCase("No"))
					BookingGuestConstants.setShowDate(showDate);
				else
					BookingGuestConstants.setDuplicateBookingShowDate(showDate);

				// To update show date , clearing show date field
				if (WebAction.isDisplayed(updateButton)) {
					Waits.waitForElement(updateButton, WAIT_CONDITIONS.CLICKABLE);
					Thread.sleep(2000);
					WebAction.click(showDateField);
					WebAction.click(showDateClear);
				}
				WebAction.scrollUsingJavaScriptAndClick(showDateField);
				WebAction.sendKeys(showDateField, showDate);
				Thread.sleep(500);
				WebAction.keyPress(showDateField, "ENTER");

				// Select show
				if (AdminConstants.getShowName() != null && AdminConstants.getShowName().contains(AdminConstants.getDivision()))
					showName = AdminConstants.getShowName();
				BookingGuestConstants.setShowName(showName);

				WebAction.clickUsingJs(showDropDown);
				WebAction.selectDropDown(showDropDown, showName, dropDownValuesXpath, dropDownvalues,
						showName + "is missing in show drop down");

				// To verify show time is auto populated
				String actualShowTime = WebAction.getAttribute(showTimeTextBox, "value");
				String expectedShowTime = "";
				if (AdminConstants.getScheduleStartTime() != null) {
					expectedShowTime = AdminConstants.getScheduleStartTime();
					expectedShowTime = DateFunctions.convertDateStringToAnotherFormat(expectedShowTime, "hh:mma",
							"HH:mm");
					Assert.assertEquals(actualShowTime, expectedShowTime,
							"Show time is not auto populated with " + expectedShowTime);
				} else
					Assert.assertFalse(actualShowTime.isEmpty(),
							"Show time is not auto populated in show details section");

				// select show time
				if (isDuplicateBooking == null || isDuplicateBooking.equalsIgnoreCase("No"))
					BookingGuestConstants.setShowTime(showTime);
				else
					BookingGuestConstants.setDuplicateBookingShowTime(showTime);
				WebAction.scrollUsingJavaScriptAndClick(showTimeTextBox);
				WebAction.click(showTimeTextBoxClear);
				WebAction.click(showTimeTextBox);
				WebAction.sendKeys(showTimeTextBox, showTime);
				WebAction.keyPress(showTimeTextBox, "ENTER");

				// Select EventType

				BookingGuestConstants.setEventType(eventType);
				WebAction.selectDropDown(eventTypeDropDown, eventType, dropDownValuesXpath, dropDownvalues,
						eventType + " is missing in event type drop down");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To generate date based on input. Date should like CurrentDate+1,
	 * CurrentDate-2, etc.,
	 * 
	 * @param date   - date
	 * @param format - date format
	 * @throws Exception
	 */
	public String generateDate(String date, String format) throws Exception {
		String updateddate = "";
		try {
			if (date.trim() != null) {
				if (date.toUpperCase().contains("CURRENTDATE")) {
					String days = date.replaceAll("[a-zA-Z]", "").trim();
					if (days.length() == 0) {
						days = "0";
					}
					updateddate = DateFunctions.addOrMinusDateFromCurrentDate(format, days, TIMEZONES.EST);
				} else
					throw new Exception("Please provide date in valid format");
			} else
				throw new Exception("Date is empty");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return updateddate;
	}

	/**
	 * To click New topic button
	 **/
	public void clickNewTopicButton() throws Exception {
		try {
			// To scroll down to New Topic button
			Waits.waitForElement(addTopicButton, WAIT_CONDITIONS.CLICKABLE);
			if (WebAction.isDisplayed(upArrow))
				WebAction.click(upArrow);
			WebAction.scrollIntoView(addTopicButton);

			// Click Add New topic button
			WebAction.clickUsingJs(addTopicButton);
			Waits.waitForElement(topicRhDrawerHeader, WAIT_CONDITIONS.VISIBLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To add new topic
	 * 
	 * @param topicName  - topic name
	 * @param startTime  - start time
	 * @param endTime    - end time
	 * @param topicNotes - topic notes
	 * @throws Exception
	 */
	public void addTopic(String isDuplicateBooking, String topicName, String startTime, String endTime,
			String topicNotes) throws Exception {
		try {
			// Fill topic name
			BookingGuestConstants.setExistingTopicCount(addedTopicName.size());
			BookingGuestConstants.setTopicName(topicName);
			WebAction.sendKeys(topicNameTextBox, topicName);

			// Fill start time
			if (startTime != null) {
				if (isDuplicateBooking == null || isDuplicateBooking.equalsIgnoreCase("NO"))
					BookingGuestConstants.setTopicStartTime(startTime);
				else
					BookingGuestConstants.setDuplicateBookingTopicStartTime(startTime);

				WebAction.click(topicStartTimeTextBox);
				WebAction.sendKeys(topicStartTimeTextBox, startTime);
				WebAction.keyPress(topicStartTimeTextBox, "ENTER");
			}

			// Fill end time
			if (endTime != null) {
				if (isDuplicateBooking == null || isDuplicateBooking.equalsIgnoreCase("NO"))
					BookingGuestConstants.setTopicEndTime(endTime);
				else
					BookingGuestConstants.setDuplicateBookingTopicEndTime(endTime);

				WebAction.click(topicEndTimeTextBox);
				WebAction.sendKeys(topicEndTimeTextBox, endTime);
				WebAction.keyPress(topicEndTimeTextBox, "ENTER");
			}

			// Fill topic notes
			if (topicNotes != null) {
				BookingGuestConstants.setTopicNotes(topicNotes);
				Waits.waitForElement(topicNotesTextBox, WAIT_CONDITIONS.CLICKABLE);
				WebAction.sendKeys(topicNotesTextBox, topicNotes);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click Add Topic button in topic RH drawer
	 * 
	 * @throws Exception
	 */
	public void clickAddTopicInRhDrawer() throws Exception {
		try {
			// click Add topic button
			WebAction.clickUsingJs(addTopicButtonInRhDrawer);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify created topics are displaying correctly in parking lot
	 **/
	public void verifyTopicAddedSuccessfully() throws Exception {
		try {
			int existingTopicCount = BookingGuestConstants.getExistingTopicCount();
			System.out.println(existingTopicCount);
			// To verify topic added in parking lot
			Waits.waitUntilElementSizeGreater(By.xpath(addedTopicListXpath), existingTopicCount);

			// To verify topic name
			String expectedTopicName = BookingGuestConstants.getTopicName();
			CommonValidations.verifyTextValue(addedTopicName.get(0), expectedTopicName,
					"Topic name in added topic is not matching");

			// To verify topic notes
			if (BookingGuestConstants.getTopicNotes() != null) {
				String expectedTopicNotes = BookingGuestConstants.getTopicNotes();
				CommonValidations.verifyTextValue(addedTopicNotes.get(0), expectedTopicNotes,
						"Topic notes in added topic is not matching");
			}

			// To verify topic start and end time
			if (BookingGuestConstants.getTopicStartTime() != null) {
				String startAndEndTime = WebAction.getText(addedTopicTime.get(0));
				String[] timeArray = startAndEndTime.split("-");
				String actualStartTime = timeArray[0].trim();
				String actualEndTime = timeArray[1].trim();

				String expectedStartTime = "", expectedEndTime = "";
				if (BookingGuestConstants.getIsDuplicateBooking() == null
						|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO")) {
					expectedStartTime = BookingGuestConstants.getTopicStartTime();
					expectedEndTime = BookingGuestConstants.getTopicEndTime();
				} else {
					expectedStartTime = BookingGuestConstants.getDuplicateBookingTopicStartTime();
					expectedEndTime = BookingGuestConstants.getDuplicateBookingTopicEndTime();
				}

				Assert.assertEquals(actualStartTime, expectedStartTime, "Topic start time is not matching");
				Assert.assertEquals(actualEndTime, expectedEndTime, "Topic end time is not matching");
			}

			// To check edit and delete buttons
			Assert.assertTrue(WebAction.isDisplayed(topicEditIcon.get(0)),
					"Edit topic icon is not displayed in topic place holder");
			Assert.assertTrue(WebAction.isDisplayed(topicDeleteIcon.get(0)),
					"Delete topic icon is not displayed in topic place holder");

			// To close topic RH drawer
			WebAction.scrollUsingJavaScriptAndClick(closeTopicRhDrawer);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify created topic name is displayed in the drop down field
	 * 
	 * @throws Exception
	 **/
	public void verifyNewlyAddedTopicInDropDown() throws Exception {
		try {
			// To scroll down to topic drop down
			Waits.waitForElement(addTopicButton, WAIT_CONDITIONS.CLICKABLE);
			WebAction.scrollUsingJavaScriptAndClick(upArrow);
			Thread.sleep(2000);
			WebAction.scrollDown();
			Waits.waitForElement(topicsNameInDropDownField, WAIT_CONDITIONS.CLICKABLE);

			// To click topic drop down
			WebAction.scrollUsingJavaScriptAndClick(topicsNameInDropDownField);
			Waits.waitUntilElementSizeGreater(dropDownvalues, 0);
			boolean dropDownValuePresent = false;
			for (WebElement element : dropDownvalues) {
				if (WebAction.getText(element).trim().equalsIgnoreCase(BookingGuestConstants.getTopicName())) {
					WebAction.click(element);
					dropDownValuePresent = true;
					break;
				}
			}
			Assert.assertTrue(dropDownValuePresent, "Newly added topic is not displayed in Topics/Segments drop downs");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select segment from segment drop down
	 * 
	 * @throws Exception
	 */
	public void selectSegment(String segmentName) throws Exception {
		try {
			WebAction.scrollDown();
			if (BookingGuestConstants.getTopicName() != null)
				segmentName = BookingGuestConstants.getTopicName();
			WebAction.click(TopicsOrSegmentsDropDown.findElement(By.xpath("../..")));
			WebAction.nonEnterebaleSelectDropDown(dropDownValuesXpath, segmentName,
					segmentName + " option is not present in the Segment drop down");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the select form type options in booking form
	 **/
	public void verifyFromTypesDisplayed(DataTable params) {
		try {
			List<Map<String, String>> formTypes = CucumberUtils.getValuesFromDataTableAsList(params);
			for (int i = 0; i < formTypes.size(); i++) {
				String formType = formTypes.get(i).get("Form Type");
				if (formType.equalsIgnoreCase("CALL OUT"))
					Assert.assertTrue(WebAction.isDisplayed(callOutButton),
							"Call out button is not displayed in booking type");
				else if (formType.equalsIgnoreCase("BOOKING"))
					Assert.assertTrue(WebAction.isDisplayed(bookingButton),
							"Booking button is not displayed in booking type");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify Called By field is disabled and pre filled with booker name
	 * 
	 * @throws Exception
	 */
	public void verifyCalledByFieldDisabled() throws Exception {
		try {
			Waits.waitForElement(calledForDropDown, WAIT_CONDITIONS.CLICKABLE);
			Assert.assertFalse(WebAction.isEnabled(calledByTextBox),
					"Called By text box is enabled in callout details section");
			CommonValidations.verifyAttributeValue(calledByTextBox, "value", BookerProfileConstants.getBookerName(),
					"Called By field is not prefilled with booker name");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill call out details
	 * 
	 * @param calledFor     - called for
	 * @param callOutNotes  - call out notes
	 * @throws Exception
	 */
	public void fillCallOutDetails(String calledFor, String callOutStatus, String callOutNotes) throws Exception {
		try {
			// Fill called for
			if (calledFor != null) {
				BookingGuestConstants.setBookerCalledForName(calledFor);
				WebAction.selectDropDown(calledForDropDown, calledFor, dropDownValuesXpath, dropDownvalues,
						calledFor + " option is not present in the called for drop down");
			}
			// Fill call out status
			BookingGuestConstants.setCallStatus(callOutStatus);
			WebAction.scrollIntoView(calledByTextBox);
			Thread.sleep(800);
			WebAction.mouseOverAndClick(callStatusDropDown, callStatusDropDown);
			WebAction.nonEnterebaleSelectDropDown(dropDownValuesXpath, callOutStatus,
					callOutStatus + " option is not present in the call out status drop down");

			// fill call out notes
			if (callOutNotes != null) {
				BookingGuestConstants.setCallOutNotes(callOutNotes);
				WebAction.click(callNotesTextBox);
				WebAction.sendKeys(callNotesTextBox, callOutNotes);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify Booked By field is disabled and pre filled with booker name
	 * 
	 * @throws Exception
	 */
	public void verifyBookedByFieldDisabled() throws Exception {
		try {
			WebAction.scrollDown();
			Waits.waitForElement(bookedForTextBox, WAIT_CONDITIONS.CLICKABLE);
			Assert.assertFalse(WebAction.isEnabled(bookedByTextBox),
					"Booked By text box is enabled in booking details section");
			CommonValidations.verifyAttributeValue(bookedByTextBox, "value", BookerProfileConstants.getBookerName(),
					"Booked By field is not prefilled with booker name");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verified call out/booking date and time is prefilled with today date and
	 * time
	 * 
	 * @throws Exception
	 */
	public void verifyCallOutOrBookingDateAndTimePrefilled(String callOutOrBooking) throws Exception {
		try {
			// verify call out/booking date and time fields are disabled
			Assert.assertFalse(WebAction.isEnabled(bookingDateTextBox),
					callOutOrBooking + " date text box is enabled in " + callOutOrBooking + " details section");
			Assert.assertFalse(WebAction.isEnabled(bookingTimeTextBox),
					callOutOrBooking + " time text box is enabled in " + callOutOrBooking + " details section");

			// verify Call out/Booking date is prefilled
			/*
			 * String expectedDate = "", expectedTime1 = "", expectedTime2 = ""; if
			 * (callOutOrBooking.equalsIgnoreCase("BOOKING")) { expectedDate =
			 * BookingGuestConstants.getBookingDate(); expectedTime1 =
			 * BookingGuestConstants.getBookingTime(); // expectedTime2 =
			 * DateFunctions.addOrMinusTimeFromGivenTime(expectedTime1, "HH:mm",
			 * TIMETYPE.MINUTES, // "1");
			 * 
			 * } else { expectedDate = BookingGuestConstants.getCallOutDate(); expectedTime1
			 * = BookingGuestConstants.getCallOutTime(); // expectedTime2 =
			 * DateFunctions.addOrMinusTimeFromGivenTime(expectedTime1, "HH:mm",
			 * TIMETYPE.MINUTES, // "1"); }
			 * 
			 * CommonValidations.verifyAttributeValue(bookingDateTextBox, "value",
			 * expectedDate, callOutOrBooking +
			 * " date is not pre populated with today's date");
			 * 
			 */			/*
			 * if (!((WebAction.getAttribute(bookingTimeTextBox,
			 * "value").equalsIgnoreCase(expectedTime1)) ||
			 * (WebAction.getAttribute(bookingTimeTextBox,
			 * "value").equalsIgnoreCase(expectedTime2)))) Assert.assertTrue(false,
			 * callOutOrBooking +
			 * " time is not pre populated with current time. Expected Time is " +
			 * expectedTime1 + " or " + expectedTime2 + ". but actual time is " +
			 * WebAction.getAttribute(bookingTimeTextBox, "value"));
			 */
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Enter booked date and booked time in booking form section
	 **/
	public void fillBookingDetails(String bookedFor, String bookingNotes) throws Exception {
		try {
			WebAction.scrollIntoView(bookingFormHeader);

			// Fill booked for
			if (bookedFor != null) {
				BookingGuestConstants.setBookedFor(bookedFor);
				WebAction.selectDropDown(bookedForTextBox, bookedFor, dropDownValuesXpath, dropDownvalues,
						bookedFor + " option is not present in the booked for drop down");
			}

			// fill technical notes
			if (bookingNotes != null) {
				BookingGuestConstants.setBookingNotes(bookingNotes);
				WebAction.clickUsingJs(bookingTechnicalNotes);
				WebAction.sendKeys(bookingTechnicalNotes, bookingNotes);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click recurring booking button
	 * 
	 * @throws Exception
	 */
	public void clickRecurringBookingButton() throws Exception {
		try {
			WebAction.click(recurreingBookingButton);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill recurring booking details
	 * 
	 * @param bookingEndDate
	 * @param days
	 * @throws Exception
	 */
	public void fillRecurringBookingDetails(String bookingEndDate, String days) throws Exception {
		try {
			setRecurringBookingDatesInMap(bookingEndDate, days);

			// Fill booking end date
			BookingGuestConstants.setRecurringBookingEndDate(generateDate(bookingEndDate, "MM/dd/yyyy"));
			WebAction.click(recurreingBookingEndDateTextBox);
			WebAction.sendKeys(recurreingBookingEndDateTextBox, generateDate(bookingEndDate, "MM/dd/yyyy"));
			WebAction.keyPress(recurreingBookingEndDateTextBox, "ENTER");

			// Fill days
			BookingGuestConstants.setRecurringBookingDays(days);
			String[] daysArr = days.split(",");
			for (String day : daysArr) {
				switch (day.trim().toUpperCase()) {
				case "SUNDAY":
					WebAction.clickUsingJs(recurreingBookingSundayCheckBox);
					break;
				case "MONDAY":
					WebAction.clickUsingJs(recurreingBookingMondayCheckBox);
					break;
				case "TUESDAY":
					WebAction.clickUsingJs(recurreingBookingTuesdayCheckBox);
					break;
				case "WEDNESDAY":
					WebAction.clickUsingJs(recurreingBookingWednesdayCheckBox);
					break;
				case "THURSDAY":
					WebAction.clickUsingJs(recurreingBookingThursdayCheckBox);
					break;
				case "FRIDAY":
					WebAction.clickUsingJs(recurreingBookingFridayCheckBox);
					break;
				case "SATURDAY":
					WebAction.clickUsingJs(recurreingBookingSaturdayCheckBox);
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void setRecurringBookingDatesInMap(String bookingEndDate, String days) throws Exception {
		try {
			String[] daysArr = days.split(",");
			List<String> expectedDays = new ArrayList<String>();
			for (String day : daysArr) {
				expectedDays.add(WordUtils.capitalize(day.trim()));
			}

			bookingEndDate = generateDate(bookingEndDate, "MM/dd/yyyy");
			List<String> dateList = DateFunctions.getDateListBetweenDates(BookingGuestConstants.getBookingDate(),
					bookingEndDate, "MM/dd/yyyy");

			int reoccuringDaysCount = 0;
			for (int i = 1; i < dateList.size(); i++) {
				if (expectedDays.contains(
						DateFunctions.convertDateStringToAnotherFormat(dateList.get(i), "MM/dd/yyyy", "EEEE"))) {
					BookingGuestConstants.setRecurringBookingDates(reoccuringDaysCount, dateList.get(i));
					reoccuringDaysCount++;
				}

			}
			BookingGuestConstants.setRecurringBookingDatesCount(String.valueOf(reoccuringDaysCount));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/*
	 * To select studio type as Other in booking form section
	 **/
	public void fillStudioDetails(String studioType, String studio, String studioState, String otherStudio)
			throws Exception {
		try {
			WebAction.scrollIntoView(bookedForTextBox);
			BookingGuestConstants.setStudioType(studioType);
			if (studioType.equalsIgnoreCase("REGISTERED")) {
				BookingGuestConstants.setStudio(studio);
				CommonValidations.verifyColorOfElement(registeredStudioType, "color", "BLUE");
				WebAction.selectDropDown(studioDropDown, studio, dropDownValuesXpath, dropDownvalues,
						studio + " option is not present in the studio drop down");
			} else {
				BookingGuestConstants.setStudioState(studioState);
				BookingGuestConstants.setStudio(otherStudio);
				WebAction.clickUsingJs(otherStudioType);
				WebAction.scrollDown();
				Thread.sleep(4000);
				WebAction.mouseOverAndClick(studioStateDropDown, studioStateDropDown);
				WebAction.nonEnterebaleSelectDropDown(dropDownValuesXpath, studioState,
						studioState + " option is not present in the studio state drop down");
				WebAction.clickUsingJs(otherStudioTextBox);
				WebAction.sendKeys(otherStudioTextBox, otherStudio);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To add alert email address and validate
	 * 
	 * @param params
	 * @throws Exception
	 */
	public void fillEmailAddressInAlert(DataTable params) throws Exception {
		try {
			// To verify msnbc division group email and delete it
			if (AdminConstants.getDivision().equalsIgnoreCase("MSNBC")) {
				CommonValidations.verifyAttributeValue(addedAlertEmailCount.get(0), "data-email",
						ConfigFileReader.getProperty("MSNBC-default-alert-email"), "MSNBC division default dl "
								+ ConfigFileReader.getProperty("MSNBC-default-alert-email") + " is missing");
				for (WebElement element : alertEmailDeleteIcon) {
					WebAction.scrollUsingJavaScriptAndClick(element);
				}
			}

			// To add alert emails
			List<Map<String, String>> emailAlerts = CucumberUtils.getValuesFromDataTableAsList(params);
			BookingGuestConstants.setEmailAlertCount(String.valueOf(emailAlerts.size()));
			for (int i = 0; i < emailAlerts.size(); i++) {
				WebAction.scrollIntoView(studioDropDown);
				String emailAddress = emailAlerts.get(i).get("Alert Email");
				BookingGuestConstants.setEmailAlert(i, emailAddress);
				WebAction.sendKeys(alertTextBox, emailAddress);
				WebAction.click(addAlertIcon);
				Waits.waitUntilElementSizeGreater(By.xpath(addedAlertEmailCountXpath), i);
				Assert.assertEquals(WebAction.getText(addedAlertEmailCount.get(i)), emailAddress,
						"Email address added in alert field is not matching");
				Assert.assertTrue(WebAction.isDisplayed(alertEmailDeleteIcon.get(i)),
						"Delete icon is not displayed next to alert email address");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select custom email notification options
	 * 
	 * @param params
	 * @throws Exception
	 */
	public void selectCustomEmailNotification(DataTable params) throws Exception {
		try {
			WebAction.scrollIntoView(showNameCheckBox);
			List<Map<String, String>> customEmailNotificationsList = CucumberUtils.getValuesFromDataTableAsList(params);
			for (int i = 0; i < customEmailNotificationsList.size(); i++) {
				String customNotification = customEmailNotificationsList.get(i).get("Custom Notification");
				switch (customNotification.toUpperCase()) {
				case "ALL":
					WebAction.clickUsingJs(allCheckBox);
					BookingGuestConstants.setAllCustomEmailNotification("Yes");
					BookingGuestConstants.setShowNameCustomNotification("Yes");
					BookingGuestConstants.setTopicCustomNotification("Yes");
					BookingGuestConstants.setStudioCustomNotification("Yes");
					BookingGuestConstants.setMakeUpCustomNotification("Yes");
					BookingGuestConstants.setCarCustomNotification("Yes");
					break;
				case "SHOW NAME":
					WebAction.clickUsingJs(showNameCheckBox);
					BookingGuestConstants.setShowNameCustomNotification("Yes");
					break;
				case "TOPIC":
					WebAction.clickUsingJs(topicCheckBox);
					BookingGuestConstants.setTopicCustomNotification("Yes");
					break;
				case "STUDIO/OTHER LOCATION":
					WebAction.clickUsingJs(studioOrOtherCheckBox);
					BookingGuestConstants.setStudioCustomNotification("Yes");
					break;
				case "MAKEUP":
					WebAction.clickUsingJs(makeUpCheckBox);
					BookingGuestConstants.setMakeUpCustomNotification("Yes");
					break;
				case "CAR":
					WebAction.clickUsingJs(carCheckBox);
					BookingGuestConstants.setCarCustomNotification("Yes");
					break;
				default:
					Assert.assertTrue(false, "Please provide valid custom notification option");
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click click button in booking edit page
	 **/
	public void clickbutton(String buttonType) throws Exception {
		try {
			switch (buttonType.toUpperCase()) {
			case "SUBMIT":
				WebAction.click(submitButton);
				break;
			case "UPDATE":
				WebAction.click(updateButton);
				break;
			case "CANCEL":
				WebAction.click(cancelButton);
				break;
			case "CALL OUT":
				WebAction.scrollIntoView(callOutButton);
				WebAction.click(callOutButton);
				BookingGuestConstants
						.setCallOutDate(DateFunctions.getCurrentDateAndTimeByTimeZone("MM/dd/yyyy", TIMEZONES.EST));
				BookingGuestConstants
						.setCallOutTime(DateFunctions.getCurrentDateAndTimeByTimeZone("HH:mm", TIMEZONES.EST));
				break;
			case "BOOKING":
				WebAction.scrollIntoView(bookingButton);
				WebAction.click(bookingButton);
				BookingGuestConstants
						.setDefaultBookingTime(DateFunctions.getCurrentDateAndTimeByTimeZone("HH:mm", TIMEZONES.EST));
				BookingGuestConstants
						.setBookingDate(DateFunctions.getCurrentDateAndTimeByTimeZone("MM/dd/yyyy", TIMEZONES.EST));
				BookingGuestConstants
						.setBookingTime(DateFunctions.getCurrentDateAndTimeByTimeZone("HH:mm", TIMEZONES.EST));
				break;
			case "RECURRING BOOKING":
				// WebAction.scrollIntoView(recurreingBookingButton);
				WebAction.click(recurreingBookingButton);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click OK button in booking place pop-up
	 * 
	 * @param expectedPopupMessage - expected popup message
	 * @throws Exception
	 **/
	public void verifySuccessPopup(String expectedPopupMessage) throws Exception {
		try {
			Waits.waitForElement(bookingCallPlacedSuccessPopup, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyTextValue(bookingCallPlacedSuccessPopup, expectedPopupMessage,
					"Message in successful booking popup is not matched");

			// Update weekly and monthly booking count
			if (expectedPopupMessage.toUpperCase().contains("BOOKING"))
				updateWeeklyAndMonthlyBookingCount("ADD");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click button in popup
	 * 
	 * @param buttonType - Button Type
	 * @throws Exception
	 */
	public void clickButtonInPopup(String buttonType) throws Exception {
		try {
			switch (buttonType.toUpperCase()) {
			case "OK":
				WebAction.click(okButtonInSuccessPopup);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify duplicate booking pop up is displayed
	 * 
	 * @throws Exception
	 */
	public void verifyDuplicateBookingPopupDisplayed() throws Exception {
		try {
			Waits.waitForElement(duplicateBookingPopUpHeaderElement, WAIT_CONDITIONS.VISIBLE);
			Waits.waitForElement(duplicateBookingExcludeButton, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify duplicate booking details
	 * 
	 * @throws Exception
	 */
	public void verifyDuplicateBookingDetails(String duplicateBookingTitle, String duplicateBookingDisclaimer)
			throws Exception {
		try {
			CommonValidations.verifyTextValue(duplicateBookingTitleElement, duplicateBookingTitle,
					"Duplicate booking popup title is not matched");

			// verify show name
			CommonValidations.verifyTextValue(duplicateBookingShowDetails.get(0), BookingGuestConstants.getShowName(),
					"Show name in duplicate booking popup is not correct");

			// verify show date and time
			String showDate = DateFunctions.convertDateStringToAnotherFormat(BookingGuestConstants.getShowDate(),
					"MM/dd/yyyy", "MM/dd");
			String showTime = DateFunctions.convertDateStringToAnotherFormat(BookingGuestConstants.getShowTime(),
					"HH:mm", "h:mma");

			CommonValidations.verifyTextValue(duplicateBookingShowDetails.get(1), showDate + " " + showTime,
					"Show date and time in duplicate booking popup is not correct");

			// verify studio
			CommonValidations.verifyTextValue(duplicateBookingShowDetails.get(1), BookingGuestConstants.getStudio(),
					"Studio name in duplicate booking popup is not correct");

			// Verify Topic
			CommonValidations.verifyTextValue(duplicateBookingShowDetails.get(2), BookingGuestConstants.getTopicName(),
					"Topic name in duplicate booking popup is not correct");

			// verify duplicate booking disclaimer
			CommonValidations.verifyTextValue(duplicateBookingDisClaimerElement, duplicateBookingDisclaimer,
					"Duplicate booking popup disclaimer is not matched");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify buttons in duplicate booking pop up
	 * 
	 * @param params
	 * @throws Exception
	 */
	public void verifyButtonsInDuplicateBookingPopup(DataTable params) throws Exception {
		try {
			List<Map<String, String>> buttonList = CucumberUtils.getValuesFromDataTableAsList(params);
			for (int i = 0; i < buttonList.size(); i++) {
				switch (buttonList.get(i).get("Button Name").toUpperCase()) {
				case "CANCEL":
					CommonValidations.verifyElementIsEnabled(duplicateBookingCancelButton,
							"Cancel button is not present in duplicate booking popup");
					break;
				case "EXCLUDE":
					CommonValidations.verifyElementIsEnabled(duplicateBookingExcludeButton,
							"Exclude button is not present in duplicate booking popup");
					break;
				case "OK":
					CommonValidations.verifyElementIsEnabled(duplicateBookingOkButton,
							"Ok button is not present in duplicate booking popup");
					break;
				default:
					Assert.assertTrue(false, "Please provide valid button name");
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click button in duplicate booking pop up
	 * 
	 * @param buttonName - button name
	 * @throws Exception
	 */
	public void clickButtonInDuplicateBookingPopup(String buttonName) throws Exception {
		try {
			switch (buttonName.toUpperCase()) {
			case "CANCEL":
				WebAction.click(duplicateBookingCancelButton);
				break;
			case "EXCLUDE":
				WebAction.click(duplicateBookingExcludeButton);
				
				break;
			case "OK":
				WebAction.click(duplicateBookingOkButton);
				break;
			default:
				Assert.assertTrue(false, "Please provide valid button name");
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify exclude warning message
	 * 
	 * @param excludeInofMessage - expected info message
	 * @throws Exception
	 */
	public void verifyExcludeInfoMessage(String excludeInofMessage) throws Exception {
		try {
			Waits.waitForElement(excludeInfoMessageElement, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyTextValue(excludeInfoMessageElement, excludeInofMessage,
					"Exclude duplicate booking info message in booking edit page is not correct");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To update weekly or month booking count
	 * 
	 * @param addOrRemove - ADD/REMOVE
	 * @throws Exception
	 */
	public void updateWeeklyAndMonthlyBookingCount(String addOrRemove) throws Exception {
		try {

			String showDate = BookingGuestConstants.getShowDate();
			String currentDate = DateFunctions.getCurrentDateAndTimeByTimeZone("MM/dd/yyyy", TIMEZONES.EST);

			// To count weekly booking count
			String oneWeekOldDate = DateFunctions.addOrMinusDateFromCurrentDate("MM/dd/yyyy", "-7", TIMEZONES.EST);
			if ((DateFunctions.compareTwoDateWithCondition(showDate, currentDate, DATECOMPARECONDITIONS.LESSTHAN))
					&& (DateFunctions.compareTwoDateWithCondition(showDate, oneWeekOldDate,
							DATECOMPARECONDITIONS.GREATERTHANOREQUALTO))) {
				if (addOrRemove.equalsIgnoreCase("ADD")) {
					if (BookingGuestConstants.getWeeklyBookingCount() == null)
						BookingGuestConstants.setWeeklyBookingCount("1");
					else {
						String updatedWeeklyCount = String
								.valueOf(Integer.parseInt(BookingGuestConstants.getWeeklyBookingCount()) + 1);
						BookingGuestConstants.setWeeklyBookingCount(updatedWeeklyCount);
					}
				} else {
					if (BookingGuestConstants.getWeeklyBookingCount() != null) {
						String updatedWeeklyCount = String
								.valueOf(Integer.parseInt(BookingGuestConstants.getWeeklyBookingCount()) - 1);
						BookingGuestConstants.setWeeklyBookingCount(updatedWeeklyCount);
					}
				}
			}

			// To count monthly booking count
			String oneMonthOldDate = DateFunctions.addOrMinusDateFromCurrentDate("MM/dd/yyyy", "-30", TIMEZONES.EST);
			if ((DateFunctions.compareTwoDateWithCondition(showDate, currentDate, DATECOMPARECONDITIONS.LESSTHAN))
					&& (DateFunctions.compareTwoDateWithCondition(showDate, oneMonthOldDate,
							DATECOMPARECONDITIONS.GREATERTHANOREQUALTO))) {
				if (addOrRemove.equalsIgnoreCase("ADD")) {
					if (BookingGuestConstants.getMonthlyBookingCount() == null)
						BookingGuestConstants.setMonthlyBookingCount("1");
					else {
						String updatedMonthlyCount = String
								.valueOf(Integer.parseInt(BookingGuestConstants.getMonthlyBookingCount()) + 1);
						BookingGuestConstants.setMonthlyBookingCount(updatedMonthlyCount);
					}
				} else {
					if (BookingGuestConstants.getWeeklyBookingCount() != null) {
						String updatedMonthlyCount = String
								.valueOf(Integer.parseInt(BookingGuestConstants.getMonthlyBookingCount()) - 1);
						BookingGuestConstants.setMonthlyBookingCount(updatedMonthlyCount);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
