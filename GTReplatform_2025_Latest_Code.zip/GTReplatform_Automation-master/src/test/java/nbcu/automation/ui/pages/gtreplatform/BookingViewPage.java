package nbcu.automation.ui.pages.gtreplatform;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.automation.ui.constants.gtreplatform.BookerProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.BookingGuestConstants;
import nbcu.automation.ui.constants.gtreplatform.GuestProfileConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.others.DateFunctions.TIMEZONES;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class BookingViewPage {

	// Drop down value xpath
	String dropDownValuesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropDownvalues;

	// View booking page header elements
	@FindBy(xpath = "//button[span[text()='Cancel Booking']]")
	WebElement cancelBookingButton;

	@FindBy(xpath = "//button[span[text()='Edit']]")
	WebElement editBookingButton;

	@FindBy(xpath = "//button[span[text()='Reactivate Booking']]")
	WebElement reactivateBookingButton;

	@FindBy(xpath = "//button[span[text()='Edit'] or span[text()='Reactivate Booking']]")
	WebElement editOrReactivateBookingButton;

	// Guest profile header elements
	@FindBy(xpath = "//li[contains(@class,'name')]")
	WebElement guestName_Header;

	@FindBy(xpath = "//li[contains(@class,'name')]//span")
	WebElement contributorTickMark_Header;

	@FindBy(xpath = "//li[contains(@class,'title')]")
	WebElement guestJobTitle_Header;

	@FindBy(xpath = "//li[contains(@class,'company')]")
	WebElement guestCompany_Header;

	// Show Details elements
	@FindBy(xpath = "//td[div[text()='Show:']]/following-sibling::td/div/strong")
	WebElement showName;

	@FindBy(xpath = "//td[div[text()='Event:']]/following-sibling::td/div")
	WebElement eventType;

	@FindBy(xpath = "//tr[td[div[text()='Show:']]]/following-sibling::tr[td[div[text()='Date:']]]/td[2]/div")
	WebElement showDate;

	@FindBy(xpath = "//tr[td[div[text()='Show:']]]/following-sibling::tr[td[div[text()='Time:']]]/td[2]/div")
	WebElement showTimeElement;

	// Topic/Segment details element
	@FindBy(xpath = "//h3[text()='Topic / Segment']/following-sibling::p")
	WebElement segmentName;

	// Booking information details element
	@FindBy(xpath = "//td[div[text()='Booked By:']]/following-sibling::td/div/button")
	WebElement bookedBy;

	@FindBy(xpath = "//td[div[text()='Booked For:']]/following-sibling::td/div/button")
	WebElement bookedFor;

	@FindBy(xpath = "//tr[td[div[text()='Booked By:']]]/following-sibling::tr[td[div[text()='Date:']]]/td[2]/div")
	WebElement bookingDate;

	@FindBy(xpath = "//tr[td[div[text()='Booked By:']]]/following-sibling::tr[td[div[text()='Time:']]]/td[2]/div")
	WebElement bookingTime;

	@FindBy(xpath = "//td[div[text()='Technical Notes:']]/following-sibling::td/div")
	WebElement bookingNotes;

	// Recurring booking details elements
	@FindBy(xpath = "//td[div[text()='Days:']]/following-sibling::td/div")
	WebElement recurringBookingDays;

	@FindBy(xpath = "//td[div[text()='End Date:']]/following-sibling::td/div")
	WebElement recurringBookingEndDate;

	// Studio elements
	@FindBy(xpath = "//td[div[text()='Type:']]/following-sibling::td/div")
	WebElement studioType;

	@FindBy(xpath = "//td[div[text()='Studio Name:']]/following-sibling::td/div")
	WebElement studioName;

	@FindBy(xpath = "//td[div[text()='State']]/following-sibling::td/div")
	WebElement studioState;

	// Email communication elements
	@FindBy(xpath = "//span[text()='Alert List']")
	WebElement alertStudioCarrotIcon;

	@FindBy(xpath = "//div[contains(@data-component,'email-list')]/ul/li")
	List<WebElement> alertEmailList;

	// Custom email notification
	@FindBy(xpath = "//div[contains(@data-componentid,'custom-notifications')]//li")
	List<WebElement> customEmailNotificationList;

	// Header icon elements
	@FindBy(xpath = "//span[text()='Home']")
	WebElement homePageIcon;

	@FindBy(xpath = "//span[text()='Report Center']")
	WebElement reportCenterPageIcon;

	@FindBy(xpath = "//span[text()='Feeds']")
	WebElement feedsPageIcon;

	@FindBy(xpath = "//span[text()='Contributors']")
	WebElement contributorsPageIcon;

	@FindBy(xpath = "//span[text()='Support']")
	WebElement supportPageIcon;

	// Cancel booking elements
	@FindBy(xpath = "//span[@aria-label='alert']/..")
	WebElement cancellationPopUpHeader;

	@FindBy(id = "reason")
	WebElement cancellationReasonTextBox;

	@FindBy(xpath = "//button[span[text()='Ok']]")
	WebElement cancelBanner_okButton;

	@FindBy(xpath = "//button[span[text()='Cancel']]")
	WebElement cancelBanner_cancelButton;

	@FindBy(xpath = "//p[contains(@class,'title')]")
	WebElement cancelBanner_Title;

	@FindBy(xpath = "//div[contains(@class,'text')]")
	WebElement cancelBanner_CancelReason;

	@FindBy(xpath = "//div[contains(@class,'date')]")
	WebElement cancelBanner_CancelDateAndTime;

	@FindBy(xpath = "//button[span[@aria-label='close-circle']]")
	WebElement cancelBanner_closeIcon;

	// Reactivate booking popup elements
	@FindBy(xpath = "//span[@class='ant-modal-confirm-title']")
	WebElement reactivateBookingPopupTitle;

	@FindBy(xpath = "//div[@class='ant-modal-confirm-content']")
	WebElement reactivateBookingPopupContent;

	@FindBy(xpath = "//div[@class='ant-modal-confirm-btns']//span[text()='Ok']")
	WebElement okButtonInPopup;

	@FindBy(xpath = "//div[@class='ant-modal-confirm-btns']//span[text()='Cancel']")
	WebElement cancelButtonInPopup;

	// Generate Email elements
	@FindBy(xpath = "//button[span[text()='Generate Email']]")
	WebElement generateEmailButton;

	// Feed elements
	@FindBy(xpath = "//button[span[text()='Feed']]")
	WebElement addFeedButton;

	// Add car services elements
	@FindBy(xpath = "//button[span[text()='Add Pick - Up']]")
	WebElement addPickUpButton;

	@FindBy(id = "pickUpFor")
	WebElement pickUpForTextBox;

	@FindBy(xpath = "//*[@id='carServiceName']/../..")
	WebElement carServiceDropDown;

	@FindBy(id = "carNumber")
	WebElement carNumberTextBox;

	@FindBy(id = "phone")
	WebElement phoneNumberTextBox;

	@FindBy(xpath = "//input[@placeholder='Select Date']")
	WebElement pickUpDateTextBox;

	@FindBy(xpath = "//input[@placeholder='Select Time']")
	List<WebElement> pickUpOrArrivalTime;

	@FindBy(xpath = "//input[@placeholder='Select Time']/following-sibling::span[contains(@class,'clear')]")
	List<WebElement> clearPickUpOrArrivalTime;

	@FindBy(xpath = "//span[text()='Guest will be using the same car and car service for the return trip']/preceding-sibling::span/input")
	WebElement sameCarServiceForReturnCheckBox;

	@FindBy(id = "PickUp_address_address1")
	WebElement pickUpAddressLine1;

	@FindBy(id = "PickUp_address_address2")
	WebElement pickUpAddressLine2;

	@FindBy(id = "PickUp_address_city")
	WebElement pickUpCity;

	@FindBy(id = "PickUp_address_state")
	WebElement pickUpState;

	@FindBy(id = "PickUp_address_zip")
	WebElement pickUpZipCode;

	@FindBy(id = "PickUp_address_country")
	WebElement pickUpCountry;

	@FindBy(xpath = "//span[text()='Guest will be using this as the drop off address for the return trip']/preceding-sibling::span/input")
	WebElement sameDropAddressForReturnCheckBox;

	@FindBy(id = "DropOff_address_address1")
	WebElement dropOffAddressLine1;

	@FindBy(id = "DropOff_address_address2")
	WebElement dropOffAddressLine2;

	@FindBy(id = "DropOff_address_city")
	WebElement dropOffCity;

	@FindBy(id = "DropOff_address_state")
	WebElement dropOffState;

	@FindBy(id = "DropOff_address_zip")
	WebElement dropOffZipCode;

	@FindBy(id = "DropOff_address_country")
	WebElement dropOffCountry;

	@FindBy(xpath = "//span[text()='Guest will be using this as the pick up address for the return trip']/preceding-sibling::span/input")
	WebElement samePickUpAddressForReturnCheckBox;

	@FindBy(xpath = "//button[span[text()='Submit']]")
	WebElement submitButton;

	@FindBy(xpath = "//button[span[text()='Cancel']]")
	WebElement cancelButton;

	@FindBy(xpath = "//*[text()='Booking record was successfully updated.']")
	WebElement bookingRecordUpdated;

	@FindBy(xpath = "//p[text()='Pick Up']/following-sibling::p")
	WebElement pickUpAddedElement;

	@FindBy(xpath = "//p[text()='Return']/following-sibling::p")
	WebElement returnAddedElement;

	// Makeup elements
	@FindBy(xpath = "//button[span[text()='Makeup']]")
	WebElement addMakeUpButton;

	@FindBy(xpath = "//*[span[text()='Makeup Ordered']]//input")
	WebElement makeUpOrderedCheckBox;

	@FindBy(xpath = "//*[@placeholder='Add Makeup description here']")
	WebElement makeUpDescriptionTextBox;

	@FindBy(xpath = "//button[span[text()='Add Makeup Service']]")
	WebElement addMakeUpService;

	@FindBy(xpath = "//p[text()='Makeup']/following-sibling::p")
	WebElement makeUpAddedElement;

	public BookingViewPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify booking view page is loaded
	 **/
	public void verifyBookingViewPageLoaded(String buttonName) throws Exception {
		try {
			if (buttonName.equalsIgnoreCase("REACTIVATE BOOKING")) {
				WebAction.refreshPage();
				Waits.waitForElement(reactivateBookingButton, WAIT_CONDITIONS.CLICKABLE);
			} else if (buttonName.equalsIgnoreCase("EDIT")) {
				Waits.waitForElement(editBookingButton, WAIT_CONDITIONS.CLICKABLE);
				BookingGuestConstants.setBookingUrl(WebAction.getCurrentUrl());
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify edit and cancel booking button is displayed in booking view page
	 * 
	 * @throws Exception
	 */
	public void verifyEditAndCancelBookingButtonsDisplayed() throws Exception {
		try {
			Assert.assertTrue(WebAction.isDisplayed(cancelBookingButton),
					"Cancel booking button is not displayed booking view page");
			Assert.assertTrue(WebAction.isDisplayed(editBookingButton),
					"Edit button is not displayed booking view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify cancel booking and reactivate booking button color
	 * 
	 * @param buttonName
	 * @throws Exception
	 */
	public void verifyButtonColor(String buttonName, String colorName) throws Exception {
		try {
			if (buttonName.equalsIgnoreCase("CANCEL BOOKING")) {
				Waits.waitForElement(cancelBookingButton, WAIT_CONDITIONS.CLICKABLE);
				Thread.sleep(2000);
				CommonValidations.verifyColorOfElement(cancelBookingButton, "color", colorName + "-5");
			} else if (buttonName.equalsIgnoreCase("REACTIVATE BOOKING")) {
				Waits.waitForElement(reactivateBookingButton, WAIT_CONDITIONS.CLICKABLE);
				Thread.sleep(2000);
				CommonValidations.verifyColorOfElement(reactivateBookingButton, "color", colorName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Verify the Guest Name, job title, company and contributor in header
	 **/
	public void verifyGuestProfileDetailsInHeader(String fieldName) {
		try {
			switch (fieldName.toUpperCase()) {
			case "NAME":
				String expectedGuestName = "";
				if (GuestProfileConstants.getDisplayName() != null)
					expectedGuestName = GuestProfileConstants.getDisplayName();
				else
					expectedGuestName = GuestProfileConstants.getFullName();
				CommonValidations.verifyTextValue(guestName_Header, expectedGuestName,
						"Guest profile name in header is not matching");
				break;
			case "CONTRIBUTOR ICON":
				if (GuestProfileConstants.getContributors() != null) {
					Assert.assertTrue(WebAction.isDisplayed(contributorTickMark_Header),
							"Contributor tick mark icon is not displayed");
					CommonValidations.verifyColorOfElement(contributorTickMark_Header, "color", "yellow");
				}
				break;
			case "JOB TITLE":
				if (GuestProfileConstants.getPrimaryJobTitle() != null)
					CommonValidations.verifyTextValue(guestJobTitle_Header, GuestProfileConstants.getPrimaryJobTitle(),
							"Guest profile primary job in header is not matching");
				break;
			case "COMPANY":
				if (GuestProfileConstants.getPrimaryCompany() != null)
					CommonValidations.verifyTextValue(guestCompany_Header, GuestProfileConstants.getPrimaryCompany(),
							"Guest profile primary company in header is not matching");
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify show details in booking view page
	 * 
	 * @throws Exception
	 */
	public void verifyShowDetails() throws Exception {
		try {
			CommonValidations.verifyTextValue(showName, BookingGuestConstants.getShowName(),
					"Booking show name is not matched in booking view page");
			CommonValidations.verifyTextValue(eventType, BookingGuestConstants.getEventType(),
					"Booking event type is not matched in booking view page");
			CommonValidations.verifyTextValue(showDate, BookingGuestConstants.getShowDate(),
					"Booking show date is not matched in booking view page");

			// Verify show time
			String showTime = "";
			if (BookingGuestConstants.getIsDuplicateBooking() == null
					|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO"))
				showTime = BookingGuestConstants.getShowTime();
			else
				showTime = BookingGuestConstants.getDuplicateBookingShowTime();
			String expectedShowTime = DateFunctions.convertDateStringToAnotherFormat(showTime, "HH:mm", "h:mma");
			CommonValidations.verifyTextValue(showTimeElement, expectedShowTime,
					"Booking show time is not matched in booking view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify topic/segment name in booking view page
	 * 
	 * @throws Exception
	 */
	public void verifySegmentDetails() throws Exception {
		try {
			CommonValidations.verifyTextValue(segmentName, BookingGuestConstants.getTopicName(),
					"Booking topic/segment name is not matched in booking view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify booking details in booking view page
	 * 
	 * @throws Exception
	 */
	public void verifyBookingDetails() throws Exception {
		try {
			CommonValidations.verifyTextValue(bookedBy, BookerProfileConstants.getBookerName(),
					"Booked by is not matched in booking view page");

			if (BookingGuestConstants.getBookedFor() != null)
				CommonValidations.verifyTextValue(bookedFor, BookingGuestConstants.getBookedFor(),
						"Booked for is not matched in booking view page");

			CommonValidations.verifyTextValue(bookingDate, BookingGuestConstants.getBookingDate(),
					"Booking date is not matched in booking view page");

			String expectedBookingTime = DateFunctions
					.convertDateStringToAnotherFormat(BookingGuestConstants.getBookingTime(), "HH:mm", "h:mma");
			CommonValidations.verifyTextValue(bookingTime, expectedBookingTime,
					"Booking time is not matched in booking view page");

			if (BookingGuestConstants.getBookingNotes() != null)
				CommonValidations.verifyTextValue(bookingNotes, BookingGuestConstants.getBookingNotes(),
						"Booking notes is not matched in booking view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify recurring booking details
	 * 
	 * @throws Exception
	 */
	public void verifyRecurringBookingDetails() throws Exception {
		try {
			CommonValidations.verifyTextValue(recurringBookingDays, BookingGuestConstants.getRecurringBookingDays(),
					"Recurring booking days is not matched in booking view page");

			CommonValidations.verifyTextValue(recurringBookingEndDate,
					BookingGuestConstants.getRecurringBookingEndDate(),
					"Recurring booking end date is not matched in booking view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify studio details in booking view page
	 * 
	 * @throws Exception
	 */
	public void verifyStudioDetails() throws Exception {
		try {
			String expectedStudioType = BookingGuestConstants.getStudioType();
			CommonValidations.verifyTextValue(studioName, BookingGuestConstants.getStudio(),
					"Studio name is not matched in booking view page");
			if (expectedStudioType.equalsIgnoreCase("OTHER")) {
				CommonValidations.verifyTextValue(studioState, BookingGuestConstants.getStudioState(),
						"Studio state is not matched in booking view page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To validate email alerts in booking view page
	 * 
	 * @throws Exception
	 */
	public void verifyEmailCommunicationDetails() throws Exception {
		try {
			List<String> actualEmailAlertList = new ArrayList<String>();
			for (WebElement element : alertEmailList) {
				actualEmailAlertList.add(WebAction.getText(element));
			}

			if (actualEmailAlertList.contains(ConfigFileReader.getProperty("MSNBC-default-alert-email")))
				actualEmailAlertList.remove(ConfigFileReader.getProperty("MSNBC-default-alert-email"));

			for (int i = 0; i < actualEmailAlertList.size(); i++) {
				Assert.assertEquals(actualEmailAlertList.get(i), BookingGuestConstants.getEmailAlert(i),
						"Alert email address added in booking is not matching in  booking view page");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify custom email notification
	 * 
	 * @throws Exception
	 */
	public void verifyCustomEmailNoficationDetails() throws Exception {
		try {
			if (BookingGuestConstants.getAllCustomEmailNotification() != null
					&& BookingGuestConstants.getAllCustomEmailNotification().equalsIgnoreCase("YES"))
				CommonValidations.verifyTextValue(customEmailNotificationList.get(0), "All",
						"All custom email notification is selected");
			else {
				// Expected custom notification list
				ArrayList<String> expectedCustomEmailList = new ArrayList<String>();
				if (BookingGuestConstants.getShowNameCustomNotification() != null
						&& BookingGuestConstants.getShowNameCustomNotification().equalsIgnoreCase("YES"))
					expectedCustomEmailList.add("Show Name");
				if (BookingGuestConstants.getTopicCustomNotification() != null
						&& BookingGuestConstants.getTopicCustomNotification().equalsIgnoreCase("YES"))
					expectedCustomEmailList.add("Topic");
				if (BookingGuestConstants.getStudioCustomNotification() != null
						&& BookingGuestConstants.getStudioCustomNotification().equalsIgnoreCase("YES"))
					expectedCustomEmailList.add("Studio / Other Location");
				if (BookingGuestConstants.getMakeUpCustomNotification() != null
						&& BookingGuestConstants.getMakeUpCustomNotification().equalsIgnoreCase("YES"))
					expectedCustomEmailList.add("Makeup");
				if (BookingGuestConstants.getCarCustomNotification() != null
						&& BookingGuestConstants.getCarCustomNotification().equalsIgnoreCase("YES"))
					expectedCustomEmailList.add("Car");
				Collections.sort(expectedCustomEmailList);

				// Actual custom notification list
				ArrayList<String> actualCustomEmailList = new ArrayList<String>();
				for (WebElement element : customEmailNotificationList) {
					actualCustomEmailList.add(WebAction.getText(element));
				}
				Collections.sort(actualCustomEmailList);

				Assert.assertEquals(actualCustomEmailList, expectedCustomEmailList,
						"Custom email notification list in booking view page is not correct. Expected is "
								+ expectedCustomEmailList + " and actual is " + actualCustomEmailList);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To open different page from booking view page
	 * 
	 * @param pageName
	 * @throws Exception
	 */
	public void selectPageInHeader(String pageName) throws Exception {
		try {
			switch (pageName.toUpperCase()) {
			case "HOME":
				WebAction.click(homePageIcon);
				break;
			case "REPORT CENTER":
				WebAction.click(reportCenterPageIcon);
				break;
			case "FEEDS":
				WebAction.click(feedsPageIcon);
				break;
			case "CONTRIBUTORS":
				WebAction.click(contributorsPageIcon);
				break;
			case "SUPPORT":
				WebAction.click(supportPageIcon);
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click edit/cancel booking button
	 * 
	 * @param buttonType
	 * @throws Exception
	 */
	public void clickEditCancelButton(String buttonType) throws Exception {
		try {
			if (buttonType.equalsIgnoreCase("EDIT"))
				WebAction.click(editBookingButton);
			else if (buttonType.equalsIgnoreCase("CANCEL BOOKING"))
				WebAction.click(cancelBookingButton);
			else if (buttonType.equalsIgnoreCase("REACTIVATE BOOKING"))
				WebAction.click(reactivateBookingButton);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * to verify reason for cancellation pop up displayed
	 * 
	 * @throws Exception
	 */
	public void verifyReasonForCancellationPopupDisplayed() throws Exception {
		try {
			Waits.waitForElement(cancellationReasonTextBox, WAIT_CONDITIONS.CLICKABLE);
			CommonValidations.verifyTextValue(cancellationPopUpHeader, "Reason For Cancellation",
					"Reason for cancellation popup is not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill cancellation reason
	 * 
	 * @param cancellationReason - booking cancellation reason
	 * @throws Exception
	 */
	public void fillCancellationReason(String cancellationReason) throws Exception {
		try {
			BookingGuestConstants.setBookingCancellationReason(cancellationReason);
			WebAction.sendKeys(cancellationReasonTextBox, cancellationReason);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click ok/cancel button in cancellation pop up
	 * 
	 * @param buttonType - button type
	 * @throws Exception
	 */
	public void clikOkOrCancelButtonInCancellationPopup(String buttonType) throws Exception {
		try {
			if (buttonType.equalsIgnoreCase(buttonType))
				WebAction.click(cancelBanner_okButton);
			else
				WebAction.click(cancelBanner_cancelButton);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify details in cancelled banner
	 * 
	 * @throws Exception
	 */
	public void verifyCancelBannerDetails() throws Exception {
		try {
			Waits.waitForElement(cancelBanner_closeIcon, WAIT_CONDITIONS.CLICKABLE);
			CommonValidations.verifyTextValue(cancelBanner_Title, "BOOKING CANCELLED",
					"Booking cancelled banner title is not correct");
			CommonValidations.verifyTextValue(cancelBanner_CancelReason,
					BookingGuestConstants.getBookingCancellationReason(),
					"Reason for cancellation is not correct in cancelled banner");
			CommonValidations.verifyTextValue(cancelBanner_CancelDateAndTime,
					DateFunctions.getCurrentDateAndTimeByTimeZone("MM/dd/yyyy", TIMEZONES.EST),
					"Booking cancelled time is not correct in cancelled banner");

			// Set cancellation date and time
			String[] cancelDateAndTimeArr = WebAction.getText(cancelBanner_CancelDateAndTime).split(" ");
			BookingGuestConstants.setBookingCancellationDate(cancelDateAndTimeArr[0]);
			BookingGuestConstants.setBookingCancellationTime(cancelDateAndTimeArr[1]);

			// Update weekly and monthly booking count
			new BookingEditPage().updateWeeklyAndMonthlyBookingCount("REMOVE");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify reactivate booking confirmation pop up is displayed
	 * 
	 * @param popUpContent
	 * @throws Exception
	 */
	public void verifyReactivateBookingConfirmationPopup(String popUpContent) throws Exception {
		try {
			CommonValidations.verifyTextValue(reactivateBookingPopupTitle, "Reactivate Booking?",
					"'Reactivate Booking' confirmation popup is not displayed");
			CommonValidations.verifyTextValue(reactivateBookingPopupContent, popUpContent,
					"'Reactivate Booking' confirmation popup message is not correct");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click ok or cancel button in reactivate booking
	 * 
	 * @param popUpContent
	 * @throws Exception
	 */
	public void clickOnOkOrCancelInReactivateBooking(String buttonName) throws Exception {
		try {
			if (buttonName.equalsIgnoreCase("OK")) {
				WebAction.click(okButtonInPopup);

				Thread.sleep(2000);
				// Set reactivate booking date and time
				BookingGuestConstants.setReactivateBookingDate(
						DateFunctions.getCurrentDateAndTimeByTimeZone("MM/dd/yyyy", TIMEZONES.EST));
				BookingGuestConstants.setReactivateBookingTime(
						DateFunctions.getCurrentDateAndTimeByTimeZone("hh:mma", TIMEZONES.EST));

				// Update weekly and monthly booking count
				new BookingEditPage().updateWeeklyAndMonthlyBookingCount("ADD");
			} else if (buttonName.equalsIgnoreCase("CANCEL"))
				WebAction.click(cancelButtonInPopup);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click add pick up car service
	 * 
	 * @throws Exception
	 */
	public void clickAddPickupCarService() throws Exception {
		try {
			WebAction.scrollIntoView(addFeedButton);
			WebAction.click(addPickUpButton);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify pickup car service RH loaded
	 * 
	 * @throws Exception
	 */
	public void verifyPickUpCarServiceRhLoaded() throws Exception {
		try {
			Waits.waitForElement(pickUpForTextBox, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill car details in pick up car service RH
	 * 
	 * @param pickUpFor
	 * @param carService
	 * @param carNumber
	 * @param phoneNumber
	 * @param pickUpDate
	 * @param pickUpTime
	 * @param arrivalTime
	 * @throws Exception
	 */
	public void fillCarDetailsInPickUpCarService(String pickUpFor, String carService, String carNumber,
			String phoneNumber, String pickUpDate, String pickUpTime, String arrivalTime) throws Exception {
		try {

			// Picked for
			WebAction.sendKeys(pickUpForTextBox, pickUpFor);

			// Car service
			WebAction.click(carServiceDropDown);
			WebAction.nonEnterebaleSelectDropDown(dropDownValuesXpath, carService,
					"'" + carService + "' value is not present in the car service drop down");

			// Car Number
			WebAction.sendKeys(carNumberTextBox, carNumber);

			// Phone number
			String existingPhoneNumber = WebAction.getAttribute(phoneNumberTextBox, "value");
			if (existingPhoneNumber == null || existingPhoneNumber.isEmpty())
				WebAction.sendKeys(carNumberTextBox, carNumber);

			// Pick up date
			if (pickUpDate.toUpperCase().contains("CURRENTDATE"))
				pickUpDate = new BookingEditPage().generateDate(pickUpDate, "MM/dd/yyyy");
			WebAction.click(pickUpDateTextBox);
			WebAction.sendKeys(pickUpDateTextBox, pickUpDate);
			WebAction.keyPress(pickUpDateTextBox, "ENTER");

			// Pick up time
			WebAction.mouseOverAndClick(clearPickUpOrArrivalTime.get(0),clearPickUpOrArrivalTime.get(0));
			WebAction.scrollUsingJavaScriptAndClick(pickUpOrArrivalTime.get(0));
			WebAction.sendKeys(pickUpOrArrivalTime.get(0), pickUpTime);
			WebAction.keyPress(pickUpOrArrivalTime.get(0), "ENTER");

			// Arrival time
			WebAction.click(pickUpOrArrivalTime.get(1));
			WebAction.sendKeys(pickUpOrArrivalTime.get(1), arrivalTime);
			WebAction.keyPress(pickUpOrArrivalTime.get(1), "ENTER");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Fill pick up address details
	 * 
	 * @param addressLine1
	 * @param addressLine2
	 * @param city
	 * @param state
	 * @param zipCode
	 * @param country
	 * @throws Exception
	 */
	public void fillPickUpDetails(String addressLine1, String addressLine2, String city, String state, String zipCode,
			String country) throws Exception {
		try {
			WebAction.scrollIntoView(pickUpAddressLine1);
			Waits.waitForElement(pickUpAddressLine1, WAIT_CONDITIONS.CLICKABLE);

			// Address line1
			WebAction.sendKeys(pickUpAddressLine1, addressLine1);

			// Address line2
			WebAction.sendKeys(pickUpAddressLine2, addressLine2);

			// City
			WebAction.sendKeys(pickUpCity, city);

			// State
			WebAction.selectDropDown(pickUpState, state, dropDownValuesXpath, dropDownvalues,
					"'" + state + "' value is not present in the pick up state drop down");

			// Zip code
			WebAction.sendKeys(pickUpZipCode, zipCode);

			// Country
			WebAction.selectDropDown(pickUpCountry, country, dropDownValuesXpath, dropDownvalues,
					"'" + country + "' value is not present in the pick up country drop down");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill drop off address details
	 * 
	 * @param addressLine1
	 * @param addressLine2
	 * @param city
	 * @param state
	 * @param zipCode
	 * @param country
	 * @throws Exception
	 */
	public void fillDropOffDetails(String addressLine1, String addressLine2, String city, String state, String zipCode,
			String country) throws Exception {
		try {
			WebAction.scrollIntoView(dropOffAddressLine1);
			Waits.waitForElement(dropOffAddressLine1, WAIT_CONDITIONS.CLICKABLE);

			// Address line1
			WebAction.sendKeys(dropOffAddressLine1, addressLine1);

			// Address line2
			WebAction.sendKeys(dropOffAddressLine2, addressLine2);

			// City
			WebAction.sendKeys(dropOffCity, city);

			// State
			WebAction.selectDropDown(dropOffState, state, dropDownValuesXpath, dropDownvalues,
					"'" + state + "' value is not present in the pick up state drop down");

			// Zip code
			WebAction.sendKeys(dropOffZipCode, zipCode);

			// Country
			WebAction.selectDropDown(dropOffCountry, country, dropDownValuesXpath, dropDownvalues,
					"'" + country + "' value is not present in the pick up country drop down");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select check box in pick up address RH
	 * 
	 * @param checkBoxName
	 * @throws Exception
	 */
	public void selectPickUpCheckBoxes(String checkBoxName) throws Exception {
		try {
			if (checkBoxName.equalsIgnoreCase("Guest will be using the same car and car service for the return trip"))
				WebAction.clickUsingJs(sameCarServiceForReturnCheckBox);
			else if (checkBoxName
					.equalsIgnoreCase("Guest will be using this as the drop off address for the return trip"))
				WebAction.clickUsingJs(sameDropAddressForReturnCheckBox);
			else if (checkBoxName
					.equalsIgnoreCase("Guest will be using this as the pick up address for the return trip"))
				WebAction.clickUsingJs(samePickUpAddressForReturnCheckBox);
			else
				Assert.assertTrue(false, "Please provide valid check box name in pick up address RH");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Submit/Cancel button
	 * 
	 * @throws Exception
	 */
	public void clickSubmitOrCancelButton(String buttonName) throws Exception {
		try {
			WebAction.scrollIntoView(submitButton);
			if (buttonName.equalsIgnoreCase("SUBMIT"))
				WebAction.click(submitButton);
			else if (buttonName.equalsIgnoreCase("CANCEL"))
				WebAction.click(cancelButton);
			else
				Assert.assertTrue(false, "Please enter valid button name in pick up RH");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify pickup and return car services added
	 * 
	 * @throws Exception
	 */
	public void verifyPickUpAndReturnCarServiceAdded() throws Exception {
		try {
			Waits.waitForElement(bookingRecordUpdated, WAIT_CONDITIONS.VISIBLE);
			Waits.waitForElement(pickUpAddedElement, WAIT_CONDITIONS.VISIBLE);
			String expectedText = "Added: "
					+ DateFunctions.getCurrentDateAndTimeByTimeZone("MM/dd/yyyy", TIMEZONES.EST);
			CommonValidations.verifyTextValue(pickUpAddedElement, expectedText, "Pick up car service is not added");
			CommonValidations.verifyTextValue(returnAddedElement, expectedText, "Return car service is not added");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click add makeup button
	 * 
	 * @throws Exception
	 */
	public void clickAddMakeUp() throws Exception {
		try {
			WebAction.scrollIntoView(addMakeUpButton);
			WebAction.click(addMakeUpButton);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify make up RH is loaded
	 * 
	 * @throws Exception
	 */
	public void verifyMakeUpRhLoaded() throws Exception {
		try {
			Waits.waitForElement(makeUpDescriptionTextBox, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To add makeup service
	 * 
	 * @param makeUpDescription - make up description
	 * @throws Exception
	 */
	public void addMakeUpService(String makeUpDescription) throws Exception {
		try {
			WebAction.clickUsingJs(makeUpOrderedCheckBox);
			if (makeUpDescription != null)
				WebAction.sendKeys(makeUpDescriptionTextBox, makeUpDescription);
			WebAction.click(addMakeUpService);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify makeup service is added
	 * 
	 * @throws Exception
	 */
	public void verifyMakeUpAdded() throws Exception {
		try {
			Waits.waitForElement(bookingRecordUpdated, WAIT_CONDITIONS.VISIBLE);
			Waits.waitForElement(makeUpAddedElement, WAIT_CONDITIONS.VISIBLE);
			String expectedText = "Added: "
					+ DateFunctions.getCurrentDateAndTimeByTimeZone("MM/dd/yyyy", TIMEZONES.EST);
			CommonValidations.verifyTextValue(makeUpAddedElement, expectedText, "Make up service is not added");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click add feed button
	 * 
	 * @throws Exception
	 */
	public void clickAddFeed() throws Exception {
		try {
			WebAction.scrollIntoView(generateEmailButton);
			WebAction.click(addFeedButton);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}
