package nbcu.automation.ui.pages.gtreplatform;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.automation.ui.constants.gtreplatform.BookerProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.BookingGuestConstants;
import nbcu.automation.ui.constants.gtreplatform.GuestProfileConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.others.DateFunctions.TIMEZONES;

public class CalloutViewPage {

	// View call out page header elements
	@FindBy(xpath = "//div[contains(@class,'header__buttons')]/button[span[text()='Edit']]")
	WebElement editCallOut_Header;

	@FindBy(xpath = "//div[contains(@class,'header__buttons')]/button[span[text()='Book']]")
	WebElement bookButton;

	@FindBy(xpath = "//li[contains(@class,'name')]")
	WebElement guestName_Header;

	@FindBy(xpath = "//li[contains(@class,'name')]//span")
	WebElement contributorTickMark_Header;

	@FindBy(xpath = "//li[contains(@class,'title')]")
	WebElement guestJobTitle_Header;

	@FindBy(xpath = "//li[contains(@class,'company')]")
	WebElement guestCompany_Header;

	// Show Details elements
	@FindBy(xpath = "//td[div[text()='Show:']]/following-sibling::td/div/strong")
	WebElement showName;

	@FindBy(xpath = "//td[div[text()='Event:']]/following-sibling::td/div")
	WebElement eventType;
	
	@FindBy(xpath = "//tr[td[div[text()='Show:']]]/following-sibling::tr[td[div[text()='Date:']]]/td[2]/div")
	WebElement showDate;

	@FindBy(xpath = "//tr[td[div[text()='Show:']]]/following-sibling::tr[td[div[text()='Time:']]]/td[2]/div")
	WebElement showTime;

	// Topic/Segment details element
	@FindBy(xpath = "//h3[text()='Topic / Segment']/following-sibling::p")
	WebElement segmentName;

	// Call out information details element

	@FindBy(xpath = "//span[@class='ant-collapse-header-text']")
	WebElement callStatus;

	@FindBy(xpath = "//td[div[text()='Called By:']]/following-sibling::td/div/button")
	WebElement calledBy;

	@FindBy(xpath = "//td[div[text()='Called For:']]/following-sibling::td/div/button")
	WebElement calledFor;

	@FindBy(xpath = "//td[div[text()='Call Date:']]/following-sibling::td/div")
	WebElement callDate;

	@FindBy(xpath = "//td[div[text()='Call Time:']]/following-sibling::td/div")
	WebElement callTime;

	@FindBy(xpath = "//td[div[text()='Notes:']]/following-sibling::td/div/span")
	WebElement callNotes;

	@FindBy(xpath = "//table[contains(@class,'list')]/following-sibling::button[span[text()='Edit']]")
	WebElement editCallOut;

	@FindBy(xpath = "//button[span[text()='Add Call Out']]")
	WebElement addCallOut;

	public CalloutViewPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify booking view page is loaded
	 **/
	public void verifyCallOutViewPageLoaded() throws Exception {
		try {
			Waits.waitForElement(bookButton, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify edit and book buttons are displayed
	 * 
	 * @throws Exception
	 */
	public void verifyEditAndBookButtonDisplayedInHeader() throws Exception {
		try {
			Assert.assertTrue(WebAction.isDisplayed(editCallOut_Header),
					"Edit button is not displayed in the header of call out view page");
			Assert.assertTrue(WebAction.isDisplayed(bookButton),
					"Book button is not displayed in the header of call out view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Verify the Guest Name, job title, company and contributor in header
	 **/
	public void verifyGuestProfileDetailsInHeader(String fieldName) {
		try {
			switch (fieldName.toUpperCase()) {
			case "NAME":
				String expectedGuestName = "";
				if (GuestProfileConstants.getDisplayName() != null)
					expectedGuestName = GuestProfileConstants.getDisplayName();
				else
					expectedGuestName = GuestProfileConstants.getFullName();
				CommonValidations.verifyTextValue(guestName_Header, expectedGuestName,
						"Guest profile name in header is not matching");
				break;
			case "CONTRIBUTOR ICON":
				if (GuestProfileConstants.getContributors() != null) {
					Assert.assertTrue(WebAction.isDisplayed(contributorTickMark_Header),
							"Contributor tick mark icon is not displayed");
					CommonValidations.verifyColorOfElement(contributorTickMark_Header, "color", "yellow");
				}
				break;
			case "JOB TITLE":
				if (GuestProfileConstants.getPrimaryJobTitle() != null)
					CommonValidations.verifyTextValue(guestJobTitle_Header, GuestProfileConstants.getPrimaryJobTitle(),
							"Guest profile primary job in header is not matching");
				break;
			case "COMPANY":
				if (GuestProfileConstants.getPrimaryCompany() != null)
					CommonValidations.verifyTextValue(guestCompany_Header, GuestProfileConstants.getPrimaryCompany(),
							"Guest profile primary company in header is not matching");
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify show details in booking view page
	 * 
	 * @throws Exception
	 */
	public void verifyShowDetails() throws Exception {
		try {
			CommonValidations.verifyTextValue(showName, BookingGuestConstants.getShowName(),
					"Booking show name is not matched in call out view page");
			CommonValidations.verifyTextValue(eventType, BookingGuestConstants.getEventType(),
					"Booking event type is not matched in call out view page");
			CommonValidations.verifyTextValue(showDate, BookingGuestConstants.getShowDate(),
					"Booking show date is not matched in call out view page");

			String expectedShowTime = DateFunctions
					.convertDateStringToAnotherFormat(BookingGuestConstants.getShowTime(), "HH:mm", "h:mma");
			CommonValidations.verifyTextValue(showTime, expectedShowTime,
					"Booking show time is not matched in call out view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify topic/segment name in booking view page
	 * 
	 * @throws Exception
	 */
	public void verifySegmentDetails() throws Exception {
		try {
			CommonValidations.verifyTextValue(segmentName, BookingGuestConstants.getTopicName(),
					"Booking topic/segment name is not matched in call out view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify call out details
	 * 
	 * @throws Exception
	 */
	public void verifyCallOutDetails() throws Exception {
		try {
			CommonValidations.verifyTextValue(callStatus, BookingGuestConstants.getCallStatus(),
					"Call status is not matched in call out view page");

			CommonValidations.verifyTextValue(calledBy, BookerProfileConstants.getBookerName(),
					"Called by is not matched in call out view page");

			if (BookingGuestConstants.getBookerCalledForName() != null)
				CommonValidations.verifyTextValue(calledFor, BookingGuestConstants.getBookerCalledForName(),
						"Called for is not matched in call out view page");

			CommonValidations.verifyTextValue(callDate, BookingGuestConstants.getCallOutDate(),
					"Call out date is not matched in call out view page");

			String expectedBookingTime = DateFunctions
					.convertDateStringToAnotherFormat(BookingGuestConstants.getCallOutTime(), "HH:mm", "h:mma");
			CommonValidations.verifyTextValue(callTime, expectedBookingTime,
					"Call out time is not matched in call out view page");

			CommonValidations.verifyTextValue(callNotes, BookingGuestConstants.getCallOutNotes(),
					"Call out notes is not matched in call out view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify edit and add call out buttons are displayed in call out view page
	 * 
	 * @throws Exception
	 */
	public void verifyEditAndAddCallOutButton() throws Exception {
		try {
			Assert.assertTrue(WebAction.isDisplayed(editCallOut),
					"Edit call out button is not displayed in call out view page");
			Assert.assertTrue(WebAction.isDisplayed(addCallOut),
					"Add call out button is not displayed in call out view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click button in header
	 * 
	 * @param buttonName
	 * @throws Exception
	 */
	public void clickButtonInHeader(String buttonName) throws Exception {
		try {
			switch (buttonName.toUpperCase()) {
			case "EDIT":
				WebAction.click(editCallOut_Header);
				break;
			case "BOOK":
				WebAction.click(bookButton);
				BookingGuestConstants.setBookingDate(DateFunctions.getCurrentDateAndTimeByTimeZone("MM/dd/yyyy", TIMEZONES.EST));
				BookingGuestConstants.setBookingTime(DateFunctions.getCurrentDateAndTimeByTimeZone("HH:mm", TIMEZONES.EST));
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}
