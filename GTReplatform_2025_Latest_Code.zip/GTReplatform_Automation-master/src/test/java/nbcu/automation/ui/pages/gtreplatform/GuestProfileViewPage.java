package nbcu.automation.ui.pages.gtreplatform;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.gtreplatform.AdminConstants;
import nbcu.automation.ui.constants.gtreplatform.BookerProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.BookingGuestConstants;
import nbcu.automation.ui.constants.gtreplatform.GuestProfileConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.others.DateFunctions.TIMETYPE;

public class GuestProfileViewPage {

	// Guest profile Header elements
	@FindBy(xpath = "//li[contains(@class,'header__name')]")
	List<WebElement> guestProfileName;

	@FindBy(xpath = "//li[contains(@class,'header__title')]")
	List<WebElement> guestProfileJobTitle;

	@FindBy(xpath = "//li[contains(@class,'header__title')]/following-sibling::li[not(contains(@class,'status'))]")
	List<WebElement> guestProfileCompanyName;

	@FindBy(xpath = "//li[contains(@class,'header__status')]")
	List<WebElement> guestProfileContributors;

	@FindBy(xpath = "//li[contains(@class,'header__status')]/span")
	WebElement guestProfileContributorTickMark;

	// Guest profile view page icons
	@FindBy(xpath = "//li[span[@aria-label='book']]")
	List<WebElement> bookButton;

	@FindBy(xpath = "//li[span[@aria-label='edit']]")
	List<WebElement> editButton;

	@FindBy(xpath = "//li[span[@aria-label='history']]")
	List<WebElement> historyButton;

	@FindBy(xpath = "//li[span[@aria-label='copy']]")
	List<WebElement> copyButton;

	@FindBy(xpath = "//li[span[@aria-label='merge-cells']]")
	List<WebElement> mergeButton;

	@FindBy(xpath = "//li[span[@aria-label='calendar']]")
	List<WebElement> calendarButton;

	@FindBy(xpath = "//li[span[text()='Pronunciation']]")
	List<WebElement> pronunciationButton;

	// Basic info and Booking info tab
	@FindBy(xpath = "//button[span[text()='Basic Info']]")
	WebElement basicInfoTab;

	@FindBy(xpath = "//button[span[text()='Booking Info']]")
	WebElement bookingInfoTab;

	// Biography element
	@FindBy(xpath = "//h3[text()='Biography']/following-sibling::div/p")
	WebElement biography;

	// Self Identifying element
	@FindBy(xpath = "//td[div[text()='Self-Identifying:']]/following-sibling::td[1]/div")
	WebElement selfIdentifying;

	// Gender element
	@FindBy(xpath = "//td[div[text()='Gender:']]/following-sibling::td[1]/div")
	WebElement gender;

	// Ethnicity element
	@FindBy(xpath = "//td[div[text()='Ethnicity:']]/following-sibling::td[1]/div")
	WebElement ethnicity;

	// Other element
	@FindBy(xpath = "//td[div[text()='Other:']]/following-sibling::td[1]/div")
	WebElement other;

	// Languages element
	@FindBy(xpath = "//td[div[text()='Languages:']]/following-sibling::td[1]/div")
	WebElement languages;

	// Ticker element
	@FindBy(xpath = "//h3[text()='Ticker']/following-sibling::p")
	WebElement ticker;

	// Expertise element
	@FindBy(xpath = "//h3[text()='Expertise']/following-sibling::ul/li")
	List<WebElement> expertise;

	// Alert elements
	@FindBy(xpath = "//div[@role='alert']/p")
	WebElement alertHeader;

	@FindBy(xpath = "//div[@role='alert']/p/following-sibling::span[1]")
	WebElement alertMessage;

	// contact info tab elements
	@FindBy(xpath = "//span[text()='Phone']")
	WebElement phoneTab;

	@FindBy(xpath = "//span[text()='Email']")
	WebElement emailTab;

	@FindBy(xpath = "//span[text()='Other']")
	WebElement otherTab;

	@FindBy(xpath = "//span[@aria-label='ellipsis']")
	List<WebElement> threeDots;

	@FindBy(xpath = "//span[text()='Address']")
	List<WebElement> addressTab;

	// Phone number elements
	@FindBy(xpath = "//td[div[text()='1 - Phone']]/following-sibling::td/div/a")
	WebElement phone1;

	@FindBy(xpath = "//td[div[text()='Office']]/following-sibling::td/div/a")
	WebElement officePhone;

	@FindBy(xpath = "//td[div[text()='Mobile']]/following-sibling::td/div/a")
	WebElement mobilePhone;

	@FindBy(xpath = "//td[div[text()='2 - Phone']]/following-sibling::td/div/a")
	WebElement phone2;

	@FindBy(xpath = "//a[contains(@href,'tel:')]")
	List<WebElement> phoneList;

	// Email elements
	@FindBy(xpath = "//td[div[text()='1 - Email']]/following-sibling::td/div/a")
	WebElement email1;

	@FindBy(xpath = "//td[div[text()='2 - Email']]/following-sibling::td/div/a")
	WebElement email2;

	@FindBy(xpath = "//td[div[text()='3 - Email']]/following-sibling::td/div/a")
	WebElement email3;

	@FindBy(xpath = "//td[div[text()='4 - Email']]/following-sibling::td/div/a")
	WebElement email4;

	@FindBy(xpath = "//a[contains(@href,'mailto:')]")
	List<WebElement> emailList;

	// Other elements
	@FindBy(xpath = "//td[div[text()='Twitter']]/following-sibling::td/div")
	WebElement twitter;

	@FindBy(xpath = "//td[div[text()='LinkedIn']]/following-sibling::td/div")
	WebElement linkedIn;

	@FindBy(xpath = "//td[div[text()='Video']]/following-sibling::td/div")
	WebElement video;

	@FindBy(xpath = "//td[div[text()='Website']]/following-sibling::td/div")
	WebElement webSite;

	@FindBy(xpath = "//td[div[text()='Twitter' or text()='LinkedIn' or text()='Video' or text()='Website']]/following-sibling::td[1]/div")
	List<WebElement> othersList;

	// Address elements
	@FindBy(xpath = "//td[div[text()='Address']]/following-sibling::td/div")
	WebElement addressLine1;

	@FindBy(xpath = "//td[div[text()='Apt, Suite, etc']]/following-sibling::td/div")
	WebElement addressLine2;

	@FindBy(xpath = "//td[div[text()='City']]/following-sibling::td/div")
	WebElement city;

	@FindBy(xpath = "//td[div[text()='State']]/following-sibling::td/div")
	WebElement state;

	@FindBy(xpath = "//td[div[text()='Zip Code']]/following-sibling::td/div")
	WebElement zipCode;

	@FindBy(xpath = "//td[div[text()='Country']]/following-sibling::td/div")
	WebElement country;

	// Job details elements
	@FindBy(xpath = "//span[contains(@class,'jobTitle')]")
	WebElement jobTitle;

	@FindBy(xpath = "//span[contains(@class,'status')]")
	WebElement jobStatus;

	@FindBy(xpath = "//span[contains(@class,'status')]/span")
	WebElement primaryJob;

	@FindBy(xpath = "//td[div[text()='Start Date:']]/following-sibling::td/div")
	WebElement jobStartDate;

	@FindBy(xpath = "//td[div[text()='Category:']]/following-sibling::td/div")
	WebElement jobCategory;

	@FindBy(xpath = "//td[div[text()='Org/Company:']]/following-sibling::td/div")
	WebElement jobOrganization;

	@FindBy(xpath = "//td[div[text()='Department:']]/following-sibling::td/div")
	WebElement jobDepartment;

	@FindBy(xpath = "//td[div[text()='Notes:']]/following-sibling::td/div")
	WebElement jobNotes;

	// Deactivated banner element
	@FindBy(xpath = "//span[@aria-label='warning']/following-sibling::span")
	WebElement deactivatedBanner;

	// Booking info elements
	@FindBy(xpath = "//li[span[text()='Calls']]")
	WebElement callsTab;

	@FindBy(xpath = "//li[span[text()='Future Bookings']]")
	WebElement futureBookingsTab;

	@FindBy(xpath = "//li[span[text()='Past Bookings']]")
	WebElement pastBookingsTab;

	// Appearance status elements
	@FindBy(xpath = "//p[text()='Status']/following-sibling::p")
	WebElement appearanceStatus;

	@FindBy(xpath = "//p[text()='Weekly']/following-sibling::p")
	WebElement weeklyAppearanceCountElement;

	@FindBy(xpath = "//p[text()='Monthly']/following-sibling::p")
	WebElement monthlyAppearanceCountElement;

	// Calls tab elements
	String callsDivisionNameXpath = "//button[text()='<<Status>>']/../../preceding-sibling::div[1]/span[contains(@class,'division')]";

	String callsShowNameNameXpath = "//button[text()='<<Status>>']/../../preceding-sibling::div[1]/span[contains(@class,'title')]";

	String callsStatusXpath = "//button[contains(@class,'status') and text()='<<Status>>']";

	String callsDateAndTimeXpath = "//button[text()='<<Status>>']/../following-sibling::div[@data-grid='time']/span[contains(@class,'value')]";

	@FindBy(xpath = "//span[@aria-label='calendar']/following-sibling::span[contains(@class,'value')]")
	List<WebElement> callsShowDateAndTime;

	@FindBy(xpath = "//*[@data-grid='booker']/button[contains(@class,'booker')]")
	List<WebElement> callsBookerName;

	// Future and past booking elements

	@FindBy(xpath = "//div[contains(@class,'header')]/span[contains(@class,'division')]")
	List<WebElement> bookingsDivision;

	@FindBy(xpath = "//div[contains(@class,'header')]/span[contains(@class,'title')]")
	List<WebElement> bookingsShowName;

	@FindBy(xpath = "//div[@data-grid='status']/button[contains(@class,'value')]")
	List<WebElement> bookingsShowDate;

	@FindBy(xpath = "//div[@data-grid='time']/span[contains(@class,'value')]")
	List<WebElement> bookingsShowTime;

	@FindBy(xpath = "//div[@data-grid='status']/span[contains(@class,'cancelled')]")
	List<WebElement> bookingsStatus;

	@FindBy(xpath = "//div[@data-grid='topic']/span[contains(@class,'value')]")
	List<WebElement> bookingsTopic;

	public GuestProfileViewPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify view guest profile page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyGuestProfileViewPageDisplayed() throws Exception {
		Waits.waitForElement(editButton.get(0), WAIT_CONDITIONS.CLICKABLE);
		Waits.waitForElement(bookingInfoTab, WAIT_CONDITIONS.CLICKABLE);
	}

	/**
	 * To verify guest profile name in header
	 * 
	 * @throws Exception
	 */
	public void verifyGuestProfileNameInHeader() throws Exception {
		try {
			String expectedProfileName = "";
			if (GuestProfileConstants.getDisplayName() != null)
				expectedProfileName = GuestProfileConstants.getDisplayName();
			else
				expectedProfileName = GuestProfileConstants.getFullName();

			for (WebElement profileName : guestProfileName) {
				if (profileName.isDisplayed()) {
					CommonValidations.verifyTextValue(profileName, expectedProfileName,
							"Profile name in view guest profile page is not matching");
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify primary job title is getting displayed in the guest profile header
	 * 
	 * @param titleOrCompany - title/company
	 * @throws Exception
	 */
	public void verifyPrimaryJobTitleOrCompanyInHeader(String titleOrCompany) throws Exception {
		try {
			if (titleOrCompany.equalsIgnoreCase("TITLE")) {
				if (guestProfileJobTitle.size() > 0) {
					for (WebElement jobTitle : guestProfileJobTitle) {
						if (jobTitle.isDisplayed()) {
							CommonValidations.verifyTextValue(jobTitle, GuestProfileConstants.getPrimaryJobTitle(),
									"Primary job title in view guest profile page is not matching");
							break;
						}
					}
				}
			} else if (titleOrCompany.equalsIgnoreCase("COMPANY")) {
				if (guestProfileCompanyName.size() > 0) {
					CommonValidations.verifyTextValue(guestProfileCompanyName.get(0),
							GuestProfileConstants.getPrimaryCompany(),
							"Primary job company in view guest profile page is not matching");

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify guest profile contributor details
	 * 
	 * @throws Exception
	 */
	public void verifyContributorDetails() throws Exception {
		try {
			String expectedContributor = GuestProfileConstants.getContributors() + " Contributors";
			if (guestProfileContributors.size() > 0)
				CommonValidations.verifyTextValue(guestProfileContributors.get(0), expectedContributor,
						"Guest profile contributors in view guest profile page is not matching");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify contributor tick mark in yellow color
	 * 
	 * @throws Exception
	 */
	public void verifyContributorsTickMark(String color) throws Exception {
		try {
			if (guestProfileContributors.size() > 0)
				CommonValidations.verifyColorOfElement(guestProfileContributorTickMark, "color", color);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify buttons are displayed in header of view guest profile page
	 * 
	 * @param params
	 * @throws Exception
	 */
	public void verifyButtonsInHeaders(DataTable params) throws Exception {
		try {
			List<Map<String, String>> buttonsList = CucumberUtils.getValuesFromDataTableAsList(params);
			for (int i = 0; i < buttonsList.size(); i++) {
				switch (buttonsList.get(i).get("Icons").toUpperCase()) {
				case "BOOK":
					for (WebElement book : bookButton) {
						if (book.isDisplayed()) {
							CommonValidations.verifyElementIsEnabled(book,
									"Book button is not enabled in guest profile view page");
							break;
						}
					}
					break;
				case "EDIT":
					for (WebElement edit : editButton) {
						if (edit.isDisplayed()) {
							CommonValidations.verifyElementIsEnabled(edit,
									"Edit button is not enabled in guest profile view page");
							break;
						}
					}
					break;
				case "HISTORY":
					for (WebElement history : historyButton) {
						if (history.isDisplayed()) {
							CommonValidations.verifyElementIsEnabled(history,
									"History button is not enabled in guest profile view page");
							break;
						}
					}
					break;
				case "COPY":
					for (WebElement copy : copyButton) {
						if (copy.isDisplayed()) {
							CommonValidations.verifyElementIsEnabled(copy,
									"Copy button is not enabled in guest profile view page");
							break;
						}
					}
					break;
				case "MERGE":
					for (WebElement merge : mergeButton) {
						if (merge.isDisplayed()) {
							CommonValidations.verifyElementIsEnabled(merge,
									"Merge button is not enabled in guest profile view page");
							break;
						}
					}
					break;
				case "CALENDAR":
					for (WebElement calendar : calendarButton) {
						if (calendar.isDisplayed()) {
							CommonValidations.verifyElementIsEnabled(calendar,
									"Calendar button is not enabled in guest profile view page");
							break;
						}
					}
					break;
				case "PRONUNCIATION":
					for (WebElement pronunciation : pronunciationButton) {
						if (pronunciation.isDisplayed()) {
							if (GuestProfileConstants.getPronunciation() != null)
								CommonValidations.verifyElementIsEnabled(pronunciation,
										"Pronunciation button is diabled in guest profile view page");
							else
								Assert.assertFalse(WebAction.isEnabled(pronunciation),
										"Pronunciation button is enabled in guest profile view page");
							break;
						}
					}
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select basic or booking info tab
	 * 
	 * @param tabName - tab name
	 * @throws Exception
	 */
	public void openBasicOrBookingInfoTab(String tabName) throws Exception {
		try {
			if (tabName.equalsIgnoreCase("BASIC"))
				WebAction.click(basicInfoTab);
			else if (tabName.equalsIgnoreCase("BOOKING"))
				WebAction.click(bookingInfoTab);
			else
				Assert.assertTrue(false, "Please provide valid tab name in view guest profile page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify biography of guest profile
	 * 
	 * @throws Exception
	 */
	public void verifyBiography() throws Exception {
		try {
			CommonValidations.verifyTextValue(biography, GuestProfileConstants.getBiography(),
					"Biography of guest profile in guest profile view page is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify demographics details of guest profile
	 * 
	 * @throws Exception
	 */
	public void verifyDemographics() throws Exception {
		try {
			if (GuestProfileConstants.getSelfIdentifying() != null) {
				CommonValidations.verifyTextValue(selfIdentifying, GuestProfileConstants.getSelfIdentifying(),
						"Self Identifying of guest profile in guest profile view page is not matched");
			}

			CommonValidations.verifyTextValue(gender, GuestProfileConstants.getGender(),
					"Gender of guest profile in guest profile view page is not matched");

			CommonValidations.verifyTextValue(ethnicity, GuestProfileConstants.getEthnicity(),
					"Ethnicity of guest profile in guest profile view page is not matched");

			if (GuestProfileConstants.getOther() != null)
				CommonValidations.verifyTextValue(other, GuestProfileConstants.getOther(),
						"Other of guest profile in guest profile view page is not matched");

			if (GuestProfileConstants.getLanguages() != null)
				CommonValidations.verifyTextValue(languages, GuestProfileConstants.getLanguages(),
						"Languages of guest profile in guest profile view page is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify expertise details of guest profile
	 * 
	 * @throws Exception
	 */
	public void verifyExpertise() throws Exception {
		try {
			int expertiseCount = GuestProfileConstants.getExpertiseCount();
			if (expertiseCount == 0)
				CommonValidations.verifyTextValue(expertise.get(0), "None",
						"Guest profile expertise value is displayed other than None");
			else {
				List<String> expectedExpertise = new ArrayList<String>();
				for (int i = 0; i < expertiseCount; i++) {
					expectedExpertise.add(GuestProfileConstants.getExpertise(i));
				}
				Collections.sort(expectedExpertise);

				for (int i = 0; i < expectedExpertise.size(); i++) {
					CommonValidations.verifyTextValue(expertise.get(i), expectedExpertise.get(i),
							"Guest profile expertise " + (i + 1) + " is not matched");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify guest profile ticker details
	 * 
	 * @throws Exception
	 */
	public void verifyTicker() throws Exception {
		try {
			String expectedTicker = GuestProfileConstants.getTicker();
			if (!expectedTicker.trim().isEmpty()) {
				CommonValidations.verifyTextValue(ticker, expectedTicker,
						"Ticker of guest profile in guest profile view page is not matched");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify alert message of guest profile
	 * 
	 * @throws Exception
	 */
	public void verifyAlerts() throws Exception {
		try {
			Assert.assertTrue(WebAction.isDisplayed(alertHeader),
					"Alerts header is not displayed in guest profile view page");
			System.out.println("Actual Alert Message:" + alertMessage.getText());
			System.out.println("Expected Alert Message:" + GuestProfileConstants.getAlert());
			CommonValidations.verifyTextValue(alertMessage, GuestProfileConstants.getAlert(),
					"Alert message of guest profile in guest profile view page is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify alerts are displayed in red color
	 * 
	 * @throws Exception
	 */
	public void verifyAlertsColor(String color) throws Exception {
		try {
			CommonValidations.verifyColorOfElement(alertHeader, "color", color + "-6");
			CommonValidations.verifyColorOfElement(alertMessage, "color", color + "-6");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click tab in contact info
	 * 
	 * @param tabName - tab name
	 * @throws Exception
	 */
	public void selectTabInContactInfo(String tabName) throws Exception {
		try {
			switch (tabName.toUpperCase()) {
			case "PHONE":
				if ((GuestProfileConstants.getPhone1() != null) || (GuestProfileConstants.getPhone2() != null)
						|| (GuestProfileConstants.getMobilePhoneNumber() != null)
						|| (GuestProfileConstants.getOfficePhoneNumber() != null))
					WebAction.click(phoneTab);
				break;
			case "EMAIL":
				if ((GuestProfileConstants.getEmailAddress(0) != null)
						|| (GuestProfileConstants.getEmailAddress(1) != null)
						|| (GuestProfileConstants.getEmailAddress(2) != null)
						|| (GuestProfileConstants.getEmailAddress(3) != null))
					WebAction.click(emailTab);
				break;
			case "OTHER":
				if ((GuestProfileConstants.getTwitterLink() != null)
						|| (GuestProfileConstants.getLinkedInLink() != null)
						|| (GuestProfileConstants.getVideoLink() != null)
						|| (GuestProfileConstants.getWebSiteLink() != null))
					WebAction.click(otherTab);
				break;
			case "ADDRESS":
				if ((GuestProfileConstants.getAddressLine1() != null)
						|| (GuestProfileConstants.getAddressLine2() != null)
						|| (GuestProfileConstants.getCity() != null) || (GuestProfileConstants.getState() != null)
						|| (GuestProfileConstants.getCountry() != null)) {
					for (WebElement element : threeDots) {
						if (element.isDisplayed()) {
							WebAction.scrollDown();
							WebAction.mouseOver(element);
							Thread.sleep(1000);
							break;
						}
					}
					for (WebElement element : addressTab) {
						if (element.isDisplayed()) {
							WebAction.click(element);
							break;
						}
					}
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify color of selected tab of contact info
	 * 
	 * @param tabName - tab name of contact info
	 * @param color   - color
	 * @throws Exception
	 */
	public void verifyColorOfSelectTabInContactInfo(String tabName, String color) throws Exception {
		try {
			switch (tabName.toUpperCase()) {
			case "PHONE":
				CommonValidations.verifyColorOfElement(phoneTab, "color", color);
				break;
			case "EMAIL":
				Thread.sleep(1000);
				CommonValidations.verifyColorOfElement(emailTab, "color", color);
				break;
			case "Other":
				Thread.sleep(1000);
				CommonValidations.verifyColorOfElement(otherTab, "color", color);
				break;
			case "Address":
				Thread.sleep(1000);
				for (WebElement element : addressTab) {
					if (element.isDisplayed()) {
						CommonValidations.verifyColorOfElement(element, "color", color);
						break;
					}
				}
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify guest phone contact details
	 * 
	 * @throws Exception
	 */
	public void verifyGuestPhoneDetails() throws Exception {
		try {
			if (GuestProfileConstants.getPhone1() != null)
				CommonValidations.verifyTextValue(phone1, GuestProfileConstants.getPhone1(),
						"1 - Phone contact of guest profile is not matched");
			if (GuestProfileConstants.getPhone2() != null)
				CommonValidations.verifyTextValue(phone2, GuestProfileConstants.getPhone2(),
						"2 - Phone contact of guest profile is not matched");
			if (GuestProfileConstants.getOfficePhoneNumber() != null)
				CommonValidations.verifyTextValue(officePhone, GuestProfileConstants.getOfficePhoneNumber(),
						"Office phone contact of guest profile is not matched");
			if (GuestProfileConstants.getMobilePhoneNumber() != null)
				CommonValidations.verifyTextValue(mobilePhone, GuestProfileConstants.getMobilePhoneNumber(),
						"Mobile phone contact of guest profile is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify guest email contact details
	 * 
	 * @throws Exception
	 */
	public void verifyGuestEmailDetails() throws Exception {
		try {
			if (GuestProfileConstants.getEmailAddress(0) != null)
				CommonValidations.verifyTextValue(email1, GuestProfileConstants.getEmailAddress(0),
						"1 - Email contact of guest profile is not matched");
			if (GuestProfileConstants.getEmailAddress(1) != null)
				CommonValidations.verifyTextValue(email2, GuestProfileConstants.getEmailAddress(1),
						"2 - Email contact of guest profile is not matched");
			if (GuestProfileConstants.getEmailAddress(2) != null)
				CommonValidations.verifyTextValue(email3, GuestProfileConstants.getEmailAddress(2),
						"3 - Email contact of guest profile is not matched");
			if (GuestProfileConstants.getEmailAddress(3) != null)
				CommonValidations.verifyTextValue(email4, GuestProfileConstants.getEmailAddress(3),
						"4 - Email contact of guest profile is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify guest other contact details
	 * 
	 * @throws Exception
	 */
	public void verifyGuestOtherDetails() throws Exception {
		try {
			if (GuestProfileConstants.getTwitterLink() != null)
				CommonValidations.verifyTextValue(twitter, GuestProfileConstants.getTwitterLink(),
						"Twitter contact of guest profile is not matched");
			if (GuestProfileConstants.getLinkedInLink() != null)
				CommonValidations.verifyTextValue(linkedIn, GuestProfileConstants.getLinkedInLink(),
						"Linked in contact of guest profile is not matched");
			if (GuestProfileConstants.getVideoLink() != null)
				CommonValidations.verifyTextValue(video, GuestProfileConstants.getVideoLink(),
						"Video contact of guest profile is not matched");
			if (GuestProfileConstants.getWebSiteLink() != null)
				CommonValidations.verifyTextValue(webSite, GuestProfileConstants.getWebSiteLink(),
						"Web site contact of guest profile is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify address of guest profile
	 * 
	 * @throws Exception
	 */
	public void verifyGuestAddressDetails() throws Exception {
		try {
			if (GuestProfileConstants.getAddressLine1() != null)
				CommonValidations.verifyTextValue(addressLine1, GuestProfileConstants.getAddressLine1(),
						"Address line1 of guest profile is not matched");
			if (GuestProfileConstants.getAddressLine2() != null)
				CommonValidations.verifyTextValue(addressLine2, GuestProfileConstants.getAddressLine2(),
						"Address line2 of guest profile is not matched");
			if (GuestProfileConstants.getCity() != null)
				CommonValidations.verifyTextValue(city, GuestProfileConstants.getCity(),
						"City of guest profile is not matched");
			if (GuestProfileConstants.getState() != null)
				CommonValidations.verifyTextValue(state, GuestProfileConstants.getState(),
						"State of guest profile is not matched");
			if (GuestProfileConstants.getZipCode() != null)
				CommonValidations.verifyTextValue(zipCode, GuestProfileConstants.getZipCode(),
						"Zip code of guest profile is not matched");
			if (GuestProfileConstants.getCountry() != null)
				CommonValidations.verifyTextValue(country, GuestProfileConstants.getCountry(),
						"Country of guest profile is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify job details of guest profile
	 * 
	 * @throws Exception
	 */
	public void verifyGuestJobDetails() throws Exception {
		try {
			for (int i = 0; i < GuestProfileConstants.getGuestJobCount(); i++) {
				// Validate job Title
				CommonValidations.verifyTextValue(jobTitle, GuestProfileConstants.getGuestJobTitle(i),
						"Job title of job " + (i + 1) + "of guest profile is not correct");

				// Validate job status
				CommonValidations.verifyTextValue(jobStatus, GuestProfileConstants.getGuestJobStatus(i),
						"Job status of job " + (i + 1) + "of guest profile is not correct");

				// Validate primary job
				if (GuestProfileConstants.getPrimaryJob(i) != null) {
					if (GuestProfileConstants.getPrimaryJob(i).equalsIgnoreCase("YES"))
						CommonValidations.verifyTextValue(primaryJob, "Primary Job",
								"Primary job tag of job " + (i + 1) + "of guest profile is missing");
				}

				// Validate start date
				if (!GuestProfileConstants.getGuestJobStartDate(i).equalsIgnoreCase("NA"))
					CommonValidations.verifyTextValue(jobStartDate, GuestProfileConstants.getGuestJobStartDate(i),
							"Start date of job " + (i + 1) + "of guest profile is not correct");

				// Validate category
				if (!GuestProfileConstants.getGuestJobCategory(i).equalsIgnoreCase("NA"))
					CommonValidations.verifyTextValue(jobCategory, GuestProfileConstants.getGuestJobCategory(i),
							"Job category of job " + (i + 1) + "of guest profile is not correct");

				// Validate org/company
				if (!GuestProfileConstants.getGuestJobCompany(i).equalsIgnoreCase("NA"))
					CommonValidations.verifyTextValue(jobOrganization, GuestProfileConstants.getGuestJobCompany(i),
							"Organization name of job " + (i + 1) + "of guest profile is not correct");

				// Validate department
				if (!GuestProfileConstants.getGuestJobDepartment(i).equalsIgnoreCase("NA"))
					CommonValidations.verifyTextValue(jobDepartment, GuestProfileConstants.getGuestJobDepartment(i),
							"Department of job " + (i + 1) + "of guest profile is not correct");

				// Validate job notes
				if (!GuestProfileConstants.getGuestJobNotes(i).equalsIgnoreCase("NA"))
					CommonValidations.verifyTextValue(jobNotes, GuestProfileConstants.getGuestJobNotes(i),
							"Job notes of job " + (i + 1) + "of guest profile is not correct");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify primary phone number is displayed on top
	 * 
	 * @throws Exception
	 */
	public void verifyPrimaryPhoneNumberDisplayedOnTop() throws Exception {
		try {
			String primaryPhone = GuestProfileConstants.getPrimaryPhone();
			if (primaryPhone != null) {
				if (primaryPhone.equalsIgnoreCase("OFFICE")) {
					CommonValidations.verifyTextValue(phoneList.get(0), GuestProfileConstants.getOfficePhoneNumber(),
							"Office phone number is not displayed in the top eventhough office phone number is marked primary");
				} else if (primaryPhone.equalsIgnoreCase("MOBILE")) {
					CommonValidations.verifyTextValue(phoneList.get(0), GuestProfileConstants.getMobilePhoneNumber(),
							"Mobile phone number is not displayed in the top eventhough mobile phone number is marked primary");
				} else if (primaryPhone.equalsIgnoreCase("1-PHONE")) {
					CommonValidations.verifyTextValue(phoneList.get(0), GuestProfileConstants.getPhone1(),
							"1-PHONE phone number is not displayed in the top eventhough 1-PHONE phone number is marked primary");
				} else if (primaryPhone.equalsIgnoreCase("2-PHONE")) {
					CommonValidations.verifyTextValue(phoneList.get(0), GuestProfileConstants.getPhone2(),
							"2-PHONE phone number is not displayed in the top eventhough 2-PHONE phone number is marked primary");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify primary email address is displayed on top
	 * 
	 * @throws Exception
	 */
	public void verifyPrimaryEmailDisplayedOnTop() throws Exception {
		try {
			String primaryEmail = GuestProfileConstants.getPrimaryEmail();
			if (primaryEmail != null) {
				if (primaryEmail.equalsIgnoreCase("1-EMAIL")) {
					CommonValidations.verifyTextValue(emailList.get(0), GuestProfileConstants.getEmailAddress(0),
							"1-EMAIL is not displayed in the top eventhough 1-EMAIL is marked primary");
				} else if (primaryEmail.equalsIgnoreCase("2-EMAIL")) {
					CommonValidations.verifyTextValue(emailList.get(0), GuestProfileConstants.getEmailAddress(1),
							"2-EMAIL is not displayed in the top eventhough 2-EMAIL is marked primary");
				} else if (primaryEmail.equalsIgnoreCase("3-EMAIL")) {
					CommonValidations.verifyTextValue(emailList.get(0), GuestProfileConstants.getEmailAddress(2),
							"3-EMAIL is not displayed in the top eventhough 3-EMAIL is marked primary");
				} else if (primaryEmail.equalsIgnoreCase("4-EMAIL")) {
					CommonValidations.verifyTextValue(emailList.get(0), GuestProfileConstants.getEmailAddress(3),
							"4-EMAIL is not displayed in the top eventhough 4-EMAIL is marked primary");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify primary other is displayed on the top
	 * 
	 * @throws Exception
	 */
	public void verifyPrimaryOtherDisplayedOnTop() throws Exception {
		try {
			String primaryOther = GuestProfileConstants.getPrimaryOther();
			if (primaryOther != null) {
				if (primaryOther.equalsIgnoreCase("TWITTER")) {
					CommonValidations.verifyTextValue(othersList.get(0), GuestProfileConstants.getTwitterLink(),
							"Twitter is not displayed in the top eventhough twitter is marked primary");
				} else if (primaryOther.equalsIgnoreCase("LINKEDIN")) {
					CommonValidations.verifyTextValue(othersList.get(0), GuestProfileConstants.getLinkedInLink(),
							"Linked in is not displayed in the top eventhough linked in is marked primary");
				} else if (primaryOther.equalsIgnoreCase("VIDEO")) {
					CommonValidations.verifyTextValue(othersList.get(0), GuestProfileConstants.getVideoLink(),
							"Video link is not displayed in the top eventhough video link is marked primary");
				} else if (primaryOther.equalsIgnoreCase("WEBSITE")) {
					CommonValidations.verifyTextValue(othersList.get(0), GuestProfileConstants.getWebSiteLink(),
							"Web site link is not displayed in the top eventhough web site link is marked primary");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click button in header
	 * 
	 * @param buttonType
	 * @throws Exception
	 */
	public void clickButtonInHeader(String buttonType) throws Exception {
		try {
			switch (buttonType.toUpperCase()) {
			case "BOOK":
				for (WebElement book : bookButton) {
					if (book.isDisplayed()) {
						WebAction.clickUsingJs(book);
						break;
					}
				}
				break;
			case "EDIT":
				for (WebElement edit : editButton) {
					if (edit.isDisplayed()) {
						WebAction.clickUsingJs(edit);
						break;
					}
				}
				break;
			case "HISTORY":
				for (WebElement history : historyButton) {
					if (history.isDisplayed()) {
						WebAction.clickUsingJs(history);
						break;
					}
				}
				break;
			case "COPY":
				for (WebElement copy : copyButton) {
					if (copy.isDisplayed()) {
						WebAction.clickUsingJs(copy);
						break;
					}
				}
				break;
			case "MERGE":
				for (WebElement merge : mergeButton) {
					if (merge.isDisplayed()) {
						WebAction.clickUsingJs(merge);
						break;
					}
				}
				break;
			case "CALENDAR":
				for (WebElement calendar : calendarButton) {
					if (calendar.isDisplayed()) {
						WebAction.clickUsingJs(calendar);
						break;
					}
				}
				break;
			case "PRONUNCIATION":
				for (WebElement pronunciation : pronunciationButton) {
					if (pronunciation.isDisplayed()) {
						WebAction.clickUsingJs(pronunciation);
						break;
					}
				}
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify button in headers are disabled for deactivated profile
	 * 
	 * @param params
	 * @throws Exception
	 */
	public void verifyButtonsInHeadersDisabled(DataTable params) throws Exception {
		try {
			List<Map<String, String>> buttonsList = CucumberUtils.getValuesFromDataTableAsList(params);
			for (int i = 0; i < buttonsList.size(); i++) {
				switch (buttonsList.get(i).get("Icons").toUpperCase()) {
				case "BOOK":
					for (WebElement book : bookButton) {
						if (book.isDisplayed()) {
							CommonValidations.verifyAttributeValue(book, "aria-disabled", "true",
									"Book button is enabled in header of guest profile view page for deactivated guest");
							break;
						}
					}
					break;
				case "HISTORY":
					for (WebElement history : historyButton) {
						if (history.isDisplayed()) {
							CommonValidations.verifyAttributeValue(history, "aria-disabled", "true",
									"History button is enabled in header of guest profile view page for deactivated guest");
							break;
						}
					}
					break;
				case "COPY":
					for (WebElement copy : copyButton) {
						if (copy.isDisplayed()) {
							CommonValidations.verifyAttributeValue(copy, "aria-disabled", "true",
									"Copy button is enabled in header of guest profile view page for deactivated guest");
							break;
						}
					}
					break;
				case "MERGE":
					for (WebElement merge : mergeButton) {
						if (merge.isDisplayed()) {
							CommonValidations.verifyAttributeValue(merge, "aria-disabled", "true",
									"Merge button is enabled in header of guest profile view page for deactivated guest");
							break;
						}
					}
					break;
				case "CALENDAR":
					for (WebElement calendar : calendarButton) {
						if (calendar.isDisplayed()) {
							CommonValidations.verifyAttributeValue(calendar, "aria-disabled", "true",
									"Calendar button is enabled in header of guest profile view page for deactivated guest");
							break;
						}
					}
					break;
				case "PRONUNCIATION":
					for (WebElement pronunciation : pronunciationButton) {
						if (pronunciation.isDisplayed()) {
							CommonValidations.verifyAttributeValue(pronunciation, "aria-disabled", "true",
									"Pronunciation button is enabled in header of guest profile view page for deactivated guest");
							break;
						}
					}
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify profile deactivated banner is displayed
	 * 
	 * @throws Exception
	 */
	public void verifyDeactivatedProfileBannerDisplayed(String stat) throws Exception {
		try {
			if (stat.equalsIgnoreCase("DISPLAYED")) {
				String fullName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();
				CommonValidations.verifyTextValue(deactivatedBanner, fullName + " - PROFILE DEACTIVATED",
						"Profile deactivated banner is not displayed for deactivated profile");
			} else if (stat.equalsIgnoreCase("DISAPPEARED")) {
				Assert.assertFalse(WebAction.isDisplayed(deactivatedBanner),
						"Profile deactivated banner is displayed for active profile");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify appearance counter & table
	 * 
	 * @throws Exception
	 */
	public void verifyAppearanceCounter() throws Exception {
		try {
			Waits.waitForElement(appearanceStatus, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyTextValue(appearanceStatus, "Good", "Appearance status is not displayed as Good");
			CommonValidations.verifyColorOfElement(appearanceStatus, "color", "GREEN-6");

			// Check weekly appearance count
			String weeklyAppearanceCount = "0", monthlyAppearanceCount = "0";
			if (BookingGuestConstants.getWeeklyBookingCount() != null)
				weeklyAppearanceCount = BookingGuestConstants.getWeeklyBookingCount();

			System.out.println("Weekly booking count" + BookingGuestConstants.getWeeklyBookingCount());
			CommonValidations.verifyTextValue(weeklyAppearanceCountElement, weeklyAppearanceCount,
					"Weekly appearance count is not correct in booking info guest profile");

			// Check monthly appearance count
			if (BookingGuestConstants.getWeeklyBookingCount() != null)
				monthlyAppearanceCount = BookingGuestConstants.getMonthlyBookingCount();

			System.out.println("Monthly booking count" + BookingGuestConstants.getMonthlyBookingCount());
			CommonValidations.verifyTextValue(monthlyAppearanceCountElement, monthlyAppearanceCount,
					"Monthly appearance count is not correct in booking info guest profile");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select tab in booking info
	 * 
	 * @param tabName - tab name
	 * @throws Exception
	 */
	public void selectTabInBookingInfo(String tabName) throws Exception {
		try {
			switch (tabName.toUpperCase()) {
			case "CALLS":
				WebAction.click(callsTab);
				break;
			case "FUTURE BOOKINGS":
				WebAction.click(futureBookingsTab);
				break;
			case "PAST BOOKINGS":
				WebAction.click(pastBookingsTab);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify call details
	 * 
	 * @param callStatus
	 * @throws Exception
	 */
	public void verifyCallsDetails(String callStatus) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String status = "";
			if (callStatus.equalsIgnoreCase("CALL OUT"))
				status = BookingGuestConstants.getCallStatus();
			else
				status = callStatus;

			// validate division
			WebElement callsDivisionName = driver.findElement(By
					.xpath(callsDivisionNameXpath.replace("<<Status>>", StringUtils.capitalize(status.toLowerCase()))));
			CommonValidations.verifyTextValue(callsDivisionName, AdminConstants.getDivision(),
					"Division is not correct in calls tab of booking info");

			// validate show name
			WebElement callsShowName = driver.findElement(By
					.xpath(callsShowNameNameXpath.replace("<<Status>>", StringUtils.capitalize(status.toLowerCase()))));
			CommonValidations.verifyTextValue(callsShowName, BookingGuestConstants.getShowName(),
					"Show name is not correct in calls tab of booking info");

			// validate call out/booking/cancelled/reactivate date and time

			// Call status element
			List<WebElement> callsStatus = driver.findElements(
					By.xpath(callsStatusXpath.replace("<<Status>>", StringUtils.capitalize(status.toLowerCase()))));
			List<WebElement> callsDateAndTime = driver.findElements(By
					.xpath(callsDateAndTimeXpath.replace("<<Status>>", StringUtils.capitalize(status.toLowerCase()))));

			// If call status is call out
			if (callStatus.equalsIgnoreCase("CALL OUT")) {
				CommonValidations.verifyTextValue(callsStatus.get(0), BookingGuestConstants.getCallStatus(),
						"Call status is not correct in calls tab of booking info");
				CommonValidations.verifyColorOfElement(callsStatus.get(0), "color", "GREY-8");
				CommonValidations.verifyTextValue(callsDateAndTime.get(0), BookingGuestConstants.getCallOutDate(),
						"Call out date is not correct in calls tab of booking info");
				String expectedCallOutTime = DateFunctions
						.convertDateStringToAnotherFormat(BookingGuestConstants.getCallOutTime(), "HH:mm", "h:mma");
				CommonValidations.verifyTextValue(callsDateAndTime.get(0), expectedCallOutTime,
						"Call out time is not correct in calls tab of booking info");
			} else if (callStatus.equalsIgnoreCase("BOOKED")) {

				CommonValidations.verifyTextValue(callsStatus.get(0), "Booked",
						"Status is not correct in calls tab of booking info");
				CommonValidations.verifyColorOfElement(callsStatus.get(0), "color", "GREEN-6");
				CommonValidations.verifyTextValue(callsDateAndTime.get(0), BookingGuestConstants.getBookingDate(),
						"booked date is not correct in calls tab of booking info");
				String expectedBookingTime = DateFunctions
						.convertDateStringToAnotherFormat(BookingGuestConstants.getBookingTime(), "HH:mm", "h:mma");
				CommonValidations.verifyTextValue(callsDateAndTime.get(0), expectedBookingTime,
						"booked time is not correct in calls tab of booking info");
			} else if (callStatus.equalsIgnoreCase("CANCELLED")) {
				CommonValidations.verifyTextValue(callsStatus.get(0), "Cancelled",
						"Status is not correct in calls tab of booking info");
				CommonValidations.verifyColorOfElement(callsStatus.get(0), "color", "RED-6");
				CommonValidations.verifyTextValue(callsDateAndTime.get(0),
						BookingGuestConstants.getBookingCancellationDate(),
						"Cancelled date is not correct in calls tab of booking info");
				CommonValidations.verifyTextValue(callsDateAndTime.get(0),
						BookingGuestConstants.getBookingCancellationTime(),
						"Cancelled time is not correct in calls tab of booking info");
			} else if (callStatus.equalsIgnoreCase("RESTORED")) {
				CommonValidations.verifyTextValue(callsStatus.get(0), "Restored",
						"Status is not correct in calls tab of booking info");
				CommonValidations.verifyColorOfElement(callsStatus.get(0), "color", "GREY-8");
				
				CommonValidations.verifyTextValue(callsDateAndTime.get(0),
						BookingGuestConstants.getReactivateBookingDate(),
						"Restored date is not correct in calls tab of booking info");

				String expectedRestoredTime1 = DateFunctions
						.convertDateStringToAnotherFormat(BookingGuestConstants.getReactivateBookingTime(), "hh:mma", "h:mma");
				String expectedRestoredTime2 = DateFunctions.addOrMinusTimeFromGivenTime(expectedRestoredTime1, "h:mma",
						TIMETYPE.MINUTES, "1");
				if (!((WebAction.getText(callsDateAndTime.get(0)).contains(expectedRestoredTime1))
						|| (WebAction.getText(callsDateAndTime.get(0)).contains(expectedRestoredTime2))))
					Assert.assertTrue(false,
							"Restored time is not correct in calls tab of booking info. Expected time is '"
									+ expectedRestoredTime1 + " or " + expectedRestoredTime2 + "'. But actual time is '"
									+ WebAction.getText(callsDateAndTime.get(0)) + "'");
			} else
				Assert.assertTrue(false, "Please valid provide call status");

			// To validate show date and time
			String expectedShowTime = DateFunctions
					.convertDateStringToAnotherFormat(BookingGuestConstants.getShowTime(), "HH:mm", "h:mma");
			CommonValidations.verifyTextValue(callsShowDateAndTime.get(0), BookingGuestConstants.getShowDate(),
					"Show date is not correct in calls tab of booking info");
			CommonValidations.verifyTextValue(callsShowDateAndTime.get(0), expectedShowTime,
					"Show time is not correct in calls tab of booking info");

			// To validate booker name
			String expectedBookerName = BookerProfileConstants.getBookerName();
			CommonValidations.verifyTextValue(callsBookerName.get(0), expectedBookerName,
					"Booker name is not correct in calls tab of booking info");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify booking is displayed in future bookings tab
	 * 
	 * @param bookingStatus - booking status
	 * @throws Exception
	 */
	public void verifyPastOrFutureBookingDetails(String bookingStatus, String tabName) throws Exception {
		try {
			// validate division
			CommonValidations.verifyTextValue(bookingsDivision.get(0), AdminConstants.getDivision(),
					"Division is not correct in " + tabName + " tab of booking info");

			// validate show name
			CommonValidations.verifyTextValue(bookingsShowName.get(0), BookingGuestConstants.getShowName(),
					"Show name is not correct in " + tabName + " tab of booking info");

			// validate show date
			CommonValidations.verifyTextValue(bookingsShowDate.get(0), BookingGuestConstants.getShowDate(),
					"Booking show date is not correct in " + tabName + " tab of booking info");

			// validate show time
			String expectedBookingTime = DateFunctions
					.convertDateStringToAnotherFormat(BookingGuestConstants.getShowTime(), "HH:mm", "h:mma");
			CommonValidations.verifyTextValue(bookingsShowTime.get(0), expectedBookingTime,
					"Show time is not correct in " + tabName + " tab of booking info");

			// validate segment
			CommonValidations.verifyTextValue(bookingsTopic.get(0), BookingGuestConstants.getTopicName(),
					"Booking topic is not correct in " + tabName + " tab of booking info");

			// validate status is cancelled
			if (bookingStatus.equalsIgnoreCase("CANCELLED"))
				CommonValidations.verifyTextValue(bookingsStatus.get(0), "Cancelled",
						"Booking status is not displayed as cancelled in " + tabName + " tab of booking info");

			// To validate booker name
			String expectedBookerName = BookerProfileConstants.getBookerName();
			CommonValidations.verifyTextValue(callsBookerName.get(0), expectedBookerName,
					"Booker name is not correct in calls tab of booking info");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click on status button
	 * 
	 * @param stat
	 * @throws Exception
	 */
	public void clickOnStatusInCallsTab(String callStatus) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			List<WebElement> callsStatus = null;
			if (callStatus.equalsIgnoreCase("CALL OUT")) {
				String status = BookingGuestConstants.getCallStatus();
				callsStatus = driver.findElements(
						By.xpath(callsStatusXpath.replace("<<Status>>", StringUtils.capitalize(status.toLowerCase()))));
			} else if (callStatus.equalsIgnoreCase("BOOKED")) {

				callsStatus = driver.findElements(By.xpath(callsStatusXpath.replace("<<Status>>", "Booked")));
			} else if (callStatus.equalsIgnoreCase("CANCELLED")) {
				callsStatus = driver.findElements(By.xpath(callsStatusXpath.replace("<<Status>>", "Cancelled")));
			} else if (callStatus.equalsIgnoreCase("RESTORED")) {
				callsStatus = driver.findElements(By.xpath(callsStatusXpath.replace("<<Status>>", "Restored")));
			} else
				Assert.assertTrue(false, "Please valid provide call status");

			WebAction.click(callsStatus.get(0));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}
