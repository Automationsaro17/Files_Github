package nbcu.automation.ui.pages.gtreplatform;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.encryption.PasswordEncryption;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import org.testng.Assert;

public class LoginPage {

    @FindBy(name = "loginfmt")
    WebElement userNameTextBox;

    String userAccountSelection = "//div[contains(text(),'<<sso>>')]";

    @FindBy(id = "idSIButton9")
    WebElement nextButton;

    @FindBy(name = "passwd")
    WebElement passwordTextBox;

    @FindBy(xpath = "//div[text()='Stay signed in?']")
    WebElement staySignedInElement;

    public LoginPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To open GT replatform application
     *
     * @throws Exception
     */
    public void openApplication() throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        String environment = "", applicationUrl = "";
        try {
            // Fetch the application url based on application and environment
            environment = ConfigFileReader.getProperty("Environment");
            switch (environment.toUpperCase()) {
                case "QA":
                    applicationUrl = ConfigFileReader.getProperty("gt-app-url_Qa");
                    break;
                case "STG":
                    applicationUrl = ConfigFileReader.getProperty("gt-app-url_Stg");
                    break;
                case "PROD":
                    applicationUrl = ConfigFileReader.getProperty("gt-app-url_Prod");
                    break;
                default:
                    Assert.fail("Please provide valid environment. Given environment '" + environment + "' is not found");
            }

            // Launch the application
            assert driver != null;
            driver.get(applicationUrl);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify sign in page is displayed
     *
     * @throws Exception
     */
    public void verifySignInPageDisplayed() throws Exception {
        Waits.waitForElement(userNameTextBox, WAIT_CONDITIONS.VISIBLE);
    }

    /**
     * To login into application
     *
     * @throws Exception
     */
    public void loginIntoApplication() throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        String userNameText = "", passwordText = "";
        try {

            userNameText = ConfigFileReader.getProperty("gt-admin-username");
            passwordText = ConfigFileReader.getProperty("gt-admin-password");

            userNameText = userNameText + "@tfayd.com";
            Thread.sleep(2000);
            if (WebAction.isDisplayed(userNameTextBox)) {
                WebAction.sendKeys(userNameTextBox, userNameText);
            } else {
                assert driver != null;
                WebAction.click(driver.findElement(By.xpath(userAccountSelection.replace("<<sso>>", userNameText))));
            }
            WebAction.click(nextButton);
            String decryptedPassword = PasswordEncryption.decrypt(passwordText);
            Waits.waitForElement(passwordTextBox, WAIT_CONDITIONS.VISIBLE);
            WebAction.sendKeys(passwordTextBox, decryptedPassword);
            WebAction.click(nextButton);
            Waits.waitForElement(staySignedInElement, WAIT_CONDITIONS.VISIBLE);
            WebAction.click(nextButton);

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

}
