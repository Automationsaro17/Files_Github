package nbcu.automation.ui.pages.gtreplatform;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.gtreplatform.CompanyProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.ProxyConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.others.CommonUtils;

public class ProxyProfilePage {

	@FindBy(xpath = "//h2[text()='Proxy Profile']")
	WebElement proxyProfileHeader;

	@FindBy(xpath = "//span[text()='Basic Info']")
	WebElement basicInfoTab;

	@FindBy(xpath = "//span[text()='Job Info']")
	WebElement jobInfoTab;

	@FindBy(id = "ProxyInfo_displayName")
	WebElement txtBoxDisplayName;

	@FindBy(id = "ProxyInfo_firstName")
	WebElement txtBoxFirstName;

	@FindBy(id = "ProxyInfo_lastName")
	WebElement txtBoxLastName;

	@FindBy(xpath = "//span[text()='Select Expertise(s)']")
	WebElement expertiseDropDown;

	@FindBy(xpath = "//span[text()='Select Expertise(s)']/preceding-sibling::span/input")
	WebElement expertiseInputBox;

	@FindBy(xpath = "//input[@id='rc_select_6']")
	WebElement expertiseInputBoxTwo;

	String dropDownValuesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> listDropDownValues;

	@FindBy(id = "ProxyInfo_jobNotes")
	WebElement jobNotesField;

	@FindBy(xpath = "//span[text()='Search Companies here...']/preceding-sibling::span/input")
	WebElement searchCompaniesSugBox;

	String compDropDownValuesXpath = "//div[@class='rc-virtual-list']//div[contains(@class,'option-content')]";

	@FindBy(xpath = "//div[@class='rc-virtual-list']//div[contains(@class,'option-content')]")
	List<WebElement> compSuggestion;

	// Phone - Contact Info section
	@FindBy(xpath = "//label[text()='1 - Phone']")
	WebElement phoneLabelText;

	@FindBy(id = "Contact_Phone_0_phone")
	WebElement phoneNo0;

	@FindBy(id = "Contact_Phone_1_phone")
	WebElement phoneNo1;

	@FindBy(id = "Contact_Phone_2_phone")
	WebElement phoneNo2;

	@FindBy(id = "Contact_Phone_3_phone")
	WebElement phoneNo3;

	@FindBy(xpath = "//*[contains(@id,'Contact_Phone_')]/following-sibling::span/button")
	List<WebElement> phoneFavoriteButtons;

	// Email - Contact Info section
	@FindBy(id = "Contact_Email_0_email")
	WebElement email0;

	@FindBy(id = "Contact_Email_1_email")
	WebElement email1;

	@FindBy(id = "Contact_Email_2_email")
	WebElement email2;

	@FindBy(id = "Contact_Email_3_email")
	WebElement email3;

	@FindBy(xpath = "//*[contains(@id,'Contact_Email_')]/following-sibling::span/button")
	List<WebElement> emailFavoriteButtons;

	// Other - Contact Info section
	@FindBy(id = "Contact_Social_0_link")
	WebElement other0;

	@FindBy(id = "Contact_Social_1_link")
	WebElement otherfield1;

	@FindBy(id = "Contact_Misc_0_link")
	WebElement otherfield2;

	@FindBy(id = "Contact_Misc_1_link")
	WebElement otherfield3;

	@FindBy(xpath = "//*[contains(@id,'Contact_Social_') or contains(@id,'Contact_Misc_')]/following-sibling::span/button")
	List<WebElement> othersFavoriteButtons;

	// Address - Contact Info section
	@FindBy(xpath = "//label[text()='Address - 1']")
	WebElement addressLabel;

	@FindBy(id = "Contact_Address_0_address1")
	WebElement addressLine1;

	@FindBy(id = "Contact_Address_0_address2")
	WebElement addressLine2;

	@FindBy(id = "Contact_Address_0_city")
	WebElement addressCity;

	@FindBy(id = "Contact_Address_0_state")
	WebElement addressState;

	String dropDownStateValuesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropDownValues;

	@FindBy(id = "Contact_Address_0_zip")
	WebElement addressZip;

	@FindBy(id = "Contact_Address_0_country")
	WebElement addressCountry;

	// Alerts - Contact Info section
	@FindBy(id = "Alerts_notes")
	WebElement alertsDetails;

	@FindBy(xpath = "//span[text()='Search for Contacts to add...']/preceding-sibling::span/input")
	WebElement additionalContactTextBox;

	// Drop down value xpath
	String additionalDropDownvaluesXpath = "//div[contains(@class,'ant-select-item-option-content')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item-option-content')]")
	List<WebElement> additionalDropDownvalues;

	@FindBy(xpath = "//div[@data-component='components/cards/proxy']")
	List<WebElement> additionalContactPlaceholder;

	// Drop down value xpath
	String dropDownvaluesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropDownvalues;

	@FindBy(xpath = "//div[contains(@class,'ant-select-dropdown ant-select-dropdown-placement-topLeft')]/descendant::div[@class='ant-select-item-option-content']")
	List<WebElement> registerWebElements;

	@FindBy(xpath = "//div[contains(@class,'ant-select-dropdown-placement-topLeft')]//div[3]")
	WebElement listBox;

	@FindBy(xpath = "//span[text()='Create']")
	WebElement createProxyButton;

	@FindBy(xpath = "//span[text()='Job History']")
	WebElement jobHistoryTxt;

	@FindBy(xpath = "//span[text()='Job History']/following-sibling::button/span[2]")
	WebElement addJobButton;

	@FindBy(xpath = "//span[@class='ant-radio-button ant-radio-button-checked']/following-sibling::span")
	WebElement defEnabledStatus;

	@FindBy(xpath = "(//div[@class='ant-picker-input']/input)[1]")
	WebElement inputFieldStartDate;

	@FindBy(id = "jobTitle")
	WebElement enteringJobTitle;

	String companyOrgName = "//div[contains(@class,'ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item-option')]")
	List<WebElement> companyOrgList;

	@FindBy(id = "department")
	WebElement jobDepartment;

	@FindBy(id = "notes")
	WebElement jobNotes;

	@FindBy(xpath = "//span[text()=' Add Job']")
	WebElement addJobRHButton;

	public ProxyProfilePage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * Select the Organization/Company
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "//input[@placeholder='Org/Company']")
	WebElement searchOrg;

	public void selectOraganization(String organValue) throws Exception {
		boolean isFieldPresent = WebAction.isDisplayed(searchOrg);
		try {
			if (isFieldPresent) {
				String companyName = "";
				if (CompanyProfileConstants.getCompanyName() != null)
					companyName = CompanyProfileConstants.getCompanyName();
				else
					companyName = organValue;
				WebAction.clickUsingJs(searchOrg);
				ProxyConstants.setJobOrganization(companyName);
//				WebAction.sendKeys(searchOrg, organValue);
				WebAction.selectNonTitleDropDown(searchOrg, companyName, dropDownValuesXpath, dropDownValues,
						"'" + companyName + "' is not present in search suggestion dropbox");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * To Select category from Job history RH drawer
	 * 
	 * @throws Exception
	 */

	@FindBy(xpath = "//input[@id='category']")
	WebElement selectCateogyDate;

	String dropDownListCategory = "//div[@class='rc-virtual-list-holder-inner']/div";

	@FindBy(xpath = "//div[@class='rc-virtual-list-holder-inner']/div")
	List<WebElement> listCategoryValues;

	public void setCategory(String category) throws Exception {
		ProxyConstants.setJobCategory(category);
		WebAction.clickUsingJs(selectCateogyDate);
		try {
			if (category != null) {
				WebAction.selectDropDown(selectCateogyDate, category, dropDownListCategory, listCategoryValues,
						"'" + category + "' value is not present in Job Category drop down field");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify Proxy profile page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyProxyProfilePageDisplayed() throws Exception {
		Waits.waitForElement(proxyProfileHeader, WAIT_CONDITIONS.VISIBLE);
	}

	/**
	 * To Select Basic Info tab in Proxy profile page
	 * 
	 * @throws Exception
	 */
	public void openBasicOrJobInfoTab(String tabName) throws Exception {
		String tabBasicInfo = WebAction.getText(basicInfoTab);
		try {
			if (tabBasicInfo.equalsIgnoreCase(tabName)) {
				WebAction.click(basicInfoTab);
			} else {
				// Waits.waitForElement(jobInfoTab, WAIT_CONDITIONS.INVISIBLE);
				WebAction.clickUsingJs(jobInfoTab);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Enter the Display Name Input field
	 * 
	 * @throws Exception
	 */
	public void fillDisplayName(String displayNameValue, String profileType) throws Exception {
		try {
			boolean fieldIsPresent = WebAction.isDisplayed(txtBoxDisplayName);

			if (fieldIsPresent && profileType.equalsIgnoreCase("No")) {
				displayNameValue = displayNameValue + "_" + CommonUtils.generateRandomString(10);
				ProxyConstants.setDisplayName(displayNameValue);
				WebAction.sendKeys(txtBoxDisplayName, displayNameValue);
			} else if (fieldIsPresent && profileType.equalsIgnoreCase("Yes")) {
				ProxyConstants.secondProfileDisplayName(displayNameValue);
				WebAction.sendKeys(txtBoxDisplayName, displayNameValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Enter the First Name Input field
	 * 
	 * @throws Exception
	 */
	public void fillFirstName(String firstNameInput, String profileType) throws Exception {
		try {
			boolean fieldIsPresent = WebAction.isDisplayed(txtBoxFirstName);
			String firstNameLen = WebAction.getText(txtBoxFirstName);
			if (fieldIsPresent) {
				if (firstNameLen.length() == 0 && profileType.equalsIgnoreCase("No")) {
					ProxyConstants.setFirstName(firstNameInput);
					WebAction.sendKeys(txtBoxFirstName, firstNameInput);
				} else if (firstNameLen.length() == 0 && profileType.equalsIgnoreCase("Yes")) {
					ProxyConstants.setsecondProfileFirstName(firstNameInput);
					WebAction.sendKeys(txtBoxFirstName, firstNameInput);
				}
			} else
				throw new Exception("Name field is not present in the screen");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Enter the Last Name Input field
	 * 
	 * @throws Exception
	 */
	public void fillLastName(String lastNameInput, String profileType) throws Exception {
		try {
			int randNo = CommonUtils.generateRamdomNumberForGivenRange(1, 1000000000);
			lastNameInput = lastNameInput + "_" + randNo;
			boolean fieldIsPresent = WebAction.isDisplayed(txtBoxLastName);
			String LastNameLen = WebAction.getText(txtBoxLastName);
			if (fieldIsPresent) {
				if (LastNameLen.length() == 0 && profileType.equalsIgnoreCase("No")) {
					ProxyConstants.setLastName(lastNameInput);
					ProxyConstants.setFullName(ProxyConstants.getFirstName() + " " + ProxyConstants.getLastName());
					WebAction.sendKeys(txtBoxLastName, lastNameInput);
				} else if (LastNameLen.length() == 0 && profileType.equalsIgnoreCase("Yes")) {
					ProxyConstants.setsecondProfileLastName(lastNameInput);
					WebAction.sendKeys(txtBoxLastName, lastNameInput);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To set Expertise drop down
	 *
	 * @throws Exception
	 */

	public void setExpertise(String expValue) throws Exception {
		WebAction.clickUsingJs(expertiseDropDown);
		ProxyConstants.setExpertise(expValue);
		try {
			if (expValue != null) {
				WebAction.selectDropDown(expertiseInputBox, expValue, dropDownValuesXpath, listDropDownValues,
						"'" + expValue + "' value is not present in expertise drop down field");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To set Expertise drop down
	 *
	 * @throws Exception
	 */

	public void setExpertiseDropDown(String expValue) throws Exception {
		WebAction.clickUsingJs(expertiseDropDown);
		try {
			if (expValue != null) {
				WebAction.selectDropDown(expertiseInputBoxTwo, expValue, dropDownValuesXpath, listDropDownValues,
						"'" + expValue + "' value is not present in expertise drop down field");
			}
			// WebAction.clickUsingJs(jobNotesField);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Enter Job Notes for Proxy profile
	 * 
	 * @throws Exception
	 */
	public void fillJobNotes(String inputJobNote) throws Exception {
		ProxyConstants.setProxyJobNotes(inputJobNote);
		boolean fieldIsPresent = WebAction.isDisplayed(jobNotesField);
		try {
			if (fieldIsPresent) {
				WebAction.sendKeys(jobNotesField, inputJobNote);
			} else
				throw new Exception("Job Notes field is not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Select the Affiliated companies
	 * 
	 * @throws Exception
	 */

	public void selectAffilifatedCompanies(String value) throws Exception {
		boolean isFieldPresent = WebAction.isDisplayed(searchCompaniesSugBox);
		try {
			if (isFieldPresent) {
				String companyName = "";
				if (CompanyProfileConstants.getCompanyName() != null)
					companyName = CompanyProfileConstants.getCompanyName();
				else
					companyName = value;
				ProxyConstants.setAffiliatedCompanies(companyName);
				WebAction.clickUsingJs(searchCompaniesSugBox);
				WebAction.selectNonTitleDropDown(searchCompaniesSugBox, companyName, compDropDownValuesXpath,
						compSuggestion, "'" + companyName + "' is not present in search suggestion drop down");

			} else
				throw new Exception("Search Affifliated company search field is missing");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To enter Multiple Phone number in contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void fillPhoneNumberDetails(String Phone1, String Phone2, String Phone3, String Phone4) throws Exception {
		try {

			ProxyConstants.setProxyPhone0(Phone1);
			ProxyConstants.setProxyPhone1(Phone2);
			ProxyConstants.setProxyPhone2(Phone3);
			ProxyConstants.setProxyPhone3(Phone4);

			WebAction.clickUsingJs(phoneNo0);
			WebAction.sendKeys(phoneNo0, Phone1);
			WebAction.clickUsingJs(phoneNo1);
			WebAction.sendKeys(phoneNo1, Phone2);
			WebAction.clickUsingJs(phoneNo2);
			WebAction.sendKeys(phoneNo2, Phone3);
			WebAction.clickUsingJs(phoneNo3);
			WebAction.sendKeys(phoneNo3, Phone4);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To enter Multiple Email id's in contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void fillEmailDetails(String Email1, String Email2, String Email3, String Email4) throws Exception {
		try {

			ProxyConstants.setProxyEmail0(Email1);
			ProxyConstants.setProxyEmail1(Email2);
			ProxyConstants.setProxyEmail2(Email3);
			ProxyConstants.setProxyEmail3(Email4);

			// WebAction.scrollIntoView(phoneLabelText);
			WebAction.clickUsingJs(email0);
			WebAction.sendKeys(email0, Email1);
			WebAction.clickUsingJs(email1);
			WebAction.sendKeys(email1, Email2);
			WebAction.clickUsingJs(email2);
			WebAction.sendKeys(email2, Email3);
			WebAction.clickUsingJs(email3);
			WebAction.sendKeys(email3, Email4);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To enter other social links in contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void fillSocialMiscDetails(String other1, String other2, String other3, String other4) throws Exception {
		try {

			ProxyConstants.setProxyTwitter(other1);
			ProxyConstants.setProxyLinkedIn(other2);
			ProxyConstants.setProxyVideo(other3);
			ProxyConstants.setProxyWebsite(other4);

			// WebAction.scrollIntoView(phoneLabelText);
			WebAction.clickUsingJs(other0);
			WebAction.sendKeys(other0, other1);
			WebAction.clickUsingJs(otherfield1);
			WebAction.sendKeys(otherfield1, other2);
			WebAction.clickUsingJs(otherfield2);
			WebAction.sendKeys(otherfield2, other3);
			WebAction.clickUsingJs(otherfield3);
			WebAction.sendKeys(otherfield3, other4);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To enter Address details in contact info section
	 * 
	 * @throws Exception
	 */
	public void fillAddressDetails(String address1, String address2, String city, String state, String zip,
			String country) throws Exception {

		ProxyConstants.setProxyField1(address1);
		ProxyConstants.setProxyField2(address2);
		ProxyConstants.setAddressCityField(city);
		ProxyConstants.setAddressStateField(state);
		ProxyConstants.setAddressZipField(zip);
		ProxyConstants.setAddressCountryField(country);

		try {
			WebAction.scrollIntoView(addressLabel);
			WebAction.sendKeys(addressLine1, address1);
			WebAction.sendKeys(addressLine2, address2);
			WebAction.sendKeys(addressCity, city);
			if (state != null) {
				WebAction.selectDropDown(addressState, state, dropDownValuesXpath, dropDownValues,
						"'" + state + "' value is not present in the drop down");
			}
			WebAction.sendKeys(addressZip, zip);
			if (country != null) {
				WebAction.selectDropDown(addressCountry, country, dropDownValuesXpath, dropDownValues,
						"'" + country + "' value is not present in the drop down");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To enter Alerts in contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void fillAlertsDetails(String alertInfo) throws Exception {
		try {
			ProxyConstants.setProxyAlerts(alertInfo);
			WebAction.sendKeys(alertsDetails, alertInfo);
			// Thread.sleep(5000);
			WebAction.click(additionalContactTextBox);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select the Proxy Contacts for the Additional Contacts
	 * 
	 * @throws Exception
	 * 
	 */
	@FindBy(xpath = "//div[contains(@class,'ant-select-dropdown-placement-topLeft')]//div[@class='rc-virtual-list-holder-inner']")
	WebElement checkListBox;

	@FindBy(xpath = "//div[contains(@class,'ant-select-dropdown ant-select-dropdown-placement-topLeft')]/descendant::div[@class='ant-select-item-option-content']")
	List<WebElement> registerWebElements2;

	public void additionalContacts(DataTable params) throws Exception {
		try {
			// To scroll into additional contact field
			WebAction.scrollIntoView(additionalContactTextBox);

			String createdProfileProfileFullName = ProxyConstants.getFullName();
			List<Map<String, String>> proxyProfileNames = CucumberUtils.getValuesFromDataTableAsList(params);

			// To add proxy contact which created
			if (createdProfileProfileFullName != null) {
				int previousProxyContactCount = additionalContactPlaceholder.size();
				WebAction.selectDropDown(additionalContactTextBox, createdProfileProfileFullName, dropDownvaluesXpath,
						dropDownvalues, "'" + createdProfileProfileFullName
								+ "' contact is not present in additional contacts drop down");
				previousProxyContactCount = previousProxyContactCount + 1;
				Assert.assertEquals(proxyProfileNames.size(), previousProxyContactCount,
						"contact '" + createdProfileProfileFullName + "' is not added in additional contact");
			}
			// To add search and add proxy contact
			else if (proxyProfileNames.size() > 0) {
				for (int i = 0; i < proxyProfileNames.size(); i++) {
					int previousProxyContactCount = additionalContactPlaceholder.size();
					String proxyProfileName = proxyProfileNames.get(i).get("Proxy contact");
					ProxyConstants.setGuestContacts(proxyProfileName);

					// To select search and select proxy contact
					boolean valuePresent = false;
					WebAction.sendKeys_WithoutClear(additionalContactTextBox, proxyProfileName);
					Waits.waitUntilElementSizeGreater(By.xpath(additionalDropDownvaluesXpath), 0);
					Thread.sleep(800);
					for (WebElement ele : additionalDropDownvalues) {
						String values = WebAction.getText(ele).trim();
						System.out.println("**value**:" + values);
						if (values.contains(proxyProfileName)) {
							WebAction.click(ele);
							valuePresent = true;
							break;
						}
					}

					if (valuePresent == false)
						throw new Exception(
								"'" + proxyProfileName + "' contact is not present in additional contacts drop down");

					// To validate proxy contact is added
					previousProxyContactCount = previousProxyContactCount + 1;
					Assert.assertEquals(additionalContactPlaceholder.size(), previousProxyContactCount,
							" contact '" + proxyProfileName + "' is not added in additional contact");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Adding Guest Contact Card details in Proxy
	 */
	@FindBy(xpath = "(//ul[@class='styles__details__ezmjm']//span)")
	List<WebElement> contactCardDetails;

	@FindBy(xpath = "//section[@class='styles__contacts__AH3U4']/div")
	WebElement scrollInGuestContactCard;

	public void getGuestContactCardDetails() throws Exception {
		WebAction.scrollIntoView(scrollInGuestContactCard);
		// Thread.sleep(5000);
		Waits.waitForElement(scrollInGuestContactCard, WAIT_CONDITIONS.CLICKABLE);
		try {
			int size = contactCardDetails.size();
			System.out.println("Values of Span in the card is::" + size);
			String[] noOfValues = new String[size];
			for (int i = 0; i < size; i++) {
				noOfValues[i] = WebAction.getText(contactCardDetails.get(i)).trim();
				System.out.println("<><><><>" + noOfValues[1]);
				System.out.println("<><><><><><>" + noOfValues[2]);
			}
			ProxyConstants.setGuestJobTitleInTheCard(noOfValues[1]);
			ProxyConstants.setGuestOrgDivision(noOfValues[2]);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click Create button once entering all fields
	 * 
	 * @throws Exception
	 */
	public void clickButton(String buttonType) throws Exception {
		try {
			switch (buttonType.toUpperCase()) {
			case "CREATE":
				WebAction.click(createProxyButton);
				Waits.waitForElementToDisappear(createProxyButton);
				Waits.waitUntilElementSizeGreater(editButton, 0);
				Waits.waitForElement(editButton.get(0), WAIT_CONDITIONS.CLICKABLE);
				break;
			case "ADD JOB":
				WebAction.click(addJobRHButton);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Job Info page displayed
	 * 
	 * @throws Exception
	 */

	public void verifyJobInfoPage() throws Exception {
		try {
			String pageName = WebAction.getText(jobHistoryTxt);
			if (pageName.trim().equalsIgnoreCase("Job History"))
				;
			else
				throw new Exception("Job Info page not loaded");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * User clicking "+ Add Job" button
	 * 
	 */
	public void clickingAddJobButton() throws Exception {
		try {
			boolean buttonIsPresent = WebAction.isDisplayed(addJobButton);
			if (buttonIsPresent) {
				WebAction.click(addJobButton);

			} else
				throw new Exception("Add Job button not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Job Status as Active by default in ant drawer
	 * 
	 **/
	public void statusRadioButton() throws Exception {
		// boolean statusBtn = WebAction.isDisplayed(defEnabledStatus);
		try {
			String value = WebAction.getText(defEnabledStatus);
			if (value.equalsIgnoreCase("Active"))
				;
			else
				throw new Exception("Inactive radio button is enabled");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill the Start Date for Active Job
	 * 
	 * @throws Exception
	 */
	public void fillStartDate(String startDate) throws Exception {
		ProxyConstants.setJobStartDate(startDate);
		try {
			WebAction.click(inputFieldStartDate);
			WebAction.sendKeys(inputFieldStartDate, startDate);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill Job title for Active Job
	 * 
	 * @throws Exception
	 */
	public void enterJobTitle(String jobTitle) throws Exception {
		ProxyConstants.setJobTitle(jobTitle);
		boolean isEditable = WebAction.isDisplayed(enteringJobTitle);
		try {
			if (isEditable) {
				WebAction.sendKeys(enteringJobTitle, jobTitle);
			} else
				throw new Exception("Job title field is not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Enter the Job Department & Job Notes
	 * 
	 * @throws Exception
	 */
	public void enterJobDetails(String sectionName, String inputValue) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "DEPARTMENT":
			try {
				ProxyConstants.setJobDepartment(inputValue);

				boolean isFieldShown = WebAction.isDisplayed(jobDepartment);
				if (isFieldShown) {
					WebAction.sendKeys(jobDepartment, inputValue);
				} else
					throw new Exception("Department field is not displayed");
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
			break;

		case "JOB NOTES":
			try {
				ProxyConstants.setJobNotes(inputValue);

				boolean isFieldShown = WebAction.isDisplayed(jobNotes);
				if (isFieldShown) {
					WebAction.sendKeys(jobNotes, inputValue);
				} else
					throw new Exception("Job Notes Text area is not displayed");
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
			break;
		}
	}

	/**
	 * After creating lead proxy profile verify the view page
	 */
	@FindBy(xpath = "//div[@data-id='page-header']//li[@class='header__name__P_v1F']")
	WebElement profileName;

	public void verifyViewPage() throws Exception {
		Waits.waitForElement(basicInfoTab, WAIT_CONDITIONS.CLICKABLE);
		String proxyName = WebAction.getText(profileName);
		ProxyConstants.setFullName(ProxyConstants.getFirstName() + " " + ProxyConstants.getLastName());
		System.out.println("Lead Profile Full Name is::" + ProxyConstants.getFullName());
		if (proxyName.equalsIgnoreCase(ProxyConstants.getFullName())) {
			System.out.println("Profile Page is displayed:: " + proxyName);
		} else {
			System.out.println();
			throw new Exception("Create profile page is not displayed");
		}
	}

	/**
	 * Click Merge button in Lead proxy profile view page
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "(//span[text()='Merge'])[1]")
	WebElement mergeButton;

	public void mergeButtonClicking() throws Exception {
		Waits.waitForElement(basicInfoTab, WAIT_CONDITIONS.CLICKABLE);
		boolean isPresent = WebAction.isDisplayed(mergeButton);
		if (isPresent) {
			WebAction.clickUsingJs(mergeButton);
		} else
			throw new Exception("Failed to click merge button in view proxy profile page");
	}

	/**
	 * Verify the Merge Screen for Proxy Profile's
	 */
	@FindBy(xpath = "//div[@class='styles__text__nWoQ6']/button")
	WebElement lastModifiedRow;
	@FindBy(xpath = "//span[text()=' Add Proxy Profile']")
	WebElement proxyProfileButton;

	public void viewLeadProxyProfileInMergeScreen() throws Exception {
		try {
			Waits.waitForElement(lastModifiedRow, WAIT_CONDITIONS.CLICKABLE);
			String buttonName = WebAction.getText(proxyProfileButton);
			if (buttonName.contains("Proxy")) {
				System.out.println("Proxy Profile Merge screen is loaded");
			} else
				throw new Exception("Failed to load proxy profile merge screen");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Lead profile in Merge Table
	 */
	@FindBy(xpath = "//div[@class='styles__cell__ulgDd']/span")
	WebElement leadProxyProfileName;

	public void leadProxyProfileInTable() {
		try {
			String LeadProfileName = WebAction.getText(leadProxyProfileName);
			if (LeadProfileName.equalsIgnoreCase(ProxyConstants.getFullName())) {
				System.out.println("Lead Profile Name matched with created proxy profile");
			} else
				System.out.println("Loaded profile is not matched with created lead profile");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click "Add proxy Profile" Dynamic button
	 */
	@FindBy(xpath = "//div[@class='styles__tableHeader__kCuRC']/button")
	WebElement addProxyProfileBtn;
	@FindBy(xpath = "//div[@class='ant-drawer-title']")
	WebElement addProfileRHDrawer;

	public void clickingAddProfileButton() throws Exception {
		try {
			boolean isPresent = WebAction.isEnabled(addProxyProfileBtn);
			if (isPresent) {
				WebAction.clickUsingJs(addProxyProfileBtn);
				Waits.waitForElement(addProfileRHDrawer, WAIT_CONDITIONS.VISIBLE);
				String drawerText = WebAction.getText(addProfileRHDrawer);
				System.out.println("Add proxy Profile RH drawer is" + drawerText);
			} else
				System.out.println("Failed to display the RH drawer after clicking button in the table");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Adding Secondary Proxy profile to merge table
	 */
	@FindBy(xpath = "//input[@placeholder='Search']")
	WebElement searchButton;
	@FindBy(xpath = "//span[@class='styles__truncated__MUNON']")
	WebElement selectSecondaryProfile;
	@FindBy(xpath = "//span[text()='Profile']")
	WebElement rhDrawerProfileBtn;
	@FindBy(xpath = "//button[span[text()='Merge']]")
	WebElement btnMerge;

	public void addSecondaryProxyProfileInTable() throws Exception {
		try {
			boolean isPresent = WebAction.isDisplayed(addProfileRHDrawer);
			if (isPresent) {
				ProxyConstants.setsecondProfileFullName(
						ProxyConstants.getsecondProfileFirstName() + " " + ProxyConstants.getsecondProfileLastName());
				String secondaryProfileName = ProxyConstants.getsecondProfileFullName();
				System.out.println("Secondary Profile Name is:: " + ProxyConstants.getsecondProfileFullName());
				WebAction.sendKeys(searchButton, secondaryProfileName);
				WebAction.clickUsingJs(selectSecondaryProfile);
				WebAction.clickUsingJs(rhDrawerProfileBtn);
				Thread.sleep(1000);
				Waits.waitForElement(btnMerge, WAIT_CONDITIONS.CLICKABLE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Add Proxy Profile Button is disabled
	 */

	@FindBy(xpath = "//button[@class='ant-btn ant-btn-default']")
	WebElement addProfileButtonDisabled;

	public void disableAddProfileButton() {
		boolean isDisabled = WebAction.isEnabled(addProfileButtonDisabled);
		if (!isDisabled) {
			System.out.println("Lead & Secondary Proxy Profile are added in Merge Screen");
		} else
			System.out.println("Secondary profile is not added in merge screen");
	}

	/**
	 * Verify Proxy Profile Page after creating one
	 * 
	 * @throws Exception
	 */

	public void viewNewlyCreatedProxyProfilePage() throws Exception {
		Waits.waitForElement(basicInfoTab, WAIT_CONDITIONS.CLICKABLE);
	}

	/**
	 * Verify "Change" button in Merge Page
	 */
	@FindBy(xpath = "//button[@class='styles__changeBtn__Py36m']")
	WebElement changeBtn;

	public void isChangeOptionPresent(String btnName) {
		boolean isBtnPresent = WebAction.isDisplayed(changeBtn);
		try {
			if (isBtnPresent) {
				String optionName = WebAction.getText(changeBtn);
				while (btnName.equalsIgnoreCase(optionName)) {
					System.out.println("Button is Present in the Lead Profile");
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify "Remove" button in Merge Page
	 */
	@FindBy(xpath = "//button[@class='styles__removeBtn___el0L']")
	WebElement removeBtn;

	public void isRemoveOptionPresent(String btnName) {
		boolean isBtnPresent = WebAction.isDisplayed(removeBtn);
		try {
			if (isBtnPresent) {
				String optionName = WebAction.getText(removeBtn);
				while (btnName.equalsIgnoreCase(optionName)) {
					System.out.println("Button is Present in the Secondary Profile");
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify "Edit icon" in all fields of Lead Profile
	 */
	@FindBy(xpath = "//span[@class='anticon anticon-edit']")
	List<WebElement> editIcon;
	@FindBy(xpath = "//tbody//tr")
	List<WebElement> noOfRows;

	public void isEditOptionPresent() {
		try {
			int editIconSize = editIcon.size();
			int rowSize = noOfRows.size() - 1;
			if (editIconSize == rowSize) {
				System.out.println("Edit icon is present in all fields of Lead Profile");
			} else {
				System.out.println("Edit icon mismatch with table rows");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Switch LastName from Secondary profile to Lead Profile
	 */
	@FindBy(xpath = "(//th[text()='Last Name']/following-sibling::td[2]//div)[2]")
	WebElement secondaryProfileLastName;

	@FindBy(xpath = "(//th[text()='Last Name']/following-sibling::td[2]//span)[1]")
	WebElement lastNameRadioBtn;

	@FindBy(xpath = "//th[text()='Last Name']/following-sibling::td[1]//div[2]")
	WebElement lastNameInLeadProfile;

	@FindBy(xpath = "//tbody//th")
	List<WebElement> formOptionsRow;

	String correspondingRowEditIcon = "//th[text()='<<value>>']/following-sibling::td[1]//button";

	String correspondingRowRadioBtn = "(//th[text()='<<text value>>']/following-sibling::td[2]//span)[1]";

	String correspondingFieldLeadProfile = "//th[text()='<<Lead Profile>>']/following-sibling::td[1]//div[2]";

	String correspondingFieldSecondaryProfile = "(//th[text()='<<Secondary Profile>>']/following-sibling::td[2]//div)[2]";

	public void updateLastNameInLeadProfile() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		WebAction.scrollIntoView(secondaryProfileLastName);
		String secondaryFieldName = null, leadFieldName = null;
		try {
			int rowSize = formOptionsRow.size();
			for (int i = 0; i < rowSize; i++) {
				String lastRowName = WebAction.getText(formOptionsRow.get(i)).trim();
				System.out.println("Checking every rows from the form options:: " + lastRowName);
				if (lastRowName.contains("Last Name")) {
					String finRowName = lastRowName.replace("* ", "");
					correspondingRowEditIcon = correspondingRowEditIcon.replace("<<value>>", finRowName);
					WebAction.scrollIntoView(driver.findElement(By.xpath(correspondingRowEditIcon)));
					correspondingRowRadioBtn = correspondingRowRadioBtn.replace("<<text value>>", finRowName);
					WebAction.clickUsingJs(driver.findElement(By.xpath(correspondingRowRadioBtn)));
					correspondingFieldLeadProfile = correspondingFieldLeadProfile.replace("<<Lead Profile>>",
							finRowName);
					correspondingFieldSecondaryProfile = correspondingFieldSecondaryProfile
							.replace("<<Secondary Profile>>", finRowName);
					secondaryFieldName = WebAction
							.getText(driver.findElement(By.xpath(correspondingFieldSecondaryProfile)));
					leadFieldName = WebAction.getText(driver.findElement(By.xpath(correspondingFieldLeadProfile)));
					System.out.println("Lead Profile Last Name after changed-> " + leadFieldName);
					System.out.println("Secondary Profile Last Name-> " + secondaryFieldName);
					ProxyConstants.setLastName(leadFieldName.trim());
					break;
				}
			}
			while (secondaryFieldName.equalsIgnoreCase(leadFieldName)) {
				System.out.println("LastName from secondary Profile moved to LastName of Lead Profile");
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Update the Expertise tags for the lead profile using Edit option
	 */
	@FindBy(xpath = "//th[text()='Expertise']/following-sibling::td[1]//button")
	WebElement expertiseEditIcon;

	@FindBy(xpath = "//span[@class='ant-select-selection-item-content']")
	WebElement clickExpertiseField;

	@FindBy(xpath = "//div[@class='ant-select-selection-search']/input")
	WebElement expertiseInputField;

	String expertiseDropDownValues = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> listOfExpertiseDropDownValues;

	@FindBy(xpath = "//th[text()='Expertise']/following-sibling::td[1]//div[@class='styles__text__nWoQ6']")
	WebElement addedExpertiseTags;

	public void updateExpertiseTags(String expValue) throws Exception {
		// WebAction.scrollIntoView(expertiseEditIcon);

		try {
			WebAction.clickUsingJs(expertiseEditIcon);
			Thread.sleep(1000);
			WebAction.clickUsingJs(clickExpertiseField);

			if (expValue != null) {

				// WebAction.sendKeys(expertiseInputField, "BITCOIN");

				WebAction.selectDropDown(expertiseInputField, expValue, expertiseDropDownValues,
						listOfExpertiseDropDownValues,
						"'" + expValue + "' value is not present in expertise drop down field");

				WebAction.click(expertiseEditIcon);
				String updatedExpertiseTags = WebAction.getText(addedExpertiseTags);
				ProxyConstants.setExpertise(updatedExpertiseTags);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click Merge button after updating lead profile
	 */
	@FindBy(xpath = "//button[span[text()='Merge']]")
	WebElement mergeBtn;

	public void mergeProfiles() throws Exception {
		WebAction.clickUsingJs(mergeBtn);
	}

	/**
	 * Click OK button Merge profile pop-up
	 */
	@FindBy(xpath = "//button[span[text()='Ok']]")
	WebElement okBtn;

	public void clickOK() throws Exception {
		WebAction.clickUsingJs(okBtn);
		Waits.waitForElement(basicInfoTab, WAIT_CONDITIONS.CLICKABLE);
	}

	/**
	 * Verify the Lead Proxy Profile page after success merge
	 * 
	 * @throws Exception
	 */
	public void verifyLeadProfilePage() throws Exception {
		Waits.waitForElement(basicInfoTab, WAIT_CONDITIONS.CLICKABLE);
	}

	/**
	 * Verify the LastName of Lead Proxy profile after success merge
	 * 
	 * @throws Exception
	 */
	public void verifyLastNameInLeadProxyProfilePage() throws Exception {
		String proxyName = WebAction.getText(profileName);
		String updatedProxyName = ProxyConstants.getLastName().trim();
		if (proxyName.contains(updatedProxyName)) {
			System.out.println("Lead Proxy Profile updated name is ::" + " " + proxyName);
		} else {
			throw new Exception("Lead profile lastname got mismatched");
		}
	}

	/**
	 * Verify the Expertise tags of Lead Proxy profile after success merge
	 */
	@FindBy(xpath = "//ul[@class='styles__list__l7x6j']/li")
	List<WebElement> expertiseTagList;

	public void verifyExpertiseTagsInLeadProxyProfilePage() throws Exception {
		String expTags;
		StringBuffer sb = new StringBuffer();
		String expertiseFromMergeScreen = ProxyConstants.getExpertise().trim();
		try {
			int tagSize = expertiseTagList.size();
			for (int i = tagSize - 1; 0 <= i; i--) {
				String tagsName = WebAction.getText(expertiseTagList.get(i));
				sb = sb.append(tagsName + ", ");

			}
			// sb.deleteCharAt(sb.length()-1);
			expTags = sb.toString().trim();
			expTags = expTags.substring(0, expTags.length() - 1);

			System.out.println("In View Page---> " + expTags);
			System.out.println("In Merge Page---> " + expertiseFromMergeScreen);
			if (expTags.trim().equalsIgnoreCase(expertiseFromMergeScreen)) {
				System.out.println(expTags + "<-- Updated Expertise tags are-->" + ProxyConstants.getExpertise());
			} else {
				throw new Exception("Failed to displayed the updated expertise in Lead proxy profile");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Proxy Profile Name is displayed in Header
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "//div[@data-id='page-header']//li[@class='header__name__P_v1F']")
	WebElement viewPageProxyProfileName;

	public void verifyProfilePageAfterCreating() throws Exception {
		Waits.waitForElement(basicInfoTab, WAIT_CONDITIONS.CLICKABLE);
		String proxyProfileName = "";
		try {
			if (ProxyConstants.getDisplayName() != null)
				proxyProfileName = ProxyConstants.getDisplayName();
			else
				proxyProfileName = ProxyConstants.getFullName();
			CommonValidations.verifyTextValue(viewPageProxyProfileName, proxyProfileName,
					"Profile profile name in header is not matching");
			System.out.println("Proxy Profile Name is Verified successfully");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Job Title is displayed in Header
	 */
	@FindBy(xpath = "//div[@data-id='page-header']//li[@class='header__title__EErbo']")
	WebElement verifyPageJobTitle;

	public void verifyJobTitleInHeader() {
		String JobTitle = ProxyConstants.getJobTitle();
		try {
			CommonValidations.verifyTextValue(verifyPageJobTitle, JobTitle,
					"Profile profile job title in header is not matching");
			System.out.println("Proxy Profile user Job Title is Verified Successfully");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Company Name is displayed in Header
	 */
	@FindBy(xpath = "//ul[@class='header__details__NssiA']/li[3]")
	WebElement verifyCompanyName;

	public void verifyCompanyNameInHeader() {
		String companyName = ProxyConstants.getJobOrganization();
		try {
			CommonValidations.verifyTextValue(verifyCompanyName, companyName,
					"Profile profile company name in header is not matching");
			System.out.println("Proxy Profile user Company Name is Verified Successfully");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the header icons in Page header of view proxy profile
	 */
	@FindBy(xpath = "//li[span[text()='Edit']]")
	List<WebElement> editButton;

	@FindBy(xpath = "//li[span[text()='History']]")
	List<WebElement> historyButton;

	@FindBy(xpath = "//li[span[text()='Share']]")
	List<WebElement> shareButton;

	@FindBy(xpath = "//li[span[text()='Copy']]")
	List<WebElement> copyButton;

	@FindBy(xpath = "//li[span[text()='Merge']]")
	List<WebElement> mergeButtonList;

	public void headerIconsInProxyProfile(String headButton, DataTable params) throws Exception {
		try {
			List<Map<String, String>> headerButtons = CucumberUtils.getValuesFromDataTableAsList(params);
			for (int i = 0; i < headerButtons.size(); i++) {
				String buttonName = headerButtons.get(i).get("HeadButton");
				switch (buttonName.toUpperCase()) {
				case "EDIT":
					Assert.assertTrue(WebAction.isDisplayed(editButton.get(0)),
							"Edit button is missing in company profile header");
					break;
				case "SHARE":
					Assert.assertTrue(WebAction.isDisplayed(shareButton.get(0)),
							"Share button is missing in company profile header");
					break;
				case "COPY":
					Assert.assertTrue(WebAction.isDisplayed(copyButton.get(0)),
							"Copy button is missing in company profile header");
					break;
				case "HISTORY":
					Assert.assertTrue(WebAction.isDisplayed(historyButton.get(0)),
							"History button is missing in company profile header");
					break;
				case "MERGE":
					Assert.assertTrue(WebAction.isDisplayed(mergeButtonList.get(0)),
							"Merge button is missing in company profile header");
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Basic Info tab is enabled
	 */
	@FindBy(xpath = "//span[text()='Basic Info']")
	WebElement basicButton;

	public void defEnabledTab() throws Exception {
		try {
			boolean tabBasic = WebAction.isDisplayed(basicButton);
			if (tabBasic) {
				WebAction.click(basicButton);
			} else {
				throw new Exception("Basic Info button not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Background section is displayed
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "//span[text()='Background']")
	WebElement backgroundSectionText;

	public void backgroundIsDisplayed() throws Exception {
		try {
			String sectionName = WebAction.getText(backgroundSectionText).trim();
			if (sectionName.length() == 0)
				throw new Exception("Background section name not displayed");
			else
				System.out.println("Section name is displayed " + sectionName);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Job Notes in Background section
	 */
	@FindBy(xpath = "//h3[text()='Job Notes']")
	WebElement sectionHeaderTxt;

	@FindBy(xpath = "//section[@class='styles__section__aeGXf']/p")
	WebElement contentTxt;

	public void verifyProxyJobNotes() {
		boolean isPresent = WebAction.isDisplayed(sectionHeaderTxt);
		try {
			if (isPresent) {
				String notesValue = WebAction.getText(contentTxt).trim();
				String value = ProxyConstants.getJobNotes();
				CommonValidations.verifyTextValue(contentTxt, value, "Proxy profile job notes is not matching");
				System.out.println("Job Notes present in the background section");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Expertise in Background section
	 */
	@FindBy(xpath = "//h3[text()='Expertise']")
	WebElement sectionHeadsTxt;

	@FindBy(xpath = "//ul[@class='styles__list__l7x6j']//li")
	WebElement expertiseList;

	public void verifyProxyExpertise() {
		boolean isPresent = WebAction.isDisplayed(sectionHeadsTxt);
		try {
			if (isPresent) {
				String tags = ProxyConstants.getExpertise();
				String expTags = WebAction.getText(expertiseList).trim();
				CommonValidations.verifyTextValue(expertiseList, expTags,
						"Proxy profile expertise tags are not matching");
				System.out.println("Expertise tags are present in the background section");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Job Alerts in Background section
	 */
	@FindBy(xpath = "//p[text()='Alerts']")
	WebElement alertsTxt;

	@FindBy(xpath = "//span[@class='styles__text__kFxzp']")
	WebElement alertsContent;

	public void verifyProxyAlerts() {
		boolean isPresent = WebAction.isDisplayed(alertsTxt);
		try {
			if (isPresent) {
				String value = WebAction.getText(alertsContent).trim();
				String proxyAlerts = ProxyConstants.getProxyAlerts();
				CommonValidations.verifyTextValue(alertsContent, value, "Proxy profile alert content is not matching");
				System.out.println("Alerts are present in the background section");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Phone numbers from contact info section
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "//div[@class='styles__tabs__Bj89H']/descendant::li/span")
	List<WebElement> verifyTab;

	@FindBy(xpath = "//div[@class='styles__content__lpxOO']//tr")
	List<WebElement> contactInfoTable;

	@FindBy(xpath = "//div[@class='styles__content__lpxOO']//tr//td[2]")
	List<WebElement> contactInfoTableData;

	public void verifyPhoneNumbers() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String phoneTabDate1 = ProxyConstants.getProxyPhone0();
		String phoneTabDate2 = ProxyConstants.getProxyPhone1();
		String phoneTabDate3 = ProxyConstants.getProxyPhone2();
		String phoneTabDate4 = ProxyConstants.getProxyPhone3();
		List<String> phoneNumbers = new ArrayList<String>();

		try {
			boolean phoneTab = WebAction.isDisplayed(verifyTab.get(0));
			WebAction.clickUsingJs(verifyTab.get(0));
			if (phoneTab) {
				int tableSize = contactInfoTable.size();
				Outer: for (int i = 0; i < tableSize; i++) {
					int tableDataSize = contactInfoTableData.size();
					for (int j = 0; j < tableDataSize; j++) {
						String xpath = "//div[@class='styles__content__lpxOO']//tr[" + (i + 1) + "]//td[" + (j + 2)
								+ "]";
						By value = By.xpath(xpath);
						String phone = driver.findElement(value).getText();
						phoneNumbers.add(phone);
						continue Outer;
					}
				}
			}
			if (phoneTabDate1.equalsIgnoreCase(phoneNumbers.get(0))
					&& phoneTabDate2.equalsIgnoreCase(phoneNumbers.get(1))
					&& phoneTabDate3.equalsIgnoreCase(phoneNumbers.get(2))
					&& phoneTabDate4.equalsIgnoreCase(phoneNumbers.get(3)))
				;
			else {
				Assert.assertFalse(false, "Phone numbers not matched in view page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Email Address from contact info section
	 * 
	 * @throws Exception
	 */
	public void verifyEmailIds() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String emailTabData1 = ProxyConstants.getProxyEmail0();
		String emailTabData2 = ProxyConstants.getProxyEmail1();
		String emailTabData3 = ProxyConstants.getProxyEmail2();
		String emailTabData4 = ProxyConstants.getProxyEmail3();

		List<String> noOfEmailIds = new ArrayList<String>();
		try {
			boolean emailTab = WebAction.isDisplayed(verifyTab.get(1));
			WebAction.clickUsingJs(verifyTab.get(1));
			if (emailTab) {
				int tableSize = contactInfoTable.size();
				Outer: for (int i = 0; i < tableSize; i++) {
					int tableDataSize = contactInfoTableData.size();
					for (int j = 0; j < tableDataSize; j++) {
						String xpath = "//div[@class='styles__content__lpxOO']//tr[" + (i + 1) + "]//td[" + (j + 2)
								+ "]";
						By value = By.xpath(xpath);
						String emailId = driver.findElement(value).getText();
						noOfEmailIds.add(emailId);
						continue Outer;
					}
				}

			}
			if (emailTabData1.equalsIgnoreCase(noOfEmailIds.get(0))
					&& emailTabData2.equalsIgnoreCase(noOfEmailIds.get(1))
					&& emailTabData3.equalsIgnoreCase(noOfEmailIds.get(2))
					&& emailTabData4.equalsIgnoreCase(noOfEmailIds.get(3)))
				;

			else {
				Assert.assertTrue(false, "Email id's are not matched in view page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Others from contact info section
	 * 
	 * @throws Exception
	 */
	public void verfiyOtherLinks() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String twitterTabData1 = ProxyConstants.getProxyTwitter();
		String linkedInTabData2 = ProxyConstants.getProxyLinkedIn();
		String videoTabData3 = ProxyConstants.getProxyVideo();
		String websiteTabData4 = ProxyConstants.getProxyWebsite();

		List<String> otherSocialLinks = new ArrayList<String>();
		try {
			boolean othersTab = WebAction.isDisplayed(verifyTab.get(2));
			WebAction.clickUsingJs(verifyTab.get(2));
			if (othersTab) {
				int tableSize = contactInfoTable.size();
				Outer: for (int i = 0; i < tableSize; i++) {
					int tableDataSize = contactInfoTableData.size();
					for (int j = 0; j < tableDataSize; j++) {
						String xpath = "//div[@class='styles__content__lpxOO']//tr[" + (i + 1) + "]//td[" + (j + 2)
								+ "]";
						By values = By.xpath(xpath);
						String links = driver.findElement(values).getText();
						otherSocialLinks.add(links);
						continue Outer;
					}
				}

			}
			if (videoTabData3.equalsIgnoreCase(otherSocialLinks.get(0))
					&& twitterTabData1.equalsIgnoreCase(otherSocialLinks.get(1))
					&& linkedInTabData2.equalsIgnoreCase(otherSocialLinks.get(2))
					&& websiteTabData4.equalsIgnoreCase(otherSocialLinks.get(3)))
				;
			else {
				Assert.assertTrue(false, "Other Social Links not matched in view page");

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Address tab displayed from contact info section
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "(//ul[@class='ant-menu ant-menu-sub ant-menu-vertical']//span[@class='ant-menu-title-content'])[1]")
	WebElement addressText;

	public void verifyProxyAddressDetails() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String addressField1 = ProxyConstants.getProxyAddressField1();
		String addressField2 = ProxyConstants.getProxyAddressField2();
		String addressCity = ProxyConstants.getProxyCity();
		String addressState = ProxyConstants.getProxyState();
		String addressZip = ProxyConstants.getProxyZip();
		String addressCountry = ProxyConstants.getProxyCountry();
		List<String> addressFields = new ArrayList<String>();
		try {
			String addTxt = WebAction.getText(addressText);
			if (addTxt.length() > 0) {
				int tableSize = contactInfoTable.size();
				Outer: for (int i = 0; i < tableSize; i++) {
					int tableDataSize = contactInfoTableData.size();
					for (int j = 0; j < tableDataSize; j++) {
						String xpath = "//div[@class='styles__content__lpxOO']//tr[" + (i + 1) + "]//td[" + (j + 2)
								+ "]";
						By values = By.xpath(xpath);
						String address = driver.findElement(values).getText();

						addressFields.add(address);
						continue Outer;
					}
				}
			}
			if (addressField1.equalsIgnoreCase(addressFields.get(0))
					&& addressField2.equalsIgnoreCase(addressFields.get(1))
					&& addressCity.equalsIgnoreCase(addressFields.get(2))
					&& addressState.equalsIgnoreCase(addressFields.get(3))
					&& addressZip.equalsIgnoreCase(addressFields.get(4))
					&& addressCountry.equalsIgnoreCase(addressFields.get(5)))
				;
			else {
				Assert.assertTrue(false, "Address not matched in view page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Ellipses in contact info section
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "(//span[@aria-label='ellipsis'])[2]")
	WebElement ellipses;

	@FindBy(xpath = "//span[text()='Address']")
	List<WebElement> contactInfoAdrsTab;

	public void clickingEllipsesTab() throws Exception {
		try {
			boolean isElipsePresent = WebAction.isDisplayed(ellipses);
			if (isElipsePresent)
				WebAction.mouseOver(ellipses);
			Thread.sleep(2000);
			for (WebElement element : contactInfoAdrsTab) {
				if (element.isDisplayed()) {
					WebAction.click(element);
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Companies Tab displayed from contact info section
	 */

	@FindBy(xpath = "//span[text()='Companies']")
	List<WebElement> companiesText;

	@FindBy(xpath = "//div[@class='styles__content__Zc4b8']//li/span")
	List<WebElement> companyDetails;

	public void verifyCompaniesDetails() throws Exception {
		boolean isElipsePresent = WebAction.isDisplayed(ellipses);
		if (isElipsePresent)
			WebAction.mouseOver(ellipses);
		Thread.sleep(1000);
		for (WebElement element : companiesText) {
			if (element.isDisplayed()) {
				WebAction.click(element);
				break;
			}
		}
		int size = companyDetails.size();
		String[] companies = new String[size];
		for (int i = 0; i < size; i++) {
			companies[i] = WebAction.getText(companyDetails.get(i)).trim();
		}
		System.out.println("company Names in Drawer:::" + companies.length);
		String companyName = ProxyConstants.getAffilifatedCompanies();
		if (companyName.equalsIgnoreCase(companies[0])) {
			System.out.println("Company Name displayed successfully" + companies[0]);
		}
	}

	/**
	 * Verify the Proxy Profile Active Roles Job Section
	 */
	@FindBy(xpath = "//span[@class='styles__jobTitle__ws453']")
	WebElement jobTitle;

	@FindBy(xpath = "//div[@class='ant-collapse-content-box']//table[@class='styles__list__wWs5e styles__stacked__YD_pJ']//tr")
	List<WebElement> jobDataTable;

	@FindBy(xpath = "//div[@class='ant-collapse-content-box']//table[@class='styles__list__wWs5e styles__stacked__YD_pJ']//tr//td[2]")
	List<WebElement> jobDataTableValue;

	public void proxyProfileJobRoles() {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String jobStartDate = ProxyConstants.getJobStartDate();
		String jobCategory = ProxyConstants.getJobCategory();
		String jobCompany = ProxyConstants.getJobOrganization();
		String jobDepartment = ProxyConstants.getJobDepartment();
		String jobNotes = ProxyConstants.getJobNotes();

		List<String> jobCardDetails = new ArrayList<>();
		try {
			String jobTleTxt = WebAction.getText(jobTitle).trim();
			if (jobTleTxt.length() > 0) {
				int tableSize = jobDataTable.size();
				Outer: for (int i = 0; i < tableSize; i++) {
					int tableDataSize = jobDataTableValue.size();
					for (int j = 0; j < tableDataSize; j++) {
						String xpath = "//div[@class='ant-collapse-content-box']//table[@class='styles__list__wWs5e styles__stacked__YD_pJ']//tr["
								+ (i + 1) + "]//td[" + (j + 2) + "]";
						By values = By.xpath(xpath);
						String jobDetails = driver.findElement(values).getText();

						jobCardDetails.add(jobDetails);
						continue Outer;
					}
				}
			}
			if (jobStartDate.equalsIgnoreCase(jobCardDetails.get(1))
					&& jobCategory.equalsIgnoreCase(jobCardDetails.get(2))
					&& jobCompany.equalsIgnoreCase(jobCardDetails.get(3))
					&& jobDepartment.equalsIgnoreCase(jobCardDetails.get(4))
					&& jobNotes.equalsIgnoreCase(jobCardDetails.get(5)))
				;
			else {
				Assert.assertTrue(false, "Job section not matched in view page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	/**
	 * Click Contacts tab in view proxy profile page
	 */

	@FindBy(xpath = "//button[span[text()='Contacts']]")
	WebElement contactsTabBtn;

	@FindBy(xpath = "//div[@class='styles__content__kfLJV']")
	WebElement nameInTheCard;

	public void clickContactsTabFromViewProxyProfile() throws Exception {
		Waits.waitForElement(contactsTabBtn, WAIT_CONDITIONS.VISIBLE);
		WebAction.clickUsingJs(contactsTabBtn);
		Waits.waitForElement(nameInTheCard, WAIT_CONDITIONS.CLICKABLE);
	}

	/**
	 * Verify the total count of the guest contact cards in proxy profile
	 */
	@FindBy(xpath = "//span[@class='styles__title__te_dH']")
	WebElement contactsSection;

	@FindBy(xpath = "//div[@class='ant-col ant-col-xs-24 ant-col-sm-24 ant-col-md-12 ant-col-lg-8']")
	List<WebElement> contactCardsTile;

	public void verifyTotalCount() throws Exception {
		boolean isPresent = WebAction.isDisplayed(contactsSection);
		try {
			String value = WebAction.getText(contactsSection).trim();
			int count = Integer.parseInt(value.replaceAll("[\\D]", ""));
			int cardSize = contactCardsTile.size();
			if (count == cardSize) {
				System.out.println(cardSize + " Count gets matched with the guest cards in the tile " + count);
			} else
				throw new Exception(count + " Count get mismatched " + cardSize);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Guest contact cards in the Contacts page of Proxy profile
	 */
	@FindBy(xpath = "//li[@class='styles__line1__IVhRc']//span")
	WebElement guestNameInTheCard;

	public void verifyGuestName() throws Exception {
		try {
			String guestName = ProxyConstants.getGuestContacts();
			String nameValue = WebAction.getText(guestNameInTheCard).trim();
			if (guestName.equalsIgnoreCase(nameValue)) {
				System.out.println("Values matched in the card" + nameValue);
			} else
				throw new Exception("Not matched with the Guest Names in the card" + nameValue);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Guest contact job title in the Contacts page of Proxy profile
	 */
	@FindBy(xpath = "//li[@class='styles__line2__B5W01']//span")
	WebElement guestJobInTheCard;

	public void verifyGuestJob() throws Exception {
		try {
			String guestCompName = ProxyConstants.getGuestJobTitleInTheCard();

			String compValue = WebAction.getText(guestJobInTheCard).trim();
			if (guestCompName.equalsIgnoreCase(compValue)) {
				System.out.println("Guest Job matched in the card " + compValue);
			} else
				throw new Exception("Guest Job Not matched in the card " + compValue);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Guest Company Name in the Contacts page of Proxy profile
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "(//li[@class='styles__line3__zuJAt']//span)")
	WebElement orgDivInTheCard;

	public void verifyGuestCompanyDivision() throws Exception {
		try {
			String guestOrgName = ProxyConstants.getGuestOrgDivision();
			String actualName = WebAction.getText(orgDivInTheCard).trim();
			if (guestOrgName.equalsIgnoreCase(actualName)) {
				System.out.println("Guest Org/Division name matched with the contact card " + actualName);
			} else
				throw new Exception("OrgName / Division not macthed with the contact card" + actualName);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

}
