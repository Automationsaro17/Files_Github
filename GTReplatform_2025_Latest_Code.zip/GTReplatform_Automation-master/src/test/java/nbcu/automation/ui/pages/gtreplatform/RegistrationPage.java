package nbcu.automation.ui.pages.gtreplatform;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;

public class RegistrationPage {

	@FindBy(xpath = "//button//span[@class='anticon anticon-arrow-left']")
	WebElement backButton;

	public RegistrationPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify registration page loaded
	 * 
	 * @throws Exception
	 **/

	public void verifyUserRegistrationPage() throws Exception {
		try {
			Thread.sleep(1000);
			Waits.waitForElement(backButton, WAIT_CONDITIONS.VISIBLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Need to verify the user information based on NCX database
	 **/

	public void userInformation() {
	}

	/**
	 * To verify Registration info section
	 **/

	@FindBy(xpath = "//h3[text() = 'User Information']")
	WebElement userInformationText;

	@FindBy(xpath = "//input[@id='division']/..")
	WebElement divisionSelection;

	public void verifyDivisionSelection() {
		try {
			Thread.sleep(1000);
			WebAction.scrollIntoView(userInformationText);
			Waits.waitForElement(divisionSelection, WAIT_CONDITIONS.VISIBLE);

			if (WebAction.isDisplayed(divisionSelection)) {
				System.out.println("Division Selection dropdown is displayed in the user registraiton page");
			} else
				System.out.println("Failed to displayed the division selection drop down");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * To verify user able to select division from registration info section
	 * 
	 * @throws Exception
	 **/

	@FindBy(xpath = "//input[@id='division']/../following-sibling::span")
	WebElement selectDivision;

	String dropDownValuesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	public void selectionDivision(String division) throws Exception {
		try {
			Waits.waitForElement(selectDivision, WAIT_CONDITIONS.CLICKABLE);
			WebAction.click(selectDivision);
			WebAction.nonEnterebaleSelectDropDown(dropDownValuesXpath, division,
					" ' " + division + " 'value is not present in the division drop down ");

			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select the available shows listed in the User registration screen
	 **/
	@FindBy(xpath = "//span[text()='Available Shows / Clients']")
	WebElement showClientText;

	@FindBy(id = "availableShowsClients")
	WebElement showsClientArea;

	@FindBy(xpath = "//span[text()='Available Shows / Clients']//span")
	WebElement toolTipVerification;

	@FindBy(xpath = "//*[@id='availableShowsClients']//span[@class='ant-checkbox-inner']")
	List<WebElement> selectShowsCheckBox;

	@FindBy(xpath = "//h3[text()= 'Registration Info']")
	WebElement headerPart;

	public void selectShowsCheckBoxes() throws Exception {
		try {
			String areaText = WebAction.getText(showClientText);
			if (areaText.equalsIgnoreCase("Available Shows / Clients")) {
				if (showsClientArea.isDisplayed()) {
					System.out.println("Section area displayed successfully");

					Thread.sleep(1000);

					WebAction.scrollIntoView(headerPart);
					int listOfAvailableShows = selectShowsCheckBox.size();
					System.out.println("sizes are>>>> " + listOfAvailableShows);

					while (listOfAvailableShows != 0) {
						for (int i = 0; i < listOfAvailableShows; i++) {
							WebAction.clickUsingJs(selectShowsCheckBox.get(i));
							Thread.sleep(500);
							System.out.println("CLicking the checkboxes");
						}
						break;
					}
				} else
					System.out.println("Failed to displayed it");
			} else
				System.out.println("Failed to displayed the text itself");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select the approvers as Don't Know for the selected shows
	 */
	@FindBy(xpath = "//label[@for='approvers']/span")
	WebElement approverTextArea;

	@FindBy(xpath = "//*[@id='approvers']//span[@class='ant-checkbox-inner']")
	WebElement selectApprCheckBox;

	public void selectasDontKnow() throws Exception {
		try {
			String apprvTxt = WebAction.getText(approverTextArea);
			if (apprvTxt.equalsIgnoreCase("Approvers")) {
				System.out.println("Approver section displaed Successfully");
				if (selectApprCheckBox.isDisplayed()) {
					WebAction.clickUsingJs(selectApprCheckBox);
					System.out.println("Clicked Show Approver button");
				} else
					System.out.println("Failed to displayed the Approver checkbox");
			} else
				System.out.println("Failed to displayed the Approver section");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * TO select the Agree checkbox present in the registration page
	 */
	@FindBy(xpath = "//*[@id='isAcknowledge']/following-sibling::span")
	WebElement checkBoxAgree;

	public void checkAgreeBox() throws Exception {
		try {
			if (checkBoxAgree.isDisplayed()) {
				System.out.println("I acknowledge check box is displayed");
				WebAction.clickUsingJs(checkBoxAgree);
				System.out.println("I acknowledge checkbox is displayed");
				Thread.sleep(1000);
			} else
				System.out.println("Failed to display the acknowledge checkbox");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Submit button in user registration page
	 */
	@FindBy(xpath = "//button[@type='button']/span")
	WebElement sbtBtn;

	public void clickSubmitBtn() throws Exception {
		try {
			if (sbtBtn.isDisplayed()) {
				System.out.println("Submit is displayed at the bottom os user registration page");
				WebAction.clickUsingJs(sbtBtn);
				System.out.println("Submit button is clicked in the user registration page");
			} else
				System.out.println("Failed to click submit button");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * TO verify the Thanks Confirmation pop-up displayed
	 */

	@FindBy(xpath = "//div[@role='dialog']")
	WebElement confirmationPopUp;

	@FindBy(xpath = "//span[text()='OK']")
	WebElement okBtn;

	public void successPopup() throws Exception {
		try {
			if (confirmationPopUp.isDisplayed()) {
				System.out.println("Thanks Confirmation pop-up is displayed");
				Assert.assertTrue(confirmationPopUp.isDisplayed(),
						"Success pop-up is displayed in the User registration page");
				if (okBtn.isDisplayed()) {
					WebAction.click(okBtn);
					System.out.println("OK button is clicked");
				} else {
					System.out.println("Failed to display the ok button");
				}
			} else
				System.out.println("Failed to displayed the thanks Confirmaiton pop-up");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Registered user logout from the page after success pop-up
	 */

	public void logoutFromRegistrationPage() throws Exception {
		try {
			if (backButton.isDisplayed()) {
				System.out.println("Back Button is displayed in the header");
				WebAction.click(backButton);
				Thread.sleep(1000);

			} else
				System.out.println("Failed to display the back button in user registration page");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Logout Page is displayed
	 */

	@FindBy(xpath = "//div//p[text()='To completely logout of Single Sign On,']")
	WebElement logOutLogo;

	public void sessionLogOutPage() throws Exception {
		try {
			WebAction.switchToFrame("header");
			String text = WebAction.getText(logOutLogo).trim();
			boolean value = text.contains("To completely logout of Single Sign On,");
			Assert.assertTrue(value, "Logout Message should be displayed with NBC Universal logo.");
			System.out.println("Logout message should be displayed.");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;

		}
	}
}
