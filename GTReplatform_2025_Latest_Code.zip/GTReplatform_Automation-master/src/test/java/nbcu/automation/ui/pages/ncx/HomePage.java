package nbcu.automation.ui.pages.ncx;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;

import java.util.List;

public class HomePage {

	/**
	 * Ready Column Elements
	 */

	@FindBy(xpath = "//div[span[text()='Ready']]/following-sibling::div[@class='options']/button[i[@nztype='search']]")
	WebElement readyColumnSearchIcon;

	/**
	 * Working Column Elements
	 */
	@FindBy(xpath = "//div[span[text()='Working']]/following-sibling::div[@class='options']/button[i[@nztype='search']]")
	WebElement workingColumnSearchIcon;

	/**
	 * Collapse/Expand left side menu
	 */
	@FindBy(xpath = "//div[@class='left-side']/button/i")
	WebElement leftSideMenuCollapse;

	/**
	 * Left side menus
	 */
	@FindBy(xpath = "//*[@ng-reflect-nz-title='Support']")
	WebElement supportTab;

	@FindBy(xpath = "//a[contains(text(),' Admin')]")
	WebElement adminTab;

	@FindBy(xpath = "//*[@routerlink='ncx/profile']")
	WebElement profileIcon;

	@FindBy(xpath = "//button[contains(text(),'Logout')]")
	WebElement logOut;

	@FindBy(xpath = "//*[text()='Signed in (NBCUniversal)']")
	WebElement chooseAccountToLogOff;
	
	@FindBy(name = "header")
	WebElement frame;

	@FindBy(id = "login_workload_logo_text")
	WebElement logOutConfirmation;
	

	public HomePage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify home page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyHomePageLoaded() throws Exception {
		try {
			WebAction.refreshPage();
			Waits.waitForElement(readyColumnSearchIcon, WAIT_CONDITIONS.CLICKABLE);
			Waits.waitForElement(workingColumnSearchIcon, WAIT_CONDITIONS.CLICKABLE);
			if (WebAction.getAttribute(leftSideMenuCollapse, "class").contains("menu-fold"))
				WebAction.clickUsingJs(leftSideMenuCollapse);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To open admin page
	 * 
	 * @throws Exception
	 */
	public void openAdminPage() throws Exception {
		try {
			WebAction.click(leftSideMenuCollapse);
			WebAction.scrollIntoView(adminTab);
			WebAction.click(adminTab);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To open profile page
	 * @throws Exception
	 */
	public void clickProfile() throws Exception {
		try {
			WebAction.click(profileIcon);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To log out of application
	 * @throws Exception
	 */
	public void logOut() throws Exception {
		try {
			WebAction.click(profileIcon);
			WebAction.mouseOverAndClick(profileIcon, logOut);
			WebAction.click(chooseAccountToLogOff);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify application logged out
	 */
	public void verifyApplicationLoggedOut() throws Exception {
		try {
			Waits.waitForElement(logOutConfirmation, WAIT_CONDITIONS.VISIBLE);
		} catch (Exception e) {
			e.fillInStackTrace();
			throw e;
		}
	}
}
