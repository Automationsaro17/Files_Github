package nbcu.automation.ui.pages.ncx;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.automation.ui.constants.ncx.NCXProfileConstants;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.factory.DriverFactory;

public class ProfilePage {

	@FindBy(xpath = "//button[span[contains(text(),'Edit Profile')]]")
	WebElement editProfileButton;

	@FindBy(xpath = "//span[text()='First:']/following-sibling::span[1]")
	WebElement userFirstName;
	
	@FindBy(xpath = "//span[text()='Last:']/following-sibling::span[1]")
	WebElement userLastName;
	
	@FindBy(xpath = "//span[text()='Work:']/following-sibling::span[1]")
	List<WebElement> userEmailId;

	@FindBy(xpath = "//span[text()='Job Title:']/following-sibling::span[1]")
	WebElement userJobTitle;

	@FindBy(xpath = "//span[text()='Company:']/following-sibling::span[1]")
	WebElement userCompany;

	@FindBy(xpath = "//span[text()='Group:']/following-sibling::span[1]")
	WebElement userGroup;

	public ProfilePage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify profile page is loaded
	 * 
	 * @throws Exception
	 */
	public void verifyProfilePageLoaded() throws Exception {
		try {
			Thread.sleep(2000);
			Waits.waitForElement(userFirstName, WAIT_CONDITIONS.VISIBLE);
			Waits.waitForElement(userLastName, WAIT_CONDITIONS.VISIBLE);
			Waits.waitForElement(editProfileButton, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.fillInStackTrace();
			throw e;
		}
	}
	
	/**
	 * To fetch user profile details and store in constants
	 * @throws Exception
	 */
	public void fetchUserDetails() throws Exception {
		try {
			String expectedFirstName = WebAction.getText(userFirstName);
			NCXProfileConstants.setFirstName(expectedFirstName);
			
			String expectedLastName = WebAction.getText(userLastName);
			NCXProfileConstants.setLastName(expectedLastName);
			
			String expectedEmailId  = "";
			for(WebElement element:userEmailId) {
			if(!WebAction.getText(element).isEmpty()) {
			expectedEmailId = WebAction.getText(element);
			NCXProfileConstants.setEmailId(expectedEmailId);
			}
			}
			
			String expectedJobTitle = WebAction.getText(userJobTitle);
			NCXProfileConstants.setJobTitle(expectedJobTitle);
			
			String expectedCompany = WebAction.getText(userCompany);
			NCXProfileConstants.setCompanyName(expectedCompany);
			
			String expectedGroup = WebAction.getText(userGroup);
			NCXProfileConstants.setBusinessUnit(expectedGroup);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
