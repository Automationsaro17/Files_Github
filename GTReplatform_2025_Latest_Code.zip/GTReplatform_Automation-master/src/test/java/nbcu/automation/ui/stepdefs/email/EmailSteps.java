package nbcu.automation.ui.stepdefs.email;

import io.cucumber.java.en.Then;
import nbcu.automation.ui.pages.email.EmailReader;
import nbcu.automation.ui.validation.common.EmailValidation;
import org.testng.Assert;

public class EmailSteps {

    @Then("verify email notification is {string} for {string}")
    public void verifyEmailReceived(String emailreceived, String bookingType) throws Exception {
        EmailReader.verifyEmailReceived(emailreceived, bookingType);
    }

    @Then("verify {string} in email notification for {string}")
    public void verifyEmailToOrCcListOrSubject(String contentType, String bookingType) throws Throwable {
        if ((contentType.equalsIgnoreCase("TO LIST")) || (contentType.equalsIgnoreCase("CC LIST")))
            EmailValidation.validateEmailToAndCcList("TO LIST", bookingType);
        else if (contentType.equalsIgnoreCase("SUBJECT"))
            EmailValidation.validateSubject(bookingType);
        else Assert.fail("Please provide email section name to verify");

    }

    @Then("verify {string} of email body for {string}")
    public void verifyEmailBody(String contentType, String bookingType) throws Throwable {
        EmailValidation.validateEmailBody(bookingType, contentType, "");
    }

    @Then("verify {string} of email body is {string} for {string}")
    public void verifyEmailBody(String contentType, String expectedValue, String bookingType) throws Throwable {
        EmailValidation.validateEmailBody(bookingType, contentType, expectedValue);
    }

}
