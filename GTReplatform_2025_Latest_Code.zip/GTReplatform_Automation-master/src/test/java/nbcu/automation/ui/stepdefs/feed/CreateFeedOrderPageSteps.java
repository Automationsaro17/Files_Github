package nbcu.automation.ui.stepdefs.feed;

import io.cucumber.java.en.Given;
import nbcu.automation.ui.pages.feed.CreateFeedOrderPage;

public class CreateFeedOrderPageSteps {

	CreateFeedOrderPage createFeedOrderPage = new CreateFeedOrderPage();

	@Given("verify order feed page is loaded")
	public void openGtApp() throws Exception {
		createFeedOrderPage.verifyFeedOrderPageLoaded();
	}
}
