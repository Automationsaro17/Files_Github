package nbcu.automation.ui.stepdefs.gtreplatform;

import org.testng.Assert;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.gtreplatform.BookerProfileEditPage;

public class BookerProfileEditPageSteps {

	BookerProfileEditPage bookerProfileEditPage = new BookerProfileEditPage();

	@Then("verify booker profile edit page is displayed")
	public void verifyBookerProfileLoaded() throws Exception {
		bookerProfileEditPage.verifyBookerProfileEditPageLoaded();
	}

	@Then("verify name,job info and work email fields are disabled")
	public void verifyNameJobInfoAndWorkEmailAreDisabled() throws Exception {
		bookerProfileEditPage.verifyNameJobDetailsFieldsDisabled();
	}

	@Then("verify {string} details in booker profile edit page")
	public void verifyBookerProfileDetails(String sectionName) throws Exception {
		if (sectionName.equalsIgnoreCase("NAME"))
			bookerProfileEditPage.verifyBookerProfileNameDetails();
		else if (sectionName.equalsIgnoreCase("JOB INFO"))
			bookerProfileEditPage.verifyBookerProfileJobDetails();
		else if (sectionName.equalsIgnoreCase("WORK EMAIL"))
			bookerProfileEditPage.verifyBookerProfileWorkEmail();
		else
			Assert.assertTrue(false, "Please provide valid section name in booker profile edit page");
	}

	@When("user changes {string}")
	public void changeDivisionOrViewSelector(String fieldName) throws Exception {
		if (fieldName.equalsIgnoreCase("DIVISION SELECTOR"))
			bookerProfileEditPage.changeDivisionSelector();
		else if (fieldName.equalsIgnoreCase("VIEW SELECTOR"))
			bookerProfileEditPage.changeViewSelector();
		else
			Assert.assertTrue(false, "Please provide valid field name in booker profile edit page");

	}

	@Then("user clicks on {string} button in booker profile edit page")
	public void clickButton(String buttonName) throws Exception {
		bookerProfileEditPage.clickUpdateOrCancelButton(buttonName);
	}
	
	@When("user updates booker {string} with email notification email id")
	public void updateBookerEmailAddress(String contactType) throws Exception {
		bookerProfileEditPage.updateEmailAddress();
	}
}
