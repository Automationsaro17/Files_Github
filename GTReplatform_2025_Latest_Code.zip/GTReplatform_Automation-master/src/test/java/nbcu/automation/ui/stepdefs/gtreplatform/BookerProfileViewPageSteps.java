package nbcu.automation.ui.stepdefs.gtreplatform;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.gtreplatform.BookerProfileViewPage;

public class BookerProfileViewPageSteps {

	BookerProfileViewPage bookerProfileViewPage = new BookerProfileViewPage();

	@Then("verify booker profile view page is displayed")
	public void verifyBookerProfileLoaded() throws Exception {
		bookerProfileViewPage.verifyBookerProfileViewPageLoaded();
	}

	@And("verify booker profile {string} details")
	public void verifySectionDetails(String sectionName) throws Exception {
		if (sectionName.equalsIgnoreCase("HEADER"))
			bookerProfileViewPage.verifyHeaderSection();
		else if (sectionName.equalsIgnoreCase("JOB"))
			bookerProfileViewPage.verifyJobInfoSection();
		else if (sectionName.equalsIgnoreCase("CONTACT INFO"))
			bookerProfileViewPage.verifyContactInfoSection();
	}

	@Then("verify \"edit\" and \"copy\" buttons are displayed in booker profile view page")
	public void verifyButtons() throws Exception {
		bookerProfileViewPage.verifyButtons();
	}

	@When("user clicks {string} button in booker profile view page")
	public void clickEditOrCopyButton(String buttonName) throws Exception {
		bookerProfileViewPage.clickEditOrCopyButton(buttonName);
	}
	
	@Then("verify copy clipboard message is displayed")
	public void verifyCopyClipBoardInfo() throws Exception {
		bookerProfileViewPage.verifyCopyClipBoardMessage();
	}
	
	@Then("verify copied booker profile url is valid")
	public void verifyCopiedBookerProfileUrl() throws Exception {
		bookerProfileViewPage.verifyCopiedBookerProfileLink();
	}
}
