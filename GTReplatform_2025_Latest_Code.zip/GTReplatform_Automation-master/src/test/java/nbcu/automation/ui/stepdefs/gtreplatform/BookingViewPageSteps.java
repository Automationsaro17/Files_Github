package nbcu.automation.ui.stepdefs.gtreplatform;

import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.gtreplatform.BookingViewPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class BookingViewPageSteps {

	BookingViewPage bookingViewPage = new BookingViewPage();

	@Then("verify booking view page is loaded with {string} button")
	public void verifyBookingEditPageLoaded(String buttonName) throws Exception {
		bookingViewPage.verifyBookingViewPageLoaded(buttonName);
	}

	@Then("verify {string} and {string} buttons are displayed in the header")
	public void verifyBookingEditPageLoaded(String button1, String button2) throws Exception {
		bookingViewPage.verifyEditAndCancelBookingButtonsDisplayed();
	}

	@Then("verify {string} button is displayed in {string} color in the header")
	public void verifyColorOfButton(String buttonName, String color) throws Exception {
		bookingViewPage.verifyButtonColor(buttonName, color);
	}

	@And("verify guest profile {string} is displayed in the header of booking view page")
	public void verifyGuestProfileDetailsInHeader(String fieldName) throws Exception {
		bookingViewPage.verifyGuestProfileDetailsInHeader(fieldName);
	}

	@Then("verify {string} details in booking view page")
	public void verifyBookingDetails(String sectionName) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "SHOW":
			bookingViewPage.verifyShowDetails();
			break;
		case "SEGMENT":
			bookingViewPage.verifySegmentDetails();
			break;
		case "BOOKING":
			bookingViewPage.verifyBookingDetails();
			break;
		case "RECURRING BOOKING":
			bookingViewPage.verifyRecurringBookingDetails();
			break;
		case "STUDIO":
			bookingViewPage.verifyStudioDetails();
			break;
		case "EMAIL ALERT":
			bookingViewPage.verifyEmailCommunicationDetails();
			break;
		case "CUSTOM EMAIL NOTIFICATION":
			bookingViewPage.verifyCustomEmailNoficationDetails();
			break;
		}
	}

	@Then("user clicks {string} page in headers")
	public void openDifferentPageInHeader(String pageName) throws Exception {
		bookingViewPage.selectPageInHeader(pageName);
	}

	@When("user clicks {string} button in booking view page")
	public void clickEditOrCancelButton(String buttonType) throws Exception {
		bookingViewPage.clickEditCancelButton(buttonType);
	}

	@Then("verify reason for cancellation popup is displayed")
	public void verifyReasonForCancellationPopUpDisplayed() throws Exception {
		bookingViewPage.verifyReasonForCancellationPopupDisplayed();
	}

	@When("user fills cancellation reason in cancellation reason popup")
	public void fillCancellationReason(DataTable dataTable) throws Exception {
		bookingViewPage
				.fillCancellationReason(CucumberUtils.getValuesFromDataTable(dataTable, "Reason for cancellation"));
	}

	@And("user clicks {string} in cancellation reason popup")
	public void clickButtonInReasonForCancellationPopUp(String buttonType) throws Exception {
		bookingViewPage.clikOkOrCancelButtonInCancellationPopup(buttonType);
	}

	@And("verify booking is cancelled and cancelled banner is displayed")
	public void verifyCancelledBannerDetails() throws Exception {
		bookingViewPage.verifyCancelBannerDetails();
	}

	@And("verify reactivate booking confirmation pop up is displayed")
	public void verifyReactivateBookingConfirmationPopup(DataTable dataTable) throws Exception {
		bookingViewPage.verifyReactivateBookingConfirmationPopup(
				CucumberUtils.getValuesFromDataTable(dataTable, "Reactivate popup message"));
	}

	@And("user clicks on {string} in reactivate booking confirmation pop up")
	public void clickOnOkOrCancelInReactivateBooking(String buttonType) throws Exception {
		bookingViewPage.clickOnOkOrCancelInReactivateBooking(buttonType);
	}

	@And("user clicks on {string} button under car services")
	public void clickButoonUnderCarServices(String buttonType) throws Exception {
		bookingViewPage.clickAddPickupCarService();
	}

	@And("verify pick up car services RH is displayed")
	public void verifyPickUpCarServiceRhDisplayed() throws Exception {
		bookingViewPage.verifyPickUpCarServiceRhLoaded();
	}

	@And("user fills {string} details in pick up services RH")
	public void verifyPickUpCarServiceRhDisplayed(String sectionName, DataTable dataTable) throws Exception {
		if (sectionName.equalsIgnoreCase("CAR"))
			bookingViewPage.fillCarDetailsInPickUpCarService(
					CucumberUtils.getValuesFromDataTable(dataTable, "Pick Up For"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Car Service"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Car Number"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Phone Number"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Pick Up Date"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Pick Up Time"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Arrival Time"));
		else if (sectionName.equalsIgnoreCase("PICK UP"))
			bookingViewPage.fillPickUpDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Address Line1"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Address Line2"),
					CucumberUtils.getValuesFromDataTable(dataTable, "City"),
					CucumberUtils.getValuesFromDataTable(dataTable, "State"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Zip"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Country"));
		else if (sectionName.equalsIgnoreCase("DROP OFF"))
			bookingViewPage.fillDropOffDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Address Line1"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Address Line2"),
					CucumberUtils.getValuesFromDataTable(dataTable, "City"),
					CucumberUtils.getValuesFromDataTable(dataTable, "State"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Zip"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Country"));
		else
			Assert.assertTrue(false, "Please enter valid service name");
	}

	@And("user clicks on {string} check box")
	public void verifyPickUpCarServiceRhDisplayed(String checkBoxName) throws Exception {
		bookingViewPage.selectPickUpCheckBoxes(checkBoxName);
	}

	@And("user clicks on {string} button in pick up services RH")
	public void clickButtonInPickUpServicesRh(String buttonName) throws Exception {
		bookingViewPage.clickSubmitOrCancelButton(buttonName);
	}

	@And("verify {string} services are added")
	public void verifyServicesAdded(String serviceType) throws Exception {
		if (serviceType.equalsIgnoreCase("PICK UP AND RETURN CAR"))
			bookingViewPage.verifyPickUpAndReturnCarServiceAdded();
		else if (serviceType.equalsIgnoreCase("MAKE UP"))
			bookingViewPage.verifyMakeUpAdded();
		else
			Assert.assertTrue(false, "Please enter valid service name");
	}
	
	@And("user clicks on {string} button under logistics")
	public void clickButtonUnderLogistics(String serviceName) throws Exception {
		bookingViewPage.clickAddMakeUp();
	}
	
	@Then("verify makeup RH is displayed")
	public void verifyMakeUpRhDisplayed() throws Exception {
		bookingViewPage.verifyMakeUpRhLoaded();
	}
	
	@Then("user adds {string} details in makeup RH")
	public void verifyMakeUpRhDisplayed(String serviceName, DataTable dataTable) throws Exception {
		bookingViewPage.addMakeUpService(CucumberUtils.getValuesFromDataTable(dataTable, "Make Up Description"));
	}
	
	@And("user clicks on {string} button under order feed")
	public void clickAddFeedButton(String buttonType) throws Exception {
		bookingViewPage.clickAddFeed();
	}

}
