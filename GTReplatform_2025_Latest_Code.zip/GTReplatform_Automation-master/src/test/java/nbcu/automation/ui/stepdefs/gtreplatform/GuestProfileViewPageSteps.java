package nbcu.automation.ui.stepdefs.gtreplatform;

import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.gtreplatform.GuestProfileViewPage;

public class GuestProfileViewPageSteps {

	GuestProfileViewPage guestProfileViewPage = new GuestProfileViewPage();

	@Then("validate Guest profile view page is loaded")
	public void verifyViewGuestProfilePageDisplayed() throws Exception {
		guestProfileViewPage.verifyGuestProfileViewPageDisplayed();
	}

	@Then("verify guest profile {string} in header")
	public void verifyViewGuestProfileName(String guestProfileName) throws Exception {
		guestProfileViewPage.verifyGuestProfileNameInHeader();
	}

	@Then("verify primary job {string} is displayed as guest profile job {string} in header")
	public void verifyViewGuestProfileJobTitleAndCompany(String titleOrCompany1, String titleOrCompany2)
			throws Exception {
		guestProfileViewPage.verifyPrimaryJobTitleOrCompanyInHeader(titleOrCompany1);
	}

	@Then("verify guest profile contributors are displayed in header")
	public void verifyContributors() throws Exception {
		guestProfileViewPage.verifyContributorDetails();
	}

	@Then("verify {string} color tick mark is displayed before contributors in header")
	public void verifyContributorsTickMarkColor(String color) throws Exception {
		guestProfileViewPage.verifyContributorsTickMark(color);
	}

	@Then("verify below icon are enabled in header of guest profile view page")
	public void verifyViewGuestProfileIcons(DataTable dataTable) throws Exception {
		guestProfileViewPage.verifyButtonsInHeaders(dataTable);
	}

	@Then("verify guest profile {string} details in background section")
	public void verifyViewGuestProfileIcons(String section) throws Exception {
		switch (section.toUpperCase()) {
		case "BIOGRAPHY":
			guestProfileViewPage.verifyBiography();
			break;
		case "DEMOGRAPHICS":
			guestProfileViewPage.verifyDemographics();
			break;
		case "EXPERTISE":
			guestProfileViewPage.verifyExpertise();
			break;
		case "TICKER":
			guestProfileViewPage.verifyTicker();
			break;
		}
	}

	@Then("verify guest profile {string} details in contact info section")
	public void verifyAlertMessage(String section) throws Exception {
		switch (section.toUpperCase()) {
		case "ALERTS":
			guestProfileViewPage.verifyAlerts();
			break;
		case "PHONE":
			guestProfileViewPage.verifyGuestPhoneDetails();
			break;
		case "EMAIL":
			guestProfileViewPage.verifyGuestEmailDetails();
			break;
		case "OTHER":
			guestProfileViewPage.verifyGuestOtherDetails();
			break;
		case "ADDRESS":
			guestProfileViewPage.verifyGuestAddressDetails();
			break;
		}
	}

	@Then("verify guest profile {string} are displayed in {string} color")
	public void verifyAlertsColor(String section, String color) throws Exception {
		guestProfileViewPage.verifyAlertsColor(color);
	}

	@Then("user selects {string} tab in contact info section of guest profile")
	public void clickTabInContactInfo(String tabName) throws Exception {
		guestProfileViewPage.selectTabInContactInfo(tabName);
	}

	@Then("verify selected {string} tab is highlighted in {string} color")
	public void verifyColorofSelectedTabOfContactInfo(String tabName, String colorName) throws Exception {
		guestProfileViewPage.verifyColorOfSelectTabInContactInfo(tabName, colorName);
	}

	@Then("verify guest profile {string} details in job section")
	public void verifyJobDetails(String tabName) throws Exception {
		guestProfileViewPage.verifyGuestJobDetails();
	}

	@Then("verify guest profile primary {string} is displayed in the top")
	public void verifyPrimaryContactDisplayedOnTop(String section) throws Exception {
		switch (section.toUpperCase()) {
		case "PHONE":
			guestProfileViewPage.verifyPrimaryPhoneNumberDisplayedOnTop();
			break;
		case "EMAIL":
			guestProfileViewPage.verifyPrimaryEmailDisplayedOnTop();
			break;
		case "OTHER":
			guestProfileViewPage.verifyPrimaryOtherDisplayedOnTop();
			break;
		}
	}

	@Given("user clicks {string} icon from guest profile header")
	public void clickIconInGuestProfileHeader(String iconName) throws Exception {
		guestProfileViewPage.clickButtonInHeader(iconName);
	}

	@Then("verify below icon are disabled in header of guest profile view page")
	public void verifyButtonsInHeadersDisabled(DataTable dataTable) throws Exception {
		guestProfileViewPage.verifyButtonsInHeadersDisabled(dataTable);
	}

	@Then("Profile Deactivated banner is {string} in guest profile view page")
	public void verifyDeactivatedBannerDisplayed(String stat) throws Exception {
		guestProfileViewPage.verifyDeactivatedProfileBannerDisplayed(stat);
	}

	@When("user opens {string} info tab in guest profile view page")
	public void clickBasicOrBookingInfoTab(String tabName) throws Exception {
		guestProfileViewPage.openBasicOrBookingInfoTab(tabName);
	}

	@When("user clicks {string} tab in booking info")
	public void clickTabInBookingInfo(String tabName) throws Exception {
		guestProfileViewPage.selectTabInBookingInfo(tabName);
	}

	@When("verify {string} in booking info")
	public void verifyDetailsInBookingInfo(String sectionName) throws Exception {
		guestProfileViewPage.verifyAppearanceCounter();
	}

	@When("verify {string} details in {string} tab of booking info")
	public void verifyDetailsInBookingInfo(String callStatus, String tabName) throws Exception {
		if (tabName.equalsIgnoreCase("CALLS"))
			guestProfileViewPage.verifyCallsDetails(callStatus);
		else if ((tabName.equalsIgnoreCase("FUTURE BOOKINGS")) || (tabName.equalsIgnoreCase("PAST BOOKINGS")))
			guestProfileViewPage.verifyPastOrFutureBookingDetails(callStatus, tabName);
		else
			Assert.assertTrue(false, "Please provide valid tab name in booking info of guest profile");
	}

	@When("user clicks on {string} status in {string} tab of booking info")
	public void clickStatusLink(String callStatus, String tabName) throws Exception {
		if (tabName.equalsIgnoreCase("CALLS"))
			guestProfileViewPage.clickOnStatusInCallsTab(callStatus);
	}

}
