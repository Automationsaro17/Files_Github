package nbcu.automation.ui.stepdefs.gtreplatform;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.constants.gtreplatform.BookingGuestConstants;
import nbcu.automation.ui.pages.gtreplatform.LandingPage;
import nbcu.automation.ui.pages.gtreplatform.ReportCenterPage;

public class LandingPageSteps {

	LandingPage homePage = new LandingPage();
	ReportCenterPage reportCenterPage = new ReportCenterPage();

	@And("verify booked tab of landing page is loaded")
	@Given("verify landing page is loaded")
	public void verifyLandingPageIsLoaded() throws Exception {
		homePage.verifyLandingPageLoaded();
	}

	@Given("user changes division to {string}")
	public void changeDivision(String division) throws Exception {
		homePage.changeDivision(division);
	}
	
	@Given("user selects {string} icon from profile dropdown")
	public void selectIconFromProfileDropDown(String iconName) throws Exception {
		homePage.selectIconFromProfileDropDown(iconName);
	}

	@Given("user clicks on {string} icon")
	public void clickAddProfile(String profileType) throws Exception {
		homePage.clickAddProfile(profileType);
	}

	@When("user selects {string} in landing page")
	public void selectLinkInLandingPage(String tabName) throws Exception {
		homePage.clickLandingPageTabs(tabName);
	}

	@Then("verify landing page default settings")
	public void verifyLandingPageDefaultSettings() throws Exception {
		homePage.verifyLandingPageDefaults();
	}

	@Then("verify cancelled booking is present in {string} tab of landing page")
	@Then("verify duplicate booking placed is present in {string} tab of landing page")
	@Then("verify booking placed is present in {string} tab of landing page")
//	@Then("verify( duplicate| ) booking placed is present in {string} tab of landing page")
	public void verifyPlacedBookingPresentInLandingPage(String tabName) throws Exception {
		if (tabName.equalsIgnoreCase("BOOKED"))
			homePage.verifyBookingDisplayedInBookedTab();
		else if (tabName.equalsIgnoreCase("SEGMENTS"))
			homePage.verifyBookingDisplayedInSegmentTab();
		else if (tabName.equalsIgnoreCase("CANCELLED"))
			homePage.verifyBookingDisplayedInCancelledTab();
	}

	//@Then("verify export icon is displayed for( duplicate| ) booking show in {string} tab of landing page")
	@Then("verify export icon is displayed for duplicate booking show in {string} tab of landing page")
	@Then("verify export icon is displayed for booking show in {string} tab of landing page")
	public void verifyExportIconDisplayedForShow(String tabName) throws Exception {
		if (tabName.equalsIgnoreCase("BOOKED") || tabName.equalsIgnoreCase("CANCELLLED"))
			homePage.verifyShowExportIconDisplayedInBookedTab(tabName);
		else if (tabName.equalsIgnoreCase("SEGMENTS"))
			homePage.verifyShowExportIconDisplayedInSegmentTab();
	}

	@Then("verify ellipsis icon is displayed for( duplicate| ) booking in {string} tab of landing page")
	
	@Then("verify ellipsis icon is displayed for duplicate booking in {string} tab of landing page")
	public void verifyEllipsisIconDisplayed(String tabName) throws Exception {
		if ((tabName.equalsIgnoreCase("BOOKED")) || (tabName.equalsIgnoreCase("CANCELLED")))
			homePage.verifyBookingHasEllipsisIconInBookedTab(tabName);
		else if (tabName.equalsIgnoreCase("SEGMENTS"))
			homePage.verifyBookingHasEllipsisIconInSegmentTab();
	}

	//@When("user clicks {string} icon of( duplicate| ) booking in {string} tab of landing page")
	@When("user clicks {string} icon of duplicate booking in {string} tab of landing page")
	@When("user clicks {string} icon of booking in {string} tab of landing page")
	public void clickIconsOfbooking(String iconName, String tabName) throws Exception {
		homePage.clickIconInAllTab(iconName, tabName);
	}

	@Then("verify {string} and {string} icons are displayed in {string} tab of landing page")
	public void verifyOptionsInEllipsisIcon(String icon1, String icon2, String tabName) throws Exception {
		homePage.verifyOptionsInEllipsis(icon1, icon2, tabName);
	}

	@When("user selects {string} tab in landing page")
	public void clickTabInLandingPage(String tabName) throws Exception {
		homePage.clickTabInLandingPage(tabName);
	}
	
	@Then("verify default view in landing page")
	public void verifydefaultViewInLandingView() throws Exception {
		homePage.verifyDefaultSelectedTab();
	}

	@Then("verify segments tab is loaded in landing page")
	public void verifySegmentTabLoaded() throws Exception {
		homePage.verifySegmentsTabLoaded();
	}

	@Then("user clicks carrot icon of show in {string} tab of landing page")
	public void clickCarrotIconOfShowInSegmentTab(String tabName) throws Exception {
		homePage.openShowInSegmentTab();
	}

	@Then("user clicks on show time of booking in booked tab")
	public void clickOnShowTimeInBookedTab() throws Exception {
		homePage.clickOnShowTimeLinkInBookedTab();
	}

	@When("change date in calendar to booking date")
	public void selectDateInCalendar() throws Exception {
		homePage.changeCalenderDate(BookingGuestConstants.getShowDate());
	}

	@When("verify cancelled tab of landing page is loaded")
	public void verifyCancelledTabLoaded() throws Exception {
		homePage.verifyCancelledTabLoaded();
	}

	@Then("verify recurring bookings are displayed in {string} tab")
	public void verifyRecurringBookingDetailsInBookedAndSegmentsTab(String tabName) throws Exception {
		if (tabName.toUpperCase().contains("BOOKED AND SEGMENTS"))
			homePage.verifyRecurringBookingDetailsInBookedAndSegmentTab();
	}
	
	@Then("verify below icon are displayed for show")
	public void verifyIconsOfShow(DataTable params) throws Exception {
		homePage.verifyAddSegmentOrGuestButtonDisplayed(params);
	}
	
	@When("user clicks {string} button of show")
	public void clickAddSegmentOrGuest(String iconName) throws Exception {
		homePage.clickAddSegmentOrGuestButton(iconName);
	}
	
	@Then("verify Add segment RH is displayed")
	public void verifySegmentRhDisplayed() throws Exception {
		homePage.verifyAddSegmentRhDisplayed();
	}
	
	@And("verify default division in division dropdown")
	public void verifyDefaultDivision() throws Exception {
		homePage.verifyDefaultDivision();
	}
	
	@And("user clicks global search icon")
	public void clickGlobalSearchIcon() throws Exception {
		homePage.clickGlobalSearchIcon();
	}
	
	@And("searches {string} profile")
	public void clickGlobalSearchIcon(String profileType) throws Exception {
		homePage.searchProfile(profileType);
	}
	
	@And("user searches and opens guest profile")
	public void searchGuestProfile() throws Exception {
		homePage.searchAndOpenGuestProfile();
	}
	
	@And("verify Top 50 {string} profile search results are displayed")
	public void verifyTop50ResultsDisplayed(String profileType) throws Exception {
		homePage.verifyTop50SearchResultsAreDisplayed(profileType);
	}
	
	@And("exact search {string} profile is displayed on top")
	public void verifyExactSearchResult(String profileType) throws Exception {
		homePage.verifyExactSearchResult(profileType);
	}
	
	@And("user clicks {string} link")
	public void clickLink(String linkName) throws Exception {
		homePage.clickSeeFullReportLink();
	}
	
	@And("selects {string} tab in global search")
	public void selectTab(String tabName) throws Exception {
		homePage.selectGlobalSearchTab(tabName);
	}
}
