package nbcu.automation.ui.stepdefs.gtreplatform;

import io.cucumber.java.en.Given;
import nbcu.automation.ui.pages.gtreplatform.LandingPage;
import nbcu.automation.ui.pages.gtreplatform.LoginPage;

public class LoginPageSteps {

	LoginPage loginPage = new LoginPage();
	LandingPage homePage = new LandingPage();

	@Given("user opens guest tracker application")
	public void openGtApp() throws Exception {
		loginPage.openApplication();
	}

	@Given("user logins into application")
	public void loginIntoGtApp() throws Exception {
		loginPage.loginIntoApplication();
		homePage.verifyLandingPageLoaded();
	}
}
