package nbcu.automation.ui.stepdefs.gtreplatform;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import nbcu.automation.ui.pages.gtreplatform.ProxyProfilePage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class ProxyProfilePageSteps {

	ProxyProfilePage proxyProfilePage = new ProxyProfilePage();

	@Then("verify that proxy profile page is loaded")
	public void verifyProxyProfilePageLoaded() throws Exception {
		proxyProfilePage.verifyProxyProfilePageDisplayed();
	}

	/*
	 * @Given("user opens {string} tab") public void selectTab(String defTab) throws
	 * Exception { proxyProfilePage.openBasicOrJobInfoTab(defTab); }
	 */

	@Given("user clicking {string} tab button")
	public void toClickBasicInfoTab(String tabName) throws Exception {
		proxyProfilePage.openBasicOrJobInfoTab(tabName);
	}

	@And("user enters the {string} details in Proxy profile background section")
	public void enterBackgroundSectionInputs(String sectionName, DataTable dataTable) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "DISPLAY NAME":
			proxyProfilePage.fillDisplayName(CucumberUtils.getValuesFromDataTable(dataTable, "Display Name"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Store as second profile"));
			break;
		case "FIRST NAME":
			proxyProfilePage.fillFirstName(CucumberUtils.getValuesFromDataTable(dataTable, "First Name"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Store as second profile"));
			// proxyProfilePage.setName(dataTable);
			break;
		case "LAST NAME":
			proxyProfilePage.fillLastName(CucumberUtils.getValuesFromDataTable(dataTable, "Last Name"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Store as second profile"));
			break;
		case "EXPERTISE":
			List<Map<String, String>> expertiseList = CucumberUtils.getValuesFromDataTableAsList(dataTable);
			for (int i = 0; i < expertiseList.size(); i++) {
				proxyProfilePage.setExpertise(expertiseList.get(i).get("Expertise"));
			}
			break;
		case "COMPANY NAME":
			proxyProfilePage.selectAffilifatedCompanies(CucumberUtils.getValuesFromDataTable(dataTable, "Companies"));
			break;
		case "JOB NOTES":
			proxyProfilePage.fillJobNotes(CucumberUtils.getValuesFromDataTable(dataTable, "Job Notes"));
			break;
		}
	}

	@And("user entered the Expertise details in Lead Proxy profile background section")
	public void selectExpertiseDropDown(DataTable dataTable) throws Exception {
		proxyProfilePage.setExpertiseDropDown(CucumberUtils.getValuesFromDataTable(dataTable, "Expertise"));
	}

	@And("user added additional expertise tags from the dropdown")
	public void addAdditionalExpertise(DataTable dataTable) throws Exception {
		proxyProfilePage.updateExpertiseTags(CucumberUtils.getValuesFromDataTable(dataTable, "Expertise"));
	}

	@And("user enters the {string} details in Proxy profile of contact info section")
	public void fillProxyContactInfo(String secName, DataTable dataTable) throws Exception {
		switch (secName.toUpperCase()) {
		case "PHONE":
			proxyProfilePage.fillPhoneNumberDetails(CucumberUtils.getValuesFromDataTable(dataTable, "1-Phone"),
					CucumberUtils.getValuesFromDataTable(dataTable, "2-Phone"),
					CucumberUtils.getValuesFromDataTable(dataTable, "3-Phone"),
					CucumberUtils.getValuesFromDataTable(dataTable, "4-Phone"));
			break;
		case "EMAIL":
			proxyProfilePage.fillEmailDetails(CucumberUtils.getValuesFromDataTable(dataTable, "1-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "2-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "3-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "4-Email"));
			break;
		case "OTHERS":
			proxyProfilePage.fillSocialMiscDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Twitter"),
					CucumberUtils.getValuesFromDataTable(dataTable, "LinkedIn"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Video"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Website"));
			break;
		case "ADDRESS":
			proxyProfilePage.fillAddressDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Address-1"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Address-2"),
					CucumberUtils.getValuesFromDataTable(dataTable, "City"),
					CucumberUtils.getValuesFromDataTable(dataTable, "State"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Zip"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Country"));
			break;
		case "ALERT":
			proxyProfilePage.fillAlertsDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Alerts"));
			break;

		case "ADD CONTACT":
			proxyProfilePage.additionalContacts(dataTable);
		}
	}

	@When("user clicking on {string} button")
	public void clickButton(String buttonType) throws Exception {
		proxyProfilePage.clickButton(buttonType);
	}

	@Then("user view newly create proxy profile page")
	public void verifyProxyProfilePage() throws Exception {
		proxyProfilePage.viewNewlyCreatedProxyProfilePage();
	}

	@And("Job history page is displayed")
	public void verifyJobDetailPage() throws Exception {
		proxyProfilePage.verifyJobInfoPage();
	}

	@And("user clicks on +Add Job button in Job info page")
	public void clickAddJobButton() throws Exception {
		proxyProfilePage.clickingAddJobButton();
	}

	@And("verify Active status is Enabled in RH drawer")
	public void isEnabledButton() throws Exception {
		proxyProfilePage.statusRadioButton();
	}

	@And("user filling {string} in Job History RH drawer")
	public void fillJobHistoryDetails(String fieldName, DataTable dataTable) throws Exception {
		switch (fieldName.toUpperCase()) {
		case "START DATE":
			proxyProfilePage.fillStartDate(CucumberUtils.getValuesFromDataTable(dataTable, "Start Date"));
			break;

		case "JOB TITLE":
			proxyProfilePage.enterJobTitle(CucumberUtils.getValuesFromDataTable(dataTable, "Job Title"));
			break;

		case "CATEGORY":
			proxyProfilePage.setCategory(CucumberUtils.getValuesFromDataTable(dataTable, "Category"));
			break;

		case "ORGANIZATION":
			proxyProfilePage.selectOraganization(CucumberUtils.getValuesFromDataTable(dataTable, "Org/Company"));
			break;

		case "DEPARTMENT":
			proxyProfilePage.enterJobDetails(fieldName, CucumberUtils.getValuesFromDataTable(dataTable, "Department"));
			break;

		case "JOB NOTES":
			proxyProfilePage.enterJobDetails(fieldName, CucumberUtils.getValuesFromDataTable(dataTable, "Job Notes"));
			break;

		}
	}

	@And("user view the created proxy profile page loaded completely")
	public void verifyLeadProxyProfileViewPage() throws Exception {
		proxyProfilePage.verifyViewPage();
	}

	@And("Clicking Merge button present in the header of an profile view page")
	public void clickMergeButtonViewLeadProfile() throws Exception {
		proxyProfilePage.mergeButtonClicking();
	}

	@And("verify the Proxy profile merge screen is loaded")
	public void verifyProxyProfileMergeScreen() throws Exception {
		proxyProfilePage.viewLeadProxyProfileInMergeScreen();
	}

	@Then("created profile is displayed in the merge screen as Lead proxy profile")
	public void verifyLeadProfileInMergeScreen() {
		proxyProfilePage.leadProxyProfileInTable();
	}

	@And("clicking Add Proxy Profile shown the Add Profile RH drawer")
	public void clickAddProxyProfile() throws Exception {
		proxyProfilePage.clickingAddProfileButton();
	}

	@Then("user searches for the secondary proxy profile and add it to merge screen")
	public void addSecondaryProxyProfileInTable() throws Exception {
		proxyProfilePage.addSecondaryProxyProfileInTable();
	}

	@And("Add Proxy profile button should greyed out in header of the table")
	public void verifyAddProfileButton() {
		proxyProfilePage.disableAddProfileButton();
	}

	@And("verify {string} button present in the Lead Proxy profile")
	public void verifyButtonsInLeadProfile(String value) {
		proxyProfilePage.isChangeOptionPresent(value);
	}

	@And("verify {string} button present in the secondary Proxy profile")
	public void verifyButtonsInSecondaryProfile(String value) {
		proxyProfilePage.isRemoveOptionPresent(value);
	}

	@And("verify {string} icon present for all fields in Lead Proxy profile")
	public void verifyEditIconInLeadProfileFields(String value) {
		proxyProfilePage.isEditOptionPresent();
	}

	@And("user changed the lastname of lead proxy profile")
	public void changeLastName() throws Exception {
		proxyProfilePage.updateLastNameInLeadProfile();
	}

	@Then("user clicking {string} button")
	public void clickMergeButton(String btnName) throws Exception {

		switch (btnName.toUpperCase()) {
		case "MERGE":
			proxyProfilePage.mergeProfiles();
			break;
		case "OK":
			proxyProfilePage.clickOK();
			break;
		}
	}

	@And("lead proxy profile page loaded after success merging of profiles")
	public void verifyHomePageOfLeadProfile() throws Exception {
		proxyProfilePage.verifyLeadProfilePage();
	}

	@And("verify the updated {string} of lead profile")
	public void updatedFields(String fieldValues) throws Exception {
		switch (fieldValues.toUpperCase()) {
		case "LAST NAME":
			proxyProfilePage.verifyLastNameInLeadProxyProfilePage();
			break;
		case "EXPERTISE":
			proxyProfilePage.verifyExpertiseTagsInLeadProxyProfilePage();
			break;
		}
	}

	@And("verify the {string} is displayed in proxy page header")
	public void viewProxyProfilePageHeader(String headerPart) throws Exception {
		switch (headerPart.toUpperCase()) {
		case "PROXY PROFILE NAME":
			proxyProfilePage.verifyProfilePageAfterCreating();
			break;
		case "JOB TITLE":
			proxyProfilePage.verifyJobTitleInHeader();
			break;
		case "COMPANY NAME":
			proxyProfilePage.verifyCompanyNameInHeader();
			break;
		}
	}

	@And("verify the {string} are displayed")
	public void viewProxyProfilePageHeaderButton(String headersButton, DataTable dataTable) throws Exception {
		proxyProfilePage.headerIconsInProxyProfile(headersButton, dataTable);
	}

	@Then("verify Basic Info tab is enabled")
	public void basicInfoTab() throws Exception {
		proxyProfilePage.defEnabledTab();
	}

	@And("verify the Background section is displayed")
	public void backGround() throws Exception {
		proxyProfilePage.backgroundIsDisplayed();
	}

	@And("verify the {string} in background section is displayed")
	public void verifyBackgroundSection(String sectionNames) {
		switch (sectionNames.toUpperCase()) {
		case "Biography":
			proxyProfilePage.verifyProxyJobNotes();
			break;
		case "Expertise":
			proxyProfilePage.verifyProxyExpertise();
			break;
		case "ALERTS":
			proxyProfilePage.verifyProxyAlerts();
			break;
		}
	}

	@And("verify the Job details in Active Role section is displayed")
	public void proxyProfileActiveRoles() {
		proxyProfilePage.proxyProfileJobRoles();
	}

	@Then("verify the {string} displayed in the contact info section")
	public void verifyContactInfoSection(String tabNames) throws Exception {
		switch (tabNames.toUpperCase()) {
		case "PHONE":
			proxyProfilePage.verifyPhoneNumbers();
			break;
		case "EMAIL":
			proxyProfilePage.verifyEmailIds();
			break;
		case "OTHER":
			proxyProfilePage.verfiyOtherLinks();
			break;
		case "ADDRESS":
			proxyProfilePage.clickingEllipsesTab();
			proxyProfilePage.verifyProxyAddressDetails();
			break;
		case "COMPANIES":
			proxyProfilePage.clickingEllipsesTab();
			proxyProfilePage.verifyCompaniesDetails();

			break;
		}
	}

	@Then("clicking one of the info buttons called Contacts")
	public void clickContactsTab() throws Exception {
		proxyProfilePage.clickContactsTabFromViewProxyProfile();
	}

	@And("verify the total count of guest cards in the page")
	public void clickGuestContactCard() throws Exception {
		proxyProfilePage.verifyTotalCount();
	}

	@Then("verify the {string} is matched")
	public void verifyGuestContactCards(String lists) throws Exception {
		switch (lists.toUpperCase()) {
		case "GUEST NAME":
			proxyProfilePage.verifyGuestName();
			break;
		case "GUEST JOB":
			proxyProfilePage.verifyGuestJob();
			break;
		case "GUEST ORG/DIVISION":
			proxyProfilePage.verifyGuestCompanyDivision();
			break;

		}
	}

}
