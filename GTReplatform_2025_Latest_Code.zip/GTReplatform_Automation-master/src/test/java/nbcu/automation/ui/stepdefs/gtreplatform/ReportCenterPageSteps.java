package nbcu.automation.ui.stepdefs.gtreplatform;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.gtreplatform.ReportCenterPage;

public class ReportCenterPageSteps {

	ReportCenterPage reportCenterPage = new ReportCenterPage();

	@Then("verify report center page is loaded")
	public void verifyReportCenterPageLoaded() throws Exception {
		reportCenterPage.verifyReportCenterPageDisplayed();
	}

	@Then("verify {string} tab selected by default")
	@And("verify {string} tab selected by default in calls tab")
	public void selectLinkInHomePage(String tabName) throws Exception {
		reportCenterPage.verifyCallsTabSelectedByDefault(tabName);
	}

	@And("verify clear button is disabled by default")
	public void verifyClearButtonDisableByDefault() throws Exception {
		reportCenterPage.verifyClearButtonDisabledByDefault();
	}

	@And("verify global search text box is present")
	public void verifyGlobalSearchTextBoxPresent() throws Exception {
		reportCenterPage.verifyGlobalSearchTextBoxIsPresent();
	}

	@And("verify {string} icon is enabled by default")
	public void verifyExportPrinterSettingsAreEnabled(String iconName) throws Exception {
		reportCenterPage.verifyExportPrintAndSettingAreEnabled(iconName);
	}

	@And("verify below columns are displayed in {string} table")
	public void verifyCallsTableColumns(String tableName, DataTable params) throws Exception {
		reportCenterPage.verifyCallsTableColumns(tableName, params);
	}

	@And("verify number of records per page is selected as {string} by default")
	public void verifyDefaultRecordsPerPage(String recordsPerPage) throws Exception {
		reportCenterPage.verifyNumberRecordsPerPage(recordsPerPage);
	}

	@And("verify page number 1 is selected by default")
	public void verifypageNumber1SelectedByDefault() throws Exception {
		reportCenterPage.verifyPageisSelected();
	}

	@And("verify left arrow is disabled by default")
	public void verifyLeftArrowDisabled() throws Exception {
		reportCenterPage.verifyLeftArrowIsDisabled();
	}

	@And("verify right arrow is enabled by default")
	public void verifyRightArrowEnabled() throws Exception {
		reportCenterPage.verifyRightArrowIsEnabled();
	}

	@When("user click {string} tab")
	public void clickTabs(String tabName) throws Exception {
		reportCenterPage.clickTabs(tabName);
	}
	
	@And("verify {string} tab selected by default in Bookings tab")
	public void verifyBookingsTabDefaultSection(String tabName) throws Exception {
		reportCenterPage.verifyBookingsTabSelectedByDefault(tabName);
	}

	@And("validate {string} search in {string} table")
	public void ValidateSearchOptions(String searchType,String tableName) throws Exception {
		reportCenterPage.ValidateSearchInBookingsPage(searchType,tableName);
				
	}

	@And("verify calls placed in report centre {string} table")
	public void verifyCallsPlacedTableColumns(String tableName, DataTable params) throws Exception {
		reportCenterPage.verifyplacedCallsTableColumns(tableName, params);
	}
	
	@Then("verify report center directory {string} page is opened")
	public void clickContactsTab(String tabName) throws Exception {
		reportCenterPage.verifyDefaultSelectedTabInDirectory(tabName);
	}
	
	@And("verify {string} profile search text is prefilled in search text box of table")
	public void verifySearchTextPrefilled(String profileType) throws Exception {
		reportCenterPage.verifySearchTextBoxPrefilled(profileType);
	}
}
