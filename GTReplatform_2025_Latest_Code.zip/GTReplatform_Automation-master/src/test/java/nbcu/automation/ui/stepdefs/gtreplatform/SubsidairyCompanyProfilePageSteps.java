package nbcu.automation.ui.stepdefs.gtreplatform;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.gtreplatform.SubsidairyCompanyProfilePage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class SubsidairyCompanyProfilePageSteps {

	SubsidairyCompanyProfilePage subCompanyProfilePage = new SubsidairyCompanyProfilePage();

	@And("user selecting company type as {string}")
	public void selectProfileTypeAsSubsidiary(String compType) throws Exception {
		subCompanyProfilePage.selectProfileType(compType);
	}

	@Then("user entering {string} name")
	public void fillCompanyNameDetails(String enterCompanyName, DataTable dataTable) throws Exception {
		switch (enterCompanyName.toUpperCase()) {
		case "PARENT COMPANY":
			subCompanyProfilePage.enterAndSelectParentCompanyName(
					CucumberUtils.getValuesFromDataTable(dataTable, "Parent Company Name"));
			break;
		case "SUBSIDIARY COMPANY":
			subCompanyProfilePage.enterSubsidiaryName(CucumberUtils.getValuesFromDataTable(dataTable, "Subsidiary"));
			break;
		}
	}
	
	@When("user entered the {string} details in background section of company profile")
	public void fillBackgroundInfoOfComapnyProfile(String sectionName, DataTable dataTable) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "EXPERTISE":
			List<Map<String, String>> expertiseList = CucumberUtils.getValuesFromDataTableAsList(dataTable);
			for (int i = 0; i < expertiseList.size(); i++) {
				subCompanyProfilePage.selectExpertise(expertiseList.get(i).get("Expertise"));
			}
			break;
		case "BIOGRAPHY":
			subCompanyProfilePage.fillBiogrpahyDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Bio-graphy"));
			break;
		case "TICKER":
			List<Map<String, String>> tickerList = CucumberUtils.getValuesFromDataTableAsList(dataTable);
			for (int i = 0; i < tickerList.size(); i++) {
				subCompanyProfilePage.fillTickerDetails(tickerList.get(i).get("Ticker"));
			}
			break;
		}
	}
	
	@When("user entered the {string} details in Contact info section of company profile")
	public void fillContactInfoOfComapnyProfile(String sectionName, DataTable dataTable) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "PHONE":
			subCompanyProfilePage.fillPhoneNumberDetails(CucumberUtils.getValuesFromDataTable(dataTable, "1-Phone"),
					CucumberUtils.getValuesFromDataTable(dataTable, "2-Phone"),
					CucumberUtils.getValuesFromDataTable(dataTable, "3-Phone"),
					CucumberUtils.getValuesFromDataTable(dataTable, "4-Phone"));
			break;
		case "EMAIL":
			subCompanyProfilePage.fillEmailDetails(CucumberUtils.getValuesFromDataTable(dataTable, "1-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "2-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "3-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "4-Email"));
			break;
		case "OTHER":
			subCompanyProfilePage.fillSocialMiscDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Twitter"),
					CucumberUtils.getValuesFromDataTable(dataTable, "LinkedIn"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Video"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Website"));
			;
			break;
		case "ADDRESS":
			subCompanyProfilePage.fillAddressDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Address-1"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Address-2"),
					CucumberUtils.getValuesFromDataTable(dataTable, "City"),
					CucumberUtils.getValuesFromDataTable(dataTable, "State"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Zip"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Country"));
			break;
		case "ALERT":
			subCompanyProfilePage.fillAlertsDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Alerts"));
			break;
		}
	}

	@When("user selected {string} favorite in Contact info section of company profile")
	public void selectFavorite(String sectionName, DataTable dataTable) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "PHONE":
			subCompanyProfilePage.selectFavoritePhone(CucumberUtils.getValuesFromDataTable(dataTable, "Phone"));
			break;
		case "EMAIL":
			subCompanyProfilePage.selectFavoriteEmail(CucumberUtils.getValuesFromDataTable(dataTable, "Email"));
			break;
		case "OTHER":
			subCompanyProfilePage.selectFavoriteSocialMisc(CucumberUtils.getValuesFromDataTable(dataTable, "Other"));
			break;
		}
	}

	@When("user clicked on {string} button")
	public void clickButton(String buttonType) throws Exception {
		subCompanyProfilePage.clickButton(buttonType);
	}



}
