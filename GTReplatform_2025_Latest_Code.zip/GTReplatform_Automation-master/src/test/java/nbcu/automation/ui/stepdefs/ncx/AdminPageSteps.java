package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.AdminPage;

public class AdminPageSteps {

	AdminPage adminPage = new AdminPage();

	@When("searches SSO in admin page")
	public void searchSso() throws Exception {
		adminPage.searchSso();
	}
	
	@When("clicks {string} link of user profile")
	public void clickEditAndDisbaleLink(String linkName) throws Exception {
		if(linkName.equalsIgnoreCase("EDIT"))
			adminPage.clickEditLink();
	}
	
	@Then("verify edit user popup is displayed")
	public void verifyEditUserPopUpDisplayed() throws Exception {
		adminPage.verifyEditUserPopup();
	}
	
	@Then("verify user captures user profile details")
	public void verifyUserCapturesProfileDetails() throws Exception {
		adminPage.fetchUserDetails();
	}

}
