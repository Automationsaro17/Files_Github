package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.AdminPage;
import nbcu.automation.ui.pages.ncx.HomePage;
import nbcu.automation.ui.pages.ncx.ProfilePage;

public class HomePageSteps {

	HomePage homePage = new HomePage();
	AdminPage adminPage = new AdminPage();
	ProfilePage profilePage = new ProfilePage();

	@Given("verify ncx home page is loaded")
	public void verifyHomePageLoaded() throws Exception {
		homePage.verifyHomePageLoaded();
	}

	@When("user opens {string} page")
	public void openAdminPage(String pageName) throws Exception {
		if (pageName.equalsIgnoreCase("ADMIN")) {
			homePage.openAdminPage();
			adminPage.verifyAdminPageLoaded();
		} else if (pageName.equalsIgnoreCase("PROFILE")) {
			homePage.clickProfile();
			profilePage.verifyProfilePageLoaded();
		}
	}

	@When("user clicks logs out link in NCX application")
	public void logOut() throws Exception {
		homePage.logOut();
	}

	@Then("verify application have been logged out")
	public void verifyLogOutSuccessfull() throws Exception {
		homePage.verifyApplicationLoggedOut();
	}
}
