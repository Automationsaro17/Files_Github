package nbcu.automation.ui.validation.common;

import org.testng.Assert;

import nbcu.automation.ui.constants.email.EmailConstants;
import nbcu.automation.ui.constants.gtreplatform.AdminConstants;
import nbcu.automation.ui.constants.gtreplatform.BookerProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.BookingGuestConstants;
import nbcu.automation.ui.constants.gtreplatform.GuestProfileConstants;
import nbcu.framework.utils.others.DateFunctions;

import java.util.LinkedHashSet;
import java.util.Set;

public class EmailValidation {

    /**
     * To validate email to list
     *
     * @param toOrCCList - To List / Cc List
     * @throws Throwable
     */
    public static void validateEmailToAndCcList(String toOrCCList, String bookingType) throws Throwable {
        StringBuilder expectedToList = new StringBuilder();
        StringBuilder expectedCcList = new StringBuilder();
        Set<String> expectedTo = new LinkedHashSet<String>();
        try {
            // Forming expected To and CC list
            if (BookerProfileConstants.getEmail1() != null)
                expectedTo.add(BookerProfileConstants.getEmail1());
            if (BookerProfileConstants.getEmail2() != null)
                expectedTo.add(BookerProfileConstants.getEmail2());
            if (BookerProfileConstants.getEmail3() != null)
                expectedTo.add(BookerProfileConstants.getEmail3());
            if (BookerProfileConstants.getEmail4() != null)
                expectedTo.add(BookerProfileConstants.getEmail4());

            // Expected CC list
            for (String emailAddress : expectedTo)
                expectedCcList.append(emailAddress).append(",");
            expectedCcList = new StringBuilder(expectedCcList.substring(0, expectedCcList.length() - 1));

            // Adding email alert address in To list

            //Add duplicate email alert email id if duplicate booking
            if (bookingType.equalsIgnoreCase("DUPLICATE BOOKING")) {
                expectedTo.clear();
                expectedTo.add(AdminConstants.getAlertEmailList().replace(" ", ""));
            }

            // Email alert email address
            int alertEmailCount = Integer.parseInt(BookingGuestConstants.getEmailAlertCount());
            for (int i = 0; i < alertEmailCount; i++)
                expectedTo.add(BookingGuestConstants.getEmailAlert(i));

            // Expected To List
            for (String emailAddress : expectedTo)
                expectedToList.append(emailAddress).append(",");
            expectedToList = new StringBuilder(expectedToList.substring(0, expectedToList.length() - 1));

            if (toOrCCList.equalsIgnoreCase("TO LIST")) {
                //To update jive@localhost email
                StringBuilder actualToList = new StringBuilder();
                if (EmailConstants.getEmailToList().contains("jive")) {
                    String[] actualToArray = EmailConstants.getEmailToList().split(",");
                    for (String emailAddress : actualToArray) {
                        if (emailAddress.contains("jive"))
                            actualToList.append("jive@localhost").append(",");
                        else actualToList.append(emailAddress).append(",");
                    }
                }
                actualToList = new StringBuilder(actualToList.substring(0, actualToList.length() - 1));
                Assert.assertEquals(actualToList.toString(), expectedToList.toString(),
                        "Email notification To list is not matched");
            } else if (toOrCCList.equalsIgnoreCase("CC LIST")) {
                //To update jive@localhost email
                StringBuilder actualCcList = new StringBuilder();
                if (EmailConstants.getEmailToList().contains("jive")) {
                    String[] actualToArray = EmailConstants.getEmailCcList().split(",");
                    for (String emailAddress : actualToArray) {
                        if (emailAddress.contains("jive"))
                            actualCcList.append("jive@localhost").append(",");
                        else actualCcList.append(emailAddress).append(",");
                    }
                }
                actualCcList = new StringBuilder(actualCcList.substring(0, actualCcList.length() - 1));
                Assert.assertEquals(actualCcList.toString(), expectedCcList.toString(),
                        "Email notification CC list is not matched");
            } else
                Assert.fail("Enter valid email content type");

        } catch (Exception | Error e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify email subject
     *
     * @throws Throwable
     */
    public static void validateSubject(String bookingType) throws Throwable {
        String expectSubject = "";
        try {
            // Forming expected subject
            String division = AdminConstants.getDivision();
            String guestName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();
            String showDate = BookingGuestConstants.getShowDate();
            String showTime = DateFunctions.convertDateStringToAnotherFormat(BookingGuestConstants.getShowTime(),
                    "HH:mm", "hh:mm:ss a");

            if ((bookingType.equalsIgnoreCase("NEW BOOKING")) || (bookingType.equalsIgnoreCase("EDITED BOOKING")))
                expectSubject = division + " Booking Alert: " + guestName + " on " + showDate + " " + showTime;
            else if (bookingType.equalsIgnoreCase("CANCEL BOOKING"))
                expectSubject = division + " Booking Alert: " + guestName + " on " + showDate;
            else if (bookingType.equalsIgnoreCase("DUPLICATE BOOKING")) {
                showTime = DateFunctions.convertDateStringToAnotherFormat(
                        BookingGuestConstants.getDuplicateBookingShowTime(), "HH:mm", "hh:mm:ss a");
                expectSubject = "[Duplicate Booking] " + guestName + " Booking is confirmed on " + division + " for " + showDate + " " + showTime;
                ;
            } else
                Assert.assertTrue(false, "Enter valid booking type for email subject validation");

            Assert.assertEquals(EmailConstants.getEmailSubject(), expectSubject,
                    "Email notification subject is not matched");

        } catch (Exception | Error e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify email body
     *
     * @param bodyContentName - content name
     * @throws Throwable
     */
    public static void validateEmailBody(String bookingType, String bodyContentName, String expectedValue)
            throws Throwable {
        String showDate = "", showTime = "";
        try {
            String actualEmailBody = EmailConstants.getEmailBody();

            // Forming expected email body
            String division = AdminConstants.getDivision();
            String guestName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();
            String showName = BookingGuestConstants.getShowName();
            String topicName = BookingGuestConstants.getTopicName();
            String studioName = BookingGuestConstants.getStudio();
            String bookingUrl = BookingGuestConstants.getBookingUrl();
            String bookerName = BookerProfileConstants.getBookerName();
            String bookingDate = BookingGuestConstants.getBookingDate();
            String bookingTime = DateFunctions.convertDateStringToAnotherFormat(BookingGuestConstants.getBookingTime(),
                    "HH:mm", "hh:mm:ss a");
            String bookingCancelledDate = BookingGuestConstants.getBookingCancellationDate();
            String bookingCancelledTime = BookingGuestConstants.getBookingCancellationTime();

            String technicalNotes = BookingGuestConstants.getBookingNotes();

            // Getting show date and time
            showDate = BookingGuestConstants.getShowDate();
            showTime = DateFunctions.convertDateStringToAnotherFormat(BookingGuestConstants.getShowTime(), "HH:mm",
                    "hh:mm:ss a");

            switch (bodyContentName.toUpperCase()) {
                case "HEADING":
                    if (bookingType.equalsIgnoreCase("DUPLICATE BOOKING"))
                        Assert.assertTrue(
                                actualEmailBody.contains("NBC Universal Guest Tracker - Duplicate Booking Alert:"),
                                "Email body header is not correct. Expected heading is 'NBC Universal Guest Tracker - Duplicate Booking Alert:'");
                    else
                        Assert.assertTrue(
                                (actualEmailBody.contains("NBC Universal Guest Tracker - Booking Alert:") || actualEmailBody
                                        .contains("NBC Universal Guest Tracker - " + division + " Booking Alert:")),
                                "Email body header is not correct. Expected heading is 'NBC Universal Guest Tracker - Booking Alert:'");
                    break;
                case "BOOKING CONFIRMED MESSAGE":
                    String expectedMessage = guestName + "'s Booking is confirmed on " + showName + " for " + showDate + " "
                            + showTime + ".";
                    Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedMessage.toLowerCase()),
                            "Booking confirmation message in email body is not correct. Expected confirmation message is '"
                                    + expectedMessage + "'");
                    break;
                case "BOOKING CANCELLED MESSAGE":
                    String expectedCancelledMessage = "The following show has been cancelled ";
                    Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedCancelledMessage.toLowerCase()),
                            "Booking confirmation message in email body is not correct. Expected confirmation message is '"
                                    + expectedCancelledMessage + "'");
                    break;
                case "TOPIC":
                    String expectedTopic = "Topic: " + topicName;
                    Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedTopic.toLowerCase()),
                            "Topic name in email body is not correct. Expected topic is '" + expectedTopic + "'");
                    break;
                case "STUDIO":
                    String expectedStudio = "Studio/Other Location: " + studioName;
                    Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedStudio.toLowerCase()),
                            "Studio in email body is not correct. Expected studio is '" + expectedStudio + "'");
                    break;
                case "FEED":
                    String expectedFeed = "Feed: " + expectedValue;
                    Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedFeed.toLowerCase()),
                            "Feed in email body is not correct. Expected feed is '" + expectedFeed + "'");
                    break;
                case "MAKEUP":
                    String expectedMakeUp = "Makeup: " + expectedValue;
                    Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedMakeUp.toLowerCase()),
                            "Make up in email body is not correct. Expected makeup is '" + expectedMakeUp + "'");
                    break;
                case "CAR":
                    String expectedCar = "Car: " + expectedValue;
                    Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedCar.toLowerCase()),
                            "Car in email body is not correct. Expected car is '" + expectedCar + "'");
                    break;
                case "TECHNICAL NOTES":
                    String expectedTechnicalNotes = "Technical Notes: " + technicalNotes;
                    Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedTechnicalNotes.toLowerCase()),
                            "Technical notes in email body is not correct. Expected teachnical notes is '"
                                    + expectedTechnicalNotes + "'");
                    break;
                case "BOOKING URL":
                    String expectedBookingUrl = "Details are available for viewing at: »" + bookingUrl;
                    Assert.assertTrue(
                            actualEmailBody.toLowerCase().replace(" https", "https")
                                    .contains(expectedBookingUrl.toLowerCase()),
                            "Booking url in email body is not correct. Expected booking url is '" + expectedBookingUrl
                                    + "'");
                    break;
                case "BOOKER DETAIL":
                    String expectedBookerDetail = "";
                    expectedBookerDetail = "This guest was booked by: " + bookerName + " (on " + bookingDate + " at "
                            + bookingTime + ")";
                    Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedBookerDetail.toLowerCase()),
                            "Booker details in email body is not correct. Expected booker detail is '"
                                    + expectedBookerDetail + "'");
                    break;
                default:
                    Assert.fail("Please provide valid content name of email body");
            }
        } catch (Exception | Error e) {
            e.fillInStackTrace();
            throw e;
        }
    }

}
