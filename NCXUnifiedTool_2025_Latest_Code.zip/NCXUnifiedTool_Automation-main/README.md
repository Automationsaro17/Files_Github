# NCXUnifiedTool_Automation
Both UI &amp; API validations can be done using the NCXUnifiedTool Automation framework 
