package nbcu.automation.api.pojo;

public class CnbcAvid {
	public String avidBinName;
    public String avidProjectName;
    public String avidWorkspace;
	public String getAvidBinName() {
		return avidBinName;
	}
	public void setAvidBinName(String avidBinName) {
		this.avidBinName = avidBinName;
	}
	public String getAvidProjectName() {
		return avidProjectName;
	}
	public void setAvidProjectName(String avidProjectName) {
		this.avidProjectName = avidProjectName;
	}
	public String getAvidWorkspace() {
		return avidWorkspace;
	}
	public void setAvidWorkspace(String avidWorkspace) {
		this.avidWorkspace = avidWorkspace;
	}
}
