package nbcu.automation.ui.enums;

public enum RequestMode {
	CREATE,EDIT,READONLY;
}
