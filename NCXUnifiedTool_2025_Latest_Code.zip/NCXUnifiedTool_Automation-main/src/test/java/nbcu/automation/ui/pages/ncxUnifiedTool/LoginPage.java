package nbcu.automation.ui.pages.ncxUnifiedTool;

import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.encryption.PasswordEncryption;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import nbcu.framework.utils.ui.Waits;
import nbcu.framework.utils.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.utils.ui.WebAction;
import nbcu.automation.ui.constants.ncxUnifiedTool.Constants;
import nbcu.automation.ui.enums.UserRole;

public class LoginPage {

    @FindBy(name = "loginfmt")
    WebElement userNameTextBox;

    String userAccountSelection = "//div[contains(text(),'<<sso>>')]";

    @FindBy(id = "idSIButton9")
    WebElement nextButton;

    @FindBy(name = "passwd")
    WebElement passwordTextBox;

    @FindBy(xpath = "//div[text()='Stay signed in?']")
    WebElement staySignedInElement;

    public LoginPage() {
        //Constants.initConstants();
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    public void navigateApplication() throws Exception {
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			driver.navigate().to(ConfigFileReader.getProperty("prodreq-app-url"));
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
    /**
     * To open NCX rights management application in different environment
     */
    public void openApplication() throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        String environment, applicationUrl = "";
        try {
            // Fetch the application url based on application and environment
            environment = ConfigFileReader.getProperty("environment");
            applicationUrl = switch (environment.toUpperCase()) {
                case "QA" -> ConfigFileReader.getProperty("prodreq-app-url-Qa");
                case "QAUI" -> ConfigFileReader.getProperty("prodreq-app-url-QAUI");
                case "STG" -> ConfigFileReader.getProperty("prodreq-app-url-Stg");
                case "STGUI" -> ConfigFileReader.getProperty("prodreq-app-url-STGUI");
                case "PROD" -> ConfigFileReader.getProperty("prodreq-app-url");
                default -> applicationUrl;
            };

            // Launch the application
            if (driver != null) {
            	driver.manage().deleteAllCookies();
                driver.get(applicationUrl);
            }else Assert.fail("Browser is not launched");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify sign in page is displayed
     * <p>
     * - exception
     */
    public void verifySignInPageDisplayed() throws Exception {
        Waits.waitForElement(userNameTextBox, WAIT_CONDITIONS.VISIBLE);
    }

    /**
     * To Login NCX rights management application
     *
     * @param role - NCX Role
     */
    public void loginIntoApplication(String role) throws Exception {
    	
    	
    	String userNameText = "", passwordText = "",displayName="";

		try {
			switch (role.toUpperCase()) {
			case "PRODUCER":
				userNameText = ConfigFileReader.getProperty("producer-username");
				passwordText = ConfigFileReader.getProperty("producer-password");
				displayName  = ConfigFileReader.getProperty("producer-name");
				Constants.setUserRole(UserRole.PRODUCER);
				break;
			case "FULFILLER":
				userNameText = ConfigFileReader.getProperty("ncx-fulfiller-username");
				passwordText = ConfigFileReader.getProperty("ncx-fulfiller-password");
				displayName  = ConfigFileReader.getProperty("fulfiller-name");
				Constants.setUserRole(UserRole.FULFILLER);
				break;
			case "ADMIN":
				userNameText = ConfigFileReader.getProperty("ncx-admin-username");
				passwordText = ConfigFileReader.getProperty("ncx-admin-password");
				Constants.setUserRole(UserRole.ADMIN);
				break;

			}
        WebDriver driver = DriverFactory.getCurrentDriver();
        String userName = userNameText, password = passwordText;

            userName = userName + "@tfayd.com";
            if (WebAction.isDisplayed(userNameTextBox))
                WebAction.sendKeys(userNameTextBox, userName);
            else {
                assert driver != null;
                WebAction.click(driver.findElement(By.xpath(userAccountSelection.replace("<<sso>>", userName))));
            }
            WebAction.click(nextButton);
            String decryptedPassword = PasswordEncryption.decrypt(password);
            Waits.waitForElement(passwordTextBox, WAIT_CONDITIONS.VISIBLE);
            WebAction.sendKeys(passwordTextBox, decryptedPassword);
            WebAction.click(nextButton);
            Waits.waitForElement(staySignedInElement, WAIT_CONDITIONS.VISIBLE);
            WebAction.click(nextButton);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

}
