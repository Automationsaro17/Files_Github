package nbcu.framework.Wrapper.ui;

import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;


public class Waits {

    /**
     * To make driver to wait for particular condition.It will throw timeout
     * exception if max wait time is reached
     *
     * @param element       - Web Element
     * @param waitCondition - CLICKABLE/VISIBLE/INVISBLE
     * @throws Exception - If condition not satisfied for max wait time, it will
     *                   throw time out exception
     */
    public static void waitForElement(WebElement element, WAIT_CONDITIONS waitCondition) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            WebDriverWait wait = new WebDriverWait(driver,
                    Duration.ofSeconds(Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"))));
            switch (waitCondition) {
                case CLICKABLE:
                    wait.until(ExpectedConditions.elementToBeClickable(element));
                    break;
                case VISIBLE:
                    wait.until(ExpectedConditions.visibilityOf(element));
                    break;
                case INVISIBLE:
                    wait.until(ExpectedConditions.invisibilityOf(element));
                    break;
                default:
                    Assert.assertTrue(false, "provide valid wait condition");
                    break;

            }
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("wait error");
            e.printStackTrace();
            throw new Exception("wait condition has been failed");
        }
    }

    ;

    /**
     * To make driver to wait for particular condition.It will throw timeout
     * exception if max wait time is reached
     *
     * @param by            - By
     * @param waitCondition - CLICKABLE/VISIBLE/INVISBLE
     * @throws Exception
     */
    public static void waitForElement(By by, WAIT_CONDITIONS waitCondition) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            WebDriverWait wait = new WebDriverWait(driver,
                    Duration.ofSeconds(Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"))));
            switch (waitCondition) {
                case CLICKABLE:
                    wait.until(ExpectedConditions.elementToBeClickable(by));
                    break;
                case VISIBLE:
                    wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(by));
                    break;
                case INVISIBLE:
                    wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
                    break;
                default:
                    Assert.assertTrue(false, "provide valid wait condition");
                    break;

            }
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("wait error");
            e.printStackTrace();
            throw new Exception("wait condition has been failed");
        }
    }

    ;

    /**
     * To make driver to wait for particular condition.It will throw timeout
     * exception if max wait time is reached
     *
     * @param elements      - List of Web Elements
     * @param waitCondition - Maximum wait time
     * @throws Exception - If condition not satisfied for max wait time, it will
     *                   throw time out exception
     */
    public static void waitForAllElements(List<WebElement> elements, WAIT_CONDITIONS waitCondition) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            WebDriverWait wait = new WebDriverWait(driver,
                    Duration.ofSeconds(Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"))));
            switch (waitCondition) {
                case VISIBLE:
                    wait.until(ExpectedConditions.visibilityOfAllElements(elements));
                    break;
                case INVISIBLE:
                    wait.until(ExpectedConditions.invisibilityOfAllElements(elements));
                    break;
                default:
                    Assert.assertTrue(false, "provide valid wait condition");
                    break;

            }
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("wait error");
            e.printStackTrace();
            throw new Exception("wait condition has been failed");
        }
    }

    /**
     * To wait until the element size is greater than given count
     *
     * @param elements
     * @param count
     * @throws Exception
     */
    public static void waitUntilElementSizeGreater(List<WebElement> elements, int count) throws Exception {
        try {
            int intialWaitCount = 0;
            while (intialWaitCount < Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"))) {
                Thread.sleep(1000);
                if (elements.size() > count) {
                    Thread.sleep(1000);
                    break;
                }
                intialWaitCount++;
            }

            if (intialWaitCount == Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time")))
                throw new Exception("wait condition has been failed");

        } catch (Exception e) {
            // AllureUtility.captureScreenshot("wait error");
            e.printStackTrace();
            throw new Exception("wait condition has been failed");
        }
    }

    /**
     * To wait until drop down list has options
     *
     * @param count
     * @throws Exception
     */
    public static void waitUntilElementSizeGreater(By by, int count) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            int intialWaitCount = 0;
            while (intialWaitCount < Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"))) {
                Thread.sleep(1000);
                List<WebElement> elements = driver.findElements(by);
                if (elements.size() > count) {
                    Thread.sleep(1000);
                    break;
                }
                intialWaitCount++;

                if (intialWaitCount >= Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time")))
                    throw new Exception("wait condition has been failed");
            }

        } catch (Exception e) {
            // AllureUtility.captureScreenshot("wait error");
            e.printStackTrace();
            throw new Exception("wait condition has been failed");
        }
    }

    /**
     * To wait until element attribute value equal to expected value
     *
     * @param element        - element
     * @param attributeName  - attribute name
     * @param attributeValue - attribute value
     * @throws Exception
     */
    public static void waitUntilAttributeValueToBe(WebElement element, String attributeName, String attributeValue)
            throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            WebDriverWait wait = new WebDriverWait(driver,
                    Duration.ofSeconds(Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"))));
            wait.until(ExpectedConditions.attributeToBe(element, attributeName, attributeValue));
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("wait error");
            e.printStackTrace();
            throw new Exception("wait condition has been failed");
        }
    }

    /**
     * To wait until element attribute value contains expected value
     *
     * @param element        - element
     * @param attributeName  - attribute name
     * @param attributeValue - attribute value
     * @throws Exception
     */
    public static void waitUntilAttributeValueContains(WebElement element, String attributeName, String attributeValue)
            throws Exception {
        try {
            int intialWaitCount = 0;
            int maxTimeOut = Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"));
            while (intialWaitCount < maxTimeOut) {
                Thread.sleep(1000);
                if (WebAction.getAttribute(element, attributeName).toUpperCase().contains(attributeValue.toUpperCase())) {
                    break;
                }
                intialWaitCount++;
                if (intialWaitCount >= maxTimeOut)
                    throw new Exception("wait condition has been failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("wait condition has been failed");
        }
    }

    /**
     * To wait until element text value is changed to expected value
     *
     * @param element
     * @param expectedText
     * @throws Exception
     */
    public static void waitUntilTextValueChanges(WebElement element, String expectedText) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            WebDriverWait wait = new WebDriverWait(driver,
                    Duration.ofSeconds(Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"))));
            wait.until(ExpectedConditions.textToBePresentInElement(element, expectedText));
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("wait error");
            e.printStackTrace();
            throw new Exception("wait condition has been failed");
        }
    }

    /**
     * To wait until new window get opened
     *
     * @param windowSize
     * @throws Exception
     */
    public static void waitForNumberOfWindowsToBe(int windowSize)
            throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            WebDriverWait wait = new WebDriverWait(driver,
                    Duration.ofSeconds(Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"))));
            wait.until(ExpectedConditions.numberOfWindowsToBe(windowSize));
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("New Window is not opened");
        }
    }

    /**
     * To wait for element to is displayed
     *
     * @param element - web element
     * @return
     * @throws Exception
     */
    public static boolean waitForElementIsDisplayed(WebElement element) throws Exception {
        boolean isDisplayed = false;
        try {
            int intialWaitCount = 0;
            int maxTimeOut = Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"));
            while (intialWaitCount < maxTimeOut) {
                Thread.sleep(1000);
                if (WebAction.isDisplayed(element)) {
                    isDisplayed = true;
                    break;
                }
                intialWaitCount++;

                if (intialWaitCount >= maxTimeOut)
                    break;
            }

        } catch (Exception e) {
            //do nothing

        }
        return isDisplayed;
    }

    /**
     * To wait for element to disappear
     *
     * @param element
     * @return
     * @throws Exception
     */
    public static boolean waitForElementToDisappear(WebElement element) throws Exception {
        boolean isDisplayed = true;
        try {
            int intialWaitCount = 0;
            int maxTimeOut = Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"));
            while (intialWaitCount < maxTimeOut) {
                Thread.sleep(1000);
                if (!WebAction.isDisplayed(element)) {
                    isDisplayed = false;
                    Thread.sleep(1000);
                    break;
                }
                intialWaitCount++;

                if (intialWaitCount >= maxTimeOut)
                    break;
            }

        } catch (Exception e) {

        }
        return isDisplayed;
    }

    public enum WAIT_CONDITIONS {
        CLICKABLE, VISIBLE, INVISIBLE, LESS_THAN, GREATER_THAN, EQUAL_TO
    }

}
