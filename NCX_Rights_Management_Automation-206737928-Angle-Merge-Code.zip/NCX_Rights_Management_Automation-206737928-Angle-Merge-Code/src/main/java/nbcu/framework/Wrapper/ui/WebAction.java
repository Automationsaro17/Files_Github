package nbcu.framework.Wrapper.ui;

import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class WebAction {
    /**
     * To clear the text box, then enter value in text box
     *
     * @param element   - Web Element
     * @param inputText - Text to be entered in text box
     * @throws Exception
     */
    public static void sendKeys(WebElement element, String inputText) throws Exception {
        try {
            element.clear();
            element.sendKeys(inputText);
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("webelement send keys error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To enter value in text box
     *
     * @param element
     * @param inputText
     */
    public static void sendKeys_WithoutClear(WebElement element, String inputText) {
        try {
            element.sendKeys(inputText);
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("webelement send keys error");
            e.printStackTrace();
            throw e;
        }
    }

    public static void sendKeys_WithTimeGap(WebElement element, String inputText) throws Exception {
        try {
            element.clear();
            for (int i = 0; i < inputText.length(); i++) {
                Thread.sleep(50);
                element.sendKeys(inputText.substring(i, i + 1));
            }
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("webelement send keys error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To click button/Web element
     *
     * @param element - Web Element
     * @throws Exception
     */
    public static void click(WebElement element) throws Exception {
        try {
            Waits.waitForElement(element, WAIT_CONDITIONS.VISIBLE);
            Waits.waitForElement(element, WAIT_CONDITIONS.CLICKABLE);
            element.click();
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("webelement click error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To clear text box
     *
     * @param element
     * @throws Exception
     */
    public static void clearUsingKeys(WebElement element) throws Exception {
        try {
            click(element);
            Thread.sleep(1000);
            element.sendKeys(Keys.CONTROL + "A");
            element.sendKeys(Keys.ENTER);
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("webelement click error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To double click the element
     *
     * @param element - Web Element
     * @throws Exception
     */
    public static void doubleClick(WebElement element) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            Waits.waitForElement(element, WAIT_CONDITIONS.VISIBLE);
            Waits.waitForElement(element, WAIT_CONDITIONS.CLICKABLE);
            Actions action = new Actions(driver);
            action.doubleClick(element).perform();
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("webelement click error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To clear value in text box
     *
     * @param element - Web Element
     */
    public static void clear(WebElement element) {
        try {
            element.clear();
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("webelement clear error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To select value from drop down
     *
     * @param element       - Web Element
     * @param selectionType - VISIBLETEXT/VALUE/INDEX
     * @param value         - Value for drop down
     */
    public static void selectDropDown(WebElement element, String selectionType, String value) {
        try {
            Select select = new Select(element);
            switch (selectionType.toUpperCase()) {
                case "VISIBLETEXT":
                    select.selectByVisibleText(value);
                    break;
                case "VALUE":
                    select.selectByValue(value);
                    break;
                case "INDEX":
                    select.selectByIndex(Integer.parseInt(value));
                    break;
                default:
                    Assert.assertTrue(false, "Given selection type is not valid-" + selectionType);
                    break;
            }
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("dropdown select error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fetch selected value from drop down
     *
     * @param element - Web Element
     * @return
     */
    public static String getDropDownSelectedValue(WebElement element) {
        String selectedValue = "";
        try {
            Select select = new Select(element);
            WebElement selectedElement = select.getFirstSelectedOption();
            selectedValue = WebAction.getText(selectedElement);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return selectedValue;
    }

    /**
     * To select value from drop down in angular JS application
     *
     * @param inputElement        - To input value in the text box
     * @param value               - value to select
     * @param dropDownvaluesXpath - Drop down options xpath
     * @param failureMessage      - failure message if given value is not present in
     *                            the drop down
     * @throws Exception
     */
    public static void selectDropDown(WebElement inputElement, String value, String dropDownvaluesXpath, String failureMessage) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            boolean valuePresent = false;
            Waits.waitForElement(inputElement, WAIT_CONDITIONS.CLICKABLE);
            sendKeys(inputElement, value);
            Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
            Thread.sleep(1500);
            List<WebElement> dropDownvalues = driver.findElements(By.xpath(dropDownvaluesXpath));
            for (WebElement ele : dropDownvalues) {
                if (WebAction.getAttribute(ele, "title").trim().equalsIgnoreCase(value)) {
                    if (WebAction.isDisplayed(ele)) {
                        WebAction.click(ele);
                        valuePresent = true;
                        break;
                    }
                }
            }
            if (valuePresent == false)
                throw new Exception(failureMessage);
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("dropdown select error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To select drop down where value is in text
     *
     * @param inputElement
     * @param value
     * @param dropDownvaluesXpath
     * @param failureMessage
     * @throws Exception
     */
    public static void selectNonTitleDropDown(WebElement inputElement, String value, String dropDownvaluesXpath,
                                              String failureMessage) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            boolean valuePresent = false;
            Waits.waitForElement(inputElement, WAIT_CONDITIONS.CLICKABLE);
            sendKeys(inputElement, value);
            Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
            Thread.sleep(1000);
            List<WebElement> dropDownvalues = driver.findElements(By.xpath(dropDownvaluesXpath));
            for (WebElement ele : dropDownvalues) {
                if (WebAction.getText(ele).trim().equalsIgnoreCase(value)) {
                    if (WebAction.isDisplayed(ele)) {
                        WebAction.click(ele);
                        valuePresent = true;
                        break;
                    }
                }
            }
            if (valuePresent == false)
                throw new Exception(failureMessage);

        } catch (Exception e) {
            // AllureUtility.captureScreenshot("dropdown select error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To select drop down where input is not available
     *
     * @param dropDownvaluesXpath
     * @param value
     * @param failureMessage
     * @throws Exception
     */
    public static void nonEnterableSelectDropDown(String dropDownvaluesXpath, String value, String failureMessage)
            throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            boolean valuePresent = false;

            outer:
            while (true) {
                Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
                Thread.sleep(1000);
                List<WebElement> dropDownValues = driver.findElements(By.xpath(dropDownvaluesXpath));
                String pageSourceBeforeScroll = driver.getPageSource();
                for (int i = 0; i < dropDownValues.size(); i++) {
                    if (WebAction.getAttribute(dropDownValues.get(i), "title").equalsIgnoreCase(value)) {
                        WebAction.mouseOver(dropDownValues.get(i));
                        WebAction.scrollIntoView(dropDownValues.get(i));
                        Thread.sleep(1000);
                        WebAction.clickUsingJs(dropDownValues.get(i));
                        valuePresent = true;
                        break outer;

                    }
                }
                System.out.println();
                WebAction.mouseOver(dropDownValues.get(0));
                WebAction.scrollIntoView(dropDownValues.get(dropDownValues.size() - 1));
                String pageSourceAfterScroll = driver.getPageSource();
                if (pageSourceBeforeScroll.equalsIgnoreCase(pageSourceAfterScroll))
                    break;
            }
            if (valuePresent == false)
                throw new Exception(failureMessage);
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("dropdown select error");
            e.printStackTrace();
            throw e;
        }
    }
    
    /**
	 * To select drop down where value is in text
	 *
	 * @param inputElement
	 * @param value
	 * @param dropDownvaluesXpath
	 * @param failureMessage
	 * @throws Exception
	 */
	public static void selectNonTitleDropDown1(WebElement inputElement, String value, String dropDownvaluesXpath,
			String failureMessage) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			boolean valuePresent = false;
			Waits.waitForElement(inputElement, WAIT_CONDITIONS.CLICKABLE);
			sendKeys(inputElement, value);
			Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
			Thread.sleep(5000);
			List<WebElement> dropDownvalues = driver.findElements(By.xpath(dropDownvaluesXpath));
			for (WebElement ele : dropDownvalues) {
				if (WebAction.getText(ele).trim().equalsIgnoreCase(value)) {
					if (WebAction.isDisplayed(ele)) {
						Thread.sleep(1000);
						WebAction.clickUsingJs(ele);
						Thread.sleep(1000);
						valuePresent = true;
						break;
					}
				}
			}
			if (valuePresent == false)
				throw new Exception(failureMessage);

		} catch (Exception e) {
			// AllureUtility.captureScreenshot("dropdown select error");
			e.printStackTrace();
			throw e;
		}
	}

    

    /**
     * To select any available drop down value based search text
     *
     * @param inputElement        - Input Element
     * @param searchText          - Search Text
     * @param dropDownvaluesXpath - Drop down values xpath
     * @param failureMessage      - Failure Message
     * @throws Exception
     */
    public static String selectDropDownBySearchText(WebElement inputElement, String searchText, String dropDownvaluesXpath, String failureMessage) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        String secondaryStory = "";
        try {
            Waits.waitForElement(inputElement, WAIT_CONDITIONS.CLICKABLE);
            sendKeys(inputElement, searchText);
            Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
            Thread.sleep(1500);
            List<WebElement> dropDownvalues = driver.findElements(By.xpath(dropDownvaluesXpath));
            if (dropDownvalues.size() > 0) {
                WebAction.click(dropDownvalues.get(dropDownvalues.size() - 1));
                WebAction.getText(dropDownvalues.get(dropDownvalues.size() - 1));
            } else Assert.assertTrue(false, failureMessage);
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("dropdown select error");
            e.printStackTrace();
            throw e;
        }
        return secondaryStory;
    }

    /**
     * To mover over on web element
     *
     * @param element - Web Element
     * @throws Exception
     */
    public static void mouseOver(WebElement element) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            Thread.sleep(1000);
            Actions action = new Actions(driver);
            action.moveToElement(element).build().perform();
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("Mouse over error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To mouse over and click
     *
     * @param mouseOverElement
     * @param clickElement
     * @throws Exception
     */
    public static void mouseOverAndClick(WebElement mouseOverElement, WebElement clickElement) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            Actions action = new Actions(driver);
            action.moveToElement(mouseOverElement).build().perform();
            Thread.sleep(1000);
            action.click(clickElement).build().perform();
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("Mouse over error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To click web element using java script
     *
     * @param element - Web Element
     * @throws Exception
     */
    public static void clickUsingJs(WebElement element) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            // Waits.waitForElement(element, WAIT_CONDITIONS.CLICKABLE);
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", element);
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("javascript click error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To get text of web element
     *
     * @param element - Web Element
     * @return - web element text
     */
    public static String getText(WebElement element) {
        String elementText = "";
        try {
            elementText = element.getText().trim();
            if (elementText.equals("")) {
                JavascriptExecutor js = (JavascriptExecutor) DriverFactory.getCurrentDriver();
                elementText = (String) js.executeScript("return arguments[0].innerText;", element);
            }
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("get text error");
            e.printStackTrace();
            throw e;
        }
        return elementText;
    }

    /**
     * To get the attribute value
     *
     * @param element - Web Element
     * @return - attribute value
     */
    public static String getAttribute(WebElement element, String attributeName) {
        String attributeValue = "";
        try {
            attributeValue = element.getAttribute(attributeName).trim();
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("get attribute error");
            e.printStackTrace();
            throw e;
        }
        return attributeValue;
    }

    /**
     * To get the CSS property values
     *
     * @param element     - Web Element
     * @param cssProperty - CSS property
     * @return
     */
    public static String getCssValue(WebElement element, String cssProperty) {
        String cssValue = "";
        try {
            cssValue = element.getCssValue(cssProperty);
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("get CSS value error");
            e.printStackTrace();
            throw e;
        }
        return cssValue;
    }

    /**
     * To get the location of the element
     *
     * @param element - Web Element
     * @return
     */
    public static Point getLocation(WebElement element) {
        Point point;
        try {
            point = element.getLocation();
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("get location error");
            e.printStackTrace();
            throw e;
        }
        return point;
    }

    /**
     * To verify element is displayed
     *
     * @param element - Web Element
     * @return - true/false
     */
    public static boolean isDisplayed(WebElement element) {
        boolean isDiplayed = false;
        try {
            if (element.isDisplayed())
                isDiplayed = true;

        } catch (Exception e) {

        }
        return isDiplayed;
    }

    /**
     * To verify element is Enabled
     *
     * @param element - Web Element
     * @return - true/false
     */
    public static boolean isEnabled(WebElement element) {
        boolean isEnabled = false;
        try {
            if (element.isEnabled())
                isEnabled = true;

        } catch (Exception e) {

        }
        return isEnabled;
    }

    /**
     * To verify check box/Radio button is already selected
     *
     * @param element
     * @return
     */
    public static boolean isSelected(WebElement element) {
        boolean isSelected = false;
        try {
            if (element.isSelected())
                isSelected = true;

        } catch (Exception e) {
            //do nothing
        }
        return isSelected;
    }

    /**
     * To open to given url
     *
     * @param applicationUrl - url of the application/page
     */
    public static void get(String applicationUrl) {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            driver.get(applicationUrl);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To navigate to given url
     *
     * @param applicationUrl - url of the application/page
     */
    public static void navigateTo(String applicationUrl) {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            driver.navigate().to(applicationUrl);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To scroll into element
     *
     * @param ele - Web Element
     * @throws Exception
     */
    public static void scrollIntoView(WebElement ele) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].scrollIntoView(true);", ele);
            Thread.sleep(500);
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("Not able to scroll");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To scroll down page
     */
    public static void scrollDown() {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy(0,250)", "");
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("Not able to scroll");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To scroll up
     */
    public static void scrollUp() {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy(250,0)", "");
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("Not able to scroll");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To switch to frame using frame id
     *
     * @param frameId
     * @throws Exception
     */
    public static void switchToFrame(String frameId) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            WebDriverWait wait = new WebDriverWait(driver,
                    Duration.ofSeconds(Integer.parseInt(ConfigFileReader.getProperty("max-wait-time"))));
            wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameId));
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("iframe switch error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To switch to frame using element
     *
     * @param element
     * @throws Exception
     */
    public static void switchToFrame(WebElement element) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            WebDriverWait wait = new WebDriverWait(driver,
                    Duration.ofSeconds(Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"))));
            wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(element));
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("iframe switch error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To switch to frame using index
     *
     * @param index
     * @throws Exception
     */
    public static void switchToFrame(int index) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            WebDriverWait wait = new WebDriverWait(driver,
                    Duration.ofSeconds(Integer.parseInt(ConfigFileReader.getProperty("Max-Wait-Time"))));
            wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(index));
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("iframe switch error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To come out of frame
     *
     * @throws Exception
     */
    public static void switchToDefaultContent() throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            driver.switchTo().defaultContent();
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("switch main window error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To refresh current page
     *
     * @throws Exception
     */
    public static void refreshPage() throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            driver.navigate().refresh();
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("switch main window error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To get current page url
     *
     * @throws Exception
     */
    public static String getCurrentUrl() throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        String currentUrl = "";
        try {
            currentUrl = driver.getCurrentUrl();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return currentUrl;
    }

    /**
     * To press key board key
     *
     * @param element
     * @param keyType
     * @throws Exception
     */
    public static void keyPress(WebElement element, String keyType) throws Exception {
        try {
            switch (keyType.toUpperCase()) {
                case "DOWN":
                    element.sendKeys(Keys.ARROW_DOWN);
                    break;
                case "ENTER":
                    element.sendKeys(Keys.ENTER);
                    break;
                case "SPACE":
                    element.sendKeys(Keys.BACK_SPACE);
                    break;
                case "ESC":
                    element.sendKeys(Keys.ESCAPE);
                    break;
                case "TAB":
                    element.sendKeys(Keys.TAB);
                    break;
            }
        } catch (Exception e) {
            // AllureUtility.captureScreenshot("webelement send keys error");
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To get parent current window id
     *
     * @return
     * @throws Exception
     */
    public static String getCurrentWindowId() throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        String windowId = "";
        try {
            windowId = driver.getWindowHandle();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return windowId;
    }

    /**
     * To switch to newly opened window
     *
     * @param windowSize     - number of windows
     * @param parentWindowId - parent window id
     * @throws Exception
     */
    public static void switchToNewWindow(int windowSize, String parentWindowId) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        boolean windowSwitchCheck = false;
        try {
            Waits.waitForNumberOfWindowsToBe(windowSize);
            Set<String> windowsList = driver.getWindowHandles();
            for (String windowId : windowsList) {
                if (!(windowId.equalsIgnoreCase(parentWindowId))) {
                    driver.switchTo().window(windowId);
                    windowSwitchCheck = true;
                    break;
                }
            }

            Assert.assertTrue(windowSwitchCheck, "Window switch is failed");

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To switch to parent window
     *
     * @param parentWindowId - parent window id
     * @throws Exception
     */
    public static void switchToParentWindow(String parentWindowId) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            driver.switchTo().window(parentWindowId);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To open new tab and switch to it
     *
     * @throws Exception
     */
    public static void openNewTabAndSwitchToIt() throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            driver.switchTo().newWindow(WindowType.TAB);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
    
   
	/**
	 * To get title of the window
	 */
	public static String getWindowTitle() {
		String title = "";
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			title = driver.getTitle();
			return title;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	/**
	 * To check element is clickable or not
	 * 
	 * @param element - Web Element
	 * @throws Exception
	 */
	public static boolean isClickable(WebElement element) throws Exception {
		try {
			Waits.waitForElement(element, WAIT_CONDITIONS.VISIBLE);
			Waits.waitForElement(element, WAIT_CONDITIONS.CLICKABLE);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
