package nbcu.framework.utils.others;

import java.util.Comparator;
import java.util.Date;

public class DateComparator implements Comparator<Date> {
    @Override
    public int compare(Date date1, Date date2) {
        return date2.compareTo(date1);
    }
}
