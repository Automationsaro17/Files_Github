package nbcu.framework.utils.others;

import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FolderFunctions {

    /**
     * To delete all files from given folder
     *
     * @param path - Folder Path
     * @throws Exception
     */
    public static void clearFolder(String path) throws Exception {
        try {
            FileUtils.cleanDirectory(new File(path));
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }


    /**
     * To get all file names from given folder
     *
     * @param path - Folder Path
     * @return - All file names
     * @throws Exception
     */
    public static List<String> getFileNameFromFolder(String path) throws Exception {
        List<String> fileNamesList = new ArrayList<String>();
        try {
            // Using File class create an object for specific directory
            File directory = new File(path);
            File[] files = directory.listFiles();

            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    fileNamesList.add(files[i].getName());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return fileNamesList;
    }

    public static void main(String[] args) throws Exception {
        System.out.println(System.getProperty("user.dir") + "\\" + ConfigFileReader.getProperty("File-Download-Path"));
        clearFolder(System.getProperty("user.dir") + "\\" + ConfigFileReader.getProperty("File-Download-Path"));
    }
}
