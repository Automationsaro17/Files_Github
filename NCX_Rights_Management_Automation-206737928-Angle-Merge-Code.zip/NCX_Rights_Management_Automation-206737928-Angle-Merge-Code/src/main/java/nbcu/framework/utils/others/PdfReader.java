package nbcu.framework.utils.others;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.File;

public class PdfReader {

    /**
     * To read PDF file
     *
     * @param path - PDF file path
     * @return
     * @throws Exception
     */
    public static String readPdfFile(String path) throws Exception {
        String pdfContent = null;
        try {
            File file = new File(path);
            PDDocument document = PDDocument.load(file);
            PDFTextStripper stripper = new PDFTextStripper();
            pdfContent = stripper.getText(document);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return pdfContent;
    }
    
}
