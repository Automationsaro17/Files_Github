package nbcu.framework.utils.report;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import nbcu.framework.factory.DriverFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ExtentReportUtils {

    /**
     * To capture screenshot
     *
     * @return
     */
    public static String getBase64Screenshot() {
        WebDriver driver = DriverFactory.getCurrentDriver();
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
    }

    /**
     * To add failure screenshot in the current step
     */
    public static void addFailureScreenShot() {
        try {
            ExtentCucumberAdapter.getCurrentStep().log(Status.FAIL, MediaEntityBuilder.createScreenCaptureFromBase64String(getBase64Screenshot()).build());
        } catch (Exception e) {

        }
    }

    /**
     * To log message in report
     *
     * @param status     - Status.PASS, Status.INFO, Status.WARNING, Status.FAIL
     * @param logMessage
     */
    public static void addLog(Status status, String logMessage) {
        try {
            ExtentCucumberAdapter.getCurrentStep().log(status, logMessage);
        } catch (Exception e) {

        }
    }

}
