package nbcu.automation.ui.constants.ncx;

import java.util.HashMap;

public class AngleConstants {

	private static final ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
		@Override
		protected HashMap<String, Object> initialValue() {
			return new HashMap<>();
		}
	};

	//To get and set Angle Search Keyword
	public static String getSearchKeyword() {
		return (String) constantMap.get().get("Search Keyword");
	}
	
	public static void setSearchKeyword(String angleKeyword) {
		constantMap.get().put("Search Keyword", angleKeyword);
	}
	
	
	//To get and set Angle ID
	public static String getAngleID() {
		return (String) constantMap.get().get("Angle ID");
	}
	
	public static void setAngleID(String angleID) {
		constantMap.get().put("Angle ID", angleID);
	}
	
	
	
	// To get and set Angle name
	public static String getAngleTitle() {
		return (String) constantMap.get().get("Angle Title");
	}

	public static void setAngleTitle(String angleTitle) {
		constantMap.get().put("Angle Title", angleTitle);

	}

	// To get and set Story Team Member name
	public static String getTeamMemberName() {
		return (String) constantMap.get().get("Team Member");
	}

	public static void setTeamMemberName(String teamMembers) {
		constantMap.get().put("Team Member", teamMembers);
	}

	// To get and set Angle description
	public static String getAngleDescription() {
		return (String) constantMap.get().get("Angle Description");
	}

	public static void setAngleDescription(String angleDescription) {
		constantMap.get().put("Angle Description", angleDescription);
	}
	
	

	// To get and set Angle creation time
	public static String getAngleCreationTime() {
		return (String) constantMap.get().get("Story Creation Time");
	}

	public static void setAngleCreationTime(String creationTime) {
		constantMap.get().put("Story Creation Time", creationTime);
	}

	// To get and set Angle creation date
	public static String getAngleCreationDate() {
		return (String) constantMap.get().get("Story Creation Date");
	}

	public static void setAngleCreationDate(String creationDate) {
		constantMap.get().put("Story Creation Date", creationDate);
	}
	
	//To get and set Angle filter name
	public static void setFilterAuthorName(String name) {
		constantMap.get().put("Filter Author Name", name);
	}
	
	public static String getFilterAuthorName() {
		return (String) constantMap.get().get("Filter Author Name");
	}
	
	

	
	/*******************************************************************/

	// To get and set story topic count
	public static int getStoryTopicCount() {
		return (int) constantMap.get().get("Story Topic Count");
	}

	public static void setStoryTopicCount(int topicNumber) {
		constantMap.get().put("Story Topic Count", topicNumber);
	}

	// To get and set story topic
	public static String getStoryTopic(int topicNumber) {
		return (String) constantMap.get().get("Story Topic_" + topicNumber);
	}

	public static void setStoryTopic(int topicNumber, String topic) {
		constantMap.get().put("Story Topic_" + topicNumber, topic);
	}

	// To get and set story tag count
	public static int getStoryTagCount() {
		return (int) constantMap.get().get("Story Tag Count");
	}

	public static void setStoryTagCount(int tagNumber) {
		constantMap.get().put("Story Tag Count", tagNumber);
	}

	// To get and set story tag
	public static String getStoryTag(int tagNumber) {
		return (String) constantMap.get().get("Story Tag_" + tagNumber);
	}

	public static void setStoryTag(int tagNumber, String tag) {
		constantMap.get().put("Story Tag_" + tagNumber, tag);
	}

	// To get and set story tag count
	public static int getStorySlackChannelCount() {
		return (int) constantMap.get().get("Slack Channel Count");
	}

	public static void setStorySlackChannelCount(int slackChannelCount) {
		constantMap.get().put("Slack Channel Count", slackChannelCount);
	}

	// To get and set story slack channel
	public static String getStorySlackChannel(int slackNumber) {
		return (String) constantMap.get().get("Slack Channel_" + slackNumber);
	}

	public static void setStorySlackChannel(int slackNumber, String slackChannel) {
		constantMap.get().put("Slack Channel_" + slackNumber, slackChannel);
	}

	// To get and set story creation time
	public static String getStoryCreationTime() {
		return (String) constantMap.get().get("Story Creation Time");
	}

	public static void setStoryCreationTime(String creationTime) {
		constantMap.get().put("Story Creation Time", creationTime);
	}

	// To get and set story creation date
	public static String getStoryCreationDate() {
		return (String) constantMap.get().get("Story Creation Date");
	}

	public static void setStoryCreationDate(String creationDate) {
		constantMap.get().put("Story Creation Date", creationDate);
	}

}
