package nbcu.automation.ui.constants.ncx;

public class Constants {

    public static void initConstants(){
        StoryConstants.init();
        PostConstants.init();
    }
}
