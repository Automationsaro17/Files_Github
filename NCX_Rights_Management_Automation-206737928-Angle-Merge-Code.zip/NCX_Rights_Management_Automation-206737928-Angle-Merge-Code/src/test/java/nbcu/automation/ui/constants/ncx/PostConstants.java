package nbcu.automation.ui.constants.ncx;

import java.util.HashMap;

public class PostConstants {

    private static ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
        @Override
        protected HashMap<String, Object> initialValue() {
            return new HashMap<>();
        }
    };

    public static void init() {
        constantMap.remove();
    }

    // To get and set full name
    public static String getFullName() {
        return (String) constantMap.get().get("Full Name");
    }

    public static void setFullName(String fullName) {
        constantMap.get().put("Full Name", fullName);
    }

    // To get and set first name
    public static String getFirstName() {
        return (String) constantMap.get().get("First Name");
    }

    public static void setFirstName(String firstName) {
        constantMap.get().put("First Name", firstName);
    }

    // To get and set last name
    public static String getLastName() {
        return (String) constantMap.get().get("Last Name");
    }

    public static void setLastName(String lastName) {
        constantMap.get().put("Last Name", lastName);
    }

    // To get and set email id
    public static String getDisplayName() {
        return (String) constantMap.get().get("Display Name");
    }

    public static void setDisplayName(String displayName) {
        constantMap.get().put("Display Name", displayName);
    }

    // To get and set job title
    public static String getJobTitle() {
        return (String) constantMap.get().get("Job Title");
    }

    public static void setJobTitle(String jobTitle) {
        constantMap.get().put("Job Title", jobTitle);
    }

    // To set and get post title
    public static String getPostTitle() {
        return (String) constantMap.get().get("Post Title");
    }

    public static void setPostTitle(String postTitle) {
        constantMap.get().put("Post Title", postTitle);
    }

    // To set and get post description
    public static String getPostDescription() {
        return (String) constantMap.get().get("Post Description");
    }

    public static void setPostDescription(String postDescription) {
        constantMap.get().put("Post Description", postDescription);
    }

    // To set and get linked angles count
    public static int getLinkedAngleCount() {
        return (int) constantMap.get().get("Linked Angle Count");
    }

    public static void setLinkedAngleCount(int angleCount) {
        constantMap.get().put("Linked Angle Count", angleCount);
    }

    // To get and set linked angle
    public static String getLinkedAngle(int angleNumber) {
        return (String) constantMap.get().get("Linked Angle_" + angleNumber);
    }

    public static void setLinkedAngle(int angleNumber, String angleName) {
        constantMap.get().put("Linked Angle_" + angleNumber, angleName);
    }

    // To set and get linked angles
    public static int getLinkedStoryCount() {
        return (int) constantMap.get().get("Linked Story Count");
    }

    public static void setLinkedStoryCount(int storyCount) {
        constantMap.get().put("Linked Story Count", storyCount);
    }

    // To get and set linked story
    public static String getLinkedStory(int storyNumber) {
        return (String) constantMap.get().get("Linked Story_" + storyNumber);
    }

    public static void setLinkedStory(int storyNumber, String storyName) {
        constantMap.get().put("Linked Story_" + storyNumber, storyName);
    }

    // To set and get primary story
    public static String getPrimaryStory() {
        return (String) constantMap.get().get("Primary Story");
    }

    public static void setPrimaryStory(String primaryStory) {
        constantMap.get().put("Primary Story", primaryStory);
    }

    // To set and get linked attachment count
    public static String getAttachmentCount() {
        return (String) constantMap.get().get("Attachment Count");
    }

    public static void setAttachmentCount(String attachmentCount) {
        constantMap.get().put("Attachment Count", attachmentCount);
    }

    // To set and get attachment name
    public static String getAttachmentName(int attachmentNumber) {
        return (String) constantMap.get().get("Attachment_" + attachmentNumber);
    }

    public static void setAttachmentName(int attachmentNumber, String attachmentName) {
        constantMap.get().put("Attachment_" + attachmentNumber, attachmentName);
    }

    // To set and get link to source
    public static String getLinkToSource() {
        return (String) constantMap.get().get("Link To Source");
    }

    public static void setLinkToSource(String linkToSource) {
        constantMap.get().put("Link To Source", linkToSource);
    }

    // To set and get mandatory credit option
    public static String getMandatoryCreditOption() {
        return (String) constantMap.get().get("Mandatory Credit Option");
    }

    public static void setMandatoryCreditOption(String mandatoryCreditOption) {
        constantMap.get().put("Mandatory Credit Option", mandatoryCreditOption);
    }

    // To set and get mandatory credit value
    public static String getMandatoryCreditValue() {
        return (String) constantMap.get().get("Mandatory Credit Value");
    }

    public static void setMandatoryCreditValue(String mandatoryCreditValue) {
        constantMap.get().put("Mandatory Credit Value", mandatoryCreditValue);
    }

    // To set and get material cleared for
    public static String getClearedForNbcuPartners() {
        return (String) constantMap.get().get("Cleared For NBCU Partners");
    }

    public static void setClearedForNbcuPartners(String clearedForNbcuPartners) {
        constantMap.get().put("Cleared For NBCU Partners", clearedForNbcuPartners);
    }

    // To set and get standards labels count
    public static String getStandardsLabelsCount() {
        return (String) constantMap.get().get("Standards label Count");
    }

    public static void setStandardsLabelsCount(String standardsLabelsCount) {
        constantMap.get().put("Standards label Count", standardsLabelsCount);
    }

    // To set and get show
    public static String getStandardsLabel(int labelNumber) {
        return (String) constantMap.get().get("Standards Label_" + labelNumber);
    }

    public static void setStandardsLabel(int labelNumber, String standardsLabelName) {
        constantMap.get().put("Standards Label_" + labelNumber, standardsLabelName);
    }

    // To set and get R&C/Legal labels count
    public static String getLegalLabelsCount() {
        return (String) constantMap.get().get("Legal label Count");
    }

    public static void setLegalLabelsCount(String legalLabelsCount) {
        constantMap.get().put("Legal label Count", legalLabelsCount);
    }

    // To set and get show
    public static String getLegalLabel(int labelNumber) {
        return (String) constantMap.get().get("Legal Label_" + labelNumber);
    }

    public static void setLegalLabel(int labelNumber, String standardsLabelName) {
        constantMap.get().put("Legal Label_" + labelNumber, standardsLabelName);
    }

    // To get and set post tag count
    public static int getPostTagCount() {
        return (int) constantMap.get().get("Post Tag Count");
    }

    public static void setPostTagCount(int tagNumber) {
        constantMap.get().put("Post Tag Count", tagNumber);
    }

    // To get and set post tag
    public static String getPostTag(int tagNumber) {
        return (String) constantMap.get().get("Post Tag_" + tagNumber);
    }

    public static void setPostTag(int tagNumber, String tag) {
        constantMap.get().put("Post Tag_" + tagNumber, tag);
    }

    // To get and set draft post creation date
    public static String getDraftPostCreationDate() {
        return (String) constantMap.get().get("Draft Post Creation Date");
    }

    public static void setDraftPostCreationDate(String postCreationDate) {
        constantMap.get().put("Draft Post Creation Date", postCreationDate);
    }

    // To get and set draft post creation time
    public static String getDraftPostCreationTime() {
        return (String) constantMap.get().get("Draft Post Creation Time");
    }

    public static void setDraftPostCreationTime(String postCreationTime) {
        constantMap.get().put("Draft Post Creation Time", postCreationTime);
    }

    // To get and set post creation date
    public static String getPostCreationDate() {
        return (String) constantMap.get().get("Post Creation Date");
    }

    public static void setPostCreationDate(String postCreationDate) {
        constantMap.get().put("Post Creation Date", postCreationDate);
    }

    // To get and set post creation time
    public static String getPostCreationTime() {
        return (String) constantMap.get().get("Post Creation Time");
    }

    public static void setPostCreationTime(String postCreationTime) {
        constantMap.get().put("Post Creation Time", postCreationTime);
    }

    // To get and set post modified date
    public static String getPostModifiedDate() {
        return (String) constantMap.get().get("Post Modified Date");
    }

    public static void setPostModifiedDate(String postModifiedDate) {
        constantMap.get().put("Post Modified Date", postModifiedDate);
    }

    // To get and set post modified time
    public static String getPostModifiedTime() {
        return (String) constantMap.get().get("Post Modified Time");
    }

    public static void setPostModifiedTime(String postModifiedTime) {
        constantMap.get().put("Post Modified Time", postModifiedTime);
    }

    // To get and set post standard guidance
    public static String getStandardGuidance() {
        return (String) constantMap.get().get("Standard Guidance Description");
    }

    public static void setStandardGuidance(String standardGuidanceDescription) {
        constantMap.get().put("Standard Guidance Description", standardGuidanceDescription);
    }

    // To get and set reportable approver option
    public static String getReportableApproverOption() {
        return (String) constantMap.get().get("Reportable Approver Option");
    }

    public static void setReportableApproverOption(String reportableApproverOption) {
        constantMap.get().put("Reportable Approver Option", reportableApproverOption);
    }

    // To get and set senior approver name
    public static String getSrApproverName() {
        return (String) constantMap.get().get("Senior Approver Name");
    }

    public static void setSrApproverName(String seniorApproverName) {
        constantMap.get().put("Senior Approver Name", seniorApproverName);
    }

    // To get and set reportable section notes
    public static String getReportableNotes() {
        return (String) constantMap.get().get("Reportable Notes");
    }

    public static void setReportableNotes(String reportableNotes) {
        constantMap.get().put("Reportable Notes", reportableNotes);
    }

    // To get and set Limited license
    public static String getLimitedLicense() {
        return (String) constantMap.get().get("Limited License");
    }

    public static void setLimitedLicense(String limitedLicense) {
        constantMap.get().put("Limited License", limitedLicense);
    }

    public static String getStandardGuidanceCreationDate() {
        return (String) constantMap.get().get("Standard Guidance Creation Date");
    }

    public static void setStandardGuidanceCreationDate(String standardGuidanceCreationDate) {
        constantMap.get().put("Standard Guidance Creation Date", standardGuidanceCreationDate);
    }

    // To get and set post creation time
    public static String getStandardGuidanceCreationTime() {
        return (String) constantMap.get().get("Standard Guidance Creation Time");
    }

    public static void setStandardGuidanceCreationTime(String standardGuidanceCreationTime) {
        constantMap.get().put("Standard Guidance Creation Time", standardGuidanceCreationTime);
    }

    // To set and get comments count
    public static String getCommentsCount() {
        return (String) constantMap.get().get("Comments Count");
    }

    public static void setCommentsCount(String commentsCount) {
        constantMap.get().put("Comments Count", commentsCount);
    }

    // To set and get post comment
    public static String getPostComment(int commentNumber) {
        return (String) constantMap.get().get("Post Comment_" + commentNumber);
    }

    public static void setPostComment(int commentNumber, String postComment) {
        constantMap.get().put("Post Comment_" + commentNumber, postComment);
    }

    //To set and get post PDF content
    public static String getPostPdfContent() {
        return (String) constantMap.get().get("Post PDF Content");
    }

    public static void setPostPdfContent(String postPdfContent) {
        constantMap.get().put("Post PDF Content", postPdfContent);
    }

    //To set and get post url
    public static String getPostUrl() {
        return (String) constantMap.get().get("Post URL");
    }

    public static void setPostUrl(String postUrl) {
        constantMap.get().put("Post URL", postUrl);
    }
}
