package nbcu.automation.ui.constants.ncx;

import java.util.HashMap;
import java.util.Map;

public class StoryConstants {

    private static ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
        @Override
        protected HashMap<String, Object> initialValue() {
            return new HashMap<>();
        }
    };

    public static void init(){
        constantMap.remove();
    }

    // To get and set story type
    public static String getStoryStatus() {
        return (String) constantMap.get().get("Story Type");
    }

    public static void setStoryStatus(String storyType) {
        constantMap.get().put("Story Type", storyType);
    }

    // To get and set story privacy
    public static String getStoryPrivacy() {
        return (String) constantMap.get().get("Story Privacy");
    }

    public static void setStoryPrivacy(String storyPrivacy) {
        constantMap.get().put("Story Privacy", storyPrivacy);
    }

    // To get and set story name
    public static String getStoryTitle() {
        return (String) constantMap.get().get("Story Title");
    }

    public static void setStoryTitle(String storyTitle) {
        constantMap.get().put("Story Title", storyTitle);
    }

    // To get and set story description
    public static String getStoryDescription() {
        return (String) constantMap.get().get("Story Description");
    }

    public static void setStoryDescription(String storyDescription) {
        constantMap.get().put("Story Description", storyDescription);
    }

    // To get and set story topic count
    public static int getStoryTopicCount() {
        return (int) constantMap.get().get("Story Topic Count");
    }

    public static void setStoryTopicCount(int topicNumber) {
        constantMap.get().put("Story Topic Count", topicNumber);
    }

    // To get and set story topic
    public static String getStoryTopic(int topicNumber) {
        return (String) constantMap.get().get("Story Topic_" + topicNumber);
    }

    public static void setStoryTopic(int topicNumber, String topic) {
        constantMap.get().put("Story Topic_" + topicNumber, topic);
    }

    // To get and set story tag count
    public static int getStoryTagCount() {
        return (int) constantMap.get().get("Story Tag Count");
    }

    public static void setStoryTagCount(int tagNumber) {
        constantMap.get().put("Story Tag Count", tagNumber);
    }

    // To get and set story tag
    public static String getStoryTag(int tagNumber) {
        return (String) constantMap.get().get("Story Tag_" + tagNumber);
    }

    public static void setStoryTag(int tagNumber, String tag) {
        constantMap.get().put("Story Tag_" + tagNumber, tag);
    }

    // To get and set story tag count
    public static int getStorySlackChannelCount() {
        return (int) constantMap.get().get("Slack Channel Count");
    }

    public static void setStorySlackChannelCount(int slackChannelCount) {
        constantMap.get().put("Slack Channel Count", slackChannelCount);
    }

    // To get and set story slack channel
    public static String getStorySlackChannel(int slackNumber) {
        return (String) constantMap.get().get("Slack Channel_" + slackNumber);
    }

    public static void setStorySlackChannel(int slackNumber, String slackChannel) {
        constantMap.get().put("Slack Channel_" + slackNumber, slackChannel);
    }

    // To get and set draft story creation time
    public static String getDraftStoryCreationTime() {
        return (String) constantMap.get().get("Draft Story Creation Time");
    }

    public static void setDraftStoryCreationTime(String creationTime) {
        constantMap.get().put("Draft Story Creation Time", creationTime);
    }

    // To get and set draft story creation date
    public static String getDraftStoryCreationDate() {
        return (String) constantMap.get().get("Draft Story Creation Date");
    }

    public static void setDraftStoryCreationDate(String creationDate) {
        constantMap.get().put("Draft Story Creation Date", creationDate);
    }

    // To get and set story creation time
    public static String getStoryCreationTime() {
        return (String) constantMap.get().get("Story Creation Time");
    }

    public static void setStoryCreationTime(String creationTime) {
        constantMap.get().put("Story Creation Time", creationTime);
    }

    // To get and set story creation date
    public static String getStoryCreationDate() {
        return (String) constantMap.get().get("Story Creation Date");
    }

    public static void setStoryCreationDate(String creationDate) {
        constantMap.get().put("Story Creation Date", creationDate);
    }

}
