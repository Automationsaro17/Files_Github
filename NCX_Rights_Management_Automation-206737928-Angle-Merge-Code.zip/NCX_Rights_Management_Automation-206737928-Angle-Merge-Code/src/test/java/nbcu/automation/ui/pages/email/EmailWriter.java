package nbcu.automation.ui.pages.email;

import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.IOException;
import java.util.Properties;

public class EmailWriter {

    public static void addPostViaEmail(String toEmail, String postTitle, String postDescription, String attachmentName) throws Exception {
        Store store = null;

        /**
         * Fetching info required to send email
         */
        String host = ConfigFileReader.getProperty("Gmail-Host");
        String userName = ConfigFileReader.getProperty("Gmail-UserName");
        String password = ConfigFileReader.getProperty("Gmail-Password");

        String emailSubject = postTitle;

        System.out.println("TLSEmail Start");
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com"); //SMTP Host
        properties.put("mail.smtp.port", "25"); //TLS Port
        properties.put("mail.smtp.auth", "false"); //enable authentication
        properties.put("mail.smtp.starttls.enable", "false"); //enable STARTTLS


        Session emailSession = Session.getInstance(properties);

        try {
            // MimeMessage object.
            MimeMessage message = new MimeMessage(emailSession);

            // Set From Field: adding senders email to from field.
            message.setFrom(new InternetAddress(userName));

            // Set To Field: adding recipient's email to from field.
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));

            // Set Subject: subject of the email
            message.setSubject(emailSubject);

            // set body of the email.
            /** To add email body **/
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent(postDescription, "text/html");

            //** To add attachment **//*
            String htmlReportPath = "";
            MimeBodyPart attachmentPart = new MimeBodyPart();
            attachmentPart.attachFile(System.getProperty("user.dir") + "/"+ ConfigFileReader.getProperty("File-Upload-Path") +"/" + attachmentName);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            multipart.addBodyPart(attachmentPart);


            // sets the multi-part as e-mail's content
            message.setContent(multipart);

            // Send email.
            Transport.send(message);
            System.out.println("Email successfully sent");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public static void sendMail(String attachmentName) {
        // TODO Auto-generated method stub
        Properties props = new Properties();
        props.put("mail.smtp.auth", false);
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "25");

        Session session = Session.getInstance(props);

        try {

            Message message = new MimeMessage(session);

            message.setFrom(new InternetAddress("mag459new@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("mag459new@gmail.com"));
            message.setSubject("Test");
            // message.setText(composedMail.getsBody());

            // ///////////////////////////////////////////////

            // creates message part
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent("test", "text/html");

            // creates multi-part
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);

            // adds attachments

            String filePath = System.getProperty("user.dir") + "/"+ ConfigFileReader.getProperty("File-Upload-Path") +"/" + attachmentName;
            if (!filePath.isEmpty()) {
                MimeBodyPart attachPart = new MimeBodyPart();
                try {
                    attachPart.attachFile(filePath);

                } catch (IOException ex) {
                    ex.printStackTrace();
                }

                multipart.addBodyPart(attachPart);
            }


            // sets the multi-part as e-mail's content
            message.setContent(multipart);
            // /////////////////////////////////////////
            // message.setContent(composedMail.getsBody(), "text/html");

            Transport.send(message);

            System.out.println("Done");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) throws Exception {
        sendMail("Text File.txt");
    }
}
