package nbcu.automation.ui.pages.ncx;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.AngleConstants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;

public class AngleDetailsPage {

	HomePage homePage = new HomePage();
	ProfilePage profilePage = new ProfilePage();

	/**
	 * Story details elements
	 **/
	@FindBy(xpath = "//div[contains(@class,'story-status')]")
	WebElement storyStatusElement;

	@FindBy(xpath = "//div[contains(@class,'story-status')]/span")
	WebElement storyStatusIndicatorElement;

	@FindBy(xpath = "//div[contains(@class,'storyTopics')]/span")
	WebElement storyTopicElement;

	@FindBy(xpath = "//div[@class='angle-title']")
	WebElement angleTitleElement;

	@FindBy(xpath = "//div[contains(@class,'storyDescription')]")
	WebElement storyDescriptionElement;

	@FindBy(xpath = "//button[contains(@class,'creators')]/span")
	WebElement storyCreatorNameElement;

	@FindBy(xpath = "//span[contains(@class,'time')]")
	WebElement storyCreationTimeElement;

	@FindBy(xpath = "//span[contains(@class,'date')]")
	WebElement storyCreationDateElement;

	@FindBy(xpath = "//div[contains(@class,'storyTags')]/span")
	WebElement storyTagsElement;

	@FindBy(xpath = "//span[contains(@class,'follower')]//button[contains(@class,'count')]")
	WebElement storyFollowerCountElement;

	/**
	 * Angle Related Buttons
	 */
	@FindBy(xpath = "//i[contains(@class,'anticon-delete')]/following-sibling::span")
	WebElement deleteBtn;

	@FindBy(xpath = "//i[contains(@class,'anticon-edit')]/following-sibling::span")
	WebElement editBtn;

	/**
	 * Angle Landing Page elements
	 */
	@FindBy(xpath = "//div[@class='linked-story']/span[1]")
	WebElement linkedStoryLabel;

	@FindBy(xpath = "//div[@class='linked-story']//span[2]")
	WebElement linkedStoryName;

	@FindBy(xpath = "//div[@class='story-team']/span[1]")
	WebElement collaboratorsLbl;

	@FindBy(xpath = "//span[@class='story-team-members']/button")
	List<WebElement> teamMembers;

	@FindBy(xpath = "//div[contains(@class,'tab-active')]")
	WebElement overViewTab;

	@FindBy(xpath = "//div[@role='tab' and text()='Material']")
	WebElement materialTab;

	@FindBy(xpath = "//div[@role='tab' and text()='Log']")
	WebElement logsTab;

	@FindBy(xpath = "//div[contains(@class,'overview')]")
	WebElement angleDescription;

	@FindBy(xpath = "//div[@role='tab']")
	List<WebElement> tabsList;

	@FindBy(xpath = "//button[contains(@class,'add-new-element-btn')]//span")
	WebElement addNewElementBtn;

	public AngleDetailsPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify angle details page is loaded
	 *
	 * @throws Exception
	 */

	@FindBy(xpath = "//i[contains(@class,'anticon-arrow-left')]")
	WebElement backIconHeader;

	public void verifyAngleDetailsPageLoaded() throws Exception {
		try {
			Waits.waitForElement(deleteBtn, Waits.WAIT_CONDITIONS.CLICKABLE);
			Thread.sleep(1000);
			String angleTitle = WebAction.getWindowTitle();
			Waits.waitForElement(backIconHeader, Waits.WAIT_CONDITIONS.CLICKABLE);
			Thread.sleep(800);
			if (angleTitle.equalsIgnoreCase(WebAction.getText(angleTitleElement).trim()))
				System.out.println("Angle title matched with tab title");
			else {
				CommonValidations.verifyTextValue(angleTitleElement, angleTitle,
						"Angle title is not matched in angle landing page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify angle landing page header part
	 * 
	 * @param section - Angle Landing page each section area
	 * @throws Exception
	 */

	public void verifyAnglePageHeader(String sectionTxt) throws Exception {
		try {
			switch (sectionTxt.toUpperCase().trim()) {
			case "LINKED STORY":
				CommonValidations.verifyTextValue(linkedStoryLabel, "Linked Story", "Linked Story label is not found");
				String actualStoryName = StoryConstants.getStoryTitle();
				String ExpectedStoryName = WebAction.getText(linkedStoryName).trim();
				if (actualStoryName.equalsIgnoreCase(ExpectedStoryName)) {
					System.out.println("Linked Story Name is matched in Angle Landing page");
					boolean clickableLink = WebAction.isClickable(angleTitleElement);
					if (clickableLink) {
						System.out.println("Linked Story Name is clickable hyperlink in Angle Landing Page");
					} else {
						Assert.assertTrue(clickableLink, "Unable to click linked story name in Angle Landing page");
					}
				} else
					Assert.assertTrue(false, "Linked story name is different in Angle landing page");
				break;
			case "STORY TEAM MEMBERS":
				CommonValidations.verifyTextValue(collaboratorsLbl, "Collaborators:", "Unable to find Story team members");
				//String StoryTeams = AngleConstants.getTeamMemberName();
				int no_of_members = teamMembers.size();
				List<String> names = new ArrayList<String>();
				for (int i = 0; i < no_of_members; i++) {
					String teamName = teamMembers.get(i).getText().trim();
					names.add(teamName);
					
				}
				if (names.get(0).trim().equalsIgnoreCase(PostConstants.getDisplayName().trim())) {
					System.out.println("Story team members displayed in the Angle Landing page");
				} /* To verify more story team members
					 * if (names.get(1).trim().contains(StoryTeams.trim())) {
					 * System.out.println("Story team members displayed in the Angle Landing page");
					 * }
					 */
				for (int i = 0; i < no_of_members; i++) {
					boolean clickAbleNames = WebAction.isClickable(teamMembers.get(i));
					if (clickAbleNames) {
						System.out.println("Story team Members name are clickable in Angle Landing Page");
					} else {
						System.out.println("Unable to see hyperlinks in Story team Members");
					}
				}
				break;
			case "OVERVIEW DESCRIPTION":
				CommonValidations.verifyTextValue(overViewTab, "Overview", "Unable to load the Overviewtab");
				String angleActualDescription = AngleConstants.getAngleDescription();

				System.out.println("actual Angle description from constants" + angleActualDescription);

				String angleExpectedDescription = WebAction.getText(angleDescription).trim();

				System.out.println("From WebElement" + angleExpectedDescription);

				if (angleExpectedDescription.equalsIgnoreCase(angleActualDescription.trim())) {
					Assert.assertTrue(true, "Angle Description matched with the expected content");
				} else
					Assert.assertTrue(false, "Unable to matched the angle description");
				break;
			case "TABS":
				int no_of_tabs = tabsList.size();
				System.out.println("No of tabs are added in the angle page is " + no_of_tabs);
				List<String> tabNames = new ArrayList<String>();
				if (no_of_tabs > 0) {
					for (int i = 0; i < no_of_tabs; i++) {

						tabNames.add(tabsList.get(i).getText().trim());
					}

					if (tabNames.get(0).trim().equalsIgnoreCase(WebAction.getText(overViewTab).trim())) {
						System.out.println("Overview tab is enabled by default in Angle Landing Page");
					} else if (tabNames.get(1).trim().equalsIgnoreCase(WebAction.getText(materialTab).trim())) {
						System.out.println("Material tab is displayed in the Angle Landing Page");
					} else if (tabNames.get(1).trim().equalsIgnoreCase(WebAction.getText(logsTab).trim())) {
						System.out.println("Log tab is displayed in the Angle Landing Page");
					} else
						Assert.assertTrue(false, "Unable to load the tabs in Angle Landing Page");
				}

				break;
			case "ADD NEW ELEMENT":
				if (addNewElementBtn.isDisplayed()) {
					CommonValidations.verifyElementIsEnabled(addNewElementBtn,
							"Button Add New Element button is not enabled in angle landing page");
				} else
					System.out.println("Failed to enabled the Add New Element button in Angle Landing page");
				break;
			default:
				Assert.assertTrue(false, "Failed to displayed the header part label text");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To click Add New Element button from sticky footer section of
	 * angle landing page
	 */
	
	@FindBy(xpath ="//nz-footer[contains(@class,'page-footer')]//button//span[text()='Add New Element']/preceding-sibling::i")
	WebElement angleLandingPageAddNewElementBtn;
	
	public void clickAddNewElementBtn() throws Exception {
		try {
			CommonValidations.verifyElementIsEnabled(angleLandingPageAddNewElementBtn, "Failed to display the"
					+ "Add New Element button from angle landing page");
			WebAction.click(angleLandingPageAddNewElementBtn);
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify Angle options in Landing page
	 * 
	 * @param role - NCX user profile
	 * @throws Exception
	 */
	public void verifyAngleOptions(String role) throws Exception {
		try {
			switch (role.toUpperCase()) {
			case "SENIOR EDITOR", "STANDARDS", "ADMIN" -> {
				CommonValidations.verifyElementIsEnabled(deleteBtn,
						"Delete Button is not enabled in the Angle Landing Page");
				CommonValidations.verifyElementIsEnabled(editBtn,
						"Edit Button is not enabled in the Angle Landing Page");
			}
			case "JOURNALIST", "EDITOR" -> {
				CommonValidations.verifyElementIsEnabled(deleteBtn,
						"Delete Button is not enabled in the Angle Landing Page");
				CommonValidations.verifyElementIsEnabled(editBtn,
						"Edit Button is not enabled in the Angle Landing Page");
			}
			default -> Assert.assertTrue(false, "Logged in user ' " + role + " ' is not a vlid ncx user profile");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify Angle Log options in Landing page
	 * 
	 * @throws Exception
	 */

	@FindBy(xpath = "//div[@role='tab' and text()='Log']")
	WebElement logTab;

	@FindBy(xpath = "//nz-collapse-panel[contains(@class,'angle-log-collapse')]/div[1]")
	WebElement logDate;

	@FindBy(xpath = "//i[contains(@class,'ant-collapse-arrow')]")
	WebElement expandIcon;

	@FindBy(xpath = "//span[contains(@class,'description')]")
	WebElement angleCreatedTxt;

	@FindBy(xpath = "//span[@class='user-name']")
	WebElement userNCXProfile;

	@FindBy(xpath = "//span[@class='time']")
	WebElement logTime;

	public void verifyAngleInformation() throws Exception {
		try {
			boolean isPresent = WebAction.isEnabled(logTab);
			if (isPresent) {
				WebAction.click(logTab);
				//System.out.println("Log tab is clickable in Angle landing page");
				Thread.sleep(1000);
				CommonValidations.verifyElementIsEnabled(expandIcon, "Failed to display the expand icon in Log tab");
				String ExpectedValue = AngleConstants.getAngleCreationDate();
				String ActualValue = WebAction.getText(logDate).trim();
				if (ActualValue.equalsIgnoreCase(ExpectedValue)) {
					Assert.assertTrue(true, "Angle creation date not got matched in the Angle Landing Page");
				} else
					Assert.assertTrue(false, "Angle creation date not matched in the Angle landing page");
				String ActualTextDescription = WebAction.getText(angleCreatedTxt).trim().toLowerCase();
				if (ActualTextDescription.equalsIgnoreCase("Angle was created")) {
					//System.out.println("Angle Log tab content got matched with date created");
				} else
					Assert.assertTrue(false, "Angle was created content not matched with the log page");
				String userProfileName = PostConstants.getDisplayName();
				String expectedProfileName = WebAction.getText(userNCXProfile).trim().toLowerCase();
				if (userProfileName.equalsIgnoreCase(expectedProfileName)) {
				//	System.out.println("Angle created user profile name matched in the angle log tab");
				} else
					Assert.assertTrue(false, "User Name not matched in the Angle log tab");
				String ActualTime = AngleConstants.getAngleCreationTime();
				String ExpectedTime = WebAction.getText(logTime).trim();
				/*
				 * System.out.println("Actual time is --->" +ActualTime);
				 * System.out.println("Expected time is -->" +ExpectedTime);
				 */
				if (ActualTime.equalsIgnoreCase(ExpectedTime)) {
					System.out.println("User created angle log time matched in Angle log tab");
				} else
					Assert.assertTrue(false, "Log time not matched in the Angle log tab");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the user can collapse the container details in log page
	 * 
	 * throws Exception
	 */

	public void collapseLog() throws Exception {
		try {
			if (expandIcon.isDisplayed()) {
				CommonValidations.verifyElementIsEnabled(expandIcon,
						"Failed to enable the expand icon in the Log page");
				WebAction.click(expandIcon);
				System.out.println("Log date wise container got collapsed in Angle Log tab");
			} else
				Assert.assertTrue(false, "Expand icon is not displayed in the Angle Log tab");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click edit button in angle details page
	 * 
	 * @throws Exception
	 */

	public void clickEditButtonInAnglePage(String btnActions) throws Exception {
		try {
			switch (btnActions.toUpperCase()) {
			case "EDIT" -> {
				WebAction.click(editBtn);
			}
			case "DELETE" -> {
				WebAction.click(deleteBtn);
			}
			case "ADD NEW ELEMENT" -> {
				WebAction.click(editBtn);
			}
			default -> Assert.assertFalse(false, "Failed to perform button actions in Angle details page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the Angle ID in header section of Angle Landing page
	 * 
	 * @throws Exception
	 */

	@FindBy(xpath = "//span[contains(text(),' Angle ID ')]")
	WebElement angleIDTxt;

	public void verifyAngleIDInLandingPage() throws Exception {
		try {
			String anlgLandingURL = WebAction.getCurrentUrl();
			String[] angleID = anlgLandingURL.split("/:");
			String ExpectedID = angleID[1].toString().trim();
			String FullID = WebAction.getText(angleIDTxt).trim();
			String[] actual = FullID.split("#");
			String ActualID = actual[1].toString().trim();
			AngleConstants.setAngleID(ActualID);
			
			if (ExpectedID.equalsIgnoreCase(ActualID)) {
				System.out.println("ID got matched in Angle Landing Page");
			} else
				Assert.assertTrue(false, "Failed to matched the Angle ID with current URL ID");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the Angle Title in header section of Angle Landing page
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "//div[@class='angle-title']")
	WebElement angleTitleTxt;

	public void verifyAngleTitleInLandingPage() {
		try {
			String ExpectedTitle = AngleConstants.getAngleTitle();
			String ActualTitle = WebAction.getText(angleTitleTxt).trim();
			System.out.println("Angle title after updating the Angle " +ActualTitle);
			System.out.println("Angle constants from get angletitle is " +ExpectedTitle);
			if (ExpectedTitle.trim().equalsIgnoreCase(ActualTitle)) {
				System.out.println("Updated Angle title matched in the angle landing page");
			} else
				Assert.assertTrue(false, "Failed to match the updated angle title in Angle landing page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the confirmation pop-up in angle landing page
	 * 
	 * @throws Exception
	 */

	@FindBy(xpath = "//div[contains(@class,'ant-modal-content')]")
	WebElement deleteAnglePopup;

	@FindBy(xpath = "//span[contains(@class,'ant-modal-confirm-title')]/span")
	WebElement deleteAngleConfirmationMessage;

	@FindBy(xpath = "//div[contains(@class,'ant-modal-confirm-btns')]/button[span[contains(text(),'Cancel')]]")
	WebElement deleteAngleCancelButton;

	@FindBy(xpath = "//div[contains(@class,'ant-modal-confirm-btns')]/button[span[contains(text(),'Delete')]]")
	WebElement deleteAnglepopupBtn;;

	@FindBy(xpath = "//div[@class='ant-message']//span[contains(text(), 'Deleted')]")
	WebElement deletedAngleMessage;

	public void veriyDeleteConfirmationPopup(String angleName, String message) {
		try {
			boolean isDisplayed = WebAction.isDisplayed(deleteAnglePopup);
			if (isDisplayed) {
				String actualMessage = WebAction.getText(deleteAngleConfirmationMessage).trim();
				if (actualMessage.equalsIgnoreCase(message)) {
					Assert.assertTrue(true, actualMessage + " " + "displayed correctly in delete angle pop-up message");
				} else
					Assert.assertFalse(true,
							"Failed to display delete angle pop-up text message its showing as " + actualMessage);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click cancel button in angle delete confirmation pop-up
	 * 
	 * @throws Exception
	 */

	@FindBy(xpath = "//div[contains(@class,'ant-message-notice')]/div")
	WebElement successToastPopup;

	@FindBy(xpath = "//div[contains(@class,'ant-message-notice')]//span")
	WebElement deleteAngleSuccessToast;

	public void clickOKBtnInPop(String button, String message) throws Exception {
		try {
			boolean isDisplayed = WebAction.isDisplayed(deleteAnglepopupBtn);
			if (isDisplayed) {
				WebAction.click(deleteAnglepopupBtn);
				Thread.sleep(2000);
				Waits.waitForElement(deleteAngleSuccessToast, WAIT_CONDITIONS.VISIBLE);
				boolean Displayed = WebAction.isDisplayed(successToastPopup);
				if (Displayed) {
					String Actualvalue = WebAction.getText(deleteAngleSuccessToast).trim();
					System.out.println("Actual value from WebElement is ;;;->" +Actualvalue);
					if (message.equalsIgnoreCase(Actualvalue)) {
						System.out.println(
								"To displayed the Angle success toast message after success deletion of angle-->"
										+ Actualvalue);
					} else
						System.out.println("Failed to displayed the success toast message");

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify angle overview page load from angle listing page
	 * 
	 * throws Exception
	 */

	@FindBy(xpath = "//div[@class='angle-details-content']/div[@class='angle-details-id']//span")
	WebElement angleID;

	@FindBy(xpath = "//div[contains(@class,'overview')]/p")
	WebElement angleDescriptionArea;

	public void verifyAngleDetailPage() throws Exception {
		try {
			String parentWindowName = WebAction.getCurrentWindowId();
			boolean isDisplayed = WebAction.isDisplayed(angleID);
			if (isDisplayed) {
				Assert.assertTrue(isDisplayed, "Angle ID is displayed in the angle listing page");
				WebAction.click(angleID);
				WebAction.switchToNewWindow(2, parentWindowName);
				Waits.waitForElement(angleDescriptionArea, Waits.WAIT_CONDITIONS.VISIBLE);
			} else
				Assert.assertFalse(true, "Failed to display the Angle modal in the anlge listing page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify buttons in footer part of angle overview page
	 */

	@FindBy(xpath = "//div[contains(@class,'overview')]/p")
	WebElement angleContainer;

	@FindBy(xpath = "//button[i[@nztype='delete']]//span[text()='Delete']")
	WebElement angleDeleteBtn;

	@FindBy(xpath = "//button[contains(@class,'add-new-element-btn')]//span[text()='Add New Element']")
	WebElement addNewElemtBtn;

	@FindBy(xpath = "//button[@id='test']//span[text()=' Edit ']")
	WebElement editAngleBtn;

	public void verifyButtonsInAngleOverviewFooterPart(String userRole,DataTable params) {
		try {
		switch(userRole.toUpperCase().trim()) {
		  case "EDITOR" : {
			//List<Map<String, String>> btns = CucumberUtils.getValuesFromDataTableAsList(params);
			Waits.waitForElement(angleContainer, Waits.WAIT_CONDITIONS.VISIBLE);
			boolean isDeleteBtnDisplayed = WebAction.isDisplayed(angleDeleteBtn);
			//boolean isAddNewBtnDisplayed = WebAction.isDisplayed(addNewElemtBtn);
			boolean isEditTnDisplayed = WebAction.isDisplayed(editAngleBtn);
			if (!isDeleteBtnDisplayed && !isEditTnDisplayed) {
				Assert.assertTrue(true, "Angle overview page not displayed the buttonin sticky footer section");
			} else Assert.assertFalse(true,
						"Angle overview page displayed the buttons like Edit, Delete & Add new Element");
		  }
		  break;
			
		  case "READ ONLY": {
			 // List<Map<String, String>> btns = CucumberUtils.getValuesFromDataTableAsList(params);
				Waits.waitForElement(angleContainer, Waits.WAIT_CONDITIONS.VISIBLE);
				boolean isDeleteBtnDisplayed = WebAction.isDisplayed(angleDeleteBtn);
				boolean isAddNewBtnDisplayed = WebAction.isDisplayed(addNewElemtBtn);
				boolean isEditTnDisplayed = WebAction.isDisplayed(editAngleBtn);
				if (!isDeleteBtnDisplayed && !isAddNewBtnDisplayed && !isEditTnDisplayed) {
					Assert.assertTrue(true, "Angle overview page not displayed the buttonin sticky footer section");
				} else Assert.assertFalse(true,
							"Angle overview page displayed the buttons like Edit, Delete & Add new Element");
		  }
		  break;
			default : 
			Assert.assertFalse(true, userRole+" not matched with the logged in user credentials");
			} }catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * To logout from the application as NCX application
	 * 
	 * @throws Exception
	 */

	public void logoutNCXApplication() throws Exception {
		try {
			homePage.clickProfile();
			profilePage.verifyProfilePageLoaded();
			homePage.logOut();
			homePage.verifyApplicationLoggedOut();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
