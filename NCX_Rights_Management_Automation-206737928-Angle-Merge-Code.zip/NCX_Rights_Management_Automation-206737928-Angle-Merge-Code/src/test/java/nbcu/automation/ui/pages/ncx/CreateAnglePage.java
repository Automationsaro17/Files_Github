package nbcu.automation.ui.pages.ncx;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.AngleConstants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.others.CommonUtils;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.cucumber.CucumberUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;
import java.util.Map;

public class CreateAnglePage {

	/**
	 * Main Content Elements
	 **/

	@FindBy(xpath = "//div[@class='angle-title']/input")
	WebElement angleTitleTextBox;

	@FindBy(xpath = "//div[@class='fr-element fr-view']")
	WebElement angleDescriptionTextBox;

	@FindBy(xpath = "//nz-input-group[contains(@class,'input-group')]/input")
	WebElement storyNamefield;

	@FindBy(xpath = "//input[@placeholder='Search Story Name']")
	WebElement addStoryTextBox;

	@FindBy(xpath = "//input[@placeholder='Search Story Name']")
	WebElement storyNameField;

	String searchDropDownValuesXpath = "//nz-auto-option[contains(@class,'ant-select-item ant-select-item-option')]/div";

	@FindBy(xpath = "//nz-option-item[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropDownvalues;

	/**
	 * Buttons Element
	 */
	@FindBy(xpath = "//button[contains(@class,'footer-btn publish-btn')]/span[text()='Publish ']")
	WebElement publishButton;

	@FindBy(xpath = "//span[text()='Cancel']")
	WebElement cancelButton;

	@FindBy(xpath = "//button[@class='ant-btn']")
	WebElement deleteBtn;

	@FindBy(xpath = "//div[contains(@class,'mandatory-text')]")
	WebElement inlineError;

	@FindBy(xpath = "//div[contains(@class,'mandatory-text')]/span")
	WebElement inlineErrorText;

	@FindBy(xpath = "//nz-input-group[@class='ant-input-affix-wrapper']/input")
	WebElement searchStoryNameField;

	@FindBy(xpath = "//*[@role='menuitem']/div")
	WebElement storyTeamSuggestionList;

	@FindBy(xpath = "//div[contains(@class,'ant-select-item-option')]")
	WebElement storySuggestionList;

	@FindBy(xpath = "//div[@class='link-story']/following-sibling::div")
	WebElement linkedStorySection;

	@FindBy(xpath = "//span[@class='story-text']/div")
	WebElement linkedStoryName;

	@FindBy(xpath = "//span[@nztype='delete']")
	WebElement deleteStoryMember;

	@FindBy(xpath = "//div[@class='name']")
	WebElement deletedStoryMemberName;

	public CreateAnglePage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify create angle page is loaded
	 * 
	 * @throws Exception
	 */
	public void verifyCreateAnglePageLoaded() throws Exception {
		try {
			
			Waits.waitForElement(angleTitleTextBox, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill angle title
	 * 
	 * @param angleTitle - angle title. 12 digits random alphanumeric string will be
	 *                   appended in the end for automation purpose
	 * @throws Exception
	 */
	public void fillAngleTitle(String angleTitle) throws Exception {
		try {
			angleTitle = angleTitle + "_" + CommonUtils.generateRandomString(12);
			AngleConstants.setAngleTitle(angleTitle);
			WebAction.clearUsingKeys(angleTitleTextBox);
			WebAction.sendKeys(angleTitleTextBox, angleTitle);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill angle description
	 * 
	 * @param angleDescription - Angle description
	 * @throws Exception
	 */
	public void fillAngleDescription(String angleDescription) throws Exception {
		try {
			AngleConstants.setAngleDescription(angleDescription);
			WebAction.sendKeys(angleDescriptionTextBox, angleDescription);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
/** To verify the collaborate team name field
 * 
 */
	@FindBy(xpath = "//input[@placeholder='Search for Collaborators']")
	WebElement CollaborateField;
	public void verifySearchCollaborateName() {
		try {
			boolean field = WebAction.isDisplayed(CollaborateField);
			if(field) {
				Assert.assertTrue(field, "Collaborate search section is displayed");
			}
			else Assert.assertTrue(false, "Failed to displayed the Collaborate search section");
		}
		catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To enter Story name in Angle creation page & re-enter the same story in Angle
	 * update page
	 * 
	 * @throws Exception
	 */

	public void enterStoryName() throws Exception {
		try {
			String storyNames = StoryConstants.getStoryTitle();
			if (!storyNames.isEmpty()) {
				System.out.println("Story Title is------->>>" + storyNames);
				

				WebAction.selectNonTitleDropDown1(addStoryTextBox, storyNames, searchDropDownValuesXpath,
						storyNames + " is not present in the add to story");

			} else {
				System.out.println("StoryName field is not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select story team members to the angle
	 * 
	 * @throws Exception
	 */
	public void selectStoryTeamMembers(String memberName) throws Exception {
		try {
			AngleConstants.setTeamMemberName(memberName);
			WebAction.sendKeys(searchStoryNameField, memberName);
			if (storyTeamSuggestionList.isDisplayed()) {
				WebAction.click(storyTeamSuggestionList);
			} else
				System.out.println("Failed to displated the Story Team Member SuggestionList");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click button in create/edit Angle page
	 * 
	 * @param buttonName - button name
	 * @throws Exception
	 */
	@FindBy(xpath = "//button[contains(@class,'delete-btn')]")
	WebElement deleteButton;

	public void clickButton(String buttonName) throws Exception {
		try {
			switch (buttonName.toUpperCase()) {
			case "CANCEL":
				WebAction.click(cancelButton);
				break;
			case "PUBLISH":
				WebAction.click(publishButton);
				//AngleConstants.setAngleCreationTime(DateFunctions.getCurrentDate("h:mm:ss a")); ->9:38:23 AM
				AngleConstants.setAngleCreationTime(DateFunctions.getCurrentDate("h:mm a"));
				AngleConstants.setAngleCreationDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
				
				Waits.waitForElement(deleteButton, WAIT_CONDITIONS.CLICKABLE);
				break;
			default:
				Assert.assertTrue(false, "Please provide valid button name in create/edit story page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the application linked stories in Angle edit page
	 * 
	 * @throws Exception
	 */
	public void verifyAppLinkedStoriesName() throws Exception {
		try {
			WebAction.scrollIntoView(linkedStorySection);
			if (linkedStorySection.isDisplayed()) {
				String actualStoryName = WebAction.getText(linkedStoryName).trim();
				System.out.println("Actual Story Name->" +actualStoryName );
				String ExpectedStoryName = StoryConstants.getStoryTitle();
				System.out.println("ExpectedStoryName->" +ExpectedStoryName);
				if (actualStoryName.equalsIgnoreCase(ExpectedStoryName.trim())) {
					Assert.assertTrue(true, "Story Name matched with linked associated story name field");
				} else
					Assert.assertTrue(false, "Not displayed the Story name in linked story section");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To verify the application linked members card in Angle creation page
	 * 
	 */
	
	@FindBy(xpath = "//span[contains(@class,'story-gap')]")
	WebElement storyCardBlock;
	
	@FindBy(xpath = "//span[contains(@class,'story-gap')]//div[@class='name']")
	WebElement storyNameCard;
	
	public void verifyDefaultMemberCard() {
		try {
			boolean isDisplayed = WebAction.isDisplayed(storyCardBlock);
			if(isDisplayed) {
				String userName = WebAction.getText(storyNameCard).trim();
				String actualName =PostConstants.getFirstName().trim()+" "+PostConstants.getLastName().trim();
				if(userName.equalsIgnoreCase(actualName)) {
					Assert.assertTrue(true, userName+" is displayed in the story team default contact card");
				}
				else Assert.assertFalse(true, actualName+" is displayed in the story team default contact card");
			}else Assert.assertFalse(isDisplayed, "Failed to displayed the story team default contact card"
					+ "in angle creation page");
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To delete the associated linked story section
	 * 
	 * @throws Exception
	 */
	public void deletingAssociatedStory() throws Exception {
		try {
			WebAction.scrollIntoView(storyNameField);
			
			if (WebAction.isEnabled(deleteBtn)) {
				//WebAction.scrollIntoView(storyTeamField);
				
				WebAction.click(deleteBtn);
				
				WebAction.isDisplayed(inlineError);
				
				String errorText = WebAction.getText(inlineErrorText).trim();
				
				if (errorText.equalsIgnoreCase("Story is required".trim())) {
					CommonValidations.verifyTextValue(inlineError, "Story is required",
							"Failed to display the inline error message after deleting the associated story");
				} else
					Assert.assertTrue(false, "Story is required not displayed the inline error message");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To delete the associated story team members
	 * 
	 * @throws Exception
	 */
	public void deleteStoryTeam() throws Exception {
		try {
			if (deleteStoryMember.isDisplayed()) {
				WebAction.click(deleteStoryMember);
				String removedStoryMember = WebAction.getText(deletedStoryMemberName).trim();
				String actualRemovedStoryMember = AngleConstants.getTeamMemberName();
				if (!removedStoryMember.equalsIgnoreCase(actualRemovedStoryMember.trim())) {
					System.out.println("Story team members removed from the Angle update page");
				} else
					Assert.assertTrue(false, "Tema members not removed from the Angle update page");
			} else
				Assert.assertTrue(false, "Failed to display the delete icon in Story tema members");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify story team members displayed the login user profile name in contact
	 * card
	 * 
	 * @param - Login User Profile Role
	 * 
	 */

	@FindBy(xpath = "//span[@class='story-gap']")
	WebElement profileCard;

	@FindBy(xpath = "//span[@class='story-gap']//div[@class='name']")
	WebElement userDisplayName;

	public void verifyLoginUserNameInCard(String ncxRole) {
		try {
			switch (ncxRole.toUpperCase()) {

			case "JOURNALIST":
				boolean defaProfileCard = WebAction.isDisplayed(profileCard);
				if (defaProfileCard) {
					String JournalistName = PostConstants.getFirstName() + " " + PostConstants.getLastName();
					String ActualName = WebAction.getText(userDisplayName).trim();
					if (JournalistName.equalsIgnoreCase(ActualName)) {
						System.out.println("Logged in Journalist profile name got matched in story profile card");
					} else
						Assert.assertTrue(false, "Failed to match the Journalist profile name in story team card");
				} else
					Assert.assertTrue(false, "Failed to display the Journalist profile card in story team section");
				break;

			case "EDITOR":
				boolean editorProfileCard = WebAction.isDisplayed(profileCard);
				if (editorProfileCard) {
					String EditorName = PostConstants.getFirstName() + " " + PostConstants.getLastName();
					String ActualName = WebAction.getText(userDisplayName).trim();
					if (EditorName.equalsIgnoreCase(ActualName)) {
						System.out.println("Logged in Editor profile name got matched in story profile card");
					} else
						Assert.assertTrue(false, "Failed to match the Editor profile name in story team card");
				} else
					Assert.assertTrue(false, "Failed to display the Editor profile card in story team section");
				break;

			case "SENIOR EDITOR":
				boolean seniorEditorProfileCard = WebAction.isDisplayed(profileCard);
				if (seniorEditorProfileCard) {
					String SeniorEditorName = PostConstants.getFirstName() + " " + PostConstants.getLastName();
					String ActualName = WebAction.getText(userDisplayName).trim();
					if (SeniorEditorName.equalsIgnoreCase(ActualName)) {
						System.out.println("Logged in Senior Editor profile name got matched in story profile card");
					} else
						Assert.assertTrue(false, "Failed to match the Senior Editor profile name in story team card");
				} else
					Assert.assertTrue(false, "Failed to display the Senior Editor profile card in story team section");
				break;

			case "STANDARDS":
				boolean standardProfileCard = WebAction.isDisplayed(profileCard);
				if (standardProfileCard) {
					String StandardName = PostConstants.getFirstName() + " " + PostConstants.getLastName();
					String ActualName = WebAction.getText(userDisplayName).trim();
					if (StandardName.equalsIgnoreCase(ActualName)) {
						System.out.println("Logged in Standard profile name got matched in story profile card");
					} else
						Assert.assertTrue(false, "Failed to match the Standard profile name in story team card");
				} else
					Assert.assertTrue(false, "Failed to display the Standard profile card in story team section");
				break;

			default:
				Assert.assertTrue(false, "Please provide valid roles for different user profiles");

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify topics added are displayed in topic placeholder
	 * 
	 * @throws Exception
	 */
	public void verifyAddedTopics() throws Exception {
		try {
			int topicCount = StoryConstants.getStoryTopicCount();
			for (int i = 0; i < topicCount; i++) {
				// CommonValidations.verifyTextValue(addedTopicsList.get(i),
				// StoryConstants.getStoryTopic(i), "'" + StoryConstants.getStoryTopic(i) + "'
				// topic is not present in the topic place holder");
				// CommonValidations.verifyElementIsEnabled(addedTopicsRemoveIconList.get(i),
				// "Topic delete icon is not displayed for topic '" +
				// StoryConstants.getStoryTopic(i) + "'");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To add tags to story
	 *
	 * @param dataTable - Tags data table
	 * @throws Exception
	 */
	public void addTags(DataTable dataTable) throws Exception {
		try {
			List<Map<String, String>> tags = CucumberUtils.getValuesFromDataTableAsList(dataTable);
			StoryConstants.setStoryTagCount(tags.size());
			for (int i = 0; i < tags.size(); i++) {
				String tag = tags.get(i).get("Tags");
				StoryConstants.setStoryTag(i, tag);
				// WebAction.sendKeys(tagsTextBox, tag);
				// WebAction.click(addTagIcon);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify tags added are displayed in tags placeholder
	 *
	 * @throws Exception
	 */
	public void verifyAddedTags() throws Exception {
		try {
			int tagCount = StoryConstants.getStoryTagCount();
			for (int i = 0; i < tagCount; i++) {
				// CommonValidations.verifyTextValue(addedTagsList.get(i),
				// StoryConstants.getStoryTag(i), "'" + StoryConstants.getStoryTag(i) + "' tag
				// is not present in the tag place holder");
				// CommonValidations.verifyElementIsEnabled(addedTagsRemoveIconList.get(i), "Tag
				// remove icon is not displayed for tag '" + StoryConstants.getStoryTag(i) +
				// "'");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To add slack channel to story
	 *
	 * @param dataTable - Slack Channel data table
	 * @throws Exception
	 */
	public void addSlackChannel(DataTable dataTable) throws Exception {
		try {
			List<Map<String, String>> slackChannels = CucumberUtils.getValuesFromDataTableAsList(dataTable);
			StoryConstants.setStorySlackChannelCount(slackChannels.size());
			for (int i = 0; i < slackChannels.size(); i++) {
				String slackChannel = slackChannels.get(i).get("Slack Channels");
				StoryConstants.setStorySlackChannel(i, slackChannel);
				// WebAction.sendKeys(slackIntegrationTextBox, slackChannel);
				// WebAction.click(slackChannelAddIcon);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify slack channel added are displayed in slack channel placeholder
	 *
	 * @throws Exception
	 */
	public void verifyAddedSlackChannels() throws Exception {
		try {
			int slackChannelCount = StoryConstants.getStorySlackChannelCount();
			for (int i = 0; i < slackChannelCount; i++) {
				// CommonValidations.verifyTextValue(addedslackChannelList.get(i),
				// StoryConstants.getStoryTag(i), "'" + StoryConstants.getStorySlackChannel(i) +
				// "' channel is not present in the slack channel place holder");
				// CommonValidations.verifyElementIsEnabled(addedslackChannelRemoveIconList.get(i),
				// "Slack channel delete icon is not displayed for slack channel '" +
				// StoryConstants.getStorySlackChannel(i) + "'");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}