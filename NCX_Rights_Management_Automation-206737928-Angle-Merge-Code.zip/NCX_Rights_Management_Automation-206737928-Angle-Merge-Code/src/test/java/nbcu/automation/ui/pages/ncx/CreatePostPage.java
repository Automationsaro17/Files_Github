package nbcu.automation.ui.pages.ncx;

import com.aventstack.extentreports.Status;
import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.AngleConstants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.others.CommonUtils;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import nbcu.framework.utils.report.ExtentReportUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;
import java.util.Map;

public class CreatePostPage {

    /**
     * Create Post Elements
     **/
    @FindBy(xpath = "//div[contains(@class,'postTitle')]/input")
    WebElement postTitleTextBox;

    @FindBy(xpath = "//div[@class='postTitleAndContent']//div[@class='fr-element fr-view fr-element-scroll-visible']")
    WebElement postDescriptionTextBox;

    /**
     * Link Angle Elements
     */
    @FindBy(xpath = "//input[@placeholder='Search Angle Name or ID']")
    WebElement addAngleTextBox;

    /**
     * Link Story Elements
     */
    @FindBy(xpath = "//input[@placeholder='Search Story Name']")
    WebElement addStoryTextBox;
    
    @FindBy(xpath = "//input[@placeholder='Search Angle Name or ID']")
	WebElement addAngleTextBoxPlaceholder;


    @FindBy(xpath = "//span[@class='story-text']/div")
    List<WebElement> linkedStoriesName;

    @FindBy(xpath = "//span[@class='story-text']/preceding-sibling::span")
    List<WebElement> linkedStoriesCrownIcon;

    @FindBy(xpath = "//span[@class='story-text']/following-sibling::span/button[@nztype='pushpin']")
    List<WebElement> linkedStoriesPinIcon;

    @FindBy(xpath = "//span[@class='story-text']/following-sibling::span/button/span[@nztype='delete']")
    List<WebElement> linkedStoriesDeleteIcon;

    String searchDropDownValuesXpath = "//nz-auto-option[contains(@class,'ant-select-item ant-select-item-option')]/div";

    String dropDownValuesXpath = "//nz-option-item[contains(@class,'ant-select-item ant-select-item-option')]";

    @FindBy(xpath = "//div[@class='ant-message']//span[contains(text(), 'Post successfully saved as draft')]")
    WebElement savedAsDraftMessage;
    @FindBy(xpath = "//input[@type='file']")
    WebElement attachmentElement;

    /**
     * Attachment Elements
     */
    @FindBy(xpath = "//nz-upload-list[contains(@class,'ant-upload-list')]/div/div")
    List<WebElement> addedAttachmentList;

    @FindBy(xpath = "//nz-upload-list[contains(@class,'ant-upload-list')]//span[contains(@class,'ant-upload-list-item-name')]")
    List<WebElement> addedAttachmentNames;

    @FindBy(xpath = "//nz-upload-list[contains(@class,'ant-upload-list')]//span[contains(@class,'ant-upload-list-item-name')]/following-sibling::span")
    List<WebElement> addedAttachmentDeleteIcons;

    /**
     * Element details section Elements
     */
    @FindBy(xpath = "//input[@placeholder='Enter Link to Source']")
    WebElement linkToSourceTextBox;

    @FindBy(xpath = "//nz-select[contains(@class,'mandatoryCreditSelect')]")
    WebElement mandatoryCreditDropDown;

    @FindBy(xpath = "//input[@placeholder='Enter Credit Name']")
    WebElement mandatoryCreditTextBox;

    @FindBy(xpath = "//span[text()='Materials Cleared For']/span")
    WebElement materialClearedForDropDownMandatoryField;

    @FindBy(xpath = "//*[contains(@class,'materialsClearedForSelect')]/label[@nzvalue='yes']")
    WebElement clearedForNBCUPartnersYesOption;

    @FindBy(xpath = "//*[contains(@class,'materialsClearedForSelect')]/label[@nzvalue='no']")
    WebElement clearedForNBCUPartnersNoOption;

    /**
     * Post Meta Data Elements
     **/
    @FindBy(xpath = "//span[normalize-space()=\"REPORTABLE\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement reportableLabel;

    @FindBy(xpath = "//span[normalize-space()=\"NOT REPORTABLE\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement notReportableLabel;

    @FindBy(xpath = "//span[normalize-space()=\"VERIFIED\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement verifiedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"PUBLISHED/AIRED\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement publishedOrAiredLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LOG\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement logLabel;

    @FindBy(xpath = "//span[normalize-space()=\"GREAT VIDEO\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement greatVideoLabel;

    @FindBy(xpath = "//span[normalize-space()=\"IMPORTANT\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement importantLabel;

    @FindBy(xpath = "//span[normalize-space()=\"HOT\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement hotLabel;

    @FindBy(xpath = "//span[normalize-space()=\"STANDARDS\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement standardsLabel;

    @FindBy(xpath = "//span[normalize-space()=\"CLEARED\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement clearedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LICENSED\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement licensedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LIMITED LICENSE\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement limitedLicensedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"NEEDS LICENSING\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement needsLicensingLabel;

    @FindBy(xpath = "//span[normalize-space()=\"COPYRIGHT RISK\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement copyRightRiskLabel;

    @FindBy(xpath = "//span[normalize-space()=\"DO NOT USE\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement doNotUseLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LEGAL\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement legalLabel;

    /**
     * Standard Guidance Section Elements
     */
    @FindBy(xpath = "//div[@id='standardGuidance']//div[@class='fr-element fr-view']")
    WebElement standardGuidanceTextBox;

    /**
     * Reportable Section Elements
     */
    @FindBy(xpath = "//div[@class='reportableLabel']")
    WebElement reportableApproverText;

    @FindBy(xpath = "//nz-select[contains(@class,'reportableOptions')]")
    WebElement reportableApproverOption;

    @FindBy(xpath = "//input[@placeholder=\"Sr.Approver's name\"]")
    WebElement seniorApproverNameTextBox;

    @FindBy(xpath = "//div[@class='reportableTextArea']/textarea")
    WebElement reportableApproverNotesTextBox;

    /**
     * Limited License Section Elements
     */
    @FindBy(xpath = "//div[@class='licenseTextArea']/textarea")
    WebElement limitedLicenseTextBox;


    /**
     * Button Elements
     */
    @FindBy(xpath = "//button[span[@nztype='send']]")
    WebElement publishButton;

    @FindBy(xpath = "//button[span[@nztype='expand']]")
    WebElement previewButton;

    @FindBy(xpath = "//button[span[@nztype='save']]")
    WebElement saveDraftButton;

    @FindBy(xpath = "//button[span[@nztype='close']]")
    WebElement cancelButton;

    /**
     * Edit Post Elements
     */
    @FindBy(xpath = "//span[normalize-space()='Do not Send Email Update for this Edit']/preceding-sibling::span/input")
    WebElement doNotSendEmailForEditCheckBox;

    @FindBy(xpath = "//span[normalize-space()='Do not Send Email Update for this Edit']/preceding-sibling::span")
    WebElement doNotSendEmailForEditCheckBoxStatus;


    public CreatePostPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify create post page is displayed
     *
     * @throws Exception
     */
    public void verifyCreatePostPageLoaded() throws Exception {
        try {
            Waits.waitForElement(postTitleTextBox, Waits.WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
    
    
    /**
	 * To verify the browser tab title for create post screen
	 */
	public void verifyBrowserTabTitle(String ExpectedTitle) {
		try {
			String ActualTitle = WebAction.getWindowTitle().trim();
			if (ActualTitle.equalsIgnoreCase(ActualTitle)) {
				Assert.assertTrue(true, "' " + ActualTitle + " 'is smale as the" + ExpectedTitle);
			} else
				Assert.assertFalse(false, ActualTitle + " is not matched with the " + ExpectedTitle);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

    /**
     * To fill post title
     *
     * @param postTitle - Post Title
     * @throws Exception
     */
    public void fillPostTitle(String postTitle) throws Exception {
        try {
            postTitle = postTitle + "_" + CommonUtils.generateRandomString(12);
            PostConstants.setPostTitle(postTitle);
            WebAction.clearUsingKeys(postTitleTextBox);
            WebAction.sendKeys(postTitleTextBox, postTitle);
            ExtentReportUtils.addLog(Status.INFO, "Post Title: "+postTitle);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fill post description
     *
     * @param postDescription - Post description
     * @throws Exception
     */
    public void fillPostDescription(String postDescription) throws Exception {
        try {
            PostConstants.setPostDescription(postDescription);
            WebAction.click(postDescriptionTextBox);
            WebAction.sendKeys(postDescriptionTextBox, postDescription);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To Link angle to post
     *
     * @param params - Angle list
     * @throws Exception
     */
    public void linkAngle(DataTable params) throws Exception {
        try {
            List<Map<String, String>> angleList = CucumberUtils.getValuesFromDataTableAsList(params);
            PostConstants.setLinkedAngleCount(angleList.size());
            WebAction.scrollIntoView(addAngleTextBox);
            for (int i = 0; i < angleList.size(); i++) {
                String angleName = angleList.get(i).get("Angle name");
                PostConstants.setLinkedAngle(i, angleName);
                WebAction.selectNonTitleDropDown(addAngleTextBox, angleName, searchDropDownValuesXpath, angleName + " is not present in the add to angle");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To link story to post
     *
     * @param storyName - Story Name
     * @throws Exception
     */
    public void linkStory(String storyName) throws Exception {
        try {
            WebAction.scrollIntoView(addStoryTextBox);
            PostConstants.setLinkedStoryCount(1);
            PostConstants.setLinkedStory(0, storyName);
            PostConstants.setPrimaryStory(storyName);
            WebAction.selectNonTitleDropDown(addStoryTextBox, storyName, searchDropDownValuesXpath, storyName + " is not present in the add to story");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify linked stories list are displayed with pin and delete
     *
     * @throws Exception
     */
    public void verifyLinkedStories() throws Exception {
        try {
            for (int i = 0; i < PostConstants.getLinkedStoryCount(); i++) {
                CommonValidations.verifyTextValue(linkedStoriesName.get(i), PostConstants.getLinkedStory(i), "'" + PostConstants.getLinkedStory(i) + "' story is not linked to post");
                CommonValidations.verifyElementIsEnabled(linkedStoriesPinIcon.get(i), "Pin story icon is not displayed for story '" + PostConstants.getLinkedStory(i) + "'");
                CommonValidations.verifyElementIsEnabled(linkedStoriesDeleteIcon.get(i), "Delete story icon is not displayed for story '" + PostConstants.getLinkedStory(i) + "'");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify primary story of post
     *
     * @param color - crown color
     * @throws Exception
     */
    public void verifyStoryMarkedAsPrimary(String color) throws Exception {
        try {
            String primaryPrimary = PostConstants.getPrimaryStory();
            for (int i = 0; i < PostConstants.getLinkedStoryCount(); i++) {
                String actualStoryName = WebAction.getText(linkedStoriesName.get(i));
                if (actualStoryName.equalsIgnoreCase(primaryPrimary)) {
                    CommonValidations.verifyAttributeValue(linkedStoriesCrownIcon.get(i), "class", "primary", "'" + actualStoryName + "' is not ,marked as primary in create/edit post page");
                    CommonValidations.verifyColorOfElement(linkedStoriesCrownIcon.get(i), "background color", color);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify post as draft message
     *
     * @throws Exception
     */
    public void verifyPostSavedAsDraft() throws Exception {
        try {
            Waits.waitForElement(savedAsDraftMessage, Waits.WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To add attachments
     *
     * @param params - attachment names
     * @throws Exception
     */
    public void addAttachments(DataTable params) throws Exception {
        try {
            List<Map<String, String>> attachmentList = CucumberUtils.getValuesFromDataTableAsList(params);
            PostConstants.setAttachmentCount(String.valueOf(attachmentList.size()));
            WebAction.scrollIntoView(attachmentElement);
            for (int i = 0; i < attachmentList.size(); i++) {
                String attachmentName = attachmentList.get(i).get("Attachment Name");
                PostConstants.setAttachmentName(i, attachmentName);
                String filePath = System.getProperty("user.dir") + "/"+ ConfigFileReader.getProperty("File-Upload-Path") +"/" + attachmentName;
                WebAction.sendKeys_WithoutClear(attachmentElement, filePath);
                Waits.waitUntilAttributeValueContains(addedAttachmentList.get(addedAttachmentList.size() - 1), "class", "item-done");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify added attachments in post
     *
     * @throws Exception
     */
    public void verifyAddedAttachments() throws Exception {
        try {
            int attachmentSize = Integer.parseInt(PostConstants.getAttachmentCount());
            for (int i = 0; i < attachmentSize; i++) {
                CommonValidations.verifyAttributeValue(addedAttachmentNames.get(i), "title", PostConstants.getAttachmentName(i), PostConstants.getAttachmentName(i) + " file is not added to post attachment");
                CommonValidations.verifyElementIsEnabled(addedAttachmentDeleteIcons.get(i), "Delete attachment icon is not displayed for attachment '" + PostConstants.getAttachmentName(i) + "' in create post page");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify material cleared for field is marked as mandatory
     *
     * @throws Exception
     */
    public void verifyMaterialClearedForMarkedAsMandatory() throws Exception {
        try {
            CommonValidations.verifyAttributeValue(materialClearedForDropDownMandatoryField, "class", "mandatory", "Material cleared for field is not marked as mandatory even though attachment added");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fill link to source in element details section
     *
     * @param linkToSource
     * @throws Exception
     */
    public void fillLinkToSource(String linkToSource) throws Exception {
        try {
            PostConstants.setLinkToSource(linkToSource);
            WebAction.sendKeys(linkToSourceTextBox, linkToSource);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fill mandatory credit details
     *
     * @param mandatoryCreditOption - Mandatory credit option
     * @param mandatoryCreditValue  - Mandatory credit value
     * @throws Exception
     */
    public void fillMandatoryCredit(String mandatoryCreditOption, String mandatoryCreditValue) throws Exception {
        try {
            PostConstants.setMandatoryCreditOption(mandatoryCreditOption);
            PostConstants.setMandatoryCreditValue(mandatoryCreditValue);
            WebAction.click(mandatoryCreditDropDown);
            WebAction.nonEnterableSelectDropDown(dropDownValuesXpath, mandatoryCreditOption, mandatoryCreditOption + " option is not available in mandatory credit drop down option");
            if (mandatoryCreditOption.equalsIgnoreCase("YES"))
                WebAction.sendKeys(mandatoryCreditTextBox, mandatoryCreditValue);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fill cleared for NBCU partners option
     *
     * @param clearedForNbcuPartners - cleared for NBCU Parters option
     * @throws Exception
     */
    public void fillClearedForNbcuPartners(String clearedForNbcuPartners) throws Exception {
        try {
            PostConstants.setClearedForNbcuPartners(clearedForNbcuPartners);
            if (clearedForNbcuPartners.equalsIgnoreCase("YES"))
                WebAction.click(clearedForNBCUPartnersYesOption);
            else WebAction.click(clearedForNBCUPartnersNoOption);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To select editorial/standards label
     *
     * @param params - editorial/standards label
     * @throws Exception
     */
    public void selectEditorialOrStandardsLabel(DataTable params) throws Exception {
        try {
            List<Map<String, String>> standardsLabels = CucumberUtils.getValuesFromDataTableAsList(params);
            PostConstants.setStandardsLabelsCount(String.valueOf(standardsLabels.size()));
            for (int i = 0; i < standardsLabels.size(); i++) {
                String standardLabel = standardsLabels.get(i).get("Editorial/Standards Label");
                PostConstants.setStandardsLabel(i, standardLabel);
                switch (standardLabel.toUpperCase()) {
                    case "REPORTABLE":
                        WebAction.click(reportableLabel);
                        break;
                    case "NOT REPORTABLE":
                        WebAction.click(notReportableLabel);
                        break;
                    case "VERIFIED":
                        WebAction.click(verifiedLabel);
                        break;
                    case "PUBLISHED/AIRED":
                        WebAction.click(publishedOrAiredLabel);
                        break;
                    case "LOG":
                        WebAction.click(logLabel);
                        break;
                    case "GREAT VIDEO":
                        WebAction.click(greatVideoLabel);
                        break;
                    case "IMPORTANT":
                        WebAction.click(importantLabel);
                        break;
                    case "HOT":
                        WebAction.click(hotLabel);
                        break;
                    case "STANDARDS":
                        WebAction.click(standardsLabel);
                        break;
                    default:
                        Assert.assertTrue(false, "Please enter valid Editorial/Standards label. Given '" + standardLabel + "' is not present in the application");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To select R&C/Legal label
     *
     * @param params - R&C/Legal label
     * @throws Exception
     */
    public void selectRcOrLegalLabel(DataTable params) throws Exception {
        try {
            List<Map<String, String>> rcLegalLabels = CucumberUtils.getValuesFromDataTableAsList(params);
            PostConstants.setLegalLabelsCount(String.valueOf(rcLegalLabels.size()));
            WebAction.scrollIntoView(clearedLabel);
            for (int i = 0; i < rcLegalLabels.size(); i++) {
                String rcLegalLabel = rcLegalLabels.get(i).get("R&C/Legal Label");
                PostConstants.setLegalLabel(i, rcLegalLabel);
                switch (rcLegalLabel.toUpperCase()) {
                    case "CLEARED":
                        WebAction.click(clearedLabel);
                        break;
                    case "LICENSED":
                        WebAction.click(licensedLabel);
                        break;
                    case "LIMITED LICENSE":
                        WebAction.click(limitedLicensedLabel);
                        break;
                    case "NEEDS LICENSING":
                        WebAction.click(needsLicensingLabel);
                        break;
                    case "COPYRIGHT RISK":
                        WebAction.click(copyRightRiskLabel);
                        break;
                    case "DO NOT USE":
                        WebAction.click(doNotUseLabel);
                        break;
                    case "LEGAL":
                        WebAction.click(legalLabel);
                        break;
                    default:
                        Assert.assertTrue(false, "Please enter valid R&C/Legal label. Given '" + rcLegalLabel + "' is not present in the application");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify Standard Guidance/Reportable/Limited license section is displayed
     *
     * @param labelName - Standard Guidance/Reportable/Limited License
     * @throws Exception
     */
    public void verifyLabelSectionDisplayed(String labelName) throws Exception {
        try {
            if (labelName.equalsIgnoreCase("STANDARD GUIDANCE"))
                CommonValidations.verifyElementIsDisplayed(standardGuidanceTextBox, "Standard Guidance section is not displayed");
            else if (labelName.equalsIgnoreCase("REPORTABLE"))
                CommonValidations.verifyElementIsDisplayed(reportableApproverOption, "Reportable approver section is not displayed");
            else if (labelName.equalsIgnoreCase("LIMITED LICENSE"))
                CommonValidations.verifyElementIsDisplayed(limitedLicenseTextBox, "Limited license section is not displayed");
            else Assert.assertTrue(false, "Please enter valid section name");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fill standard guidance description
     *
     * @param standardGuidanceDescription - Standard guidance description
     * @throws Exception
     */
    public void fillStandardGuidance(String standardGuidanceDescription) throws Exception {
        try {
            WebAction.scrollIntoView(standardGuidanceTextBox);
            PostConstants.setStandardGuidance(standardGuidanceDescription);
            WebAction.sendKeys(standardGuidanceTextBox, standardGuidanceDescription);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fill reportable approver section
     *
     * @param reportableLabelDescription - reportable label description
     * @param reportableOption           - reportable option
     * @param seniorApproverName         - reportable senior approver name
     * @param reportableNotes            - reportable notes
     * @throws Exception
     */
    public void fillReportableApproverSection(String reportableLabelDescription, String reportableOption, String seniorApproverName, String reportableNotes) throws Exception {
        try {
            WebAction.scrollIntoView(reportableApproverOption);
            CommonValidations.verifyTextValue(reportableApproverText, reportableLabelDescription, reportableApproverText + " field name is not correct in reportable approver section");

            // To select reportable option
            PostConstants.setReportableApproverOption(reportableOption);
            WebAction.click(reportableApproverOption);
            WebAction.nonEnterableSelectDropDown(dropDownValuesXpath, reportableOption, reportableOption + " option is present in the reportable approver section");

            if (reportableOption.equalsIgnoreCase("NO"))
                WebAction.sendKeys(seniorApproverNameTextBox, seniorApproverName);
            else seniorApproverName = "From an official named source, no need for senior approval";
            PostConstants.setSrApproverName(seniorApproverName);

            // To fill reportable section notes
            if (reportableNotes != null) {
                PostConstants.setReportableNotes(reportableNotes);
                WebAction.sendKeys(reportableApproverNotesTextBox, reportableNotes);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fill limited license description
     *
     * @param limitedLicenseDescription - limited license description
     * @throws Exception
     */
    public void fillLimitedLicense(String limitedLicenseDescription) throws Exception {
        try {
            WebAction.scrollIntoView(limitedLicenseTextBox);
            PostConstants.setLimitedLicense(limitedLicenseDescription);
            WebAction.sendKeys(limitedLicenseTextBox, limitedLicenseDescription);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To click button in create post page
     *
     * @param buttonName - button name
     * @throws Exception
     */
    public void clickButton(String buttonName, String pageType) throws Exception {
        try {
            switch (buttonName.toUpperCase()) {
                case "CANCEL":
                    WebAction.click(cancelButton);
                    break;
                case "SAVE DRAFT":
                    WebAction.click(saveDraftButton);
                    PostConstants.setDraftPostCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                    PostConstants.setDraftPostCreationDate(DateFunctions.getCurrentDate("M/d/yy"));
                    break;
                case "PREVIEW":
                    WebAction.click(previewButton);
                    break;
                case "PUBLISH":
                    WebAction.click(publishButton);

                    /** To update post creation/modified date and time **/
                    if (pageType.equalsIgnoreCase("CREATE")) {
                        PostConstants.setPostCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                        PostConstants.setPostCreationDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    } else {
                        PostConstants.setPostModifiedTime(DateFunctions.getCurrentDate("h:mm a"));
                        PostConstants.setPostModifiedDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    }

                    /** To update standard guidance creation date and time if standards label is selected**/
                    boolean standardsLabelCheck = false;
                    if (PostConstants.getStandardsLabelsCount() != null) {
                        for (int i = 0; i < Integer.parseInt(PostConstants.getStandardsLabelsCount()); i++) {
                            if (PostConstants.getStandardsLabel(i).trim().equalsIgnoreCase("STANDARDS")) {
                                standardsLabelCheck = true;
                                break;
                            }
                        }
                    }
                    if (standardsLabelCheck && PostConstants.getStandardGuidanceCreationDate() == null) {
                        PostConstants.setStandardGuidanceCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                        PostConstants.setStandardGuidanceCreationDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    }
                    break;
                default:
                    Assert.assertTrue(false, "Please provide valid button name in create/edit post page");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }


    /**
     * To verify 'Do not Send Email Update for this Edit' check box is checked by default in edit post page
     */
    public void verifyDoNotSendEmailForUpdateCheckBoxStatus() throws Exception {
        try {
            Waits.waitForElement(doNotSendEmailForEditCheckBoxStatus, Waits.WAIT_CONDITIONS.CLICKABLE);
            CommonValidations.verifyAttributeValue(doNotSendEmailForEditCheckBoxStatus, "class", "checked", "'Do not Send Email Update for this Edit' check box is not checked by default in edit post page");
            Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To check/Uncheck Do not send email for update check box
     *
     * @throws Exception
     */
    public void checkOrUnCheckDoNotSendEmailForUpdateCheckBox() throws Exception {
        try {
            WebAction.scrollIntoView(doNotSendEmailForEditCheckBox);
            WebAction.clickUsingJs(doNotSendEmailForEditCheckBox);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
    
    //Loga - Merged -> Date -->> 04/22/2024
    
    /**
	 * To verify linked angles are displayed with delete icon
	 * 
	 * @throws Exception
	 */

	@FindBy(xpath = "//span[@class='angle-id-text-flex']/div[@class='angle-id']")
	WebElement angleID;

	@FindBy(xpath = "//span[@class='angle-id-text-flex']/div[@class='angle-text']")
	WebElement angleName;

	@FindBy(xpath = "//span[contains(@class,'angle-id')]/following-sibling::button/span[@nztype='delete']")
	List<WebElement> linkedAnglesDeleteICon;

	@FindBy(xpath = "//span[contains(@class,'angle-id]/following-sibling::span/button/span[@nztype='pushpin']")
	List<WebElement> linkedAnglesPinIcon;

	public void veriyfLinkedAngle() throws Exception {
		try {
			String ExpectedAngleID = AngleConstants.getAngleID();
			String ExpectedAngleTitle = AngleConstants.getAngleTitle();
			WebAction.scrollIntoView(addAngleTextBoxPlaceholder);
			String ActualAngleID = WebAction.getText(angleID).trim();
			ActualAngleID = ActualAngleID.replaceAll("\\D+", "");
			if (ActualAngleID.equalsIgnoreCase(ExpectedAngleID)) {
				Assert.assertTrue(true, ExpectedAngleID + " got matched while" + " creating a new post to an angle");
			} else
				Assert.assertFalse(true, ExpectedAngleID + " is matched with creating a new post");
			CommonValidations.verifyTextValue(angleName, ExpectedAngleTitle,
					"'" + ExpectedAngleTitle + "'" + " is not linked to the post");
			CommonValidations.verifyElementIsEnabled(linkedAnglesDeleteICon.get(0),
					"Delete angle picon is not enabled to the linked angle " + ExpectedAngleTitle);
			/*
			 * if( WebAction.isDisplayed(linkedAnglesPinIcon.get(0))){
			 * Assert.assertTrue(false,
			 * "'Linked angles having the Pin icon to the section'"); }else
			 * Assert.assertFalse(false,
			 * "'Linked angles not having the pin icon to the section'");
			 */
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
