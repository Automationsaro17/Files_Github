package nbcu.automation.ui.pages.ncx;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.others.CommonUtils;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.cucumber.CucumberUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;
import java.util.Map;

public class CreateStoryPage {

    /**
     * Main Content Elements
     **/
    @FindBy(xpath = "//label[contains(@nzvalue,'WORKING')]")
    WebElement workingStory;
    @FindBy(xpath = "//label[contains(@nzvalue,'READY')]")
    WebElement readyStory;

    @FindBy(xpath = "//nz-select-item[@class='ant-select-selection-item ng-star-inserted']")
    WebElement storyPrivacyDropDown;

    @FindBy(xpath = "//div[contains(@class,'storyInput')]/input")
    WebElement storyTitleTextBox;

    @FindBy(xpath = "//div[@class='fr-element fr-view fr-element-scroll-visible']")
    WebElement storyDescriptionTextBox;

    // Drop down value xpath
    String dropDownValuesXpath = "//nz-option-item[contains(@class,'ant-select-item ant-select-item-option')]";

    /**
     * Meta Data Elements
     **/
    @FindBy(xpath = "//nz-select[@nzplaceholder='Select Topic']//input")
    WebElement topicDropDown;

    @FindBy(xpath = "//div[@class='topic-text']")
    List<WebElement> addedTopicsList;

    @FindBy(xpath = "//div[@class='topic-text']/following-sibling::div[@nztype='close']")
    List<WebElement> addedTopicsRemoveIconList;

    @FindBy(xpath = "//input[@placeholder='Add Tag']")
    WebElement tagsTextBox;

    @FindBy(xpath = "//i[@nztitle='Add Tag']")
    WebElement addTagIcon;

    @FindBy(xpath = "//button[span[text()='Generate Tags']]")
    WebElement generateTagsButton;

    @FindBy(xpath = "//span[@class='tags-text']")
    List<WebElement> addedTagsList;

    @FindBy(xpath = "//span[@class='tags-text']/following-sibling::span[@nztype='close']")
    List<WebElement> addedTagsRemoveIconList;

    @FindBy(xpath = "//input[@placeholder='Enter slack channel name here']")
    WebElement slackIntegrationTextBox;

    @FindBy(xpath = "//input[@placeholder='Enter slack channel name here']/following-sibling::span/i")
    WebElement slackChannelAddIcon;

    @FindBy(xpath = "//div[contains(@class,'slack-list')]/span")
    List<WebElement> addedslackChannelList;

    @FindBy(xpath = "//div[contains(@class,'slack-list')]/span/following-sibling::i[@nztype='delete']")
    List<WebElement> addedslackChannelRemoveIconList;

    /**
     * Buttons Element
     */
    @FindBy(id = "test")
    WebElement publishButton;

    @FindBy(xpath = "//button[contains(@class,'preview')]")
    WebElement previewButton;

    @FindBy(xpath = "//button[contains(@class,'save-draft')]")
    WebElement saveDraftButton;

    @FindBy(xpath = "//button[contains(@class,'cancel')]")
    WebElement cancelButton;

    public CreateStoryPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify create story page is loaded
     *
     * @throws Exception
     */
    public void verifyCreateStoryPageLoaded() throws Exception {
        try {
            Waits.waitForElement(storyTitleTextBox, WAIT_CONDITIONS.CLICKABLE);
            Waits.waitForElement(publishButton, WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To select story type
     *
     * @param storyStatus - Story Status.(i.e) Working/Ready
     * @throws Exception
     */
    public void selectStoryStatus(String storyStatus) throws Exception {
        try {
            StoryConstants.setStoryStatus(storyStatus);
            Waits.waitForElement(workingStory, WAIT_CONDITIONS.CLICKABLE);
            if (storyStatus.equalsIgnoreCase("WORKING")) WebAction.click(workingStory);
            else WebAction.click(readyStory);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To select story visibility to public/private
     *
     * @param storyPrivacy - Public/Private
     * @throws Exception
     */
    public void selectStoryPrivacy(String storyPrivacy) throws Exception {
        try {
            StoryConstants.setStoryPrivacy(storyPrivacy);
            Waits.waitForElement(storyPrivacyDropDown, WAIT_CONDITIONS.CLICKABLE);
            WebAction.click(storyPrivacyDropDown);
            WebAction.nonEnterableSelectDropDown(dropDownValuesXpath, storyPrivacy, storyPrivacy + " is not present in the story visibility drop down");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fill story title
     *
     * @param storyTitle - Story title. 12 digits random alphanumeric string will be appended in the end for automation purpose
     * @throws Exception
     */
    public void fillStoryTitle(String storyTitle) throws Exception {
        try {
            storyTitle = storyTitle + "_" + CommonUtils.generateRandomString(12);
            StoryConstants.setStoryTitle(storyTitle);
            WebAction.clearUsingKeys(storyTitleTextBox);
            WebAction.sendKeys(storyTitleTextBox, storyTitle);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fill story description
     *
     * @param storyDescription - Story description
     * @throws Exception
     */
    public void fillStoryDescription(String storyDescription) throws Exception {
        try {
            StoryConstants.setStoryDescription(storyDescription);
            WebAction.click(storyDescriptionTextBox);
            WebAction.sendKeys(storyDescriptionTextBox, storyDescription);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To add topics to story
     *
     * @param dataTable - Topics data table
     * @throws Exception
     */
    public void selectTopic(DataTable dataTable) throws Exception {
        try {
            //To remove already added topics
            if (addedTopicsRemoveIconList.size() > 0) {
                for (WebElement topicRemoveBtn : addedTopicsRemoveIconList)
                    WebAction.click(topicRemoveBtn);
            }

            //To add topics
            List<Map<String, String>> topics = CucumberUtils.getValuesFromDataTableAsList(dataTable);
            StoryConstants.setStoryTopicCount(topics.size());
            for (int i = 0; i < topics.size(); i++) {
                String topic = topics.get(i).get("Topics");
                StoryConstants.setStoryTopic(i, topic);
                WebAction.selectDropDown(topicDropDown, topic, dropDownValuesXpath, topic + " is not present in the topics drop down");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify topics added are displayed in topic placeholder
     *
     * @throws Exception
     */
    public void verifyAddedTopics() throws Exception {
        try {
            int topicCount = StoryConstants.getStoryTopicCount();
            for (int i = 0; i < topicCount; i++) {
                CommonValidations.verifyTextValue(addedTopicsList.get(i), StoryConstants.getStoryTopic(i), "'" + StoryConstants.getStoryTopic(i) + "' topic is not present in the topic place holder");
                CommonValidations.verifyElementIsEnabled(addedTopicsRemoveIconList.get(i), "Topic delete icon is not displayed for topic '" + StoryConstants.getStoryTopic(i) + "'");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To add tags to story
     *
     * @param storyOrPost - Story/Post
     * @param dataTable   - Tags data table
     * @throws Exception
     */
    public void addTags(String storyOrPost, DataTable dataTable) throws Exception {
        try {
            //To remove already added tags
            if (addedTagsRemoveIconList.size() > 0) {
                for (WebElement tagRemoveBtn : addedTagsRemoveIconList)
                    WebAction.click(tagRemoveBtn);
            }

            //To add tags
            List<Map<String, String>> tags = CucumberUtils.getValuesFromDataTableAsList(dataTable);
            if (storyOrPost.equalsIgnoreCase("story"))
                StoryConstants.setStoryTagCount(tags.size());
            else
                PostConstants.setPostTagCount(tags.size());
            for (int i = 0; i < tags.size(); i++) {
                String tag = tags.get(i).get("Tags");
                if (storyOrPost.equalsIgnoreCase("story"))
                    StoryConstants.setStoryTag(i, tag);
                else PostConstants.setPostTag(i, tag);
                WebAction.sendKeys(tagsTextBox, tag);
                WebAction.click(addTagIcon);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify tags added are displayed in tags placeholder
     *
     * @throws Exception
     */
    public void verifyAddedTags() throws Exception {
        try {
            int tagCount = StoryConstants.getStoryTagCount();
            for (int i = 0; i < tagCount; i++) {
                CommonValidations.verifyTextValue(addedTagsList.get(i), StoryConstants.getStoryTag(i), "'" + StoryConstants.getStoryTag(i) + "' tag is not present in the tag place holder");
                CommonValidations.verifyElementIsEnabled(addedTagsRemoveIconList.get(i), "Tag remove icon is not displayed for tag '" + StoryConstants.getStoryTag(i) + "'");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To add slack channel to story
     *
     * @param dataTable - Slack Channel data table
     * @throws Exception
     */
    public void addSlackChannel(DataTable dataTable) throws Exception {
        try {
            WebAction.scrollIntoView(slackIntegrationTextBox);
            //To remove already added slack channels
            if (addedslackChannelRemoveIconList.size() > 0) {
                for (WebElement slackChannelRemoveBtn : addedslackChannelRemoveIconList)
                    WebAction.click(slackChannelRemoveBtn);
            }

            //To add slack channels
            List<Map<String, String>> slackChannels = CucumberUtils.getValuesFromDataTableAsList(dataTable);
            StoryConstants.setStorySlackChannelCount(slackChannels.size());
            for (int i = 0; i < slackChannels.size(); i++) {
                String slackChannel = slackChannels.get(i).get("Slack Channels");
                StoryConstants.setStorySlackChannel(i, slackChannel);
                WebAction.sendKeys(slackIntegrationTextBox, slackChannel);
                WebAction.click(slackChannelAddIcon);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify slack channel added are displayed in slack channel placeholder
     *
     * @throws Exception
     */
    public void verifyAddedSlackChannels() throws Exception {
        try {
            int slackChannelCount = StoryConstants.getStorySlackChannelCount();
            for (int i = 0; i < slackChannelCount; i++) {
                CommonValidations.verifyTextValue(addedslackChannelList.get(i), StoryConstants.getStorySlackChannel(i), "'" + StoryConstants.getStorySlackChannel(i) + "' channel is not present in the slack channel place holder");
                CommonValidations.verifyElementIsEnabled(addedslackChannelRemoveIconList.get(i), "Slack channel delete icon is not displayed for slack channel '" + StoryConstants.getStorySlackChannel(i) + "'");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To click button in create/edit story page
     *
     * @param buttonName - button name
     * @throws Exception
     */
    public void clickButton(String buttonName, String pageType) throws Exception {
        try {
            switch (buttonName.toUpperCase()) {
                case "CANCEL":
                    WebAction.click(cancelButton);
                    break;
                case "SAVE DRAFT":
                    WebAction.click(saveDraftButton);
                    StoryConstants.setDraftStoryCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                    StoryConstants.setDraftStoryCreationDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    break;
                case "PREVIEW":
                    WebAction.click(previewButton);
                    break;
                case "PUBLISH":
                    WebAction.click(publishButton);
                    if (pageType.equalsIgnoreCase("CREATE")) {
                        StoryConstants.setStoryCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                        StoryConstants.setStoryCreationDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    }
                    break;
                default:
                    Assert.assertTrue(false, "Please provide valid button name in create/edit story page");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
    
    
    /**
     * To click button in create/edit story page
     *
     * @param buttonName - button name
     * @throws Exception
     */
    public void clickButtons(String buttonName) throws Exception {
        try {
            switch (buttonName.toUpperCase()) {
                case "CANCEL":
                    WebAction.click(cancelButton);
                    break;
                case "SAVE DRAFT":
                    WebAction.click(saveDraftButton);
                    break;
                case "PREVIEW":
                    WebAction.click(previewButton);
                    break;
                case "PUBLISH":
                    WebAction.click(publishButton);
                    StoryConstants.setStoryCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                    StoryConstants.setStoryCreationDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    break;
                default:
                    Assert.assertTrue(false, "Please provide valid button name in create/edit story page");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

}