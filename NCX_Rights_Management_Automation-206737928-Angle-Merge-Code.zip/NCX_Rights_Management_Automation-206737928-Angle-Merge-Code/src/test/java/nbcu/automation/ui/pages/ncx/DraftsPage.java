package nbcu.automation.ui.pages.ncx;

import nbcu.automation.ui.constants.ncx.Constants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.encryption.PasswordEncryption;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

public class DraftsPage {

    /**
     * Drafts page Header elements
     */
    @FindBy(xpath = "//button[span[normalize-space()='Posts']]")
    WebElement draftTypeDropDown;

    @FindBy(xpath = "//li[contains(@class,'ant-dropdown-menu-item')]/span[normalize-space()='Posts']")
    WebElement postsDraftOption;

    @FindBy(xpath = "//li[contains(@class,'ant-dropdown-menu-item')]/span[normalize-space()='Stories']")
    WebElement storiesDraftOption;

    @FindBy(xpath = "//li[contains(@class,'ant-dropdown-menu-item')]/span[normalize-space()='Discussions']")
    WebElement discussionsDraftOption;

    /**
     * Drafts page content elements
     */

    @FindBy(xpath = "//div[@class='head ng-star-inserted']")
    List<WebElement> draftsTypeList;

    @FindBy(xpath = "//div[contains(@class,'draftTitle')]/a")
    List<WebElement> draftsPostorStoryTitleList;

    @FindBy(xpath = "//span[@class='dateTime']")
    List<WebElement> draftsPostorStoryDateAndTimeList;

    @FindBy(xpath = "//span[@class='deleteIcon']")
    List<WebElement> draftsPostorStoryDeleteIconList;

    public DraftsPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify drafts page loaded
     *
     * @throws Exception
     */
    public void verifyDraftsPageLoaded() throws Exception {
        try {
            Waits.waitForElement(draftsPostorStoryTitleList.get(0), WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }


    /**
     * To select Posts/Stories/Discussions tab
     *
     * @param draftType - Draft name
     * @throws Exception
     */
    public void selectDraftPage(String draftType) throws Exception {
        try {
            if (draftType.equalsIgnoreCase("POSTS"))
                WebAction.mouseOverAndClick(draftTypeDropDown, postsDraftOption);
            else if (draftType.equalsIgnoreCase("STORIES"))
                WebAction.mouseOverAndClick(draftTypeDropDown, storiesDraftOption);
            else if (draftType.equalsIgnoreCase("DISCUSSIONS"))
                WebAction.mouseOverAndClick(draftTypeDropDown, discussionsDraftOption);
            else
                Assert.assertTrue(false, "Given draft type " + draftType + "is not found. Please enter valid tab name in drafts page");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify draft post/story/discussion details
     *
     * @param draftType POSTS/STORIES/DISCUSSIONS
     * @throws Exception
     */
    public void verifyDraftPostStoryDetails(String draftType) throws Exception {
        try {
            /**
             * Setting expected value
             */
            int expectedRecordNumber = -1;
            String expectedDraftTitle = "", expectedDraftType = "", expectedDraftCreationDate = "", expectedDraftCreationTime = "";
            if (draftType.equalsIgnoreCase("POSTS")) {
                expectedDraftType = "Post";
                expectedDraftTitle = PostConstants.getPostTitle();
                expectedDraftCreationDate = PostConstants.getDraftPostCreationDate();
                expectedDraftCreationTime = PostConstants.getDraftPostCreationTime();
            } else if (draftType.equalsIgnoreCase("STORIES")) {
                expectedDraftType = "Story";
                expectedDraftTitle = StoryConstants.getStoryTitle();
                expectedDraftCreationDate = StoryConstants.getDraftStoryCreationDate();
                expectedDraftCreationTime = StoryConstants.getDraftStoryCreationTime();
            } else if (draftType.equalsIgnoreCase("DISCUSSIONS")) {
                //TO DO
            } else
                Assert.assertTrue(false, "Given draft type " + draftType + "is not found. Please enter valid tab name in drafts page");

            /**
             * Find draft post/story/discussion row number
             */
            Waits.waitForElement(draftsPostorStoryTitleList.get(0), WAIT_CONDITIONS.CLICKABLE);
            for (int i = 0; i < draftsPostorStoryTitleList.size(); i++) {
                if (WebAction.getText(draftsPostorStoryTitleList.get(i)).trim().equalsIgnoreCase(expectedDraftTitle)) {
                    expectedRecordNumber = i;
                    break;
                }
            }


            /**
             * Validating draft post/story/discussion details
             */
            if (expectedRecordNumber >= 0) {
                CommonValidations.verifyTextValue(draftsTypeList.get(expectedRecordNumber), expectedDraftType, "Draft type is not displayed as " + draftType);
                CommonValidations.verifyTextValue(draftsPostorStoryTitleList.get(expectedRecordNumber), expectedDraftTitle, "Draft " + expectedDraftType + " title is not correct");
                CommonValidations.verifyTextValue(draftsPostorStoryDateAndTimeList.get(expectedRecordNumber), expectedDraftCreationDate, "Draft " + expectedDraftType + " creation date is not correct");
                CommonValidations.verifyCreationTime(draftsPostorStoryDateAndTimeList.get(expectedRecordNumber), expectedDraftCreationTime, "h:mm a", "Draft " + expectedDraftType + " creation time is not correct");
                CommonValidations.verifyElementIsDisplayed(draftsPostorStoryDeleteIconList.get(expectedRecordNumber), "Delete icon is not displayed for draft " + expectedDraftType);
            } else Assert.assertTrue(false, "Draft " + draftType + "is not found in the drafts page");

            /**
             * To open draft post/story/discussion
             */
            WebAction.clickUsingJs(draftsPostorStoryTitleList.get(expectedRecordNumber));
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
}
