package nbcu.automation.ui.pages.ncx;

import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class HomePage {

    /**
     * Column elements
     */
    @FindBy(xpath = "//div[span[text()='Ready']]/following-sibling::div[@class='options']/button[i[@nztype='search']]")
    WebElement readyColumnSearchIcon;

    @FindBy(xpath = "//div[span[text()='Working']]/following-sibling::div[@class='options']/button[i[@nztype='search']]")
    WebElement workingColumnSearchIcon;

    /**
     * Header elements
     */
    @FindBy(xpath = "//button[contains(@class,'plusIcon')]")
    WebElement plusIcon;

    @FindBy(xpath = "//*[@routerlink='ncx/profile']")
    WebElement profileIcon;

    @FindBy(xpath = "//button[contains(text(),'Logout')]")
    WebElement logOut;

    @FindBy(name = "header")
    WebElement frame;

    @FindBy(xpath = "//p[contains(text(),'You have been logged out of this application.')]")
    WebElement logOutConfirmation;

    @FindBy(xpath = "//input[@data-id='global-search-input']")
    WebElement globalSearchBar;

    @FindBy(xpath = "//h3[text()='Stories/Groups']/following-sibling::div[1]//span")
    List<WebElement> storyOrGroupsSearchResult;

    @FindBy(xpath = "//h3[text()='Stories/Groups']/following-sibling::div[1]/p")
    WebElement storysOrGroupsSearchResultNoResults;

    @FindBy(xpath = "//h3[text()='Posts']/following-sibling::div[1]/p")
    WebElement postsSearchResultNoResults;

    @FindBy(xpath = "//h3[text()='Posts']/following::div[1]/button/span[@class='separate-line']")
    List<WebElement> searchResultPostTitles;

    @FindBy(xpath = "//h3[text()='Stories/Groups']/following::div[1]/button/span")
    List<WebElement> searchResultStoryTitles;

    /**
     * Left side menu elements
     */
    @FindBy(xpath = "//div[@class='nav-header']/a[h1[text()='NewsConnect']]")
    WebElement homePageLink;

    @FindBy(xpath = "//li[span[span[text()='Drafts']]]")
    WebElement draftsPageLink;

    public HomePage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify home page loaded
     *
     * @throws Exception
     */
    public void verifyHomePageLoaded() throws Exception {
        try {
            Waits.waitForElement(readyColumnSearchIcon, WAIT_CONDITIONS.CLICKABLE);
            Waits.waitForElement(workingColumnSearchIcon, WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To click on Plus icon
     *
     * @throws Exception
     */
    public void clickCreateContentButton() throws Exception {
        try {
            Waits.waitForElement(plusIcon, WAIT_CONDITIONS.CLICKABLE);
            WebAction.click(plusIcon);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fill search text in global search bar
     *
     * @param searchText - Search text
     * @throws Exception
     */
    public void fillSearchText(String searchText) throws Exception {
        try {
            if (searchText == null)
                searchText = StoryConstants.getStoryTitle();
            Waits.waitForElement(globalSearchBar, WAIT_CONDITIONS.CLICKABLE);
            WebAction.sendKeys(globalSearchBar, searchText);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify no search result is displayed
     *
     * @param searchCategory
     * @throws Exception
     */
    public void verifyNoSearchResult(String searchCategory) throws Exception {
        try {
            switch (searchCategory.toUpperCase()) {
                case "STORY", "GROUP":
                    Waits.waitForElement(storysOrGroupsSearchResultNoResults, WAIT_CONDITIONS.VISIBLE);
                    break;
                case "POST":
                    Waits.waitForElement(postsSearchResultNoResults, WAIT_CONDITIONS.VISIBLE);
                    break;
                default:
                    Assert.assertTrue(false, "Please enter valid search category");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public void verifySearchResultAndOpen(String searchCategory, String searchText) throws Exception {
        List<WebElement> searchResults = new ArrayList<>();
        try {
            switch (searchCategory.toUpperCase()) {
                case "STORY", "GROUP":
                    searchResults.addAll(searchResultStoryTitles);
                    Assert.assertTrue(searchResultStoryTitles.size() > 0, "No search result is displayed under Stories/Groups in global search");
                    if (searchText == null)
                        searchText = StoryConstants.getStoryTitle();
                    break;
                case "POST":
                    searchResults.addAll(searchResultPostTitles);
                    Assert.assertTrue(searchResultPostTitles.size() > 0, "No search result is displayed under Posts in global search");
                    if (searchText == null)
                        searchText = PostConstants.getPostTitle();
                    break;
                default:
                    Assert.assertTrue(false, "Please enter valid search category");
            }

            boolean storyOrPostPresent = false;
            for (WebElement element : searchResults) {
                if (WebAction.getText(element).toLowerCase().contains(searchText.toLowerCase())) {
                    String currentWindowId = WebAction.getCurrentWindowId();
                    storyOrPostPresent = true;
                    WebAction.click(element);
                    WebAction.switchToNewWindow(2, currentWindowId);
                    break;
                }
            }

            Assert.assertTrue(storyOrPostPresent, searchCategory + " '" + searchText + "' is not present in global search result");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To open profile page
     *
     * @throws Exception
     */
    public void clickProfile() throws Exception {
        try {
            WebAction.click(profileIcon);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To log out of application
     *
     * @throws Exception
     */
    public void logOut() throws Exception {
        try {
            clickProfile();
            WebAction.mouseOverAndClick(profileIcon, logOut);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To open side menu pages
     *
     * @param menuName
     * @throws Exception
     */
    public void openLeftSideMenu(String menuName) throws Exception {
        try {
            switch (menuName.toUpperCase()) {
                case "HOME":
                    WebAction.click(homePageLink);
                    break;
                case "DRAFTS":
                    WebAction.click(draftsPageLink);
                    break;
                case "STORIES":
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify application logged out
     *
     * @throws Exception
     */
    public void verifyApplicationLoggedOut() throws Exception {
        try {
            WebAction.switchToFrame(frame);
            Waits.waitForElement(logOutConfirmation, WAIT_CONDITIONS.VISIBLE);
            WebAction.switchToDefaultContent();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To open post using url
     *
     * @throws Exception
     */
    public void openPost() throws Exception {
        try {
            WebAction.navigateTo(PostConstants.getPostUrl());
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
}
