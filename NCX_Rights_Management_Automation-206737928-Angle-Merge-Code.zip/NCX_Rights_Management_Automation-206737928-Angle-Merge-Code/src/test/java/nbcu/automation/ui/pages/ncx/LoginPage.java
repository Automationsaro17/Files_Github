package nbcu.automation.ui.pages.ncx;

import nbcu.automation.ui.constants.ncx.Constants;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.encryption.PasswordEncryption;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginPage {

    @FindBy(id = "username")
    WebElement userNameTextBox;

    @FindBy(id = "password")
    WebElement passwordTextBox;

    @FindBy(id = "submitBtn")
    WebElement submitButton;

    public LoginPage() {
        Constants.initConstants();
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To open NCX rights management application in different environment
     *
     * @throws Exception
     */
    public void openApplication() throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        String environment, applicationUrl = "";
        try {
            // Fetch the application url based on application and environment
            environment = ConfigFileReader.getProperty("Environment");
            switch (environment.toUpperCase()) {
                case "QA":
                    applicationUrl = ConfigFileReader.getProperty("ncx-app-url_Qa");
                    break;
                case "STAGE":
                    applicationUrl = ConfigFileReader.getProperty("ncx-app-url_Stage");
                    break;
                case "PROD":
                    applicationUrl = ConfigFileReader.getProperty("ncx-app-url_Prod");
                    break;
            }

            // Launch the application
            driver.get(applicationUrl);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify sign in page is displayed
     *
     * @throws Exception - exception
     */
    public void verifySignInPageDisplayed() throws Exception {
        Waits.waitForElement(userNameTextBox, WAIT_CONDITIONS.VISIBLE);
    }

    /**
     * To Login NCX rights management application
     *
     * @param role - NCX Role
     * @throws Exception
     */
    public void loginIntoApplication(String role) throws Exception {
        String userName = "", password = "";
        try {
            switch (role.toUpperCase()) {
                case "READ ONLY":
                    userName = ConfigFileReader.getProperty("ncx-ReadOnly-username");
                    password = ConfigFileReader.getProperty("ncx-ReadOnly-password");
                    break;
                case "JOURNALIST":
                    userName = ConfigFileReader.getProperty("ncx-Journalist-username");
                    password = ConfigFileReader.getProperty("ncx-Journalist-password");
                    break;
                case "EDITOR":
                    userName = ConfigFileReader.getProperty("ncx-Editor-username");
                    password = ConfigFileReader.getProperty("ncx-Editor-password");
                    break;
                case "SENIOR EDITOR":
                    userName = ConfigFileReader.getProperty("ncx-SeniorEditor-username");
                    password = ConfigFileReader.getProperty("ncx-SeniorEditor-password");
                    break;
                case "STANDARDS":
                    userName = ConfigFileReader.getProperty("ncx-Standards-username");
                    password = ConfigFileReader.getProperty("ncx-Standards-password");
                    break;
                case "ADMIN":
                    userName = ConfigFileReader.getProperty("ncx-Admin-username");
                    password = ConfigFileReader.getProperty("ncx-Admin-password");
                    break;
                default:
                    Assert.assertTrue(false, "Please enter valid role name for login into NCX application");
            }


            WebAction.sendKeys(userNameTextBox, userName);
            String decryptedPassword = PasswordEncryption.decrypt(password);
            WebAction.sendKeys(passwordTextBox, decryptedPassword);
            WebAction.click(submitButton);

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

}
