package nbcu.automation.ui.pages.ncx;

import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.others.DateFunctions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class PostVersionsPage {

    /**
     * Version Table Elements
     */
    @FindBy(xpath = "//tr[contains(@class,'ant-table-row')]/td[2]/a[@class='versionIdChangedBy']")
    List<WebElement> postVersionNumber;

    @FindBy(xpath = "//tr[contains(@class,'ant-table-row')]/td[3]")
    List<WebElement> postVersionState;

    @FindBy(xpath = "//tr[contains(@class,'ant-table-row')]/td[4]/span")
    List<WebElement> postChangedBy;

    @FindBy(xpath = "//tr[contains(@class,'ant-table-row')]/td[5]")
    List<WebElement> postUpdatedTimeStamp;

    public PostVersionsPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify versions page loaded
     *
     * @throws Exception
     */
    public void verifyPostVersionsPageLoaded() throws Exception {
        try {
            Waits.waitForElement(postVersionNumber.get(0), Waits.WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Verify versions details of post
     *
     * @throws Exception
     */
    public void verifyVersionsDetails() throws Exception {
        try {
            //verify live post details
            CommonValidations.verifyTextValue(postVersionNumber.get(0), "2", "Live post version number is not correct in version page");
            CommonValidations.verifyTextValue(postVersionState.get(0), "LIVE", "Post version state is not correct in version page");
            CommonValidations.verifyTextValue(postChangedBy.get(0), PostConstants.getFullName(), "Live post changed by name is not correct in version page");
            String expectedLiveTimeStamp = DateFunctions.convertDateStringToAnotherFormat(PostConstants.getPostModifiedDate(), "MM/dd/yyyy", "M/dd/yyyy") + " - " + PostConstants.getPostModifiedTime();
            CommonValidations.verifyTextValue(postUpdatedTimeStamp.get(0), expectedLiveTimeStamp, "Live post time stamp is not correct in version page");

            //verify archived post details
            CommonValidations.verifyTextValue(postVersionNumber.get(1), "1", "Archived post version number is not correct in version page");
            CommonValidations.verifyTextValue(postVersionState.get(1), "ARCHIVED", "Post version state is not correct in version page");
            CommonValidations.verifyTextValue(postChangedBy.get(1), PostConstants.getFullName(), "Archived post changed by name is not correct in version page");
            String expectedArchivedTimeStamp = DateFunctions.convertDateStringToAnotherFormat(PostConstants.getPostCreationDate(), "MM/dd/yyyy", "M/dd/yyyy") + " - " + PostConstants.getPostCreationTime();
            CommonValidations.verifyTextValue(postUpdatedTimeStamp.get(1), expectedArchivedTimeStamp, "Archived post time stamp is not correct in version page");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To open archived version post
     *
     * @throws Exception
     */
    public void openArchivedVersionPost() throws Exception {
        try {
            WebAction.click(postVersionNumber.get(postVersionNumber.size() - 1));
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }


}
