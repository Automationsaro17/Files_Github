package nbcu.automation.ui.pages.ncx;

import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.others.FolderFunctions;
import nbcu.framework.utils.others.PdfReader;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

public class PostViewAsPdfPage {

    public PostViewAsPdfPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify post is downloaded as PDF file
     *
     * @throws Exception
     */
    public void verifyPostDownloadedAsPdfFile() throws Exception {
        try {
            List<String> fileNameList = FolderFunctions.getFileNameFromFolder(System.getProperty("user.dir") + "\\" + ConfigFileReader.getProperty("File-Download-Path"));
            Assert.assertTrue(fileNameList.size() > 0, "Post is not downloaded as PDF file");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To read post PDF file
     *
     * @throws Exception
     */
    public void readPostPdfFile() throws Exception {
        try {
            List<String> fileNameList = FolderFunctions.getFileNameFromFolder(System.getProperty("user.dir") + "\\" + ConfigFileReader.getProperty("File-Download-Path"));
            String pdfContent = PdfReader.readPdfFile(System.getProperty("user.dir") + "\\" + ConfigFileReader.getProperty("File-Download-Path") + "\\" + fileNameList.get(0));
            PostConstants.setPostPdfContent(pdfContent);
            Assert.assertTrue(pdfContent != null, "Post PDF file content is null");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public void verifyPdfFileContent(String fieldName) throws Exception {
        try {
            String pdfContent = PostConstants.getPostPdfContent();
            switch (fieldName.toUpperCase()) {
                case "TITLE":
                    String expectedPostTitle = PostConstants.getPostTitle();
                    CommonValidations.verifyStringValues(pdfContent, expectedPostTitle, "Post title is not correct in the PDF file");
                    break;
                case "DESCRIPTION":
                    String expectedPostDescription = PostConstants.getPostDescription();
                    CommonValidations.verifyStringValues(pdfContent, expectedPostDescription, "Post description is not correct in the PDF file");
                    break;
                case "CREATED BY":
                    String expectedPostCreatedBy = "Created By: "+PostConstants.getDisplayName();
                    CommonValidations.verifyStringValues(pdfContent, expectedPostCreatedBy, "Post created by is not correct in the PDF file");
                    break;
                case "CREATION DATE":
                    String expectedPostCreatedDate = "Date: "+PostConstants.getPostCreationDate();
                    CommonValidations.verifyStringValues(pdfContent, expectedPostCreatedDate, "Post created date is not correct in the PDF file");
                    break;
                case "CREATION TIME":
                    boolean timeValidationCheck = false;
                    String expectedPostCreatedTime = DateFunctions.convertDateStringToAnotherFormat(PostConstants.getPostCreationTime(), "h:mm a", "HH:mm");
                    String expectedTimePast = DateFunctions.addOrMinusTimeFromGivenTime(expectedPostCreatedTime, "HH:mm", DateFunctions.TIMETYPE.MINUTES, "-1");
                    String expectedTimeFuture = DateFunctions.addOrMinusTimeFromGivenTime(expectedPostCreatedTime, "HH:mm", DateFunctions.TIMETYPE.MINUTES, "1");

                    if ((pdfContent.toLowerCase().contains(expectedTimePast.toLowerCase())) || (pdfContent.toLowerCase().contains(expectedPostCreatedTime.toLowerCase())) || (pdfContent.toLowerCase().contains(expectedTimeFuture.toLowerCase())))
                        timeValidationCheck = true;
                    Assert.assertTrue(timeValidationCheck, "Post created time is not correct in the PDF file. Expected text is '" + expectedPostCreatedTime + "' and actual text is '" + pdfContent + "'");
                    break;
                default:
                    Assert.assertTrue(false, "Please provide valid field name in post PDF reader");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

}
