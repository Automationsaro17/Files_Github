package nbcu.automation.ui.pages.ncx;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.factory.DriverFactory;

public class ProfilePage {

    @FindBy(xpath = "//button[span[contains(text(),'Edit Profile')]]")
    WebElement editProfileButton;

    @FindBy(xpath = "//button[span[contains(text(),'Edit Profile')]]/../preceding-sibling::p")
    WebElement userFullName;

    @FindBy(xpath = "//span[text()='First:']/following-sibling::span[1]")
    WebElement userFirstName;

    @FindBy(xpath = "//span[text()='Last:']/following-sibling::span[1]")
    WebElement userLastName;

    @FindBy(xpath = "//span[text()='DisplayName:']/following-sibling::span[1]")
    WebElement userDisplayName;

    @FindBy(xpath = "//span[text()='Job Title:']/following-sibling::span[1]")
    WebElement userJobTitle;

    public ProfilePage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify profile page is loaded
     *
     * @throws Exception
     */
    public void verifyProfilePageLoaded() throws Exception {
        try {
            Waits.waitForElement(userLastName, WAIT_CONDITIONS.VISIBLE);
            Waits.waitForElement(editProfileButton, WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To fetch user profile details and store in constants
     *
     * @throws Exception
     */
    public void fetchUserDetails() throws Exception {
        try {
            String expectedFullName = WebAction.getText(userFullName);
            PostConstants.setFullName(expectedFullName);

            String expectedFirstName = WebAction.getText(userFirstName);
            PostConstants.setFirstName(expectedFirstName);

            String expectedLastName = WebAction.getText(userLastName);
            PostConstants.setLastName(expectedLastName);

            String expectedDisplayName = WebAction.getText(userDisplayName);
            PostConstants.setDisplayName(expectedDisplayName);

            String expectedJobTitle = WebAction.getText(userJobTitle);
            PostConstants.setJobTitle(expectedJobTitle);

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

}
