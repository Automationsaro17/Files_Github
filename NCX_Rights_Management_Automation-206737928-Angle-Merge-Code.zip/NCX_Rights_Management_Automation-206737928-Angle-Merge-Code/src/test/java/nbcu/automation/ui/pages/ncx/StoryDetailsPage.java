package nbcu.automation.ui.pages.ncx;

import com.sun.source.tree.AssertTree;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.AngleConstants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.others.DateFunctions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class StoryDetailsPage {

    /**
     * Story details elements
     **/
    @FindBy(xpath = "//div[contains(@class,'story-status')]")
    WebElement storyStatusElement;

    @FindBy(xpath = "//div[contains(@class,'story-status')]/span")
    WebElement storyStatusIndicatorElement;

    @FindBy(xpath = "//div[contains(@class,'storyTopics')]/span")
    WebElement storyTopicElement;

    @FindBy(xpath = "//div[contains(@class,'storyTitle')]/a")
    WebElement storyTitleElement;

    @FindBy(xpath = "//div[contains(@class,'storyDescription')]")
    WebElement storyDescriptionElement;

    @FindBy(xpath = "//button[contains(@class,'creators')]/span")
    WebElement storyCreatorNameElement;

    @FindBy(xpath = "//span[contains(@class,'time')]")
    WebElement storyCreationTimeElement;

    @FindBy(xpath = "//span[contains(@class,'date')]")
    WebElement storyCreationDateElement;

    @FindBy(xpath = "//div[contains(@class,'storyTags')]/span")
    WebElement storyTagsElement;

    @FindBy(xpath = "//span[contains(@class,'follower')]//button[contains(@class,'count')]")
    WebElement storyFollowerCountElement;

    /**
     * Story right side slider elements
     */
    @FindBy(xpath = "//button[i[contains(@class,'anticon-close')]]")
    WebElement closeRightDrawer;

    @FindBy(xpath = "//button[i[contains(@class,'anticon-setting')]]")
    WebElement openRightDrawer;

    @FindBy(xpath = "//div[text()='Topic']/following-sibling::div")
    WebElement rightDrawerStoryTopicsElement;

    @FindBy(xpath = "//div[text()='Slack Connections']/following-sibling::div")
    List<WebElement> rightDrawerSlackChannelElement;

    @FindBy(xpath = "//div[text()='Privacy']/following-sibling::div")
    WebElement rightDrawerStoryPrivacyElement;

    @FindBy(xpath = "//div[text()='State']/following-sibling::div")
    WebElement rightDrawerStoryStatusElement;

    @FindBy(xpath = "//div[text()='Creator']/following-sibling::button/span")
    WebElement rightDrawerStoryCreatorElement;

    @FindBy(xpath = "//div[text()='Created']/following-sibling::div")
    WebElement rightDrawerStoryCreationDateAndTimeElement;

    /**
     * Button elements
     */
    @FindBy(xpath = "//button[span[contains(text(),'Edit Story')]]")
    WebElement editStoryButton;

    @FindBy(xpath = "//button[span[contains(text(),'Merge Story')]]")
    WebElement mergeStoryButton;

    @FindBy(xpath = "//button[span[contains(text(),'Delete')]]")
    WebElement deleteStoryButton;

    @FindBy(xpath = "//a[span[contains(text(),'Add Post via Email')]]")
    WebElement addPostViaEmailButton;

    @FindBy(xpath = "//button[span[contains(text(),'Request Infocenter Research')]]")
    WebElement requestInfoCenterResearchButton;

    @FindBy(xpath = "//span[contains(text(),'Block from Slack')]/following-sibling::nz-switch/button")
    WebElement blockFromSlackToggle;

    /**
     * Delete story elements
     */
    @FindBy(xpath = "//span[contains(@class,'ant-modal-confirm-title')]/span")
    WebElement deleteStoryConfirmationPopUp;

    @FindBy(xpath = "//div[contains(@class,'ant-modal-confirm-btns')]/button[span[contains(text(),'Cancel')]]")
    WebElement deleteStoryCancelButton;

    @FindBy(xpath = "//div[contains(@class,'ant-modal-confirm-btns')]/button[span[contains(text(),'OK') or contains(text(),'Delete')]]")
    WebElement deleteStoryOkButton;

    @FindBy(xpath = "//div[@class='ant-message']//span[contains(translate(text(),'ABCDEFGHIJKLMNOPURSTUWXYZ','abcdefghijklmnopurstuwxyz'), 'successfully deleted')]")
    WebElement deletedStoryMessage;
    
    /**
	 * Post tab elements
	 */
	@FindBy(xpath = "//div[@role='tab' and contains(text(),'Posts')]")
	WebElement postTab;
	
	@FindBy(xpath = "//p[//span[normalize-space()='No Posts Found']]")
	WebElement noPostTxt;
	
    
    /**
	 * Angle FilterRH drawer elements
	 */
	@FindBy(xpath = "//div[@class='angle-details-split']")
	WebElement filterResultCard;
	
	@FindBy(xpath = "//app-angle-details[//div[@class='angle-details-modal']]")
	WebElement angleCards;
	
	@FindBy(xpath = "//div[@class='angle-created-user']//span[2]")
	WebElement filterAuthorName;
	
	@FindBy(xpath = "//button[contains(@class,'ant-btn')]/i[@nztype='filter']")
	WebElement flterEnabledColor;
	
    
    /**
	 * Angle cards listing page elements
	 */
	@FindBy(xpath = "//app-story-angles//div[@class='angle-details-modal']")
	List<WebElement> angleListCards;
	
	@FindBy(xpath = "//div[@class='angle-details-content']//div[@class='angle-details-id']//span")
	List<WebElement> angleListIds;
	
	@FindBy(xpath = "//div[@class='angle-details-content']//div[@class='angle-created-user']//span[3]")
	List<WebElement> angleListCreationDateAndTime;
	
	
	/**
	 * select drop down from filter drawer
	 */
	String searchDropDownValuesXpath = "//nz-auto-option[contains(@class,'ant-select-item ant-select-item-option')]/div";


    public StoryDetailsPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify story details page is loaded
     *
     * @throws Exception
     */
    public void verifyStoryDetailsPageLoaded() throws Exception {
        try {
            Waits.waitForElement(storyTitleElement, Waits.WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify story status indicator color
     *
     * @param storyStatus   - Story status
     * @param expectedColor - Expected color
     * @throws Exception
     */
    public void verifyStoryStatusIndicator(String expectedColor, String storyStatus) throws Exception {
        try {
            if (storyStatus.equalsIgnoreCase("READY"))
                expectedColor = "GREEN-6";
            else expectedColor = "YELLOW-6";
            CommonValidations.verifyColorOfElement(storyStatusIndicatorElement, "background color", expectedColor);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify story details section in story details page
     *
     * @param fieldName - field name in story details page
     * @throws Exception
     */
    public void verifyStoryDetailsSection(String fieldName) throws Exception {
        try {
            switch (fieldName.toUpperCase()) {
                case "STATUS":
                    String expectedStoryStatus = StoryConstants.getStoryStatus();
                    CommonValidations.verifyTextValue(storyStatusElement, expectedStoryStatus, "Story status is not correct in story details page");
                    break;
                case "TOPIC":
                    String expectedStoryTopics = "";
                    for (int i = 0; i < StoryConstants.getStoryTopicCount(); i++)
                        expectedStoryTopics = expectedStoryTopics + ",";
                    expectedStoryTopics = expectedStoryTopics.substring(0, expectedStoryTopics.length() - 1);
                    CommonValidations.verifyTextValue(storyTopicElement, expectedStoryTopics, "Story topics are not correct in story details page");
                    break;
                case "TITLE":
                    String expectedStoryTitle = StoryConstants.getStoryTitle();
                    CommonValidations.verifyTextValue(storyTitleElement, expectedStoryTitle, "Story title is not correct in story details page");
                    break;
                case "DESCRIPTION":
                    String expectedStoryDescription = StoryConstants.getStoryDescription();
                    CommonValidations.verifyTextValue(storyDescriptionElement, expectedStoryDescription, "Story description is not correct in story details page");
                    break;
                case "CREATED BY":
                    String expectedDisplayName = PostConstants.getDisplayName();
                    CommonValidations.verifyTextValue(storyCreatorNameElement, expectedDisplayName, "Story creator name is not correct in story details page");
                    break;
                case "CREATION TIME":
                    String expectedStoryCreationTime = StoryConstants.getStoryCreationTime();
                    CommonValidations.verifyCreationTime(storyCreationTimeElement, expectedStoryCreationTime, "h:mm a", "Story creation time is not correct in story details page");
                    break;
                case "CREATION DATE":
                    String expectedStoryCreationDate = StoryConstants.getStoryCreationDate();
                    CommonValidations.verifyTextValue(storyCreationDateElement, expectedStoryCreationDate, "Story creation date is not correct in story details page");
                    break;
                case "TAGS":
                    String expectedStoryTags = "";
                    for (int i = 0; i < StoryConstants.getStoryTagCount(); i++)
                        expectedStoryTags = expectedStoryTags + ",";
                    expectedStoryTags = expectedStoryTags.substring(0, expectedStoryTags.length() - 1);
                    CommonValidations.verifyTextValue(storyTagsElement, expectedStoryTags, "Story tags are not correct in story details page");
                    break;
                case "FOLLOWERS COUNT":
                    CommonValidations.verifyTextValue(storyFollowerCountElement, "1", "Story followers count is not correct in story details page");
                    break;
                default:
                    Assert.assertTrue(false, "Please provide valid field name in story details page");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify story details in right hand drawer
     *
     * @param fieldName - field name in RH drawer
     * @throws Exception
     */
    public void verifyStoryDetailsInRightDrawer(String fieldName) throws Exception {
        try {
            switch (fieldName.toUpperCase()) {
                case "TOPIC":
                    String expectedStoryTopics = "";
                    for (int i = 0; i < StoryConstants.getStoryTopicCount(); i++)
                        expectedStoryTopics = expectedStoryTopics + ",";
                    expectedStoryTopics = expectedStoryTopics.substring(0, expectedStoryTopics.length() - 1);
                    CommonValidations.verifyTextValue(rightDrawerStoryTopicsElement, expectedStoryTopics, "Story topics in right drawer are not correct in story details page");
                    break;
                case "SLACK CHANNELS":
                    for (int i = 0; i < StoryConstants.getStorySlackChannelCount(); i++)
                        CommonValidations.verifyTextValue(rightDrawerSlackChannelElement.get(i), StoryConstants.getStorySlackChannel(i), "Story slack channel in right drawer is not correct in story details page");
                    break;
                case "PRIVACY":
                    String expectedStoryPrivacy = StoryConstants.getStoryPrivacy();
                    CommonValidations.verifyTextValue(rightDrawerStoryPrivacyElement, expectedStoryPrivacy, "Story status in right drawer is not correct in story details page");
                    break;
                case "STATE":
                    String expectedStoryStatus = StoryConstants.getStoryStatus();
                    CommonValidations.verifyTextValue(rightDrawerStoryStatusElement, expectedStoryStatus, "Story state in right drawer is not correct in story details page");
                    break;
                case "CREATOR":
                    String expectedCreator = PostConstants.getFullName();
                    CommonValidations.verifyTextValue(rightDrawerStoryCreatorElement, expectedCreator, "Story creator name in right drawer is not correct in story details page");
                    break;
                case "CREATED":
                    String expectedStoryCreationDateTime = DateFunctions.convertDateStringToAnotherFormat(StoryConstants.getStoryCreationDate(), "MM/dd/yyyy", "MMM dd yyyy") + ", " + StoryConstants.getStoryCreationTime();
                    CommonValidations.verifyTextValue(rightDrawerStoryCreationDateAndTimeElement, expectedStoryCreationDateTime, "Story creation date and time in right drawer is not correct in story details page");
                    break;
                default:
                    Assert.assertTrue(false, "Please provide valid field name in RH drawer of story details page");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify options in story details page
     *
     * @param role - NCX role
     * @throws Exception
     */
    public void verifyStoryOptions(String role) throws Exception {
        try {
            switch (role.toUpperCase()) {
                case "SENIOR EDITOR", "STANDARDS", "ADMIN":
                    CommonValidations.verifyElementIsEnabled(editStoryButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(mergeStoryButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(deleteStoryButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(addPostViaEmailButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(requestInfoCenterResearchButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(blockFromSlackToggle, "Block from slack toggle is not displayed in story details page");
                    break;
                case "JOURNALIST", "EDITOR":
                    CommonValidations.verifyElementIsEnabled(editStoryButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(addPostViaEmailButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(blockFromSlackToggle, "Block from slack toggle is not displayed in story details page");
                    break;
                default:
                    Assert.assertTrue(false, "Given role name '" + role + "' is not valid. Please enter valid ncx role name");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public void clickButtonInStoryDetailsPage(String buttonName) throws Exception {
        try {
            switch (buttonName.toUpperCase()) {
                case "EDIT STORY":
                    WebAction.click(editStoryButton);
                    break;
                case "MERGE STORY":
                    WebAction.click(mergeStoryButton);
                    break;
                case "DELETE STORY":
                    WebAction.click(deleteStoryButton);
                    break;
                case "ADD POST VIA EMAIL":
                    WebAction.click(addPostViaEmailButton);
                    break;
                case "REQUEST INFOCENTER RESEARCH":
                    WebAction.click(requestInfoCenterResearchButton);
                    break;
                case "BLOCK FROM SLACK":
                    WebAction.click(blockFromSlackToggle);
                    break;
                default:
                    Assert.assertTrue(false, "Given button name '" + buttonName + "' is not valid. Please enter valid button name");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify story/post delete confirmation pop up is displayed
     *
     * @param storyOrPost       - Story/Post
     * @param confirmationTitle - Confirmation pop up title
     * @throws Exception
     */
    public void verifyDeleteConfirmationPopupDisplayed(String storyOrPost, String confirmationTitle) throws Exception {
        try {
            Waits.waitForElement(deleteStoryConfirmationPopUp, Waits.WAIT_CONDITIONS.VISIBLE);
            CommonValidations.verifyTextValue(deleteStoryConfirmationPopUp, confirmationTitle, "Delete " + storyOrPost + " confirmation pop up is not displayed");
            CommonValidations.verifyElementIsDisplayed(deleteStoryOkButton, "Ok button is not displayed in delete " + storyOrPost + " confirmation pop up");
            CommonValidations.verifyElementIsDisplayed(deleteStoryCancelButton, "Cancel button is not displayed in delete " + storyOrPost + " confirmation pop up");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To click button in confirmation pop up
     *
     * @param buttonName - button name
     * @throws Exception
     */
    public void clickButtonInConfirmationPopUp(String buttonName) throws Exception {
        try {
            if (buttonName.equalsIgnoreCase("OK"))
                WebAction.click(deleteStoryOkButton);
            else if (buttonName.equalsIgnoreCase("CANCEL"))
                WebAction.click(deleteStoryCancelButton);
            else Assert.assertTrue(false, "Please valid button name in delete confirmation pop up");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * To verify story/post deleted message
     *
     * @param storyOrPost     - Story/Post
     * @param deletionMessage - Deletion message
     * @throws Exception
     */
    public void verifyStoryDeleteMessage(String storyOrPost, String deletionMessage) throws Exception {
        try {
            Waits.waitForElement(deletedStoryMessage, Waits.WAIT_CONDITIONS.VISIBLE);
            CommonValidations.verifyTextValue(deletedStoryMessage, deletionMessage, storyOrPost + " deleted message is not displayed");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
    
    /**
	 * To verify user navigated to Dashboard page
	 * 
	 * @param Navigation icon - Left Hand Navigation icons
	 * @throws Exception
	 */

	@FindBy(xpath = "//span[text()='Stories']/../i")
	WebElement storiesIcon;

	@FindBy(xpath = "//button[span[text()=' Follow ']]")
	List<WebElement> listFollowBtns;

	public void clickStoriesIcon(String navName) throws Exception {
		try {
			switch (navName.toUpperCase()) {
			case "STORIES":
				boolean isDisplayed = WebAction.isDisplayed(storiesIcon);
				if (isDisplayed) {
					WebAction.click(storiesIcon);
					Waits.waitUntilElementSizeGreater(listFollowBtns, 5);
					if (listFollowBtns.size() > 0) {
						System.out.println("Home Dashboard column is displayed");
					}
				} else
					System.out.println("Failed to load the Dashboard page");
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the created story name in dashboard page
	 * 
	 */

	@FindBy(xpath = "//span[text()='Working']/../../../following-sibling::app-scroll-container//ncx-story//div[@class='ncx-story-header']/a")
	List<WebElement> StoryNames;
	
	@FindBy(xpath = "(//div[@class='section-header']/following-sibling::app-scroll-container)[2]//a")
	List<WebElement> storyNamesInWorkingColumn;
	
	@FindBy(xpath = "(//div[@class='section-header']//i[contains(@class,'anticon-search')])[2]")
	WebElement workingColumnSearchIcon;
	
	public void verifyStoryNameInColumn() throws Exception {
		try {
			Waits.waitForElement(workingColumnSearchIcon, WAIT_CONDITIONS.CLICKABLE);
			Thread.sleep(1000);
			if (storyNamesInWorkingColumn.size() > 0) {
				String ActualStoryName = StoryConstants.getStoryTitle().trim();
				String ExpectedStoryName = null;
				System.out.println("Test story name from story constants " +ActualStoryName);
				for(int i = 0; i < storyNamesInWorkingColumn.size(); i++) {
					ExpectedStoryName = WebAction.getText(StoryNames.get(i));
					 if(ActualStoryName.equalsIgnoreCase(ExpectedStoryName)) {
							System.out.println("User created story name is displayed in dashboard column::" +ExpectedStoryName);
							break;
							}}
				}else System.out.println("Failed to display the Story Name in Dashboard column");
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click the created story name from Working column
	 * 
	 * @throws Exception
	 */

	@FindBy(xpath = "//button[@class='back']/i")
	WebElement backIconInStoryLandingPage;

	@FindBy(xpath = "//i[@nztype='star']/following-sibling::span[normalize-space()='Following']")
	WebElement followingBtn;
	
	@FindBy(xpath = "//i[@nztype='star']/following-sibling::span[normalize-space()='Follow']")
	WebElement followBtn;
	
	@FindBy(xpath="//i[@nztype='file-text']/following-sibling::span[normalize-space()='Story Details']")
	WebElement storyDetailsBtn;
	
	
	public void clickStoryNameFromWorkingColumn(String roles) throws Exception {
		try {
			String ActualStoryName = StoryConstants.getStoryTitle().trim();
			String ExpectedStoryName = null;
			String ParentWindowName = WebAction.getCurrentWindowId();
           for(int i = 0; i < storyNamesInWorkingColumn.size(); i++) {
			ExpectedStoryName = WebAction.getText(storyNamesInWorkingColumn.get(i));
			if(ActualStoryName.equalsIgnoreCase(ExpectedStoryName.trim())){
			WebAction.click(storyNamesInWorkingColumn.get(i));
			WebAction.switchToNewWindow(2, ParentWindowName);
			Thread.sleep(2000);
			
			Waits.waitForElement(storyDetailsBtn, Waits.WAIT_CONDITIONS.CLICKABLE);
			//Waits.waitForElement(storyDetailsBtn, Waits.WAIT_CONDITIONS.CLICKABLE);
			
			break; 
			}}} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the story landing page from clicking dashboard column
	 */

	@FindBy(xpath = "//button[@class='back']/i")
	WebElement backIconButtonInHeader;

	public void isStoryLandingPageDisplayed() {
		try {
			boolean isBackBtnDisplayed = WebAction.isDisplayed(backIconButtonInHeader);
			if (isBackBtnDisplayed) {
				System.out.println("Back icon is displayed in the Story Landing Page");
			} else
				System.out.println("Failed to display the back icon in the story landing page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To load the Angles tab from the Story landing page
	 */
	@FindBy(xpath = "//div[text()=' Angles ']")
	WebElement anglesTab;

	@FindBy(xpath = "//nz-spin[@class='icon']")
	WebElement spinningGauge;

	@FindBy(xpath = "//div[@class='angle-details-modal']")
	List<WebElement> anglesTileCard;

	public void loadAnglesTab() throws Exception {
		try {
			boolean isAngleTabBtn = WebAction.isDisplayed(anglesTab);
			if (isAngleTabBtn) {
				WebAction.click(anglesTab);
				Waits.waitForElementIsDisplayed(addNewBtn);
				} else
				System.out.println("Failed to display the angle tab in Story landing page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To load the angle tab from the story landing page as read only users
	 */
	public void loadAnglesTabasReadOnly() throws Exception {
		try {
			boolean isAngleTabBtn = WebAction.isDisplayed(anglesTab);
			if (isAngleTabBtn) {
			WebAction.click(anglesTab);
			}else
			System.out.println("Failed to display the angle tab in Story landing page");
		}catch (Exception e){
			e.printStackTrace();
			throw e;}
		}
	
	/**
	 * To verify the RH filter drawer enabled by default in Angle listing page
	 */
	
	@FindBy(xpath = "//i[@nztype='close']")
	WebElement closeFilterIcon;
	
	@FindBy(xpath = "//span[normalize-space()='Filters']")
	WebElement filterDrawertTxt;
	
	public void verifyRHDrawerEnabledByDefault() {
		try {
			boolean isDisplayed = WebAction.isDisplayed(closeFilterIcon);
			if(isDisplayed) {
			String drawerName = WebAction.getText(filterDrawertTxt).trim();
			if(drawerName.equalsIgnoreCase("Filters")) {
				Assert.assertTrue(isDisplayed,"Filter RH drawer is enabled in Angle listing page");
			}else Assert.assertFalse(true,"Failed to display the Filter RH drawer in Angle listing page");
			}}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Add New button in Angle listing page
	 */

	@FindBy(xpath = "//span[text()=' Add New ']")
	WebElement addNewBtn;

	@FindBy(xpath = "//div[@class='angle-title']/input")
	WebElement angleTitleTextBox;

	public void clickAddNewInFooter() throws Exception {
		try {
			boolean isDisplayed = WebAction.isDisplayed(addNewBtn);
			if (isDisplayed) {
				WebAction.click(addNewBtn);
				Waits.waitForElement(angleTitleTextBox, Waits.WAIT_CONDITIONS.CLICKABLE);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the Filter RH drawer enabled by default in Angle Listing page
	 */

	@FindBy(xpath = "//i[@nztype='close']")
	WebElement filterDrawerCloseIcon;

	@FindBy(xpath = "//span[text()='Filters']")
	WebElement filterName;

	public void verifyFilterDrawer() {
		try {
			boolean isDisplayed = WebAction.isDisplayed(filterDrawerCloseIcon);
			if (isDisplayed) {
				String drawerTitle = WebAction.getText(filterName).trim();
				if (drawerTitle.equalsIgnoreCase("Filters")) {
					Assert.assertTrue(true, "Filter drawer is opened by default");
				} else
					Assert.assertFalse(true, "Unable to see the filter RH drawer in angle listing page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify filter icon color in Filter RH drawer of Angle listing page
	 * 
	 * @throws Exception
	 */

	@FindBy(xpath = "//i[@nztype='filter']")
	WebElement filterIcon;

	public void verifyColor() throws Exception {
		try {
			boolean isDisplayed = WebAction.isDisplayed(filterIcon);
			if (isDisplayed) {
				boolean click = WebAction.isClickable(filterIcon);
				if (click)
					;
				String expectedColor = "White";
				Assert.assertTrue(click, "Filter icon is filled with " + expectedColor);
			} else
				Assert.assertFalse(isDisplayed, "Failed to display the filter icon in Angle listing page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the options in Filter drawer present in Angle listing page
	 */

	@FindBy(xpath = "//span[text()='Sort By']")
	WebElement filterSortOptions;

	@FindBy(xpath = "//span[contains(text(),'First')]")
	List<WebElement> sortRadioOptions;

	@FindBy(xpath = "//span[text()='Author']")
	WebElement filterAuthorOptions;

	public void verifyFilterDrawerOptions() {
		try {
			boolean isDisplayed = WebAction.isDisplayed(filterSortOptions);
			if (isDisplayed) {
				int size = sortRadioOptions.size();
				if (size == 2) {
					String firstOption = WebAction.getText(sortRadioOptions.get(0)).trim();
					String secondOption = WebAction.getText(sortRadioOptions.get(1)).trim();
					if ((firstOption.equalsIgnoreCase("newest first")
							&& (secondOption.equalsIgnoreCase("oldest first")))) {
						Assert.assertTrue(true, "Sort by filter optoins having two choices in" + "filter RH drawer");
					} else
						Assert.assertFalse(true, "Failed to display the two option in sort by section");
				} else
					Assert.assertFalse(true, "Failed to display the sort option in filter RH drawer");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify default sort by option enabled in the filter present in angle
	 * listing page
	 */

	@FindBy(xpath = "//span[contains(@class,'ant-radio-checked')]/following-sibling::span")
	WebElement newestFirstOption;

	@FindBy(xpath = "//span[contains(@class,'ant-radio-checked')]")
	WebElement radioSelectedOption;

	public void verifyDefaulFilterInSortBy() {
		try {
			boolean isEnabled = WebAction.isDisplayed(radioSelectedOption);
			if (isEnabled) {
				String radioSelectedxt = WebAction.getText(newestFirstOption).trim();
				if (radioSelectedxt.equalsIgnoreCase("newest first")) {
					Assert.assertTrue(true,
							"Newest First radio option is selected by default radio" + "option in filter RH drawer");
				} else
					Assert.assertFalse(true, "Newst First radio option is not selected by default "
							+ "radio option in filter RH drawer");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify author section filter option in RH drawer
	 */

	@FindBy(xpath = "//span[contains(text(),'Author')]")
	WebElement authorOption;

	public void verifyAuthorOption() {
		try {
			String authoTxtrOption = WebAction.getText(authorOption).trim();
			if (authoTxtrOption.equalsIgnoreCase("author")) {
				Assert.assertTrue(true, "Author filter option is displayed in filter RH drawer");
			} else
				Assert.assertFalse(true, "Failed to display the author filter section in RH drawer");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the author text field is blank by default in filter section
	 */

	@FindBy(xpath = "//input[@name='author']")
	WebElement authorInputField;

	public void authorInputField() {
		try {
			boolean inputTxtField = WebAction.isDisplayed(authorInputField);
			if (inputTxtField) {
				String defValue = WebAction.getAttribute(authorInputField, "value");
				if (defValue == null || defValue.isEmpty()) {
					Assert.assertTrue(true, "Author field in filter Rh drawer displayed as blank");
				}else Assert.assertFalse(true, "Author field is pre-filled with ncx user profile name");
			}else Assert.assertFalse(true, "Failed to display the author name field in Filter RH drawer");
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}}
	
	/**
	 * To enter the ncx profile user name in author search field
	 * 
	 * @throws Exception
	 */
	public void enterAnyProfileName(String authorNames) throws Exception {
		try {
			boolean inputTxtField = WebAction.isDisplayed(authorInputField);
			if (inputTxtField) {
				Thread.sleep(3000);
				WebAction.clearUsingKeys(authorInputField);
				AngleConstants.setFilterAuthorName(authorNames);
				WebAction.selectNonTitleDropDown1(authorInputField, authorNames, searchDropDownValuesXpath, 
						authorNames+" failed to select the ncx user name for author drop down search result");
				//Waits.waitForAllElements(angleTitleCard, Waits.WAIT_CONDITIONS.CLICKABLE);
			}else Assert.assertFalse(true, "Failed to display the input text field");
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}}

	/**
	 * To verify the angle filter results based on given author name in search field
	 * 
	 * @throws Exception
	 */
	public void verifyFilterResults() throws Exception {
		try {
			Waits.waitForElement(angleCards, WAIT_CONDITIONS.VISIBLE);
			boolean isDisplayed = WebAction.isDisplayed(filterResultCard);
			if (isDisplayed) {
				String authorName = WebAction.getText(filterAuthorName).trim();
				String expectedName = AngleConstants.getFilterAuthorName();
				String[] size = authorName.split(",");
				String actualName = size[1].trim() + " " + size[0].trim();
				if (actualName.contains(expectedName.trim())) {
					Assert.assertTrue(true, "Author name got matched in the angle title block");
				}else Assert.assertFalse(true, "Failed to match the angle filter results in angle listing page");
			}else Assert.assertFalse(true, "Failed to display the angle cards in angle listing page");
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}}
	
	/**
	 * To verify filter search results retained in Angle Landing Page
	 * 
	 * throws Exception
	 */
	public void verifyAngleFilterRetainedResults() throws Exception {
		try {
			boolean isDisplayed = WebAction.isDisplayed(postTab);
			String expectedColor = "Blue";
			if(isDisplayed) {
				WebAction.click(postTab);
				String noPostFoundTxt = WebAction.getText(noPostTxt).trim();
				if(noPostFoundTxt.equalsIgnoreCase("No Posts Found")) {
				WebAction.click(anglesTab);
				Waits.waitForElement(angleCards, WAIT_CONDITIONS.VISIBLE);
				CommonValidations.verifyColorOfElement(flterEnabledColor, "color", expectedColor);
				Assert.assertTrue(true, "Verified " +expectedColor +" is displayed in the angles tab");
				}
			}else Assert.assertFalse(true, "Failed to display the post tab in story landing page");
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}}
	
	/**
	 * To save the angle creation date and time in map
	 */
	
	public void saveDateAndTime() throws Exception {
		try {
			int cardSize = angleListCards.size();
			int cardIds = angleListIds.size();
			int cardsDateTime = angleListCreationDateAndTime.size();
			Map<Date, String> angleDetails = new TreeMap<Date, String>();
			if(cardSize == cardIds && cardIds == cardsDateTime && cardSize == cardsDateTime) {
				for(int i = 0 ; i< cardSize; i++) {
					String angleID = WebAction.getText(angleListIds.get(i)).trim();
					String createdDateTime = WebAction.getText(angleListCreationDateAndTime.get(i)).trim();
					createdDateTime = createdDateTime.replaceAll("on ", "").replaceAll("at ", "");
					System.out.println("Create date time us -->" +createdDateTime);
					Date dd = DateFunctions.convertDateStringToDate(createdDateTime,"M/dd/yyyy h:mm");
					System.out.println("Date format is -->" + dd);
					System.out.println("Test angle id is-->"+angleID);
					angleDetails.put(dd, angleID);
					}}else Assert.assertFalse(true, "Failed to match the Cards, with ID and Creation Date and time");
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}}
	
	/**
	 * To verify search field in Angle listing page loaded from Story landing page
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "//div[@class='header']//input[@placeholder='Search Angles']")
	WebElement searchField;
	public void verifySearchField() {
		try {
			boolean isDisplayed = WebAction.isDisplayed(searchField);
			if(isDisplayed);
			else Assert.assertTrue(isDisplayed, "Failed to displayed the search field");
		}catch(Exception e) {
			e.printStackTrace();
			throw e;}}
	
	/**
	 * To enter the search field in angle listing page
	 * 
	 * @throws Exception 
	 */
	@FindBy(xpath = "//button/i[contains(@class,'close-circle')]")
	WebElement closeIcon;
	public void enterSearchField() throws Exception {
		try {
			WebAction.sendKeys(searchField, "Angle");
			AngleConstants.setSearchKeyword("Angle");
			WebAction.isDisplayed(closeIcon);
		}catch(Exception e) {
			e.printStackTrace();
			throw e;}}
	
	/**
	 * To verify the search results in angle listing page
	 * 
	 */
	@FindBy(xpath = "//div[@class='scroll-container']//div[@class='angle-details-content']")
	List<WebElement> angleSearchListCard;
	
	@FindBy(xpath = "//div[@class='scroll-container']//div[@class='angle-details-id']")
	List<WebElement> angleCardListIds;
	
	@FindBy(xpath ="//div[@class='scroll-container']//div[@class='angle-details-title']//b")
	List<WebElement> angleContentName;
	
	public void verifySearchResults() throws Exception {
		try {
			Waits.waitForAllElements(angleContentName, WAIT_CONDITIONS.VISIBLE);
			int size = angleSearchListCard.size();
			//System.out.println("Cards size --> "+ size);
			int idSize = angleCardListIds.size();
			
			//System.out.println("id size --> "+ idSize);
			if(size>0 && idSize>0) {
				int angleTitle = angleContentName.size();
				//System.out.println("anglecontne t sizee --> "+ angleTitle);
				if(angleTitle>0) {
						for(int i = 0; i <angleTitle ; i++) {
							String actualKeyword = WebAction.getText(angleContentName.get(i)).trim();
							//System.out.println("actual Keyword is --->" +i +"text is '" +actualKeyword);
							String expectedKeyword = AngleConstants.getSearchKeyword().trim();
							if(expectedKeyword.contains(actualKeyword)) {
								Assert.assertTrue(true,"Search keywords got displayed in the angle listing page");
							}}}else Assert.assertTrue(false, "Search results not containg the angle cards");
				}else Assert.assertTrue(false, "Failed to displayed the search results in angle listing page");
			}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}}
	
	/**
	 * To verify the search result keyword highlighted in color
	 * @throws Exception 
	 */
	public void verifytxtColor(String actualColor) throws Exception {
		try {
			Waits.waitForAllElements(angleContentName, WAIT_CONDITIONS.VISIBLE);
			int angleTitle = angleContentName.size();
			if(angleTitle>0) {
				for(int i = 0; i < angleTitle ; i++) {
					/*
					 * String expec =WebAction.getCssValue(angleContentName.get(i), "color");
					 * System.out.println("Enter into the loop ---poda dai>" +expec); String
					 * actualColorHexaValue = Color.fromString(expec).asHex();
					 * System.out.println("Enter into the loop ---poda dai>" +actualColorHexaValue);
					 */
				CommonValidations.verifyColorOfElement(angleContentName.get(i), "color", actualColor);
				}}else Assert.assertTrue(false, "Failed to highlight the angle keyword search results ");
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To verify the "+" icon in header is disabled
	 * 
	 * @throws Exception
	 */
	
	@FindBy(xpath = "//button[contains(@class,'plusIcon')]/span")
	WebElement AddIcon;

	
	public void addPostIconDisabled() {
		try {
			boolean isDisplayed = WebAction.isDisplayed(AddIcon);
			if (!isDisplayed) {
				Assert.assertTrue(true, "Not displayed the plus icon in header for Read Only user role");
			}else Assert.assertFalse(true, "Displayed the plus icon in header for Read Only user role");
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}}

	/**
	 * To verify the button in story landing page of posts tab
	 */

	@FindBy(xpath = "//div[@class='footer']//button[contains(@class,'ant-btn')]")
	WebElement infoBtn;

	public void verifyButtonsInStoryLandingPage() {
		try {
			boolean isDisplayed = WebAction.isDisplayed(infoBtn);
			if (isDisplayed) {
				Assert.assertTrue(isDisplayed,
						"Infocenter button is displayed at the sticky footer section" + "of story landing page");
			} else
				Assert.assertFalse(isDisplayed, "Failed to display the Infocenter button for read only user");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


    
    /**
	 * To verify the post listing page should not have any button for Read only
	 * users
	 */

	@FindBy(xpath = "//i/following-sibling::span[text()='Add Post via Email']")
	WebElement addPostEmailBtn;

	@FindBy(xpath = "//button[contains(@class,'ant-btn')]//span[text()=' Add New ']")
	WebElement addnewPostBtn;

	public void verifyButtons(DataTable params) {
		try {
			List<String> listOfBtns = new ArrayList<String>();
			List<Map<String, String>> buttonNames = CucumberUtils.getValuesFromDataTableAsList(params);
			int size = buttonNames.size();
			for (int i = 0; i < size; i++) {
				String BtnName = buttonNames.get(i).get("Buttons");
				listOfBtns.add(BtnName.trim());
			}
			boolean btnEmail = WebAction.isDisplayed(addPostEmailBtn);
			boolean addNewPostBtn = WebAction.isDisplayed(addnewPostBtn);
			if (!btnEmail) {
				System.out.println( "PASS" );
				Assert.assertTrue(true,
						(listOfBtns.get(0).trim()) + " not displayed in the" + "story landing page for Read Only Users");
			}else
				Assert.assertFalse(true, (listOfBtns.get(0).trim()) + " button got displayed in the story landing for Read Only Users");
			if(!addNewPostBtn) {
				System.out.println( "PASS" );
				Assert.assertTrue(true, (listOfBtns.get(1).trim())
						 + " not displayed in the" + "story landing page for Read Only Users");
			}else
				Assert.assertFalse(true,
						(listOfBtns.get(1).trim()) + " button got displayed in the " + "story landing page for Read Only Users");
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
