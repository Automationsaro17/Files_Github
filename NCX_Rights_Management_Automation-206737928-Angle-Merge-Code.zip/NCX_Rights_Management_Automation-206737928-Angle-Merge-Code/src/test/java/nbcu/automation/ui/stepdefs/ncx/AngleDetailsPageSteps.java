package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.AngleDetailsPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class AngleDetailsPageSteps {

	AngleDetailsPage anlgeDetailsPage = new AngleDetailsPage();

	@And("verify Angle details page is loaded")
	@And("verify updated Angle details page is loaded")
	public void verifyAngleDetailsPageLoaded() throws Exception {
		anlgeDetailsPage.verifyAngleDetailsPageLoaded();
	}

	@And("verify {string} in angle landing page")
	@Then("verify {string} in updated landing page")
	@Then("verifies {string} in updated angle landing page")
	@Then("verify {string} in updated angle landing page header")
	public void verifyAngleDetailsPageHeaderSection(String textLabels) throws Exception {
		try {
			switch (textLabels.toUpperCase()) {
			case "ANGLE ID":
				anlgeDetailsPage.verifyAngleIDInLandingPage();
				break;
			case "ANGLE TITLE":
				anlgeDetailsPage.verifyAngleTitleInLandingPage();
				break;
			case "LINKED STORY":
				anlgeDetailsPage.verifyAnglePageHeader(textLabels);
				break;
			case "STORY TEAM MEMBERS":
				anlgeDetailsPage.verifyAnglePageHeader(textLabels);
				break;
			case "OVERVIEW DESCRIPTION":
				anlgeDetailsPage.verifyAnglePageHeader(textLabels);
				break;
			case "TABS":
				anlgeDetailsPage.verifyAnglePageHeader(textLabels);
				break;
			case "ADD NEW ELEMENT":
				anlgeDetailsPage.verifyAnglePageHeader(textLabels);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@Then("verify user clicks {string} button from angle landing page")
	public void clickAddNewElementBtnFromAngleLandingPage(String btnName) throws Exception {
		anlgeDetailsPage.clickAddNewElementBtn();
	}

	@And("verify edit and delete options in angle landing page for {string} different role")
	public void verifyAngleOptionsInLandingPage(String role) throws Exception {
		anlgeDetailsPage.verifyAngleOptions(role);
	}

	@Then("{string} tab loads the angle related history information")
	public void logTabInAngleLandingPage(String tab) throws Exception {
		anlgeDetailsPage.verifyAngleInformation();
	}

	@And("user able to collapse the history container in log tab")
	public void collapseLogScrollContainer() throws Exception {
		anlgeDetailsPage.collapseLog();
	}

	@Then("user clicks {string} button in sticky footer section")
	public void clickButtonInAnglePage(String edit) throws Exception {
		anlgeDetailsPage.clickEditButtonInAnglePage(edit);
	}

	@And("verify the {string} in updated angle landing Page")
	public void verifyAngleIDLandingPage(String ID) throws Exception {
		anlgeDetailsPage.verifyAngleIDInLandingPage();
	}

	@And("verify updated {string} in angle landing page")
	public void verifyUpdatedAngle(String title) {
		anlgeDetailsPage.verifyAngleTitleInLandingPage();
	}

	@When("user clicks on {string} button in Angle log page")
	public void clickDeleteBtnInAnglePage(String delete) throws Exception {
		anlgeDetailsPage.clickEditButtonInAnglePage(delete);
	}

	@Then("verify delete {string} confirmation pop up is displayed")
	public void deleteAngleConfirmPopup(String angles, DataTable dataTable) {
		anlgeDetailsPage.veriyDeleteConfirmationPopup(angles,
				CucumberUtils.getValuesFromDataTable(dataTable, "Pop Up Title"));
	}

	@When("user clicks on {string} in delete angle confirmation pop up")
	public void clickCancelBtn(String btn, DataTable table) throws Exception {
		anlgeDetailsPage.clickOKBtnInPop(btn,
				CucumberUtils.getValuesFromDataTable(table, "Delete Confirmation Message"));
	}

	@And("{string} user logout from the NCX application")
	public void logoutAsDifferentRoleUsers(String role) throws Exception {
		anlgeDetailsPage.logoutNCXApplication();
	}
	
    @And("load the angles from angle listing page")
    public void openAngleFromListingPage() throws Exception {
    	anlgeDetailsPage.verifyAngleDetailPage();
    }
    
    @Then("verify the angle landing page should not display any buttons for {string} role")
    public void angleOverviewPageFooterButtons(String role, DataTable params) {
    	anlgeDetailsPage.verifyButtonsInAngleOverviewFooterPart(role,params);
    }


}
