package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import nbcu.automation.ui.pages.ncx.CreateAnglePage;
import nbcu.automation.ui.pages.ncx.CreateStoryPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class CreateAnglePageSteps {

	CreateStoryPage createStoryPage = new CreateStoryPage();
	CreateAnglePage createAnglePage = new CreateAnglePage();
	
	@And("verify edit {string} page is loaded")
	public void verifyAngleCreationPage(String angle) throws Exception {
		createAnglePage.verifyCreateAnglePageLoaded();
	}
	
	
	@Then("user fills the Angle {string}")
	@Then("user updates the Angle {string}")
	public void enterAngleTitleAndDescription(String fieldName, DataTable dataTable) throws Exception {
		if (fieldName.equalsIgnoreCase("Title"))
			createAnglePage.fillAngleTitle(CucumberUtils.getValuesFromDataTable(dataTable, "Angle title"));
		else
			createAnglePage.fillAngleDescription(CucumberUtils.getValuesFromDataTable(dataTable, "Angle Description"));
	}
	
	@Then("user verify the {string} search suggestion drop down field should be displayed")
	public void verifyCollaborateField(String name) {
		createAnglePage.verifySearchCollaborateName();
	}

	
	
	@Then("user verified the Story name is displayed by default")
	public void verifyStoryNameInParkingLotSection() throws Exception {
		createAnglePage.verifyAppLinkedStoriesName();
	}
	
	@Then("verify story team member card should be displayed by default")
	public void verifyStoryTemaMembersCard() {
		createAnglePage.verifyDefaultMemberCard();
	}
	
	/*
	 * @And("user fills the angle {string}") 
	 * @And("user updated the Angle {string}")
	
	 * public void fillStoryTitleAndDescription(String fieldName, DataTable
	 * dataTable) throws Exception { if (fieldName.equalsIgnoreCase("DESCRIPTION"))
	 * createAnglePage.fillAngleDescription(CucumberUtils.getValuesFromDataTable(
	 * dataTable, "Angle Description")); }
	 */
	@Then("user selects the {string} to associate this angle")
	public void enterTheStoryNameInAddToStoryField(String name) throws Exception {
		createAnglePage.enterStoryName();
	}

	@And("user adds {string} for this angle")
	@And("user added {string} for update the angle")
	public void selectStoryTeamMembers(String teamName, DataTable dataTable) throws Exception {
		createAnglePage.selectStoryTeamMembers(CucumberUtils.getValuesFromDataTable(dataTable, "Team Members"));
	}

	@Then("user click on {string} button in create angle page")
	@Then("user clicked {string} button in update angle page")
	public void clickButtonFromFooter(String buttonName) throws Exception {
		createAnglePage.clickButton(buttonName);
	}
	
    @Then("verify the app linked stories in Angle landing page")
    public void linkedStoryName() throws Exception {
    	createAnglePage.verifyAppLinkedStoriesName();
    }
    
    @And("user able to delete the linked story from parking lot section")
    public void DeleteLinkedStory() throws Exception {
    	createAnglePage.deletingAssociatedStory();
    }
    
    @Then("user should select the same story to associate the angle")
    public void reselectTheStory() throws Exception {
    	createAnglePage.enterStoryName();
    }

    @And("user delete {string} for this angle")
    public void deleteAddedStoryTeamMembers(String team) throws Exception {
    	createAnglePage.deleteStoryTeam();
    }
    
    @And("user verify the story team members name card default display the {string} name")
    public void verifyStoryTeamDefaultName(String userRole) {
    	createAnglePage.verifyLoginUserNameInCard(userRole);
    }
    

	
	
//	Then user click on "publish" button in create angle page
	
		/*
	 * @And("user adds {string} to story") public void fillStoryTopicsAndTags(String
	 * fieldName, DataTable dataTable) throws Exception { switch
	 * (fieldName.toUpperCase()) { case "TOPICS":
	 * createStoryPage.selectTopic(dataTable); break; case "TAGS":
	 * createStoryPage.addTags(dataTable); break; case "SLACK CHANNELS":
	 * createStoryPage.addSlackChannel(dataTable); break; default: Assert.
	 * fail("Please provide valid section(Topics/Tags/Slack Channels) name for content creation"
	 * ); } }
	 * 
	 */ /*
		 * @And("user click on {string} button in create story page") public void
		 * clickButtonFromFooter(String buttonName) throws Exception {
		 * createStoryPage.clickButton(buttonName); }
		 */

}
