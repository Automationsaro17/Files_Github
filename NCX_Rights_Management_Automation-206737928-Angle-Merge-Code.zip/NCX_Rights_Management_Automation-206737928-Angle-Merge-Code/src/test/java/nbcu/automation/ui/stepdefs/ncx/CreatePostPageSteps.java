package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.pages.ncx.CreatePostPage;
import nbcu.framework.utils.cucumber.CucumberUtils;
import org.testng.Assert;

public class CreatePostPageSteps {

    CreatePostPage createPostPage = new CreatePostPage();

    @When("user fills post {string}")
    @When("user updates post {string}")
    public void fillPostTitleAndDescription(String postTitleOrDesc, DataTable params) throws Exception {
        if (postTitleOrDesc.equalsIgnoreCase("TITLE"))
            createPostPage.fillPostTitle(CucumberUtils.getValuesFromDataTable(params, "Post Title"));
        else if (postTitleOrDesc.equalsIgnoreCase("DESCRIPTION"))
            createPostPage.fillPostDescription(CucumberUtils.getValuesFromDataTable(params, "Post Description"));
        else
            Assert.assertTrue(false, "Please enter valid field name for create post page." + postTitleOrDesc + " field name is not valid");
    }

    @And("user links {string} to post")
    public void linkStoryOrAngle(String storyOrAngle) throws Exception {
        if (storyOrAngle.equalsIgnoreCase("STORY"))
            createPostPage.linkStory(StoryConstants.getStoryTitle());
    }

    @And("verify linked {string} is displayed with pin and delete icon")
    public void verifyLinkedStories(String storyOrAngle) throws Exception {
        if (storyOrAngle.equalsIgnoreCase("STORY"))
            createPostPage.verifyLinkedStories();
    }

    @And("verify primary story is marked with {string} color in crown")
    public void verifyPrimaryStory(String color) throws Exception {
        createPostPage.verifyStoryMarkedAsPrimary(color);
    }

    @And("verify {string} message is displayed in create post page")
    public void verifyPostSavedAsDraftMessage(String message) throws Exception {
        createPostPage.verifyPostSavedAsDraft();
    }

    @And("user adds below attachment to post")
    public void addAttachment(DataTable params) throws Exception {
        createPostPage.addAttachments(params);
    }

    @Then("verify attachments are added to post along with delete icon")
    public void verifyAddedAttachment() throws Exception {
        createPostPage.verifyAddedAttachments();
    }

    @And("verify material cleared field in element details is marked as mandatory field")
    public void verifyMaterialClearedForMarkedAsMandatory() throws Exception {
        createPostPage.verifyMaterialClearedForMarkedAsMandatory();
    }

    @And("user fills {string} in element details section")
    public void fillLinkToSourceAndMandatoryCredit(String fieldName, DataTable params) throws Exception {
        if (fieldName.equalsIgnoreCase("LINK TO SOURCE"))
            createPostPage.fillLinkToSource(CucumberUtils.getValuesFromDataTable(params, "Link To Source"));
        else if (fieldName.equalsIgnoreCase("MANDATORY CREDIT"))
            createPostPage.fillMandatoryCredit(CucumberUtils.getValuesFromDataTable(params, "Mandatory Credit Option"), CucumberUtils.getValuesFromDataTable(params, "Mandatory Credit Value"));
        else
            Assert.assertTrue(false, "Please enter valid field name in element details section." + fieldName + " field name is not valid");
    }

    @And("user selects {string} in {string}")
    public void selectClearedForNbcuPartners(String clearedForNbcuPartners, String fieldName) throws Exception {
        createPostPage.fillClearedForNbcuPartners(clearedForNbcuPartners);
    }

    @And("user selects {string} label")
    public void selectLabels(String labelType, DataTable params) throws Exception {
        if (labelType.equalsIgnoreCase("EDITORIAL/STANDARDS"))
            createPostPage.selectEditorialOrStandardsLabel(params);
        else createPostPage.selectRcOrLegalLabel(params);
    }

    @Then("verify {string} section is displayed")
    public void verifyLabelSectionDisplayed(String sectionName) throws Exception {
        createPostPage.verifyLabelSectionDisplayed(sectionName);
    }

    @And("user fills {string} details")
    public void fillStandardGuidance(String sectionName, DataTable params) throws Exception {
        if (sectionName.equalsIgnoreCase("STANDARD GUIDANCE"))
            createPostPage.fillStandardGuidance(CucumberUtils.getValuesFromDataTable(params, "Standard Guidance"));
        else if (sectionName.equalsIgnoreCase("REPORTABLE APPROVER"))
            createPostPage.fillReportableApproverSection(CucumberUtils.getValuesFromDataTable(params, "Field Name"), CucumberUtils.getValuesFromDataTable(params, "Reportable Option"), CucumberUtils.getValuesFromDataTable(params, "Reportable Value"), CucumberUtils.getValuesFromDataTable(params, "Reportable Notes"));
        else if (sectionName.equalsIgnoreCase("LIMITED LICENSE"))
            createPostPage.fillLimitedLicense(CucumberUtils.getValuesFromDataTable(params, "Limited License Description"));
        else Assert.assertTrue(false, "Please enter valid section name");
    }

    @And("user clicks on {string} button in {string} post page")
    public void clickButton(String buttonName, String pageType) throws Exception {
        createPostPage.clickButton(buttonName, pageType);
    }

    @And("verify Do not Send Email Update for this Edit checkbox is checked by default")
    public void verifyDoNotSendEmailUpdateCheckBoxCheckedByDefault() throws Exception {
        createPostPage.verifyDoNotSendEmailForUpdateCheckBoxStatus();
    }

    @And("user {string} Do not Send Email Update for this Edit checkbox")
    public void checkOrUnCheckDoNotSendEmailForUpdateCheckBox(String action) throws Exception {
        createPostPage.checkOrUnCheckDoNotSendEmailForUpdateCheckBox();
    }
    
    //Loga - Merged  --> Date - 04/22/2024
    
    @Then("verify linked {string} is displayed with delete icon")
    public void linkedAngle(String angle) throws Exception {
    	createPostPage.veriyfLinkedAngle();
    }
    
}
