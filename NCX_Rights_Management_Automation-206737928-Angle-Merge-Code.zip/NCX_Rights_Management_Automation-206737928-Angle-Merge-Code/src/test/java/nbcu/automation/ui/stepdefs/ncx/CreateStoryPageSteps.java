package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.CreateAnglePage;
import nbcu.automation.ui.pages.ncx.CreateContentPage;
import nbcu.automation.ui.pages.ncx.CreatePostPage;
import nbcu.automation.ui.pages.ncx.CreateStoryPage;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.utils.cucumber.CucumberUtils;
import org.testng.Assert;

public class CreateStoryPageSteps {

    CreateStoryPage createStoryPage = new CreateStoryPage();
    CreateAnglePage createAnglePage = new CreateAnglePage();
    CreatePostPage createPostPage = new CreatePostPage();

    @Then("verify create {string} page is loaded")
    @Then("verify edit {string} page is loaded")
    public void verifyCreatePageLoaded(String pageName) throws Exception {
        switch (pageName.toUpperCase()) {
            case "STORY":
                createStoryPage.verifyCreateStoryPageLoaded();
                break;
            case "POST":
                createPostPage.verifyCreatePostPageLoaded();
                break;
            case "ANGLE":
            	createAnglePage.verifyCreateAnglePageLoaded();
                //To be added
                break;
            default:
                Assert.fail("Please provide valid page name for content creation");
        }
    }
    
    @Then("verify the tab should be displayed as Create Post")
	public void verifyCreateElementPageTitle() {
		 createPostPage.verifyBrowserTabTitle("Create Post");
	}

    @And("user selects story {string} as {string}")
    public void selectStoryTypeAndPrivacy(String fieldName, String value) throws Exception {
        if (fieldName.equalsIgnoreCase("STATUS")) createStoryPage.selectStoryStatus(value);
        else createStoryPage.selectStoryPrivacy(value);
    }

    @And("user fills story {string}")
    @And("user updates story {string}")
    public void fillStoryTitleAndDescription(String fieldName, DataTable dataTable) throws Exception {
        if (fieldName.equalsIgnoreCase("TITLE"))
            createStoryPage.fillStoryTitle(CucumberUtils.getValuesFromDataTable(dataTable, "Story Title"));
        else createStoryPage.fillStoryDescription(CucumberUtils.getValuesFromDataTable(dataTable, "Story Description"));
    }

    @And("user updates {string} to {string}")
    @And("user adds {string} to {string}")
    public void fillStoryTopicsAndTags(String fieldName, String storyOrPost, DataTable dataTable) throws Exception {
        switch (fieldName.toUpperCase()) {
            case "TOPICS":
                createStoryPage.selectTopic(dataTable);
                break;
            case "TAGS":
                createStoryPage.addTags(storyOrPost,dataTable);
                break;
            case "SLACK CHANNELS":
                createStoryPage.addSlackChannel(dataTable);
                break;
            default:
                Assert.fail("Please provide valid section(Topics/Tags/Slack Channels) name for content creation");
        }
    }

    @And("verify added {string} are displayed in place holder")
    @And("verify updated {string} are displayed in place holder")
    @And("verify story {string} are displayed in place holder")
    public void verifyAddedTopicsOrtagsOrSlackChannel(String fieldName) throws Exception {
        switch (fieldName.toUpperCase()) {
            case "TOPICS":
                createStoryPage.verifyAddedTopics();
                break;
            case "TAGS":
                createStoryPage.verifyAddedTags();
                break;
            case "SLACK CHANNELS":
                createStoryPage.verifyAddedSlackChannels();
                break;
            default:
                Assert.fail("Please provide valid section(Topics/Tags/Slack Channels) name for content creation");
        }
    }

    @And("user click on {string} button in {string} story page")
    public void clickButtonFromFooter(String buttonName, String pageType) throws Exception {
        createStoryPage.clickButton(buttonName, pageType);
    }
    
    @And("user click on {string} button in create story page")
	public void clickButtonFromFooters(String buttonName) throws Exception {
		createStoryPage.clickButtons(buttonName);
	}
    
}
