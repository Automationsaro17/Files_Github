package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import nbcu.automation.ui.pages.ncx.DraftsPage;
import nbcu.automation.ui.pages.ncx.LoginPage;

public class DraftsPageSteps {

    DraftsPage draftsPage = new DraftsPage();

    @Given("verify drafts page is loaded")
    public void verifyDraftsPageLoaded() throws Exception {
        draftsPage.verifyDraftsPageLoaded();
    }

    @And("user opens {string} tab in drafts page")
    public void selectDraftPageTab(String tabName) throws Exception {
        draftsPage.selectDraftPage(tabName);
    }

    @And("verify draft {string} details and open draft {string}")
    public void selectDraftPageTab(String tabName, String draftType) throws Exception {
        draftsPage.verifyDraftPostStoryDetails(tabName);
    }
}
