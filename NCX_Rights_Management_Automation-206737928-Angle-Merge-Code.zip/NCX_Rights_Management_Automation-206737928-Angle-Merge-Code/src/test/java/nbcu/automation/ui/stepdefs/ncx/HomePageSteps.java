package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.HomePage;
import nbcu.automation.ui.pages.ncx.ProfilePage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class HomePageSteps {

    HomePage homePage = new HomePage();
    ProfilePage profilePage = new ProfilePage();

    @Given("verify ncx rights management home page is loaded")
    public void verifyHomePageLoaded() throws Exception {
        homePage.verifyHomePageLoaded();
    }

    @When("user searches {string} in global search")
    public void enterSearchTextInGlobalSearchBar(String searchCategory, DataTable params) throws Exception {
        homePage.fillSearchText(CucumberUtils.getValuesFromDataTable(params, "Search Text"));
    }

    @Then("verify no results is displayed under {string} tab")
    public void verifyNoResultsDisplayed(String searchCategory, DataTable params) throws Exception {
        homePage.verifyNoSearchResult(searchCategory);
    }

    @Then("open post from {string} search result")
    public void verifyGlobalSearchAndOpen(String searchCategory, DataTable params) throws Exception {
        homePage.verifySearchResultAndOpen(searchCategory, CucumberUtils.getValuesFromDataTable(params, "Search Text"));
    }

    @Given("user fetches login profile details")
    public void fetchLoginUserDetails() throws Exception {
        homePage.clickProfile();
        profilePage.verifyProfilePageLoaded();
        profilePage.fetchUserDetails();
    }

    @When("user clicks on create content icon from header")
    public void clickCreateContentIcon() throws Exception {
        homePage.clickCreateContentButton();
    }

    @When("user clicks logs out link in NCX application")
    public void logOut() throws Exception {
        homePage.logOut();
    }

    @Then("verify application have been logged out")
    public void verifyLogOutSuccessfull() throws Exception {
        homePage.verifyApplicationLoggedOut();
    }

    @When("user opens {string} page from left side menu")
    public void openLeftSideMenus(String leftSideMenu) throws Exception {
        homePage.openLeftSideMenu(leftSideMenu);
    }

    @When("user opens post using url which is created by {string}")
    public void openPost(String role) throws Exception {
        homePage.openPost();
    }
}
