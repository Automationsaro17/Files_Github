package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.StoryDetailsPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class StoryDetailsPageSteps {

    StoryDetailsPage storyDetailsPage = new StoryDetailsPage();

    @Then("verify story details page is loaded")
    public void verifyStoryDetailsPageLoaded() throws Exception {
        storyDetailsPage.verifyStoryDetailsPageLoaded();
    }

    @Then("verify story status indicator is displayed in {string} color for {string}")
    public void verifyStoryStatusIndicator(String color, String storyStatus) throws Exception {
        storyDetailsPage.verifyStoryStatusIndicator(color, storyStatus);
    }

    @And("verify story {string} in story details page")
    public void verifyStoryDetails(String fieldName) throws Exception {
        storyDetailsPage.verifyStoryDetailsSection(fieldName);
    }

    @And("verify story {string} in RH drawer")
    public void verifyStoryDetailsInRhDrawer(String fieldName) throws Exception {
        storyDetailsPage.verifyStoryDetailsInRightDrawer(fieldName);
    }

    @And("verify story options in story details page for {string} role")
    public void verifyStoryOptions(String role) throws Exception {
        storyDetailsPage.verifyStoryOptions(role);
    }

    @When("user clicks on {string} button in story details page")
    public void clickButton(String buttonName) throws Exception {
        storyDetailsPage.clickButtonInStoryDetailsPage(buttonName);
    }

    @Then("verify delete {string} confirmation pop up is displayed")
    public void verifyDeleteConfirmationPopUp(String storyOrPost, DataTable params) throws Exception {
        storyDetailsPage.verifyDeleteConfirmationPopupDisplayed(storyOrPost, CucumberUtils.getValuesFromDataTable(params, "Pop Up Title"));
    }

    @When("user clicks on {string} in delete {string} confirmation pop up")
    public void clickButtonInConfirmationPopUp(String buttonName, String storyOrPost) throws Exception {
        storyDetailsPage.clickButtonInConfirmationPopUp(buttonName);
    }

    @Then("verify {string} deleted confirmation message is displayed")
    public void verifyStoryDeletedMessage(String storyOrPost, DataTable params) throws Exception {
        storyDetailsPage.verifyStoryDeleteMessage(storyOrPost, CucumberUtils.getValuesFromDataTable(params, "Delete Confirmation Message"));
    }
    
    
    //Loga Merged - Date ->> 04/22/2024
    
   // @Then("//span[text()='Working']/../../../following-sibling::app-scroll-container//ncx-story//div[@class='ncx-story-header']/a")
 	@Then("user clicks {string} option in Left hand navigation bar")
 	public void navigateTToDashboardPage(String iconName) throws Exception {
 		storyDetailsPage.clickStoriesIcon(iconName);
 	}

 	@Then("user verify the story name in working column")
 	public void verifyStoryNameInWorkingColumn() throws Exception{
 		storyDetailsPage.verifyStoryNameInColumn();
 	}
 	
 	@And("{string} user clicks the Story name from the working column")
 	public void loadStoryDetailsFromDashBoardColumn(String role) throws Exception {
 		storyDetailsPage.clickStoryNameFromWorkingColumn(role);
 	}
 	
 	@And("user clicks the Story name from the working column")
 	public void clickStoryName() throws Exception {
 		storyDetailsPage.clickStoryNameFromWorkingColumn("test");
 	}
 	
 	 @Then("verify the Story Landing Page is displayed")
 	 public void verifyStoryLandingPage() {
 		 storyDetailsPage.isStoryLandingPageDisplayed();
 	 }
 	 
 	 @When("user clicks angle tab it should load the angle listing page")
 	 public void clickAngleTabInStoryLandingPage() throws Exception {
 		 storyDetailsPage.loadAnglesTab();
 	 }
 	 
 	 @When("user Read Only user clicks angle tab it should load the angle listing page")
 	 public void clickAngleTabInStoryLandingPageasReadOnly() throws Exception {
 		 storyDetailsPage.loadAnglesTabasReadOnly();
 	 }
 	 
 	 @When("verify the filter RH drawer is enabled by default")
 	 public void toVerifyRHdrawer() {
 		 storyDetailsPage.verifyRHDrawerEnabledByDefault();
 	 }
 	 
 	 
 	 @Then("user clicks Add new button in sticky footer section")
 	 public void clickAddNewBtn() throws Exception {
 		 storyDetailsPage.clickAddNewInFooter();
 	 }
 	 
 	 @And(" verify the filter RH drawer is enabled by default")
 	 public void verifyFilterRhDrawerEnabled() {
 		 storyDetailsPage.verifyFilterDrawer();
 	 }
 	 
 	 @And("sort filter icon should not be filled with blue color icon")
 	 public void filterIconColor() throws Exception {
 		 storyDetailsPage.verifyColor();
 	 }
 	 
 	 @Then("verify the different filters option like Sort by and Author")
 	 public void verifyFilterOptionsInRHdrawer() {
 		 storyDetailsPage.verifyFilterDrawerOptions();
 	 }
 	 
 	 @When("the sort by default selected option is {string}")
 	 public void defSelectedSortBy(String sortOption) {
 		 storyDetailsPage.verifyDefaulFilterInSortBy();
 	}
 	 
 	 @And("the Author sort section search field should be displayed")
 	 public void verifyAuthorFilterSection() {
 		 storyDetailsPage.verifyAuthorOption();
 	 }
 	 
 	 @Then("Author section search field should be displayed as default blank")
 	 public void verifyAuthorField() {
 		 storyDetailsPage.authorInputField();
 	 }
 	 
 	 @And("user able to enter the ncx user profile name {string} in Author search field")
 	 public void enterNCXUserName(String name) throws Exception {
 		 storyDetailsPage.enterAnyProfileName(name);
 	 }
 	 
 	 @Then("verify the angle results based on applied author name in filter section")
 	 public void verifyAngleAuthorFilterResults() throws Exception {
 		 storyDetailsPage.verifyFilterResults();
 	 }
 	 
 	 @When("user switches to post tab and returned back to angle tab should maintain the filter results")
 	 public void verifyFilterResultFromPostToAngleTab() throws Exception {
 		 storyDetailsPage.verifyAngleFilterRetainedResults();
 	 }
 	 
 	 @Then("user able to sort the angles based on date and time in angle listing page")
 	 public void angleCreationDateAndTime() throws Exception {
 		 storyDetailsPage.saveDateAndTime();
 	 }
 	 
 	 
 	 @Then("user view the search field in angle listing page")
 	 public void verifySearchFieldInAngleListingPage() {
 		 storyDetailsPage.verifySearchField();
 	 }
 	 
 	 @When("user enters the keyword in angle listing search field")
 	 public void enterKeywordInSearchField() throws Exception {
 		 storyDetailsPage.enterSearchField();
 	 }
 	 
 	 @Then("user verify the serch resulted keyword in angle listing page")
 	 public void verifySearchResultsLoaded() throws Exception {
 		 storyDetailsPage.verifySearchResults();
 	 }
 	 
 	 @And("verify angle title keyword got highlighted in specific color")
 	 public void verifyColorOfSearchResultedKeyword() throws Exception {
 		 storyDetailsPage.verifytxtColor("Dark voilet");
 	 }

 	 
 	 @Then("verify create content + icon should not be in header")
 	 public void verifyADDPostIconInHeader() {
 		 storyDetailsPage.addPostIconDisabled();
 	}
 	 
 	 @And("only {string} button should displayed in sticky footer section")
 	 public void activeBtnInFooterSection(String InfoBtn) {
 		storyDetailsPage.verifyButtonsInStoryLandingPage();
 	 }
 	 
 	 @Then("verify the post listing page should not display any buttons")
 	 public void readOnlyUsersButtonsInFooter(DataTable params) {
 		 storyDetailsPage.verifyButtons(params);
 	 }
 	 
 	 @Then("verify buttons in angle listing page should not display in sticky footer section")
 	 public void readOnlyUsersButtonsInAnglePage(DataTable params) {
 		 storyDetailsPage.verifyButtons(params);
 	 }
 	 

 			 
 }



