package nbcu.automation.ui.validation.common;

public class EmailValidation {

	/**
	 * To validate email to list
	 * 
	 * @param toOrCCList - To List / Cc List
	 * @throws Throwable
	 */
	/*
	 * public static void validateEmailToAndCcList(String toOrCCList, String
	 * bookingType) throws Throwable { String expectedToList = "", expectedCcList =
	 * ""; try { // Forming expected To and CC list if
	 * (BookerProfileConstants.getEmail1() != null) expectedToList = expectedToList
	 * + BookerProfileConstants.getEmail1() + ","; if
	 * (BookerProfileConstants.getEmail2() != null) expectedToList = expectedToList
	 * + BookerProfileConstants.getEmail2() + ","; if
	 * (BookerProfileConstants.getEmail3() != null) expectedToList = expectedToList
	 * + BookerProfileConstants.getEmail3() + ","; if
	 * (BookerProfileConstants.getEmail4() != null) expectedToList = expectedToList
	 * + BookerProfileConstants.getEmail4() + ",";
	 * 
	 * // Expected CC list expectedCcList = expectedToList.substring(0,
	 * expectedToList.length() - 1);
	 * 
	 * // Adding email alert address in To list
	 * 
	 * //Add duplicate email alert email id if duplicate booking if
	 * (bookingType.equalsIgnoreCase("DUPLICATE BOOKING")) { expectedToList =
	 * AdminConstants.getAlertEmailList().replace(" ", "")+","; }
	 * 
	 * int alertEmailCount =
	 * Integer.parseInt(BookingGuestConstants.getEmailAlertCount()); for (int i = 0;
	 * i < alertEmailCount; i++) { expectedToList = expectedToList +
	 * BookingGuestConstants.getEmailAlert(i) + ","; }
	 * 
	 * // Expected To List expectedToList = expectedToList.substring(0,
	 * expectedToList.length() - 1);
	 * 
	 * if (toOrCCList.equalsIgnoreCase("TO LIST"))
	 * Assert.assertEquals(EmailConstants.getEmailToList(), expectedToList,
	 * "Email notification To list is not matched"); else if
	 * (toOrCCList.equalsIgnoreCase("CC LIST"))
	 * Assert.assertEquals(EmailConstants.getEmailCcList(), expectedCcList,
	 * "Email notification CC list is not matched"); else Assert.assertTrue(false,
	 * "Enter valid email content type");
	 * 
	 * } catch (Exception | Error e) { e.printStackTrace(); throw e; } }
	 * 
	 *//**
		 * To verify email subject
		 * 
		 * @throws Throwable
		 */
	/*
	 * public static void validateSubject(String bookingType) throws Throwable {
	 * String expectSubject = ""; try { // Forming expected subject String division
	 * = AdminConstants.getDivision(); String guestName =
	 * GuestProfileConstants.getFullNameWithoutTitleAndSuffix(); String showDate =
	 * BookingGuestConstants.getShowDate(); String showTime =
	 * DateFunctions.convertDateStringToAnotherFormat(BookingGuestConstants.
	 * getShowTime(), "HH:mm", "hh:mm:ss a");
	 * 
	 * if ((bookingType.equalsIgnoreCase("NEW BOOKING")) ||
	 * (bookingType.equalsIgnoreCase("EDITED BOOKING"))) expectSubject = division +
	 * " Booking Alert: " + guestName + " on " + showDate + " " + showTime; else if
	 * (bookingType.equalsIgnoreCase("CANCEL BOOKING")) expectSubject = division +
	 * " Booking Alert: " + guestName + " on " + showDate; else if
	 * (bookingType.equalsIgnoreCase("DUPLICATE BOOKING")) { showTime =
	 * DateFunctions.convertDateStringToAnotherFormat(
	 * BookingGuestConstants.getDuplicateBookingShowTime(), "HH:mm", "hh:mm:ss a");
	 * expectSubject = "[Duplicate Booking] " + guestName +
	 * " Booking is confirmed on "+division+" for " + showDate + " " + showTime; ; }
	 * else Assert.assertTrue(false,
	 * "Enter valid booking type for email subject validation");
	 * 
	 * Assert.assertEquals(EmailConstants.getEmailSubject(), expectSubject,
	 * "Email notification subject is not matched");
	 * 
	 * } catch (Exception | Error e) { e.printStackTrace(); throw e; } }
	 * 
	 *//**
		 * To verify email body
		 * 
		 * @param bodyContentName - content name
		 * @throws Throwable
		 *//*
			 * public static void validateEmailBody(String bookingType, String
			 * bodyContentName, String expectedValue) throws Throwable { String showDate =
			 * "", showTime = ""; try { String actualEmailBody =
			 * EmailConstants.getEmailBody();
			 * 
			 * // Forming expected email body String division =
			 * AdminConstants.getDivision(); String guestName =
			 * GuestProfileConstants.getFullNameWithoutTitleAndSuffix(); String showName =
			 * BookingGuestConstants.getShowName(); String topicName =
			 * BookingGuestConstants.getTopicName(); String studioName =
			 * BookingGuestConstants.getStudio(); String bookingUrl =
			 * BookingGuestConstants.getBookingUrl(); String bookerName =
			 * BookerProfileConstants.getBookerName(); String bookingDate =
			 * BookingGuestConstants.getBookingDate(); String bookingTime =
			 * DateFunctions.convertDateStringToAnotherFormat(BookingGuestConstants.
			 * getBookingTime(), "HH:mm", "hh:mm:ss a"); String bookingCancelledDate =
			 * BookingGuestConstants.getBookingCancellationDate(); String
			 * bookingCancelledTime = BookingGuestConstants.getBookingCancellationTime();
			 * 
			 * String technicalNotes = BookingGuestConstants.getBookingNotes();
			 * 
			 * // Getting show date and time showDate = BookingGuestConstants.getShowDate();
			 * showTime =
			 * DateFunctions.convertDateStringToAnotherFormat(BookingGuestConstants.
			 * getShowTime(), "HH:mm", "hh:mm:ss a");
			 * 
			 * switch (bodyContentName.toUpperCase()) { case "HEADING": if
			 * (bookingType.equalsIgnoreCase("DUPLICATE BOOKING")) Assert.assertTrue(
			 * actualEmailBody.
			 * contains("NBC Universal Guest Tracker - Duplicate Booking Alert:"),
			 * "Email body header is not correct. Expected heading is 'NBC Universal Guest Tracker - Duplicate Booking Alert:'"
			 * ); else Assert.assertTrue(
			 * (actualEmailBody.contains("NBC Universal Guest Tracker - Booking Alert:") ||
			 * actualEmailBody .contains("NBC Universal Guest Tracker - " + division +
			 * " Booking Alert:")),
			 * "Email body header is not correct. Expected heading is 'NBC Universal Guest Tracker - Booking Alert:'"
			 * ); break; case "BOOKING CONFIRMED MESSAGE": String expectedMessage =
			 * guestName + "'s Booking is confirmed on " + showName + " for " + showDate +
			 * " " + showTime + ".";
			 * Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedMessage.
			 * toLowerCase()),
			 * "Booking confirmation message in email body is not correct. Expected confirmation message is '"
			 * + expectedMessage + "'"); break; case "BOOKING CANCELLED MESSAGE": String
			 * expectedCancelledMessage = "The following show has been cancelled ";
			 * Assert.assertTrue(actualEmailBody.toLowerCase().contains(
			 * expectedCancelledMessage.toLowerCase()),
			 * "Booking confirmation message in email body is not correct. Expected confirmation message is '"
			 * + expectedCancelledMessage + "'"); break; case "TOPIC": String expectedTopic
			 * = "Topic: " + topicName;
			 * Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedTopic.
			 * toLowerCase()),
			 * "Topic name in email body is not correct. Expected topic is '" +
			 * expectedTopic + "'"); break; case "STUDIO": String expectedStudio =
			 * "Studio/Other Location: " + studioName;
			 * Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedStudio.
			 * toLowerCase()), "Studio in email body is not correct. Expected studio is '" +
			 * expectedStudio + "'"); break; case "FEED": String expectedFeed = "Feed: " +
			 * expectedValue;
			 * Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedFeed.
			 * toLowerCase()), "Feed in email body is not correct. Expected feed is '" +
			 * expectedFeed + "'"); break; case "MAKEUP": String expectedMakeUp = "Makeup: "
			 * + expectedValue;
			 * Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedMakeUp.
			 * toLowerCase()), "Make up in email body is not correct. Expected makeup is '"
			 * + expectedMakeUp + "'"); break; case "CAR": String expectedCar = "Car: " +
			 * expectedValue;
			 * Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedCar.
			 * toLowerCase()), "Car in email body is not correct. Expected car is '" +
			 * expectedCar + "'"); break; case "TECHNICAL NOTES": String
			 * expectedTechnicalNotes = "Technical Notes: " + technicalNotes;
			 * Assert.assertTrue(actualEmailBody.toLowerCase().contains(
			 * expectedTechnicalNotes.toLowerCase()),
			 * "Technical notes in email body is not correct. Expected teachnical notes is '"
			 * + expectedTechnicalNotes + "'"); break; case "BOOKING URL": String
			 * expectedBookingUrl = "Details are available for viewing at: »" + bookingUrl;
			 * Assert.assertTrue( actualEmailBody.toLowerCase().replace(" https", "https")
			 * .contains(expectedBookingUrl.toLowerCase()),
			 * "Booking url in email body is not correct. Expected booking url is '" +
			 * expectedBookingUrl + "'"); break; case "BOOKER DETAIL": String
			 * expectedBookerDetail = ""; if ((bookingType.equalsIgnoreCase("NEW BOOKING"))
			 * || (bookingType.equalsIgnoreCase("EDITED BOOKING"))) expectedBookerDetail =
			 * "This guest was booked by: " + bookerName + " (on " + bookingDate + " at " +
			 * bookingTime + ")"; else if (bookingType.equalsIgnoreCase("CANCEL BOOKING"))
			 * expectedBookerDetail = "This guest was booked by: " + bookerName + " (on " +
			 * bookingCancelledDate + " at " +
			 * DateFunctions.convertDateStringToAnotherFormat(bookingCancelledTime, "h:mma",
			 * "hh:mm");
			 * Assert.assertTrue(actualEmailBody.toLowerCase().contains(expectedBookerDetail
			 * .toLowerCase()),
			 * "Booker details in email body is not correct. Expected booker detail is '" +
			 * expectedBookerDetail + "'"); break; default: Assert.assertTrue(false,
			 * "Please provide valid content name of email body"); } } catch (Exception |
			 * Error e) { e.printStackTrace(); throw e; } }
			 */

}
