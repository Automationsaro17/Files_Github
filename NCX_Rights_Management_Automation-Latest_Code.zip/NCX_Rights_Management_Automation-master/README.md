# Framework Overview:
It is BDD cucumber framework and feature files are written in gherkin language which is plain-text language with a simple structure.

* Core framework logics are build in src/main/java. It framework related components like driver factory, UI and API wrapper methods, cucumber runner file, allure report functions, etc.,
* Test case related functions are build in src/test/java. It will contain page classes, step definitions, etc.,
* Test case related resources are placed in src/test/resources. It will contain feature files, allure report configuration, email templates, etc.,

# Tools/Language used:
1. Java - For scripting
2. Selenium WebDriver - For web application automation
3. Rest Assured - For API automation
4. Maven - Build tool
5. Cucumber - BDD framework
6. TestNG - To supporting parellel execution
7. Extent Report - Automation report

# Tool Required for scripting:
1. Java 17/Open Jdk 17
2. Eclipse/Intellij IDE

# Feature File Location:
src/test/resources/features

# Execution From Command Prompt
As pre-requisite, user should have java and maven package in their machine and environment variable should set with java and maven bin path. If you open command prompt and mvn, then it should not say invalid command

* Download project from GitHub
* Open Config.properties and update Environment property. If user want to run test case in stage environment, change property value as STAGE
* Go to project main folder, open run command prompt
* type 'mvn clean compile test'

# Execution From Eclipse/Intellij IDE
As pre-requisite, user should have java and eclipse package in their machine and environment variable should set with java bin path.

* Download project from GitHub
* Open Eclipse ->File ->Import -> Search 'Existing Maven Project' and select ->Click Next -> Click Browse -> Go to project location and select -> Click Finish -> Project will be imported
* Go to Help->Eclipse Marketplace->Search 'Cucumber Eclipse plugin' ->Install
* Select Project root folder in eclipse ->Right Click->Configure->Convert to Cucumber Project

* Open Config.properties and update Environment property. If user want to run test case in stage environment, change property value as STAGE
* Go Run->Run Configurations->Search and double click 'Maven Build'
* Under 'Base directory' text box, Click Workspace and select the project in eclipse works
* In Goals, provide 'clean compile test' ->Apply ->Run

# Execution Report
* Sharable automation execution reports can be found in below path
/Reports/
![Alt text](image.png)

* There are 3 reports will be generated
![Alt text](image-1.png)
  1. ExtentHtmlReport - It is HTML report
  2. ExtentPDFReport - It is PDF format report
  3. SparkReport - It is same like extent report. Look and feel will be defferent
