package nbcu.framework.utils.others;

import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.FileFilterUtils;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FolderFunctions {

    /**
     * To delete all files from given folder
     *
     * @param path - Folder Path
     * @throws Exception
     */
    public static void clearFolder(String path) throws Exception {
        try {
            FileUtils.cleanDirectory(new File(path));
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }


    /**
     * To get all file names from given folder
     *
     * @param path - Folder Path
     * @return - All file names
     * @throws Exception
     */
    public static List<String> getFileNameFromFolder(String path) throws Exception {
        List<String> fileNamesList = new ArrayList<String>();
        try {
            // Using File class create an object for specific directory
            File directory = new File(path);
            File[] files = directory.listFiles();

            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    fileNamesList.add(files[i].getName());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return fileNamesList;
    }

    /**
     * To fetch most recent modified file name from given directory
     * @param path - path of folder
     * @return - File name
     */
    public static String findMostRecentFileFromGivenFolder(String path) {
        String recentFileName = null;
        try {
            File file = new File(path);
            if (file.isDirectory()) {
                File[] dirFiles = file.listFiles((FileFilter) FileFilterUtils.fileFileFilter());
                if (dirFiles != null && dirFiles.length > 0) {
                    Arrays.sort(dirFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                    return dirFiles[0].getName();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

        return recentFileName;
    }

    public static void main(String[] args) throws Exception {
        System.out.println(System.getProperty("user.dir") + "\\" + ConfigFileReader.getProperty("File-Download-Path"));
        clearFolder(System.getProperty("user.dir") + "\\" + ConfigFileReader.getProperty("File-Download-Path"));
    }
}
