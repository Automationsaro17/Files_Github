package nbcu.framework.utils.report;

import nbcu.framework.utils.others.DateComparator;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import nbcu.framework.utils.propertyfilereader.ExtentPropertiesReader;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class EmailHelper {

    /**
     * To email automation execution report
     */
    public static void sendEmail() throws Exception {

        /**
         * Fetching info required to send email
         */
        String smtpHost = ConfigFileReader.getProperty("SMTP-Host");
        String smtpPort = ConfigFileReader.getProperty("SMTP-Port");
        String fromEmail = ConfigFileReader.getProperty("From-Email");
        String toEmail = ConfigFileReader.getProperty("To-Email");
        String emailSubject = ConfigFileReader.getProperty("Email-Subject");

        // Getting system properties
        Properties properties = new Properties();

        // Setting up mail server
        properties.put("mail.smtp.auth", false);
        properties.setProperty("mail.smtp.host", smtpHost);
        properties.setProperty("mail.smtp.port", smtpPort);

        // creating session object to get properties
        Session session = Session.getDefaultInstance(properties);

        try {
            // MimeMessage object.
            MimeMessage message = new MimeMessage(session);

            // Set From Field: adding senders email to from field.
            message.setFrom(new InternetAddress(fromEmail));

            // Set To Field: adding recipient's email to from field.
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));

            // Set Subject: subject of the email
            message.setSubject(emailSubject);

            // set body of the email.
            /** To add email body **/
            String emailBody = "Hi Team, <br><br> Please find the attachment for automation execution report<br> <br>Automation Team";
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent(emailBody, "text/html");

            /** To add attachment **/
            String htmlReportPath = "";
            MimeBodyPart attachmentPart = new MimeBodyPart();
            String reportPath = fetchReportPath();
            attachmentPart.attachFile(reportPath + "/" + ExtentPropertiesReader.getProperty("SparkReport.html"));
            attachmentPart.attachFile(reportPath + "/" + ExtentPropertiesReader.getProperty("ExtentHtmlReport.html"));
            attachmentPart.attachFile(reportPath + "/" + ExtentPropertiesReader.getProperty("ExtentPdfReport.pdf"));

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            multipart.addBodyPart(attachmentPart);

            // sets the multi-part as e-mail's content
            message.setContent(multipart);

            // Send email.
            Transport.send(message);
            System.out.println("Email successfully sent");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public static String fetchReportPath() throws Exception {
        String reportBasePath = System.getProperty("user.dir") + "/Reports";
        String reportFolderName = "";
        try {
            //Reports path
            File directoryPath = new File(System.getProperty("user.dir") + "/Reports");

            //Get all report folders
            String contents[] = directoryPath.list();

            //To fetch date and time stamp of the report
            List<String> reportDateAndTimeStampString = Arrays.asList(contents)
                    .stream()
                    .map(str -> str.substring(str.lastIndexOf("_") + 1).trim())
                    .collect(Collectors.toList());

            //To covert date string to date
            SimpleDateFormat dateFormat = new SimpleDateFormat(ExtentPropertiesReader.getProperty("basefolder.datetimepattern"));
            List<Date> reportDateAndTimeStamp = new ArrayList<>();
            for (String dateString : reportDateAndTimeStampString)
                reportDateAndTimeStamp.add(dateFormat.parse(dateString));


            //Sort and get latest report time stamp
            Collections.sort(reportDateAndTimeStamp, new DateComparator());
            String latestReportDateAndTimeStamp = dateFormat.format(reportDateAndTimeStamp.get(0));

            reportFolderName = reportBasePath + "/" + Arrays.stream(contents)
                    .filter(str -> str.contains(latestReportDateAndTimeStamp))
                    .findAny()
                    .orElse(null);

            System.out.println(reportFolderName);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return reportFolderName;
    }

    public static void main(String[] args) throws Exception {
        fetchReportPath();
    }

}
