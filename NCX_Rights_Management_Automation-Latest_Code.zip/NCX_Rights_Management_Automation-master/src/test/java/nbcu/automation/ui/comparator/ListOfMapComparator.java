package nbcu.automation.ui.comparator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Map;

public class ListOfMapComparator implements Comparator<Map<String, String>>{
	SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

	@Override
	public int compare(Map<String, String> map1, Map<String, String> map2) {
		// TODO Auto-generated method stub
		try {
			return format.parse(map2.get("Start Date")).compareTo(format.parse(map1.get("Start Date")));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.fillInStackTrace();
		}
		return 0;
	}

}
