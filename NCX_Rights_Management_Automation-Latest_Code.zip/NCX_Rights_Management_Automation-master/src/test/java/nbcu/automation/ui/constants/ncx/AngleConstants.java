package nbcu.automation.ui.constants.ncx;

import java.util.HashMap;

public class AngleConstants {

    private static final ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
        @Override
        protected HashMap<String, Object> initialValue() {
            return new HashMap<>();
        }
    };

    //To remove angle constants
    public static void init() {
        constantMap.get().clear();
        constantMap.remove();
    }


    //To get and set Angle Search Keyword
    public static String getSearchKeyword() {
        return (String) constantMap.get().get("Search Keyword");
    }

    public static void setSearchKeyword(String angleKeyword) {
        constantMap.get().put("Search Keyword", angleKeyword);
    }

    //To get and set Angle ID
    public static String getAngleID(String angleNumber) {
        return (String) constantMap.get().get("Angle ID_"+angleNumber);
    }

    public static void setAngleID(String angleID) {
        constantMap.get().put("Angle ID_"+getAngleCount(), angleID);
    }

    // To set and get angle count
    public static String getAngleCount() {
        return (String) constantMap.get().get("Angle Count");
    }

    public static void setAngleCount(String angleCount) {
        constantMap.get().put("Angle Count", angleCount);
    }

    // To get and set Angle name
    public static String getAngleTitle(String angleNumber) {
        return (String) constantMap.get().get("Angle Title_" + angleNumber);
    }

    public static void setAngleTitle(String angleTitle) {
        constantMap.get().put("Angle Title_" + getAngleCount(), angleTitle);

    }

    // To get and set Story Team Member name
    public static String getCollaboratorName(int memberNumber) {
        return (String) constantMap.get().get("Team Member_" + memberNumber);
    }

    public static void setCollaboratorName(int memberNumber, String teamMembers) {
        constantMap.get().put("Team Member_" + memberNumber, teamMembers);
    }

    // To get and set Story Team Member count
    public static String getCollaboratorCount() {
        return (String) constantMap.get().get("Team Member Count");
    }

    public static void setCollaboratorCount(String memberCount) {
        constantMap.get().put("Team Member Count", memberCount);
    }

    // To get and set Angle description
    public static String getAngleDescription(String angleNumber) {
        return (String) constantMap.get().get("Angle Description_" + angleNumber);
    }

    public static void setAngleDescription(String angleDescription) {
        constantMap.get().put("Angle Description_" + getAngleCount(), angleDescription);
    }

    // To get and set angle creator first name
    public static String getAngleCreatorFirstName(String angleNumber) {
        return (String) constantMap.get().get("Angle Creator First Name_" + angleNumber);
    }

    public static void setAngleCreatorFirstName(String firstName) {
        constantMap.get().put("Angle Creator First Name_" + getAngleCount(), firstName);
    }

    // To get and set angle creator last name
    public static String getAngleCreatorLastName(String angleNumber) {
        return (String) constantMap.get().get("Angle Creator Last Name_" + angleNumber);
    }

    public static void setAngleCreatorLastName(String lastName) {
        constantMap.get().put("Angle Creator Last Name_" + getAngleCount(), lastName);
    }

    // To get and set Angle creation time
    public static String getAngleCreationTime(String angleNumber) {
        return (String) constantMap.get().get("Angle Creation Time_" + angleNumber);
    }

    public static void setAngleCreationTime(String creationTime) {
        constantMap.get().put("Angle Creation Time_" + getAngleCount(), creationTime);
    }

    // To get and set Angle creation date
    public static String getAngleCreationDate(String angleNumber) {
        return (String) constantMap.get().get("Angle Creation Date_" + angleNumber);
    }

    public static void setAngleCreationDate(String creationDate) {
        constantMap.get().put("Angle Creation Date_" + getAngleCount(), creationDate);
    }

    //To get and set Angle filter name
    public static void setFilterAuthorName(String name) {
        constantMap.get().put("Filter Author Name", name);
    }

    public static String getFilterAuthorName() {
        return (String) constantMap.get().get("Filter Author Name");
    }

}
