package nbcu.automation.ui.constants.ncx;

import java.util.HashMap;
import java.util.List;

public class SearchConstants {

    private static final ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
        @Override
        protected HashMap<String, Object> initialValue() {
            return new HashMap<>();
        }
    };

    //To remove angle constants
    public static void init() {
        constantMap.get().clear();
        constantMap.remove();
    }

    // To get and set search text
    public static List<String> getSearchText() {
        return (List<String>) constantMap.get().get("Search Text");
    }

    public static void setSearchText(List<String> searchText) {
        constantMap.get().put("Search Text", searchText);
    }

}
