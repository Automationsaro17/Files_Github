package nbcu.automation.ui.constants.ncx;

import lombok.Builder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StoryConstants {

    private static ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
        @Override
        protected HashMap<String, Object> initialValue() {
            return new HashMap<>();
        }
    };

    public static void init() {
        constantMap.get().clear();
        constantMap.remove();
    }

    // To get and set role
    public static String getUserRole() {
        return (String) constantMap.get().get("User Role");
    }

    public static void setUserRole(String role) {
        constantMap.get().put("User Role", role);
    }

    // To set and get story count
    public static String getStoryCount() {
        return (String) constantMap.get().get("Story Count");
    }

    public static void setStoryCount(String storyCount) {
        constantMap.get().put("Story Count", storyCount);
    }

    // To get and set story type
    public static String getStoryStatus() {
        return (String) constantMap.get().get("Story Type");
    }

    public static void setStoryStatus(String storyType) {
        constantMap.get().put("Story Type", storyType);
    }

    // To get and set story privacy
    public static String getStoryPrivacy() {
        return (String) constantMap.get().get("Story Privacy");
    }

    public static void setStoryPrivacy(String storyPrivacy) {
        constantMap.get().put("Story Privacy", storyPrivacy);
    }

    // To get and set story name
    public static String getStoryTitle(String storyNumber) {
        return (String) constantMap.get().get("Story Title_" + storyNumber);
    }

    public static void setStoryTitle(String storyTitle) {
        constantMap.get().put("Story Title_" + getStoryCount(), storyTitle);
    }

    // To get and set story id
    public static String getStoryId(String storyNumber) {
        return (String) constantMap.get().get("Story Id_" + storyNumber);
    }

    public static void setStoryId(String storyId) {
        constantMap.get().put("Story Id_" + getStoryCount(), storyId);
    }

    // To get and set subject
    public static String getStorySubject(String storyNumber) {
        return (String) constantMap.get().get("Story Subject_" + storyNumber);
    }

    public static void setStorySubject(String storySubject) {
        constantMap.get().put("Story Subject_" + getStoryCount(), storySubject);
    }

    // To get and set subject code
    public static String getStorySubjectCode(String storyNumber) {
        return (String) constantMap.get().get("Story Subject Code_" + storyNumber);
    }

    public static void setStorySubjectCode(String storySubjectCode) {
        constantMap.get().put("Story Subject Code_" + getStoryCount(), storySubjectCode);
    }

    // To get and set story description
    public static String getStoryDescription(String storyNumber) {
        return (String) constantMap.get().get("Story Description_" + storyNumber);
    }

    public static void setStoryDescription(String storyDescription) {
        constantMap.get().put("Story Description_" + getStoryCount(), storyDescription);
    }

    // To get and set story topic count
    public static int getStoryTopicCount() {
        return (int) constantMap.get().get("Story Topic Count");
    }

    public static void setStoryTopicCount(int topicNumber) {
        constantMap.get().put("Story Topic Count", topicNumber);
    }

    // To get and set story topic code
    public static String getStoryTopicCode() {
        return (String) constantMap.get().get("Story Topic Code");
    }

    public static void setStoryTopicCode(String topicCode) {
        constantMap.get().put("Story Topic Code", topicCode);
    }

    // To get and set story topic
    public static String getStoryTopic(int topicNumber) {
        return (String) constantMap.get().get("Story Topic_" + topicNumber);
    }

    public static void setStoryTopic(int topicNumber, String topic) {
        constantMap.get().put("Story Topic_" + topicNumber, topic);
    }

    // To get and set story tag count
    public static int getStoryTagCount(int storyNumber) {
        return (int) constantMap.get().get("Story Tag Count_"+storyNumber);
    }

    public static void setStoryTagCount(int tagNumber) {
        constantMap.get().put("Story Tag Count_"+getStoryCount(), tagNumber);
    }

    // To get and set story tag
    public static String getStoryTag(int storyNumber, int tagNumber) {
        return (String) constantMap.get().get("Story Tag_" + storyNumber + "_" + tagNumber);
    }

    public static void setStoryTag(int tagNumber, String tag) {
        constantMap.get().put("Story Tag_" + getStoryCount() + "_" + tagNumber, tag);
    }

    // To get and set story tag count
    public static int getStorySlackChannelCount() {
        return (int) constantMap.get().get("Slack Channel Count");
    }

    public static void setStorySlackChannelCount(int slackChannelCount) {
        constantMap.get().put("Slack Channel Count", slackChannelCount);
    }

    // To get and set story slack channel
    public static String getStorySlackChannel(int slackNumber) {
        return (String) constantMap.get().get("Slack Channel_" + slackNumber);
    }

    public static void setStorySlackChannel(int slackNumber, String slackChannel) {
        constantMap.get().put("Slack Channel_" + slackNumber, slackChannel);
    }

    // To get and set draft story creation time
    public static String getDraftStoryCreationTime() {
        return (String) constantMap.get().get("Draft Story Creation Time");
    }

    public static void setDraftStoryCreationTime(String creationTime) {
        constantMap.get().put("Draft Story Creation Time", creationTime);
    }

    // To get and set draft story creation date
    public static String getDraftStoryCreationDate() {
        return (String) constantMap.get().get("Draft Story Creation Date");
    }

    public static void setDraftStoryCreationDate(String creationDate) {
        constantMap.get().put("Draft Story Creation Date", creationDate);
    }

    // To get and set story creation time
    public static String getStoryCreationTime(String storyCount) {
        return (String) constantMap.get().get("Story Creation Time_" + storyCount);
    }

    public static void setStoryCreationTime(String creationTime) {
        constantMap.get().put("Story Creation Time_" + getStoryCount(), creationTime);
    }

    // To get and set story creation date
    public static String getStoryCreationDate(String storyCount) {
        return (String) constantMap.get().get("Story Creation Date_" + storyCount);
    }

    public static void setStoryCreationDate(String creationDate) {
        constantMap.get().put("Story Creation Date_" + getStoryCount(), creationDate);
    }

    //To get and set Story search word/ID
    public static String getSearchKeyword() {
        return (String) constantMap.get().get("Search Keyword");
    }

    public static void setSearchKeyword(String storyKeyword) {
        constantMap.get().put("Search Keyword", storyKeyword);
    }

    // To get and set story tag count
    public static int getRankedPostTagsCount() {
        if (constantMap.get().containsKey("Ranked Post Tag Count"))
            return (int) constantMap.get().get("Ranked Post Tag Count");
        else return 0;
    }

    public static void setRankedPostTagsCount(int rankedPostTagCount) {
        constantMap.get().put("Ranked Post Tag Count", rankedPostTagCount);
    }

    // To get and set ranked story tags
    public static String getRankedPostTags(int tagNumber) {
        return (String) constantMap.get().get("Ranked Post Tag_" + tagNumber);
    }

    public static void setRankedPostTags(int tagNumber, String rankedStoryTag) {
        constantMap.get().put("Ranked Post Tag_" + tagNumber, rankedStoryTag);
    }

}
