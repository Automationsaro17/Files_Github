package nbcu.automation.ui.pages.ncx;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.AngleConstants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class AngleLandingPage {


    /**
     * Header elements
     */

    @FindBy(xpath = "//span[contains(text(),'Angle ID')]")
    WebElement angleIdElement;

    @FindBy(xpath = "//span[@nztype='eye-invisible']")
    WebElement angleInvisibleEyeIcon;

    @FindBy(xpath = "//div[@class='angle-title']")
    WebElement angleTitleElement;

    @FindBy(xpath = "//div[@class='angle-id']/following-sibling::div//span[@class='story-title']")
    WebElement linkedStoryLabel;

    @FindBy(xpath = "//a[@class='story-text']")
    WebElement linkedStoryName;

    @FindBy(xpath = "//span[text()='Linked Story:']/following-sibling::span")
    WebElement linkedStoryId;

    @FindBy(xpath = "//div[@class='angle-id']/following-sibling::div[contains(@class,'story-team')]/span[1]")
    WebElement collaboratorsLbl;

    @FindBy(xpath = "//span[@class='story-team-members']/button")
    List<WebElement> teamMembers;

    /**
     * Tab Elements
     */
    @FindBy(xpath = "//div[@role='tablist']//button[@role='tab' and text()='Overview']")
    WebElement overViewTab;

    @FindBy(xpath = "//div[@role='tablist']/div[2]/button[@role = 'tab' and text()='Material']")
    WebElement materialTab;

    @FindBy(xpath = "//div[@role='tablist']/div[3]/button[@role = 'tab' and text()='Log']")
    WebElement logsTab;


    /**
     * Overview Tab Elements
     */
    @FindBy(xpath = "//div[contains(@class,'overview')]/p")
    WebElement angleDescription;

    @FindBy(xpath = "//p[contains(@class,'ant-empty-description')]/span")
    WebElement privateAngleOverviewMessage;

    /**
     * Material tab Elements
     */
    @FindBy(xpath = "//div[span[normalize-space()='All']]")
    List<WebElement> allTab;

    @FindBy(xpath = "//div[span[normalize-space()='Elements']]")
    List<WebElement> elementsTab;

    @FindBy(xpath = "//div[span[normalize-space()='Standards']]")
    List<WebElement> standardsTab;

    @FindBy(xpath = "//*[contains(@class,'search-post')]/input")
    List<WebElement> searchTextBox;

    @FindBy(xpath = "//button[contains(@class,'filters')]")
    List<WebElement> filterIcon;

    /**
     * Post details elements
     */
    @FindBy(xpath = "//a[@class='title']")
    List<WebElement> postTitle;

    //All/Standards tab elements
    @FindBy(xpath = "//div[@class='created-updated']/button")
    List<WebElement> allTabPostModifiedBy;

    @FindBy(xpath = "//div[@class='created-updated']")
    List<WebElement> allTabPostModifiedDateAndTime;

    @FindBy(xpath = "//div[contains(@class,'description')]")
    List<WebElement> allTabPostDescription;

    @FindBy(xpath = "//*[@class='labels']")
    List<WebElement> allTabPostLabels;

    @FindBy(xpath = "//span[@class='count']")
    List<WebElement> allTabPostAttachmentCount;

    @FindBy(xpath = "//button[i[@nztype='share-alt']]")
    List<WebElement> allTabPostShareIcon;

    @FindBy(xpath = "//span[normalize-space()='Add to Angle']")
    List<WebElement> allTabAddToAngleIcon;


    //Elements tab elements
    @FindBy(xpath = "//div[@class='date-time']")
    List<WebElement> elementsTabPostModifiedDateAndTime;

    @FindBy(xpath = "//*[contains(@class,'tags')]")
    List<WebElement> elementsTabPostLabels;

    @FindBy(xpath = "//i[@nztype='ellipsis']")
    List<WebElement> elementsTabEllipsis;

    @FindBy(xpath = "//li[span[normalize-space()='Share']]")
    List<WebElement> elementsTabShareIcon;

    @FindBy(xpath = "//li[span[normalize-space()='Add to Angle']]")
    List<WebElement> elementsTabAddToAngleIcon;

    @FindBy(xpath = "//div[@class='details']/..//ul[contains(@class,'slick-dots')]/li")
    List<WebElement> elementsTabAttachmentCount;

    String moreThan2LabelXpath = "//button[@nzsize='small']/span[normalize-space()='+<<Count>>']";

    /**
     * Log tab elements
     */
    @FindBy(xpath = "//div[contains(@class,'ant-collapse-header')]")
    WebElement expandIcon;

    @FindBy(xpath = "//nz-collapse-panel[contains(@class,'angle-log-collapse')]/div[1]")
    WebElement angleLogDate;

    @FindBy(xpath = "//div[@class='post-angle']/span")
    List<WebElement> angleLogMessage;

    @FindBy(xpath = "//div[@class='post-angle']/span[1]")
    List<WebElement> postNameInLogMessage;

    @FindBy(xpath = "//div[@class='post-angle']/a")
    List<WebElement> postLinkInLogMessage;

    @FindBy(xpath = "//span[@class='user-name']")
    List<WebElement> angleCreatedOrUpdatedBy;

    @FindBy(xpath = "//span[@class='time']")
    List<WebElement> angleLogTime;

    /**
     * Angle page buttons
     */
    @FindBy(xpath = "//button[i[@nztype='delete']]//span[text()='Delete']")
    WebElement deleteAngleButton;

    @FindBy(xpath = "//button[span[text()='Add New']]")
    WebElement addNewElementButton;

    @FindBy(xpath = "//button[@id='test']//span[text()=' Edit ']")
    WebElement editAngleButton;

    public AngleLandingPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    public void verifyAngleLandingPageLoaded() throws Exception {
        try {
            Waits.waitForElement(linkedStoryName, Waits.WAIT_CONDITIONS.CLICKABLE);
            CommonValidations.verifyTextValue(angleTitleElement, WebAction.getWindowTitle(), "Page title is displayed as angle title");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify angle landing page header part
     *
     * @param sectionTxt - Angle Landing page each section area
     */

    public void verifyAnglePageHeader(String sectionTxt) throws Exception {
        try {
            switch (sectionTxt.toUpperCase().trim()) {
                case "ANGLE ID":
                    verifyAngleIDInLandingPage();
                    break;
                case "ANGLE TITLE":
                    verifyAngleTitleInLandingPage();
                    break;
                case "LINKED STORY", "ASSOCIATED STORY":
                    verifyLinkedStory();
                    break;
                case "COLLABORATORS":
                    verifyAngleCollaborators();
                    break;
                case "OVERVIEW DESCRIPTION":
                    verifyAngleOverView();
                    break;
                case "TABS":
                    verifyAngleTabs();
                    break;
                default:
                    Assert.fail("Please provide valid field name in angle landing page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify angle options
     *
     * @param visibility - Displayed/ Not Displayed
     * @param params     - EDIT/DELETE/ADD NEW
     */
    public void verifyAngleOptions(String visibility, DataTable params) {
        try {
            List<Map<String, String>> angleOptionsList = CucumberUtils.getValuesFromDataTableAsList(params);
            for (Map<String, String> stringStringMap : angleOptionsList) {
                String option = stringStringMap.get("Angle Option");
                switch (option.toUpperCase()) {
                    case "EDIT":
                        if (visibility.equalsIgnoreCase("DISPLAYED"))
                            CommonValidations.verifyElementIsEnabled(editAngleButton, "Edit angle button is not displayed in angle landing page");
                        else
                            Assert.assertFalse(WebAction.isDisplayed(editAngleButton), "Edit angle button is displayed in angle landing page");
                        break;
                    case "DELETE":
                        if (visibility.equalsIgnoreCase("DISPLAYED"))
                            CommonValidations.verifyElementIsEnabled(deleteAngleButton, "Delete angle button is not displayed in angle landing page");
                        else
                            Assert.assertFalse(WebAction.isDisplayed(deleteAngleButton), "Delete angle button is displayed in angle landing page");
                        break;
                    case "ADD NEW":
                        if (visibility.equalsIgnoreCase("DISPLAYED"))
                            CommonValidations.verifyElementIsEnabled(addNewElementButton, "Add new element button is not displayed in angle landing page");
                        else
                            Assert.assertFalse(WebAction.isDisplayed(addNewElementButton), "Add new element button is displayed in angle landing page");
                        break;
                    default:
                        Assert.fail("Given angle option '" + option + "' is not available. Please validate angle option in angle landing page");
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }

    }

    /**
     * To open overview/Material/Log tab
     *
     * @param tabName - Tab name
     * @throws Exception
     */
    public void openTabInAngleLandingPage(String tabName) throws Exception {
        try {
            if (tabName.equalsIgnoreCase("OVERVIEW"))
                WebAction.click(overViewTab);
            else if (tabName.equalsIgnoreCase("MATERIAL"))
                WebAction.click(materialTab);
            else if (tabName.equalsIgnoreCase("LOG"))
                WebAction.click(logsTab);
            else
                Assert.fail("Given tab name " + tabName + " is not found. Please provide valid tab name in angle landing page");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click Edit/Delete/Add New button
     *
     * @param buttonName - EDIT/DELETE/ADD NEW
     * @throws Exception
     */
    public void clickButton(String buttonName) throws Exception {
        try {
            if (buttonName.equalsIgnoreCase("EDIT"))
                WebAction.click(editAngleButton);
            else if (buttonName.equalsIgnoreCase("DELETE"))
                WebAction.click(deleteAngleButton);
            else if (buttonName.equalsIgnoreCase("ADD NEW"))
                WebAction.click(addNewElementButton);
            else Assert.fail("Given button name '" + buttonName + "' is not found. Please provide valid button name");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify Angle Log options in Landing page
     *
     * @param expectedLogMessage - expected log message
     * @throws Exception
     */
    public void verifyAngleCreationLog(String action, String expectedLogMessage) throws Exception {
        try {
            //Verify log expand icon
            CommonValidations.verifyAttributeValue(expandIcon, "aria-expanded", "true", "Angle logs are not expanded");

            //verify angle log date
            CommonValidations.verifyTextValue(angleLogDate, AngleConstants.getAngleCreationDate(AngleConstants.getAngleCount()), "Angle Log date is not correct in angle landing page");

            //verify angle creation/updated by user name
            CommonValidations.verifyTextValue(angleCreatedOrUpdatedBy.get(0), PostConstants.getDisplayName(), "Angle created by user name is not correct in angle landing page");

            //verify log time
            String expectedTime = "";
            if (action.equalsIgnoreCase("ADD NEW ELEMENT"))
                expectedTime = PostConstants.getPostCreationTime(PostConstants.getPostCount());
            else if (action.equalsIgnoreCase("REMOVE ELEMENT"))
                expectedTime = PostConstants.getPostModifiedTime(PostConstants.getPostCount());
            else expectedTime = AngleConstants.getAngleCreationTime(AngleConstants.getAngleCount());
            CommonValidations.verifyCreationTime(angleLogTime.get(0), expectedTime, "h:mm a", "Angle Log time is not correct in angle landing page");

            //verify log message
            CommonValidations.verifyTextValue(angleLogMessage.get(0), expectedLogMessage, "Angle log message is not correct in angle landing page");

            //verify post link/name
            if ((action.equalsIgnoreCase("ADD NEW ELEMENT")) || (action.equalsIgnoreCase("REMOVE ELEMENT")))
                CommonValidations.verifyTextValue(postLinkInLogMessage.get(0), PostConstants.getPostTitle(PostConstants.getPostCount()), "Post link is not displayed in log message");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify the user can collapse the container details in log page
     * <p>
     * throws Exception
     */

    public void collapseLog() throws Exception {
        try {
            WebAction.click(expandIcon);
            String className = WebAction.getAttribute(expandIcon.findElement(By.xpath("..")), "class");
            Assert.assertFalse(className.contains("active"), "Angle Log is not collaped in log tab of angle landing page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify angle id in the landing page
     *
     * @throws Exception
     */
    public void verifyAngleIDInLandingPage() throws Exception {
        try {
            String currentUrl = WebAction.getCurrentUrl();
            String expectedAngleId = currentUrl.split("/:")[1].trim();
            String actualAngleId = WebAction.getText(angleIdElement).trim().split("#")[1].trim();
            AngleConstants.setAngleID(actualAngleId);
            Assert.assertEquals(actualAngleId, expectedAngleId, "Angle id is not correct in angle landing page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify invisible eye icon
     *
     * @param visibility - NOT DISPLAYED/DISPLAYED
     */
    public void verifyInvisibleEyeIcon(String visibility, String anglePrivacy) {
        try {
            if (visibility.equalsIgnoreCase("NOT DISPLAYED"))
                Assert.assertFalse(WebAction.isDisplayed(angleInvisibleEyeIcon), "Invisible eye icon is not displayed for " + anglePrivacy + " angle in angle landing page");
            else
                Assert.assertTrue(WebAction.isDisplayed(angleInvisibleEyeIcon), "Invisible eye icon is displayed for " + anglePrivacy + " angle in angle landing page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify angle title
     */
    public void verifyAngleTitleInLandingPage() {
        try {
            CommonValidations.verifyTextValue(angleTitleElement, AngleConstants.getAngleTitle(AngleConstants.getAngleCount()), "Angle title is not correct in angle landing page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify linked story in angle landing page
     */
    public void verifyLinkedStory() {
        try {
            CommonValidations.verifyTextValue(linkedStoryLabel, "Linked Story", "Linked Story label is not found");
            CommonValidations.verifyTextValue(linkedStoryName, StoryConstants.getStoryTitle(StoryConstants.getStoryCount()), "Linked Story name is not displayed in angle landing page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story id displayed in linked story field of angle landing page
     */
    public void verifyLinkedStoryId() {
        try {
            CommonValidations.verifyTextValue(linkedStoryLabel, "Linked Story", "Linked Story label is not found");
            CommonValidations.verifyTextValue(linkedStoryId, StoryConstants.getStoryId(StoryConstants.getStoryCount()), "Linked Story id is not displayed in angle landing page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify angle Collaborators
     */
    public void verifyAngleCollaborators() {
        try {
            CommonValidations.verifyTextValue(collaboratorsLbl, "Collaborators:", "Unable to find Story team members");
            CommonValidations.verifyIntegerValues(teamMembers.size(), Integer.parseInt(AngleConstants.getCollaboratorCount()), "Angle team members size is not correct");

            //Forming expected member list
            List<String> expectedMembersList = new ArrayList<>();
            expectedMembersList.add(AngleConstants.getAngleCreatorFirstName(AngleConstants.getAngleCount()).charAt(0) + ". " + AngleConstants.getAngleCreatorLastName(AngleConstants.getAngleCount()));
            for (int i = 1; i < Integer.parseInt(AngleConstants.getCollaboratorCount()); i++) {
                String[] firstAndLastName = AngleConstants.getCollaboratorName(i).split(" ");
                String memberName = firstAndLastName[0].charAt(0) + ". " + firstAndLastName[firstAndLastName.length - 1].trim();
                expectedMembersList.add(memberName);
            }

            //Forming actual member list
            List<String> actualMembersList = new ArrayList<>();
            for (WebElement element : teamMembers)
                actualMembersList.add(WebAction.getText(element));

            Assert.assertEquals(actualMembersList, expectedMembersList, "Angle team members list is not correct in angle landing page headers");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify angle overview/description
     */
    public void verifyAngleOverView() {
        try {
            CommonValidations.verifyTextValue(overViewTab, "Overview", "Angle overview tab is not displayed in angle landing page");
            CommonValidations.verifyTextValue(angleDescription, AngleConstants.getAngleDescription(AngleConstants.getAngleCount()), "Angle description is not correct in overview of angle landing page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify private angle is not accessible message in overview section for user who do not have access
     *
     * @param privateAngleMessage - Angle not accessible message
     */
    public void verifyAngleOverviewForPrivateAngle(String privateAngleMessage) {
        try {
            CommonValidations.verifyTextValue(privateAngleOverviewMessage, privateAngleMessage, "Private angle is not accessible message is not displayed");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify tabs in angle landing page
     */
    public void verifyAngleTabs() {
        try {
            CommonValidations.verifyTextValue(overViewTab, "OVERVIEW", "Overview tab is not displayed in angle landing page");
            CommonValidations.verifyTextValue(materialTab, "MATERIAL", "Material tab is not displayed in angle landing page");
            CommonValidations.verifyTextValue(logsTab, "LOG", "Log tab is not displayed in angle landing page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify private angle material and logs are disabled for user who do not have access
     */
    public void verifyMaterialAndLogTabsDisabled() {
        try {
            CommonValidations.verifyAttributeValue(materialTab, "aria-disabled", "true", "Private angle material tab is enabled in angle landing page for user who do not have access");
            CommonValidations.verifyAttributeValue(logsTab, "aria-disabled", "true", "Private angle material tab is enabled in angle landing page for user who do not have access");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    public void verifyAngleDetailPage() throws Exception {
        try {
            boolean isDisplayed = WebAction.isDisplayed(angleIdElement);
            if (isDisplayed) {
                Assert.assertTrue(isDisplayed, "Angle ID is displayed in the angle listing page");
                int currentWindowSize = WebAction.getWindowsSize();
                WebAction.click(angleIdElement);
                WebAction.switchToNewWindow(currentWindowSize + 1);
                Waits.waitForElement(angleDescription, Waits.WAIT_CONDITIONS.VISIBLE);
            } else
                Assert.assertFalse(true, "Failed to display the Angle modal in the anlge listing page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    public void verifyButtonsInAngleOverviewFooterPart(String userRole, DataTable params) {
        try {
            switch (userRole.toUpperCase().trim()) {
                case "EDITOR": {
                    //List<Map<String, String>> btns = CucumberUtils.getValuesFromDataTableAsList(params);
                    Waits.waitForElement(angleDescription, Waits.WAIT_CONDITIONS.VISIBLE);
                    boolean isDeleteBtnDisplayed = WebAction.isDisplayed(deleteAngleButton);
                    //boolean isAddNewBtnDisplayed = WebAction.isDisplayed(addNewElemtBtn);
                    boolean isEditTnDisplayed = WebAction.isDisplayed(editAngleButton);
                    if (!isDeleteBtnDisplayed && !isEditTnDisplayed) {
                        Assert.assertTrue(true, "Angle overview page not displayed the buttonin sticky footer section");
                    } else Assert.assertFalse(true,
                            "Angle overview page displayed the buttons like Edit, Delete & Add new Element");
                }
                break;

                case "READ ONLY": {
                    // List<Map<String, String>> btns = CucumberUtils.getValuesFromDataTableAsList(params);
                    Waits.waitForElement(angleDescription, Waits.WAIT_CONDITIONS.VISIBLE);
                    boolean isDeleteBtnDisplayed = WebAction.isDisplayed(deleteAngleButton);
                    boolean isAddNewBtnDisplayed = WebAction.isDisplayed(addNewElementButton);
                    boolean isEditTnDisplayed = WebAction.isDisplayed(editAngleButton);
                    if (!isDeleteBtnDisplayed && !isAddNewBtnDisplayed && !isEditTnDisplayed) {
                        Assert.assertTrue(true, "Angle overview page not displayed the buttonin sticky footer section");
                    } else Assert.assertFalse(true,
                            "Angle overview page displayed the buttons like Edit, Delete & Add new Element");
                }
                break;
                default:
                    Assert.assertFalse(true, userRole + " not matched with the logged in user credentials");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
        }
    }

    /**
     * To verify Material tab is loaded in angle landing page
     *
     * @throws Exception
     */
    public void verifyMaterialTabLoaded() throws Exception {
        try {
            Waits.waitForElement(allTab.get(0), Waits.WAIT_CONDITIONS.CLICKABLE);
            CommonValidations.verifyElementIsEnabled(allTab.get(0), "All tab is not displayed in material tab");
            CommonValidations.verifyElementIsEnabled(elementsTab.get(0), "Elements tab is not displayed in material tab");
            CommonValidations.verifyElementIsEnabled(standardsTab.get(0), "Standards tab is not displayed in material tab");
            CommonValidations.verifyElementIsEnabled(searchTextBox.get(0), "Post search text box is not displayed in material tab");
            CommonValidations.verifyElementIsEnabled(filterIcon.get(0), "Filter icon is not displayed in material tab");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To open tab of material view
     *
     * @param tabName - Tab Name
     */
    public void openTabInMaterialView(String tabName) throws Exception {
        try {
            if (tabName.equalsIgnoreCase("ALL"))
                WebAction.click(allTab.get(0));
            else if (tabName.equalsIgnoreCase("ELEMENTS"))
                WebAction.click(elementsTab.get(0));
            else if (tabName.equalsIgnoreCase("STANDARDS"))
                WebAction.click(standardsTab.get(0));
            else Assert.fail("Please provide valid tab name");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Verify Post detailed in ALL/Standards tab
     *
     * @param tabName         - Tab Name - ALL/STANDARDS
     * @param landingPageName - Landing Page Name
     */
    public void verifyPostDisplayedInAllAndStandardsTab(String tabName, String landingPageName) throws Exception {
        try {
            Waits.waitUntilElementSizeGreater(postTitle, 0);
            //Verify post Title
            CommonValidations.verifyTextValue(postTitle.get(0), PostConstants.getPostTitle(PostConstants.getPostCount()), "Post title is not correct in " + tabName + " tab of " + landingPageName + " landing page");

            //Verify post Description
            CommonValidations.verifyTextValue(allTabPostDescription.get(0), PostConstants.getPostDescription(PostConstants.getPostCount()), "Post description is not correct in " + tabName + " tab of " + landingPageName + " landing page");

            //Verify post modified by
            String expectedCreatedBy = "";
            if (PostConstants.getDisplayName().split(",").length == 2)
                expectedCreatedBy = PostConstants.getDisplayName().split(",")[1].trim().charAt(0) + ". " + PostConstants.getDisplayName().split(",")[0].trim();
            else
                expectedCreatedBy = PostConstants.getDisplayName();

            CommonValidations.verifyTextValue(allTabPostModifiedBy.get(0), expectedCreatedBy, "Post created by is not correct in " + tabName + " tab of " + landingPageName + " landing page");

            //Verify post modified date and time
            CommonValidations.verifyTextValue(allTabPostModifiedDateAndTime.get(0), PostConstants.getPostCreationDate(PostConstants.getPostCount()), "Post creation date is not correct in " + tabName + " tab of " + landingPageName + " landing page");
            CommonValidations.verifyCreationTime(allTabPostModifiedDateAndTime.get(0), PostConstants.getPostCreationTime(PostConstants.getPostCount()), "h:mm a", "Post creation time is not correct in " + tabName + " tab of " + landingPageName + " landing page");

            //Verify post labels
            verifyLabels(tabName, landingPageName, allTabPostLabels);

            //Verify attachment count
            CommonValidations.verifyTextValue(allTabPostAttachmentCount.get(0), PostConstants.getAttachmentCount(), "Post attachment count is not correct in " + tabName + " tab of " + landingPageName + " landing page");

            //Verify share icon
            CommonValidations.verifyElementIsEnabled(allTabPostShareIcon.get(0), "Post share icon is not displayed in " + tabName + " tab of " + landingPageName + " landing page");

            //Verify add to angle icon
            if (landingPageName.equalsIgnoreCase("STORY"))
                CommonValidations.verifyElementIsEnabled(allTabAddToAngleIcon.get(0), "Add to angle icon is not displayed in " + tabName + " tab of " + landingPageName + " landing page");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * To verify post is displayed in elements tab
     *
     * @param tabName         - Tab Name
     * @param landingPageName - Landing Page Name
     */
    public void verifyPostDisplayedInElementsTab(String tabName, String landingPageName) throws Exception {
        try {
            Waits.waitUntilElementSizeGreater(postTitle, 0);
            //Verify post Title
            CommonValidations.verifyTextValue(postTitle.get(0), PostConstants.getPostTitle(PostConstants.getPostCount()), "Post title is not correct in " + tabName + " tab of " + landingPageName + " landing page");

            //Verify post modified date and time
            CommonValidations.verifyTextValue(elementsTabPostModifiedDateAndTime.get(0), PostConstants.getPostCreationDate(PostConstants.getPostCount()), "Post creation date is not correct in " + tabName + " tab of " + landingPageName + " landing page");
            CommonValidations.verifyCreationTime(elementsTabPostModifiedDateAndTime.get(0), PostConstants.getPostCreationTime(PostConstants.getPostCount()), "h:mm a", "Post creation time is not correct in " + tabName + " tab of " + landingPageName + " landing page");

            //Verify post labels
            verifyLabels(tabName, landingPageName, elementsTabPostLabels);

            //Verify attachment count
            if (Integer.parseInt(PostConstants.getAttachmentCount()) > 1)
                Assert.assertEquals(elementsTabAttachmentCount.size(), Integer.parseInt(PostConstants.getAttachmentCount()), "Post attachment count is not correct in " + tabName + " tab of " + landingPageName + " landing page");

            //Verify share and add to angle icon
            WebAction.click(elementsTabEllipsis.get(0));
            Waits.waitForElement(elementsTabShareIcon.get(0), Waits.WAIT_CONDITIONS.CLICKABLE);
            CommonValidations.verifyElementIsEnabled(elementsTabShareIcon.get(0), "Post share icon is not displayed in " + tabName + " tab of " + landingPageName + " landing page");
            if (landingPageName.equalsIgnoreCase("STORY"))
                CommonValidations.verifyElementIsEnabled(elementsTabAddToAngleIcon.get(0), "Post add to angle icon is not displayed in " + tabName + " tab of " + landingPageName + " landing page");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify labels in material tab of angle landing page
     */
    public void verifyLabels(String tabName, String landingPageName, List<WebElement> postLabels) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            List<String> actualLabels = new ArrayList<>();
            List<String> expectedLabels = new ArrayList<>();

            // To click on +1/+2 to check labels in elements tab
            int totalLabelsCount = 0;
            if (tabName.equalsIgnoreCase("ELEMENTS")) {
                if (PostConstants.getStandardsLabelsCount() != null)
                    totalLabelsCount = totalLabelsCount + Integer.parseInt(PostConstants.getStandardsLabelsCount());
                if (PostConstants.getLegalLabelsCount() != null)
                    totalLabelsCount = totalLabelsCount + Integer.parseInt(PostConstants.getLegalLabelsCount());

                if (totalLabelsCount > 2) {
                    assert driver != null;
                    WebAction.click(driver.findElement(By.xpath(moreThan2LabelXpath.replace("<<Count>>", String.valueOf(totalLabelsCount - 2)))));
                }
            }

            List<WebElement> postLabelElements = postLabels.get(postLabels.size() - 1).findElements(By.xpath("//nz-tag"));
            //Forming actual list of labels
            for (int i = 0; i < postLabelElements.size(); i++)
                actualLabels.add(WebAction.getText(postLabelElements.get(i)));
            Collections.sort(actualLabels);

            //Forming expected list of labels
            if (PostConstants.getStandardsLabelsCount() != null) {
                for (int i = 0; i < Integer.parseInt(PostConstants.getStandardsLabelsCount()); i++)
                    expectedLabels.add(PostConstants.getStandardsLabel(i));
            }

            if (PostConstants.getLegalLabelsCount() != null) {
                for (int i = 0; i < Integer.parseInt(PostConstants.getLegalLabelsCount()); i++)
                    expectedLabels.add(PostConstants.getLegalLabel(i));
            }
            Collections.sort(expectedLabels);

            if (actualLabels.size() == expectedLabels.size()) {
                expectedLabels.removeAll(actualLabels);
                Assert.assertTrue(expectedLabels.isEmpty(), "'" + expectedLabels + "' labels are missing in " + tabName + " tab of " + landingPageName + " landing page");
            } else
                Assert.fail("labels are not matching in " + tabName + " tab of material view. Expected labels are '" + expectedLabels + "' and actual labels are '" + actualLabels + "'");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }
}
