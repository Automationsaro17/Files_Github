package nbcu.automation.ui.pages.ncx;

import com.aventstack.extentreports.Status;
import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.AngleConstants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.others.CommonUtils;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.report.ExtentReportUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;
import java.util.Map;

public class CreateAnglePage {

    /**
     * Main Content Elements
     **/

    @FindBy(xpath = "//div[@class='angle-title']/input")
    WebElement angleTitleTextBox;

    @FindBy(xpath = "//div[contains(@class,'fr-element fr-view fr-element')]")
    WebElement angleDescriptionTextBox;

    @FindBy(xpath = "//div[normalize-space()='Privacy']/i[@nztype='question-circle']")
    WebElement anglePrivacyToolTip;

    @FindBy(xpath = "//nz-select-item[@class='ant-select-selection-item ng-star-inserted']")
    WebElement anglePrivacyDropDown;

    @FindBy(xpath = "//div[@class='privacy-icon-text']/button/i")
    WebElement anglePrivacyEyeIcon;

    @FindBy(xpath = "//input[@placeholder='Search Story Name']")
    WebElement addStoryTextBox;

    @FindBy(xpath = "//input[@placeholder='Search Story Name']")
    WebElement storyNameField;

    @FindBy(xpath = "//button[span[@nztype='delete']]")
    WebElement storyDeleteIcon;

    String searchDropDownValuesXpath = "//nz-auto-option[contains(@class,'ant-select-item ant-select-item-option')]/div";

    @FindBy(xpath = "//nz-option-item[contains(@class,'ant-select-item ant-select-item-option')]")
    List<WebElement> dropDownvalues;

    // Drop down value xpath
    String dropDownValuesXpath = "//nz-option-item[contains(@class,'ant-select-item ant-select-item-option')]";

    /**
     * Buttons Element
     */
    @FindBy(xpath = "//button[span[normalize-space()='Publish']]")
    WebElement publishButton;

    @FindBy(xpath = "//button[span[normalize-space()='Cancel']]")
    WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@class,'mandatory-text')]")
    WebElement inlineError;

    @FindBy(xpath = "//div[contains(@class,'mandatory-text')]/span")
    WebElement inlineErrorText;

    @FindBy(xpath = "//nz-input-group[@class='ant-input-affix-wrapper']/input")
    WebElement searchCollaboratorsTextBox;

    @FindBy(xpath = "//div[contains(@class,'ant-select-item-option')]")
    WebElement storySuggestionList;

    @FindBy(xpath = "//div[@class='link-story']/following-sibling::div")
    WebElement linkedStorySection;

    @FindBy(xpath = "//span[@class='story-text']/div")
    WebElement linkedStoryNameWithId;

    @FindBy(xpath = "//span[@nztype='delete']")
    WebElement deleteStoryMember;

    @FindBy(xpath = "//div[@class='name']")
    WebElement deletedStoryMemberName;

    @FindBy(xpath = "//input[@placeholder='Search for Collaborators']")
    WebElement collaborateField;

    @FindBy(xpath = "//span[@class='story-team-details']/div[@class='name']")
    List<WebElement> collaboratorsNameList;

    @FindBy(xpath = "//span[@class='story-team-delete']/span[@nztype='delete']")
    List<WebElement> collaboratorsDeleteIconList;

    @FindBy(xpath = "//span[@class='story-gap']")
    WebElement profileCard;

    @FindBy(xpath = "//span[@class='story-gap']//div[@class='name']")
    WebElement userDisplayName;

    @FindBy(xpath = "//span[@nztype='info-circle']/following-sibling::span")
    WebElement toastMessageElement;

    public CreateAnglePage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify create angle page is loaded
     */
    public void verifyCreateAnglePageLoaded(String action) throws Exception {
        try {
            Waits.waitForElement(angleTitleTextBox, WAIT_CONDITIONS.CLICKABLE);
            Waits.waitForElement(publishButton, WAIT_CONDITIONS.CLICKABLE);

            if (action.equalsIgnoreCase("CREATE")) {
                if (AngleConstants.getAngleCount() == null)
                    AngleConstants.setAngleCount("1");
                else AngleConstants.setAngleCount(String.valueOf(Integer.parseInt(AngleConstants.getAngleCount()) + 1));

                AngleConstants.setAngleCreatorFirstName(PostConstants.getFirstName());
                AngleConstants.setAngleCreatorLastName(PostConstants.getLastName());
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill angle title
     *
     * @param action     - fills/updates
     * @param angleTitle - angle title. 12 digits random alphanumeric string will be
     *                   appended in the end for automation purpose
     */
    public void fillAngleTitle(String action, String angleTitle) throws Exception {
        try {
            if (action.equalsIgnoreCase("UPDATES"))
                Waits.waitUntilAttributeValueContains(angleTitleTextBox, "value", AngleConstants.getAngleTitle(AngleConstants.getAngleCount()));
            angleTitle = angleTitle + "_" + CommonUtils.generateRandomString(12);
            ExtentReportUtils.addLog(Status.INFO, "Angle Title: <b>" + angleTitle + "</b>");
            AngleConstants.setAngleTitle(angleTitle);
            WebAction.clearUsingKeys(angleTitleTextBox);
            WebAction.sendKeys(angleTitleTextBox, angleTitle);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill angle description
     *
     * @param action           - fills/updates
     * @param angleDescription - Angle description
     */
    public void fillAngleDescription(String action, String angleDescription) throws Exception {
        try {
            if (action.equalsIgnoreCase("UPDATES"))
                Waits.waitUntilTextValueChanges(angleDescriptionTextBox, AngleConstants.getAngleDescription(AngleConstants.getAngleCount()));
            AngleConstants.setAngleDescription(angleDescription);
            WebAction.sendKeys(angleDescriptionTextBox, angleDescription);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To select angle privacy
     *
     * @param anglePrivacy - Angle Privacy - public/private
     */
    public void selectAnglePrivacy(String anglePrivacy) throws Exception {
        try {
            WebAction.scrollIntoView(anglePrivacyDropDown);
            WebAction.clickUsingJs(anglePrivacyDropDown);
            WebAction.nonEnterableSelectDropDown(dropDownValuesXpath, anglePrivacy, anglePrivacy + " is not present in the angle privacy drop down");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify eye icon of angle privacy
     *
     * @param visibility - Visible/Invisible
     */
    public void verifyEyeIcon(String visibility) throws Exception {
        try {
            if (visibility.equalsIgnoreCase("INVISIBLE"))
                CommonValidations.verifyAttributeValue(anglePrivacyEyeIcon, "class", "anticon anticon-eye-invisible", "Invisible eye icon is not displayed when private privacy is selected");
            else
                CommonValidations.verifyAttributeValue(anglePrivacyEyeIcon, "class", "anticon anticon-eye", "Visible eye icon is not displayed when public privacy is selected");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify search Collaborators name field
     */
    public void verifySearchCollaboratorsField() throws Exception {
        try {
            WebAction.scrollIntoView(collaborateField);
            Assert.assertTrue(WebAction.isDisplayed(collaborateField), "Collaborators Search field is missing in create/edit angle page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Verify default Collaborators details
     */
    public void verifyDefaultCollaborator() {
        try {
            AngleConstants.setCollaboratorCount("1");
            AngleConstants.setCollaboratorName(0, WebAction.getText(collaboratorsNameList.get(0)));
            Assert.assertFalse(collaboratorsNameList.isEmpty(), "Default Collaborators is not displayed");
            CommonValidations.verifyTextValue(collaboratorsNameList.get(0), PostConstants.getFirstName() + " " + PostConstants.getLastName(), "Default Collaborator name is not correct in create angle page");
            Assert.assertTrue(collaboratorsDeleteIconList.isEmpty(), "Delete icon is displayed for default Collaborators");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To enter Story name in Angle creation page & re-enter the same story in Angle
     * update page
     */

    public void searchAndSelectStory() throws Exception {
        try {
            String storyName = StoryConstants.getStoryTitle(StoryConstants.getStoryCount());
            WebAction.selectNonTitleDropDown(addStoryTextBox, storyName, searchDropDownValuesXpath,
                    storyName + " is not present in the add to story search result");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To add collaborators to the angle
     */
    public void addCollaborators(DataTable dataTable) throws Exception {
        try {
            WebAction.scrollIntoView(searchCollaboratorsTextBox);
            List<Map<String, String>> collaboratorsList = CucumberUtils.getValuesFromDataTableAsList(dataTable);
            for (int i = 0; i < collaboratorsList.size(); i++) {
                String memberName = collaboratorsList.get(i).get("Collaborators");
                WebAction.selectNonTitleDropDown(searchCollaboratorsTextBox, memberName, searchDropDownValuesXpath, memberName + " is not found in Collaborators search in create angle page");
                WebAction.click(anglePrivacyToolTip);
                AngleConstants.setCollaboratorName(i + Integer.parseInt(AngleConstants.getCollaboratorCount()), WebAction.getText(collaboratorsNameList.get(i + Integer.parseInt(AngleConstants.getCollaboratorCount()))));
            }

            AngleConstants.setCollaboratorCount(String.valueOf(collaboratorsList.size() + Integer.parseInt(AngleConstants.getCollaboratorCount())));
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    public void clickButton(String buttonName) throws Exception {
        try {
            switch (buttonName.toUpperCase()) {
                case "CANCEL":
                    WebAction.click(cancelButton);
                    break;
                case "PUBLISH":
                    WebAction.click(publishButton);
                    //AngleConstants.setAngleCreationTime(DateFunctions.getCurrentDate("h:mm:ss a")); ->9:38:23 AM
                    AngleConstants.setAngleCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                    AngleConstants.setAngleCreationDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    break;
                default:
                    Assert.fail("Please provide valid button name in create/edit story page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify the application linked stories in create/edit angle page
     */
    public void verifyLinkedStoryName() throws Exception {
        try {
            WebAction.scrollIntoView(linkedStorySection);
            PostConstants.setLinkedStoryCount(1);
            PostConstants.setLinkedStory(0, StoryConstants.getStoryTitle(StoryConstants.getStoryCount()));
            CommonValidations.verifyTextValue(linkedStoryNameWithId, StoryConstants.getStoryTitle(StoryConstants.getStoryCount()), "Linked story name is not displayed in create/edit angle page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify linked story id in create/edit angle page
     * @throws Exception
     */
    public void verifyLinkedStoryId() throws Exception {
        try {
            CommonValidations.verifyTextValue(linkedStoryNameWithId, StoryConstants.getStoryId(StoryConstants.getStoryCount()), "Linked story id is not displayed in create/edit angle page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To delete the associated linked story section
     *
     * @param expectedInlineMessage - Expected Inline message
     */
    public void deleteAssociatedStory(String expectedInlineMessage) throws Exception {
        try {
            WebAction.scrollIntoView(storyNameField);
            WebAction.click(storyDeleteIcon);
            CommonValidations.verifyTextValue(inlineError, "Story is required",
                    "Failed to display the inline error message after deleting the associated story");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To delete angle Collaborators
     */
    public void deleteStoryTeam() throws Exception {
        try {
            if (deleteStoryMember.isDisplayed()) {
                WebAction.click(deleteStoryMember);
                String removedStoryMember = WebAction.getText(deletedStoryMemberName).trim();
                String actualRemovedStoryMember = AngleConstants.getCollaboratorName(Integer.parseInt(AngleConstants.getCollaboratorCount()) - 1);
                if (!removedStoryMember.equalsIgnoreCase(actualRemovedStoryMember.trim())) {
                    System.out.println("Story team members removed from the Angle update page");
                } else
                    Assert.fail("Tema members not removed from the Angle update page");
            } else
                Assert.fail("Failed to display the delete icon in Story tema members");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    public void verifyLoginUserNameInCard(String ncxRole) {
        try {
            switch (ncxRole.toUpperCase()) {

                case "JOURNALIST":
                    boolean defaProfileCard = WebAction.isDisplayed(profileCard);
                    if (defaProfileCard) {
                        String JournalistName = PostConstants.getFirstName() + " " + PostConstants.getLastName();
                        String ActualName = WebAction.getText(userDisplayName).trim();
                        if (JournalistName.equalsIgnoreCase(ActualName)) {
                            System.out.println("Logged in Journalist profile name got matched in story profile card");
                        } else
                            Assert.fail("Failed to match the Journalist profile name in story team card");
                    } else
                        Assert.fail("Failed to display the Journalist profile card in story team section");
                    break;

                case "EDITOR":
                    boolean editorProfileCard = WebAction.isDisplayed(profileCard);
                    if (editorProfileCard) {
                        String EditorName = PostConstants.getFirstName() + " " + PostConstants.getLastName();
                        String ActualName = WebAction.getText(userDisplayName).trim();
                        if (EditorName.equalsIgnoreCase(ActualName)) {
                            System.out.println("Logged in Editor profile name got matched in story profile card");
                        } else
                            Assert.fail("Failed to match the Editor profile name in story team card");
                    } else
                        Assert.fail("Failed to display the Editor profile card in story team section");
                    break;

                case "SENIOR EDITOR":
                    boolean seniorEditorProfileCard = WebAction.isDisplayed(profileCard);
                    if (seniorEditorProfileCard) {
                        String SeniorEditorName = PostConstants.getFirstName() + " " + PostConstants.getLastName();
                        String ActualName = WebAction.getText(userDisplayName).trim();
                        if (SeniorEditorName.equalsIgnoreCase(ActualName)) {
                            System.out.println("Logged in Senior Editor profile name got matched in story profile card");
                        } else
                            Assert.fail("Failed to match the Senior Editor profile name in story team card");
                    } else
                        Assert.fail("Failed to display the Senior Editor profile card in story team section");
                    break;

                case "STANDARDS":
                    boolean standardProfileCard = WebAction.isDisplayed(profileCard);
                    if (standardProfileCard) {
                        String StandardName = PostConstants.getFirstName() + " " + PostConstants.getLastName();
                        String ActualName = WebAction.getText(userDisplayName).trim();
                        if (StandardName.equalsIgnoreCase(ActualName)) {
                            System.out.println("Logged in Standard profile name got matched in story profile card");
                        } else
                            Assert.fail("Failed to match the Standard profile name in story team card");
                    } else
                        Assert.fail("Failed to display the Standard profile card in story team section");
                    break;

                default:
                    Assert.fail("Please provide valid roles for different user profiles");

            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify toast message
     * @param expectedToastMessage - Expected Toast Message
     * @throws Exception
     */
    public void verifyToastMessage(String expectedToastMessage) throws Exception {
        try {
            CommonValidations.verifyTextValue(toastMessageElement, expectedToastMessage, "Angle is linked with private story toast message is not displayed");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify Collaborators field is disabled
     * @throws Exception
     */
    public void verifyCollaboratorsFieldDisabled() throws Exception {
        try {
            CommonValidations.verifyAttributeValue(collaborateField,"class", "disabled", "Collaborators text box is enabled and it allows user to add collaborators");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify angle privacy drop down is disabled
     */
    public void verifyAnglePrivacyDropdownDisabled() throws Exception {
        try {
            Waits.waitUntilAttributeValueContains(anglePrivacyDropDown.findElement(By.xpath("../..")),"class", "disabled");
            CommonValidations.verifyAttributeValue(anglePrivacyDropDown.findElement(By.xpath("../..")),"class", "disabled", "Angle privacy drop down is enabled and it allows user to change angle privacy");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

}