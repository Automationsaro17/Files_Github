package nbcu.automation.ui.pages.ncx;

import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class CreateContentPage {
    @FindBy(xpath = "//label[contains(@nzvalue,'Story')]")
    WebElement storyTab;

    @FindBy(xpath = "//label[contains(@nzvalue,'Post')]")
    WebElement postTab;

    @FindBy(xpath = "//label[contains(@nzvalue,'Angle')]")
    WebElement angleTab;

    public CreateContentPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify create content page is loaded
     */
    public void verifyCreateContentPageLoaded() throws Exception {
        try {
            Waits.waitForElement(postTab, WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify home page loaded
     */
    public void selectTab(String tabName) throws Exception {
        try {
            Waits.waitForElement(storyTab, WAIT_CONDITIONS.CLICKABLE);
            switch (tabName.toUpperCase()) {
                case "STORY":
                    WebAction.click(storyTab);
                    break;
                case "POST":
                    WebAction.click(postTab);
                    break;
                case "ANGLE":
                    WebAction.click(angleTab);
                    break;
                default:
                    Assert.fail("Please provide valid tab name for content creation");

            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

}