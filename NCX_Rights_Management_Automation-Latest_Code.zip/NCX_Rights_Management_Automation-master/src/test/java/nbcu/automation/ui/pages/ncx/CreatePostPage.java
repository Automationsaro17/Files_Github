package nbcu.automation.ui.pages.ncx;

import com.aventstack.extentreports.Status;
import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.AngleConstants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.others.CommonUtils;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import nbcu.framework.utils.report.ExtentReportUtils;
import org.checkerframework.checker.units.qual.Angle;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import javax.activation.CommandMap;
import java.util.List;
import java.util.Map;

public class CreatePostPage {

    /**
     * Loader icon
     */
    @FindBy(xpath = "//*[@loadertype='SECTION_LOADER']/div[contains(@class,'loader section')]")
    WebElement pageLoadingSpinner;

    /**
     * Create Post Elements
     **/
    @FindBy(xpath = "//div[contains(@class,'postTitle')]/input")
    WebElement postTitleTextBox;

    @FindBy(xpath = "//div[@class='postTitleAndContent']//div[contains(@class,'fr-element fr-view fr-element')]")
    WebElement postDescriptionTextBox;

    /**
     * Link Angle Elements
     */
    @FindBy(xpath = "//input[@placeholder='Search Angle Name or ID']")
    WebElement addAngleTextBox;

    /**
     * Link Story Elements
     */
    @FindBy(xpath = "//input[@placeholder='Search Story Name']")
    WebElement addStoryTextBox;

    @FindBy(xpath = "//input[@placeholder='Search Angle Name or ID']")
    WebElement addAngleTextBoxPlaceholder;


    @FindBy(xpath = "//span[@class='story-text']/div")
    List<WebElement> linkedStoriesName;

    @FindBy(xpath = "//span[@class='story-text']/preceding-sibling::span")
    List<WebElement> linkedStoriesCrownIcon;

    @FindBy(xpath = "//span[@class='story-text']/following-sibling::span/button[@nztype='pushpin']")
    List<WebElement> linkedStoriesPinIcon;

    @FindBy(xpath = "//span[@class='story-text']/following-sibling::span/button/span[@nztype='delete']")
    List<WebElement> linkedStoriesDeleteIcon;

    String searchDropDownValuesXpath = "//nz-auto-option[contains(@class,'ant-select-item ant-select-item-option')]/div";

    String dropDownValuesXpath = "//nz-option-item[contains(@class,'ant-select-item ant-select-item-option')]";

    @FindBy(xpath = "//div[@class='ant-message']//span[contains(text(), 'Post successfully saved as draft')]")
    WebElement savedAsDraftMessage;

    /**
     * Link Angle Elements
     */
    @FindBy(xpath = "//*[@class='angle-id']")
    WebElement angleId;

    @FindBy(xpath = "//*[@class='angle-title']")
    WebElement angleTitle;

    @FindBy(xpath = "//*[contains(@class,'angle-id')]/following-sibling::button/span[@nztype='delete']")
    List<WebElement> linkedAnglesDeleteICon;

    @FindBy(xpath = "//span[@nztype='eye-invisible']")
    List<WebElement> angleInvisibleEye;


    /**
     * Attachment Elements
     */
    @FindBy(xpath = "//input[@type='file']")
    WebElement attachmentElement;

    @FindBy(xpath = "//nz-upload-list[contains(@class,'ant-upload-list')]/div/div")
    List<WebElement> addedAttachmentList;

    @FindBy(xpath = "//nz-upload-list[contains(@class,'ant-upload-list')]//span/a[2]")
    List<WebElement> addedAttachmentNames;

    String addedAttachmentNamesXpath = "//nz-upload-list[contains(@class,'ant-upload-list')]//span/a[2]";

    @FindBy(xpath = "//nz-upload-list[contains(@class,'ant-upload-list')]//button[@title='Remove file']/span[@nztype='delete']")
    List<WebElement> addedAttachmentDeleteIcons;

    /**
     * Element details section Elements
     */
    @FindBy(xpath = "//input[@placeholder='Enter Link to Source']")
    WebElement linkToSourceTextBox;

    @FindBy(xpath = "//nz-select[contains(@class,'mandatoryCreditSelect')]")
    WebElement mandatoryCreditDropDown;

    @FindBy(xpath = "//input[@placeholder='Enter Credit Name']")
    WebElement mandatoryCreditTextBox;

    @FindBy(xpath = "//span[text()='Materials Cleared For']/span")
    WebElement materialClearedForDropDownMandatoryField;

    @FindBy(xpath = "//*[contains(@class,'materialsClearedForSelect')]/label[@nzvalue='yes']")
    WebElement clearedForNBCUPartnersYesOption;

    @FindBy(xpath = "//*[contains(@class,'materialsClearedForSelect')]/label[@nzvalue='no']")
    WebElement clearedForNBCUPartnersNoOption;

    /**
     * Post Meta Data Elements
     **/
    @FindBy(xpath = "//span[normalize-space()=\"REPORTABLE\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement reportableLabel;

    @FindBy(xpath = "//span[normalize-space()=\"NOT REPORTABLE\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement notReportableLabel;

    @FindBy(xpath = "//span[normalize-space()=\"VERIFIED\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement verifiedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"PUBLISHED/AIRED\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement publishedOrAiredLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LOG\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement logLabel;

    @FindBy(xpath = "//span[normalize-space()=\"GREAT VIDEO\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement greatVideoLabel;

    @FindBy(xpath = "//span[normalize-space()=\"IMPORTANT\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement importantLabel;

    @FindBy(xpath = "//span[normalize-space()=\"HOT\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement hotLabel;

    @FindBy(xpath = "//span[normalize-space()=\"STANDARDS\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement standardsLabel;

    @FindBy(xpath = "//span[normalize-space()=\"CLEARED\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement clearedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LICENSED\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement licensedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LIMITED LICENSE\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement limitedLicensedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"NEEDS LICENSING\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement needsLicensingLabel;

    @FindBy(xpath = "//span[normalize-space()=\"COPYRIGHT RISK\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement copyRightRiskLabel;

    @FindBy(xpath = "//span[normalize-space()=\"DO NOT USE\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement doNotUseLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LEGAL\"]/preceding-sibling::span[@class='ant-checkbox']")
    WebElement legalLabel;

    /**
     * Standard Guidance Section Elements
     */
    @FindBy(xpath = "//div[@id='standardGuidance']//div[contains(@class,'fr-element-scroll-visible')]") //"//div[@id='standardGuidance']//div[@class='fr-element fr-view fr-element-scroll-visible']")
            WebElement standardGuidanceTextBox;

    /**
     * Reportable Section Elements
     */
    @FindBy(xpath = "//div[@class='reportableLabel']")
    WebElement reportableApproverText;

    @FindBy(xpath = "//nz-select[contains(@class,'reportableOptions')]")
    WebElement reportableApproverOption;

    @FindBy(xpath = "//input[@placeholder=\"Sr.Approver's name\"]")
    WebElement seniorApproverNameTextBox;

    @FindBy(xpath = "//div[@class='reportableTextArea']/textarea")
    WebElement reportableApproverNotesTextBox;

    /**
     * Limited License Section Elements
     */
    @FindBy(xpath = "//div[@class='licenseTextArea']/textarea")
    WebElement limitedLicenseTextBox;


    /**
     * Button Elements
     */
    @FindBy(xpath = "//button[span[@nztype='send']]")
    WebElement publishButton;

    @FindBy(xpath = "//button[span[@nztype='expand']]")
    WebElement previewButton;

    @FindBy(xpath = "//button[span[@nztype='save']]")
    WebElement saveDraftButton;

    @FindBy(xpath = "//button[span[@nztype='close']]")
    WebElement cancelButton;

    /**
     * Edit Post Elements
     */
    @FindBy(xpath = "//span[normalize-space()='Do not Send Email Update for this Edit']/preceding-sibling::span/input")
    WebElement doNotSendEmailForEditCheckBox;

    @FindBy(xpath = "//span[normalize-space()='Do not Send Email Update for this Edit']/preceding-sibling::span")
    WebElement doNotSendEmailForEditCheckBoxStatus;

    public CreatePostPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify create post page is displayed
     *
     * @param action - CREATE/EDIT
     */
    public void verifyCreatePostPageLoaded(String action) throws Exception {
        try {
            Waits.waitForElement(postTitleTextBox, Waits.WAIT_CONDITIONS.CLICKABLE);
            Waits.waitForElement(publishButton, Waits.WAIT_CONDITIONS.CLICKABLE);

            if (action.equalsIgnoreCase("CREATE")) {
                if (PostConstants.getPostCount() == null)
                    PostConstants.setPostCount("1");
                else PostConstants.setPostCount(String.valueOf(Integer.parseInt(PostConstants.getPostCount()) + 1));
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify the browser tab title for create post screen
     *
     * @param expectedTitle - Expected Page Title
     */
    public void verifyBrowserTabTitle(String expectedTitle) {
        try {
            String actualTitle = WebAction.getWindowTitle().trim();
            Assert.assertEquals(actualTitle, expectedTitle, "create post page is not correct");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill post title
     *
     * @param postTitle - Post Title
     */
    public void fillPostTitle(String postTitle) throws Exception {
        try {
            System.out.println("test");
            postTitle = postTitle + "_" + CommonUtils.generateRandomString(12);
            PostConstants.setPostTitle(postTitle);
            WebAction.clearUsingKeys(postTitleTextBox);
            WebAction.sendKeys(postTitleTextBox, postTitle);
            ExtentReportUtils.addLog(Status.INFO, "Post Title: <b>" + postTitle + "</b>");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill post description
     *
     * @param postDescription - Post description
     */
    public void fillPostDescription(String postDescription) throws Exception {
        try {
            PostConstants.setPostDescription(postDescription);
            WebAction.click(postDescriptionTextBox);
            WebAction.sendKeys(postDescriptionTextBox, postDescription);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify invisible eye icon is displayed for private angle and invisible eye not displayed for public angle
     *
     * @param visibility   - Not displayed/displayed
     * @param anglePrivacy - Angle privacy
     */
    public void searchAngleAndVerifyInvisibleEyeIcon(String visibility, String anglePrivacy) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            String angleId = AngleConstants.getAngleID(AngleConstants.getAngleCount());
            WebAction.scrollIntoView(addAngleTextBox);
            WebAction.sendKeys(addAngleTextBox, angleId);
            Waits.waitUntilElementSizeGreater(By.xpath(searchDropDownValuesXpath), 0);
            Thread.sleep(1000);
            assert driver != null;
            List<WebElement> dropDownValues = driver.findElements(By.xpath(searchDropDownValuesXpath));
            for (int i = 0; i < dropDownValues.size(); i++) {
                if (WebAction.getText(dropDownValues.get(i)).trim().toLowerCase().contains(angleId.toLowerCase())) {
                    if (visibility.equalsIgnoreCase("NOT DISPLAYED"))
                        Assert.assertEquals(angleInvisibleEye.size(), 0, "Invisible eye icon is displayed for '" + anglePrivacy + "' angle in angle search of create/edit post page");
                    else
                        Assert.assertTrue(WebAction.isDisplayed(angleInvisibleEye.get(i)), "Invisible eye icon is not displayed for '" + anglePrivacy + "' angle in angle search of create/edit post page");
                    break;
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To Link angle to post
     *
     * @param angleId - Angle Id
     */
    public void linkAngle(String angleId, String storyAttachment) throws Exception {
        try {
            WebAction.scrollIntoView(addAngleTextBox);
            PostConstants.setLinkedAngleCount(1);
            PostConstants.setLinkedAngle(0, angleId);
            if (storyAttachment.equalsIgnoreCase("DO NOT REMOVE"))
                PostConstants.setPrimaryStory(StoryConstants.getStoryTitle(StoryConstants.getStoryCount()));
            else clickPinOrDeleteIcon("DELETE");
            WebAction.selectNonTitleDropDown(addAngleTextBox, angleId, searchDropDownValuesXpath, angleId + " is not present in the add to angle search");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To link story to post
     *
     * @param storyName - Story Name
     */
    public void linkStory(String storyName) throws Exception {
        try {
            WebAction.scrollIntoView(addStoryTextBox);
            PostConstants.setLinkedStoryCount(1);
            PostConstants.setLinkedStory(0, storyName);
            PostConstants.setPrimaryStory(storyName);
            WebAction.selectNonTitleDropDown(addStoryTextBox, storyName, searchDropDownValuesXpath, storyName + " is not present in the add to story search");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify linked stories list are displayed with pin and delete
     */
    public void verifyLinkedStories() throws Exception {
        try {
            for (int i = 0; i < PostConstants.getLinkedStoryCount(); i++) {
                Waits.waitForElement(linkedStoriesDeleteIcon.get(i), Waits.WAIT_CONDITIONS.CLICKABLE);
                CommonValidations.verifyTextValue(linkedStoriesName.get(i), PostConstants.getLinkedStory(i), "'" + PostConstants.getLinkedStory(i) + "' story is not linked to post");
                CommonValidations.verifyElementIsEnabled(linkedStoriesDeleteIcon.get(i), "Delete story icon is not displayed for story '" + PostConstants.getLinkedStory(i) + "'");

                //Verify Pin to top icon is displayed other than Journalist role
                if (StoryConstants.getUserRole().equalsIgnoreCase("JOURNALIST"))
                    Assert.assertTrue(linkedStoriesPinIcon.isEmpty(), "Pin story icon is not displayed for story '" + PostConstants.getLinkedStory(i) + "'");
                else
                    CommonValidations.verifyElementIsEnabled(linkedStoriesPinIcon.get(i), "Pin story icon is not displayed for story '" + PostConstants.getLinkedStory(i) + "'");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify primary story of post
     *
     * @param color - crown color
     */
    public void verifyStoryMarkedAsPrimary(String color) {
        try {
            String primaryStory = PostConstants.getPrimaryStory();
            for (int i = 0; i < PostConstants.getLinkedStoryCount(); i++) {
                String actualStoryName = WebAction.getText(linkedStoriesName.get(i));
                if (actualStoryName.equalsIgnoreCase(primaryStory)) {
                    CommonValidations.verifyAttributeValue(linkedStoriesCrownIcon.get(i), "class", "primary", "'" + actualStoryName + "' is not ,marked as primary in create/edit post page");
                    CommonValidations.verifyColorOfElement(linkedStoriesCrownIcon.get(i), "background color", color);
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click pin/delete icon
     *
     * @param iconName - Icon Name
     */
    public void clickPinOrDeleteIcon(String iconName) throws Exception {
        try {
            if (iconName.equalsIgnoreCase("PIN"))
                WebAction.click(linkedStoriesPinIcon.get(0));
            else if (iconName.equalsIgnoreCase("DELETE"))
                WebAction.click(linkedStoriesDeleteIcon.get(0));
            else
                Assert.fail("Given icon name " + iconName + "is not present in linked story. Please provide valid icon name");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify post as draft message
     */
    public void verifyPostSavedAsDraft() throws Exception {
        try {
            Waits.waitForElement(savedAsDraftMessage, Waits.WAIT_CONDITIONS.VISIBLE);
            Waits.waitForElement(savedAsDraftMessage, Waits.WAIT_CONDITIONS.INVISIBLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story id is displayed for linked story in create post page
     * @throws Exception
     */
    public void verifyStoryIdDisplayedAlongWithStoryName() throws Exception {
        try {
            for (int i = 0; i < Integer.parseInt(StoryConstants.getStoryCount()); i++)
                CommonValidations.verifyTextValue(linkedStoriesName.get(i), StoryConstants.getStoryId(StoryConstants.getStoryCount()),"Story Id is not displayed for linked story '"+StoryConstants.getStoryTopic(i)+"'");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To add attachments
     *
     * @param params - attachment names
     */
    public void addAttachments(DataTable params) throws Exception {
        try {
            List<Map<String, String>> attachmentList = CucumberUtils.getValuesFromDataTableAsList(params);
            PostConstants.setAttachmentCount(String.valueOf(attachmentList.size()));
            WebAction.scrollIntoView(attachmentElement);
            for (int i = 0; i < attachmentList.size(); i++) {
                String attachmentName = attachmentList.get(i).get("Attachment Name");
                PostConstants.setAttachmentName(i, attachmentName);
                String filePath = System.getProperty("user.dir") + "/" + ConfigFileReader.getProperty("File-Upload-Path") + "/" + attachmentName;
                WebAction.sendKeys_WithoutClear(attachmentElement, filePath);
                Waits.waitUntilElementSizeGreater(By.xpath(addedAttachmentNamesXpath), i);
                Waits.waitUntilAttributeValueContains(addedAttachmentList.get(addedAttachmentList.size() - 1), "class", "item-done");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify added attachments in post
     */
    public void verifyAddedAttachments() {
        try {
            int attachmentSize = Integer.parseInt(PostConstants.getAttachmentCount());
            for (int i = 0; i < attachmentSize; i++) {
                CommonValidations.verifyAttributeValue(addedAttachmentNames.get(i), "title", PostConstants.getAttachmentName(i), PostConstants.getAttachmentName(i) + " file is not added to post attachment");
                CommonValidations.verifyElementIsEnabled(addedAttachmentDeleteIcons.get(i), "Delete attachment icon is not displayed for attachment '" + PostConstants.getAttachmentName(i) + "' in create post page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify material cleared for field is marked as mandatory
     */
    public void verifyMaterialClearedForMarkedAsMandatory() {
        try {
            CommonValidations.verifyAttributeValue(materialClearedForDropDownMandatoryField, "class", "mandatory", "Material cleared for field is not marked as mandatory even though attachment added");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill link to source in element details section
     *
     * @param linkToSource - Link to source
     */
    public void fillLinkToSource(String linkToSource) throws Exception {
        try {
            PostConstants.setLinkToSource(linkToSource);
            WebAction.sendKeys(linkToSourceTextBox, linkToSource);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill mandatory credit details
     *
     * @param mandatoryCreditOption - Mandatory credit option
     * @param mandatoryCreditValue  - Mandatory credit value
     */
    public void fillMandatoryCredit(String mandatoryCreditOption, String mandatoryCreditValue) throws Exception {
        try {
            PostConstants.setMandatoryCreditOption(mandatoryCreditOption);
            PostConstants.setMandatoryCreditValue(mandatoryCreditValue);
            WebAction.click(mandatoryCreditDropDown);
            WebAction.nonEnterableSelectDropDown(dropDownValuesXpath, mandatoryCreditOption, mandatoryCreditOption + " option is not available in mandatory credit drop down option");
            if (mandatoryCreditOption.equalsIgnoreCase("YES"))
                WebAction.sendKeys(mandatoryCreditTextBox, mandatoryCreditValue);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill cleared for NBCU partners option
     *
     * @param clearedForNbcuPartners - cleared for NBCU Parters option
     */
    public void fillClearedForNbcuPartners(String clearedForNbcuPartners) throws Exception {
        try {
            PostConstants.setClearedForNbcuPartners(clearedForNbcuPartners);
            if (clearedForNbcuPartners.equalsIgnoreCase("YES"))
                WebAction.click(clearedForNBCUPartnersYesOption);
            else WebAction.click(clearedForNBCUPartnersNoOption);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To select editorial/standards label
     *
     * @param params - editorial/standards label
     */
    public void selectEditorialOrStandardsLabel(DataTable params) throws Exception {
        try {
            List<Map<String, String>> standardsLabels = CucumberUtils.getValuesFromDataTableAsList(params);

            for (int i = 0; i < standardsLabels.size(); i++) {
                String standardLabel = standardsLabels.get(i).get("Editorial/Standards Label");
                if (PostConstants.getStandardsLabelsCount() == null)
                    PostConstants.setStandardsLabel(i, standardLabel);
                else
                    PostConstants.setStandardsLabel((Integer.parseInt(PostConstants.getStandardsLabelsCount()) + i), standardLabel);

                switch (standardLabel.toUpperCase()) {
                    case "REPORTABLE":
                        WebAction.click(reportableLabel);
                        break;
                    case "NOT REPORTABLE":
                        WebAction.click(notReportableLabel);
                        break;
                    case "VERIFIED":
                        WebAction.click(verifiedLabel);
                        break;
                    case "PUBLISHED/AIRED":
                        WebAction.click(publishedOrAiredLabel);
                        break;
                    case "LOG":
                        WebAction.click(logLabel);
                        break;
                    case "GREAT VIDEO":
                        WebAction.click(greatVideoLabel);
                        break;
                    case "IMPORTANT":
                        WebAction.click(importantLabel);
                        break;
                    case "HOT":
                        WebAction.click(hotLabel);
                        break;
                    case "STANDARDS":
                        WebAction.click(standardsLabel);
                        break;
                    default:
                        Assert.fail("Please enter valid Editorial/Standards label. Given '" + standardLabel + "' is not present in the application");
                }
            }

            if (PostConstants.getStandardsLabelsCount() == null)
                PostConstants.setStandardsLabelsCount(String.valueOf(standardsLabels.size()));
            else
                PostConstants.setStandardsLabelsCount(String.valueOf(standardsLabels.size() + Integer.parseInt(PostConstants.getStandardsLabelsCount())));

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To select R&C/Legal label
     *
     * @param params - R&C/Legal label
     */
    public void selectRcOrLegalLabel(DataTable params) throws Exception {
        try {
            List<Map<String, String>> rcLegalLabels = CucumberUtils.getValuesFromDataTableAsList(params);

            WebAction.scrollIntoView(clearedLabel);
            for (int i = 0; i < rcLegalLabels.size(); i++) {
                String rcLegalLabel = rcLegalLabels.get(i).get("R&C/Legal Label");
                if (PostConstants.getLegalLabelsCount() == null)
                    PostConstants.setLegalLabel(i, rcLegalLabel);
                else
                    PostConstants.setLegalLabel((Integer.parseInt(PostConstants.getLegalLabelsCount()) + i), rcLegalLabel);
                switch (rcLegalLabel.toUpperCase()) {
                    case "CLEARED":
                        WebAction.click(clearedLabel);
                        break;
                    case "LICENSED":
                        WebAction.click(licensedLabel);
                        break;
                    case "LIMITED LICENSE":
                        WebAction.click(limitedLicensedLabel);
                        break;
                    case "NEEDS LICENSING":
                        WebAction.click(needsLicensingLabel);
                        break;
                    case "COPYRIGHT RISK":
                        WebAction.click(copyRightRiskLabel);
                        break;
                    case "DO NOT USE":
                        WebAction.click(doNotUseLabel);
                        break;
                    case "LEGAL":
                        WebAction.click(legalLabel);
                        break;
                    default:
                        Assert.fail("Please enter valid R&C/Legal label. Given '" + rcLegalLabel + "' is not present in the application");
                }
            }

            if (PostConstants.getLegalLabelsCount() == null)
                PostConstants.setLegalLabelsCount(String.valueOf(rcLegalLabels.size()));
            else
                PostConstants.setLegalLabelsCount(String.valueOf(rcLegalLabels.size() + Integer.parseInt(PostConstants.getLegalLabelsCount())));
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify Standard Guidance/Reportable/Limited license section is displayed
     *
     * @param labelName - Standard Guidance/Reportable/Limited License
     */
    public void verifyLabelSectionDisplayed(String labelName) {
        try {
            if (labelName.equalsIgnoreCase("STANDARD GUIDANCE"))
                CommonValidations.verifyElementIsDisplayed(standardGuidanceTextBox, "Standard Guidance section is not displayed");
            else if (labelName.equalsIgnoreCase("REPORTABLE"))
                CommonValidations.verifyElementIsDisplayed(reportableApproverOption, "Reportable approver section is not displayed");
            else if (labelName.equalsIgnoreCase("LIMITED LICENSE"))
                CommonValidations.verifyElementIsDisplayed(limitedLicenseTextBox, "Limited license section is not displayed");
            else Assert.fail("Please enter valid section name");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill standard guidance description
     *
     * @param standardGuidanceDescription - Standard guidance description
     */
    public void fillStandardGuidance(String standardGuidanceDescription) throws Exception {
        try {
            WebAction.scrollIntoView(standardGuidanceTextBox);
            PostConstants.setStandardGuidance(standardGuidanceDescription);
            WebAction.sendKeys(standardGuidanceTextBox, standardGuidanceDescription);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill reportable approver section
     *
     * @param reportableLabelDescription - reportable label description
     * @param reportableOption           - reportable option
     * @param seniorApproverName         - reportable senior approver name
     * @param reportableNotes            - reportable notes
     */
    public void fillReportableApproverSection(String reportableLabelDescription, String reportableOption, String seniorApproverName, String reportableNotes) throws Exception {
        try {
            WebAction.scrollIntoView(reportableApproverOption);
            CommonValidations.verifyTextValue(reportableApproverText, reportableLabelDescription, reportableApproverText + " field name is not correct in reportable approver section");

            // To select reportable option
            PostConstants.setReportableApproverOption(reportableOption);
            WebAction.click(reportableApproverOption);
            WebAction.nonEnterableSelectDropDown(dropDownValuesXpath, reportableOption, reportableOption + " option is present in the reportable approver section");

            if (reportableOption.equalsIgnoreCase("NO"))
                WebAction.sendKeys(seniorApproverNameTextBox, seniorApproverName);
            else seniorApproverName = "From an official named source, no need for senior approval";
            PostConstants.setSrApproverName(seniorApproverName);

            // To fill reportable section notes
            if (reportableNotes != null) {
                PostConstants.setReportableNotes(reportableNotes);
                WebAction.sendKeys(reportableApproverNotesTextBox, reportableNotes);
            }

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    //Loga - Merged -> Date -->> 04/22/2024

    /**
     * To fill limited license description
     *
     * @param limitedLicenseDescription - limited license description
     */
    public void fillLimitedLicense(String limitedLicenseDescription) throws Exception {
        try {
            WebAction.scrollIntoView(limitedLicenseTextBox);
            PostConstants.setLimitedLicense(limitedLicenseDescription);
            WebAction.sendKeys(limitedLicenseTextBox, limitedLicenseDescription);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click button in create post page
     *
     * @param buttonName - button name
     */
    public void clickButton(String buttonName, String pageType) throws Exception {
        try {
            switch (buttonName.toUpperCase()) {
                case "CANCEL":
                    WebAction.click(cancelButton);
                    break;
                case "SAVE DRAFT":
                    WebAction.click(saveDraftButton);
                    PostConstants.setDraftPostCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                    PostConstants.setDraftPostCreationDate(DateFunctions.getCurrentDate("M/d/yy"));
                    break;
                case "PREVIEW":
                    WebAction.click(previewButton);
                    break;
                case "PUBLISH":
                    WebAction.click(publishButton);

                    // To update post creation/modified date and time
                    if (pageType.equalsIgnoreCase("CREATE")) {
                        PostConstants.setPostCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                        PostConstants.setPostCreationDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    } else {
                        PostConstants.setPostModifiedTime(DateFunctions.getCurrentDate("h:mm a"));
                        PostConstants.setPostModifiedDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    }

                    // To update standard guidance creation date and time if standards label is selected
                    boolean standardsLabelCheck = false;
                    if (PostConstants.getStandardsLabelsCount() != null) {
                        for (int i = 0; i < Integer.parseInt(PostConstants.getStandardsLabelsCount()); i++) {
                            if (PostConstants.getStandardsLabel(i).trim().equalsIgnoreCase("STANDARDS")) {
                                standardsLabelCheck = true;
                                break;
                            }
                        }
                    }
                    if (standardsLabelCheck && PostConstants.getStandardGuidanceCreationDate() == null) {
                        PostConstants.setStandardGuidanceCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                        PostConstants.setStandardGuidanceCreationDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    }
                    break;
                default:
                    Assert.fail("Please provide valid button name in create/edit post page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify 'Do not Send Email Update for this Edit' check box is checked by default in edit post page
     */
    public void verifyDoNotSendEmailForUpdateCheckBoxStatus() throws Exception {
        try {
            Waits.waitForElement(doNotSendEmailForEditCheckBoxStatus, Waits.WAIT_CONDITIONS.CLICKABLE);
            CommonValidations.verifyAttributeValue(doNotSendEmailForEditCheckBoxStatus, "class", "checked", "'Do not Send Email Update for this Edit' check box is not checked by default in edit post page");
            Thread.sleep(5000);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To check/Uncheck Do not send email for update check box
     */
    public void checkOrUnCheckDoNotSendEmailForUpdateCheckBox() throws Exception {
        try {
            WebAction.scrollIntoView(doNotSendEmailForEditCheckBox);
            WebAction.clickUsingJs(doNotSendEmailForEditCheckBox);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify angle is displayed in create/edit post page
     */
    public void verifyLinkedAngle() throws Exception {
        try {
            String expectedAngleId = AngleConstants.getAngleID(AngleConstants.getAngleCount());
            String expectedAngleTitle = AngleConstants.getAngleTitle(AngleConstants.getAngleCount());
            WebAction.scrollIntoView(addAngleTextBoxPlaceholder);

            //Verify Angle id
            CommonValidations.verifyTextValue(angleId, expectedAngleId, "Angle id is not correct in create/edit post page");

            //Verify Angle title
            CommonValidations.verifyTextValue(angleTitle, expectedAngleTitle, "Angle title is not correct in create/edit post page");

            //Verify delete icon of angle
            CommonValidations.verifyElementIsEnabled(linkedAnglesDeleteICon.get(0),
                    "Delete angle is not displayed to the linked angle " + expectedAngleTitle);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To delete story/angle link
     */
    public void deleteLinkedStoryOrAngle(String storyOrAngle) throws Exception {
        try {
            if (storyOrAngle.equalsIgnoreCase("STORY")) {
                WebAction.click(linkedStoriesDeleteIcon.get(0));
                PostConstants.setPrimaryStory(PostConstants.getLinkedStory(PostConstants.getLinkedStoryCount()-1));
            }
            else if (storyOrAngle.equalsIgnoreCase("ANGLE"))
                WebAction.click(linkedAnglesDeleteICon.get(0));
            else {
                WebAction.click(linkedStoriesDeleteIcon.get(0));
                WebAction.click(linkedAnglesDeleteICon.get(0));
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify invisible eye icon in linked angle
     *
     * @param visibility   - Displayed/Not Displayed
     * @param anglePrivacy - Angle Privacy
     */
    public void verifyInvisibleEyeIconInLinkedAngle(String visibility, String anglePrivacy) {
        try {
            if (visibility.equalsIgnoreCase("NOT DISPLAYED"))
                Assert.assertEquals(angleInvisibleEye.size(), 0, "Invisible eye icon is displayed for '" + anglePrivacy + "' angle in linked angle of create/edit post page");
            else
                Assert.assertTrue(WebAction.isDisplayed(angleInvisibleEye.get(0)), "Invisible eye icon is not displayed for '" + anglePrivacy + "' angle in linked angle of create/edit post page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Search with Full/Partial story ID in create post/angle page
     *
     * @param searchType - FULL/PARTIAL
     * @param params     - TOPIC ID WITH YEAR/YEAR WITH SUBJECT CODE/SUBJECT CODE WITH NUMBER
     */
    public void searchWithFullPartialStoryIdInAddToStory(String searchType, DataTable params) throws Exception {
        try {
            String searchText = new HomePage().generateFullOrPartialStoryId(searchType, params);
            System.out.println("Search Text:" + searchText);
            WebAction.sendKeys(addStoryTextBox, searchText);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story id search results in create post page
     *
     * @param searchType - FULL/PARTIAL
     * @throws Exception
     */
    public void verifyStoryIdSearchResults(String searchType, String pageName) throws Exception {
        try {
            //Wait for spinner to close
            Waits.waitForElement(pageLoadingSpinner, Waits.WAIT_CONDITIONS.VISIBLE);
            Waits.waitForElement(pageLoadingSpinner, Waits.WAIT_CONDITIONS.INVISIBLE);

            List<WebElement> searchResultList = WebAction.findElements(By.xpath(searchDropDownValuesXpath));
            for(WebElement element: searchResultList){
                String storyIdAndName = WebAction.getText(element);
                String storyId = storyIdAndName.split("-")[0].trim();
                CommonValidations.verifyStringValues(storyId, StoryConstants.getSearchKeyword(), "Story search result for "+searchType+" story id '"+StoryConstants.getSearchKeyword()+" is not correct in create "+pageName+" page");
            }

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }
}
