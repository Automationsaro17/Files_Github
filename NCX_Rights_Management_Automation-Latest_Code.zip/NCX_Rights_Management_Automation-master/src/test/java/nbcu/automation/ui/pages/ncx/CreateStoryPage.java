package nbcu.automation.ui.pages.ncx;

import com.aventstack.extentreports.Status;
import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.others.CommonUtils;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.report.ExtentReportUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.*;

public class CreateStoryPage {

    /**
     * Main Content Elements
     **/
    @FindBy(xpath = "//label[contains(@nzvalue,'WORKING')]")
    WebElement workingStory;

    @FindBy(xpath = "//label[contains(@nzvalue,'READY')]")
    WebElement readyStory;

    @FindBy(xpath = "//nz-select[@formcontrolname='access']")
    WebElement storyPrivacyDropDown;

    @FindBy(xpath = "//input[@formcontrolname='title']")
    WebElement storyTitleTextBox;

    @FindBy(xpath = "//div[@class='content-label']/span[normalize-space()='Story Name']/preceding-sibling::span")
    WebElement storyTitleMandatoryElement;

    @FindBy(xpath = "//div[contains(@class,'errorMessage')]/span[contains(text(),'title')]")
    WebElement storyTitleMissingError;

    @FindBy(xpath = "//span[normalize-space()='Story Name']/i")
    WebElement storyNameToolTipIcon;

    @FindBy(xpath = "//div[contains(@class,'ant-tooltip-inner')]/span")
    WebElement toolTipMessageElement;

    @FindBy(xpath = "//*[normalize-space()='Select Topic']/..//input | //*[@nzplaceholder='Select Topic']//input")
    WebElement topicTextBox;

    @FindBy(xpath = "//div[@class='content-label']/span[normalize-space()='Topic']/preceding-sibling::span")
    WebElement storyTopicMandatoryElement;

    @FindBy(xpath = "//div[contains(@class,'errorMessage')]/span[contains(text(),'topic')]")
    WebElement storyTopicMissingError;

    @FindBy(xpath = "//span[normalize-space()='Topic']/i")
    WebElement topicToolTipIcon;

    @FindBy(xpath = "//nz-select[@formcontrolname='topic']//nz-select-item")
    List<WebElement> addedTopicList;

    @FindBy(xpath = "//*[@formcontrolname='subject']")
    WebElement subjectTextBox;

    @FindBy(xpath = "//*[@formcontrolname='subject']//nz-select-search")
    WebElement subjectDropdown;

    @FindBy(xpath = "//div[@class='content-label']/span[normalize-space()='Subject']/preceding-sibling::span")
    WebElement storySubjectMandatoryElement;

    @FindBy(xpath = "//div[contains(@class,'errorMessage')]/span[contains(text(),'person/location')]")
    WebElement storySubjectMissingError;

    @FindBy(xpath = "//span[normalize-space()='Subject']/i")
    WebElement subjectToolTipIcon;

    @FindBy(xpath = "//*[@formcontrolname='subject']//nz-select-item")
    WebElement addedSubject;

    @FindBy(xpath = "//*[@formcontrolname='subject']//nz-select-item/span/span[@nztype='close']")
    WebElement removeSubjectIcon;

    @FindBy(xpath = "//div[contains(@class,'fr-element fr-view fr-element')]")
    WebElement storyDescriptionTextBox;

    @FindBy(xpath = "//div[contains(text(),'Add Description')]/span")
    WebElement storyDescriptionMandatoryElement;

    @FindBy(xpath = "//div[contains(@class,'errorMessage')]/span[contains(text(),'description')]")
    WebElement storyDescriptionMissingError;

    // Drop down value xpath
    String dropDownValuesXpath = "//nz-option-item[contains(@class,'ant-select-item ant-select-item-option')]";

    /**
     * Meta Data Elements
     **/

    @FindBy(xpath = "//input[@placeholder='Add Tag']")
    WebElement tagsTextBox;

    @FindBy(xpath = "//i[@nztitle='Add Tag']")
    WebElement addTagIcon;

    @FindBy(xpath = "//button[span[text()='Generate Tags']]")
    WebElement generateTagsButton;

    @FindBy(xpath = "//span[@class='tag-text']")
    List<WebElement> addedTagsList;

    @FindBy(xpath = "//span[@class='tag-text']/following-sibling::span[@nztype='close']")
    List<WebElement> addedTagsRemoveIconList;

    @FindBy(xpath = "//input[@placeholder='Enter Slack Channel Name Here']")
    WebElement slackIntegrationTextBox;

    @FindBy(xpath = "//input[@placeholder='Enter Slack Channel Name Here']/following-sibling::span/i")
    WebElement slackChannelAddIcon;

    @FindBy(xpath = "//*[@class='slack-text']")
    List<WebElement> addedslackChannelList;

    @FindBy(xpath = "//*[@class='slack-text']/following-sibling::span")
    List<WebElement> addedslackChannelRemoveIconList;

    /**
     * Buttons Element
     */
    @FindBy(xpath = "//button[i[@nztype='send']]")
    WebElement publishButton;

    @FindBy(xpath = "//button[contains(@class,'preview')]")
    WebElement previewButton;

    @FindBy(xpath = "//button[i[@nztype='save']]")
    WebElement saveDraftButton;

    @FindBy(xpath = "//button[contains(@class,'cancel')]")
    WebElement cancelButton;

    /**
     * Message Elements
     */
    @FindBy(xpath = "//div[contains(@class,'ant-message-custom')]/span[contains(text(),'The Story has been successfully updated')]")
    WebElement storyPublishMessage;

    @FindBy(xpath = "//div[contains(@class,'ant-message-custom')]/span[contains(text(),'Draft')]")
    WebElement savedAdDraftMessage;

    public CreateStoryPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify create story page is loaded
     */
    public void verifyCreateStoryPageLoaded(String action) throws Exception {
        try {
            Waits.waitForElement(storyTitleTextBox, WAIT_CONDITIONS.CLICKABLE);
            Waits.waitForElement(publishButton, WAIT_CONDITIONS.CLICKABLE);

            if (action.equalsIgnoreCase("CREATE")) {
                if (StoryConstants.getStoryCount() == null)
                    StoryConstants.setStoryCount("1");
                else StoryConstants.setStoryCount(String.valueOf(Integer.parseInt(StoryConstants.getStoryCount()) + 1));
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To select story type
     *
     * @param storyStatus - Story Status.(i.e) Working/Ready
     */
    public void selectStoryStatus(String storyStatus) throws Exception {
        try {
            StoryConstants.setStoryStatus(storyStatus);
            // Story state options will be displayed other than JOURNALIST role
            if (!StoryConstants.getUserRole().equalsIgnoreCase("JOURNALIST")) {
                Waits.waitForElement(workingStory, WAIT_CONDITIONS.CLICKABLE);
                if (storyStatus.equalsIgnoreCase("WORKING")) WebAction.click(workingStory);
                else WebAction.click(readyStory);
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify privacy drop down is disabled
     */
    public void verifyPrivacyDropDownDisabled() throws Exception {
        try {
            CommonValidations.verifyElementIsDisabledByClass(storyPrivacyDropDown, "Privacy drop down is enabled in edit story page even though privacy is public");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To select story visibility to public/private
     *
     * @param storyPrivacy - Public/Private
     */
    public void selectStoryPrivacy(String storyPrivacy) throws Exception {
        try {
            StoryConstants.setStoryPrivacy(storyPrivacy);

            // Story privacy option will be displayed other than JOURNALIST role
            if (!StoryConstants.getUserRole().equalsIgnoreCase("JOURNALIST")) {
                Waits.waitForElement(storyPrivacyDropDown, WAIT_CONDITIONS.CLICKABLE);
                WebAction.click(storyPrivacyDropDown);
                WebAction.nonEnterableSelectDropDown(dropDownValuesXpath, storyPrivacy, storyPrivacy + " is not present in the story visibility drop down");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story mandatory fields
     *
     * @param params
     * @throws Exception
     */
    public void verifyStoryMandatoryFields(DataTable params) throws Exception {
        try {
            List<Map<String, String>> fieldNames = CucumberUtils.getValuesFromDataTableAsList(params);
            for (int i = 0; i < fieldNames.size(); i++) {
                switch (fieldNames.get(i).get("Field Name").toUpperCase()) {
                    case "STORY NAME":
                        CommonValidations.verifyAttributeValue(storyTitleMandatoryElement, "class", "mandatory", "Story name field is not marked as mandatory");
                        break;
                    case "TOPIC":
                        CommonValidations.verifyAttributeValue(storyTopicMandatoryElement, "class", "mandatory", "Story name field is not marked as mandatory");
                        break;
                    case "SUBJECT":
                        CommonValidations.verifyAttributeValue(storySubjectMandatoryElement, "class", "mandatory", "Story name field is not marked as mandatory");
                        break;
                    case "ADD DESCRIPTION":
                        CommonValidations.verifyAttributeValue(storyDescriptionMandatoryElement, "class", "mandatory", "Story name field is not marked as mandatory");
                        break;
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify mandatory field missing error message
     *
     * @param fieldName - Field Name
     * @throws Exception
     */
    public void verifyMandatoryFieldMissingError(String fieldName, String expectedErrorMessage) throws Exception {
        try {
            switch (fieldName.toUpperCase()) {
                case "STORY NAME":
                    CommonValidations.verifyTextValue(storyTitleMissingError, expectedErrorMessage, "Story title is missing error message is not displayed in create/edit story page");
                    break;
                case "TOPIC":
                    CommonValidations.verifyTextValue(storyTopicMissingError, expectedErrorMessage, "Story topic is missing error message is not displayed in create/edit story page");
                    break;
                case "SUBJECT":
                    CommonValidations.verifyTextValue(storySubjectMissingError, expectedErrorMessage, "Story subject is missing error message is not displayed in create/edit story page");
                    break;
                case "ADD DESCRIPTION":
                    CommonValidations.verifyTextValue(storyDescriptionMissingError, expectedErrorMessage, "Story description is missing error message is not displayed in create/edit story page");
                    break;
            }

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To mouse over on tool tip icon
     *
     * @param fieldName - Story Name/Topic/Subject
     * @throws Exception
     */
    public void mouseOverOnToolTipIcon(String fieldName) throws Exception {
        try {
            switch (fieldName.toUpperCase()) {
                case "STORY NAME":
                    WebAction.mouseOver(storyNameToolTipIcon);
                    break;
                case "TOPIC":
                    WebAction.mouseOver(topicToolTipIcon);
                    break;
                case "SUBJECT":
                    WebAction.mouseOver(subjectToolTipIcon);
                    break;
            }

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify Story Name/Topic/Subject tool tip message
     *
     * @param fieldName              - Story Name/Topic/Subject
     * @param expectedToolTipMessage - Expected tool tip message
     * @throws Exception
     */
    public void verifyToolTipMessage(String fieldName, String expectedToolTipMessage) throws Exception {
        try {
            CommonValidations.verifyTextValue(toolTipMessageElement, expectedToolTipMessage, fieldName + " tool tip message is not correct");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify subject field is enabled/disabled
     *
     * @param fieldName         - Field Name
     * @param enabledOrDisabled - Enabled/Disabled
     * @param pageName          - Page Name
     * @throws Exception
     */
    public void verifySubjectFieldIsEnabledOrDisabled(String fieldName, String enabledOrDisabled, String pageName) throws Exception {
        try {
            if (enabledOrDisabled.equalsIgnoreCase("ENABLED")) {
                Waits.waitForElement(addedSubject, WAIT_CONDITIONS.CLICKABLE);
                CommonValidations.verifyElementIsEnabled(subjectTextBox, fieldName + " is disabled in " + pageName + " page");
            } else
                CommonValidations.verifyElementIsDisabledByClass(subjectTextBox, fieldName + " is enabled in " + pageName + " page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill story title
     *
     * @param storyTitle - Story title. 12 digits random alphanumeric string will be appended in the end for automation purpose
     */
    public void fillStoryTitle(String storyTitle) throws Exception {
        try {
            storyTitle = storyTitle + "_" + CommonUtils.generateRandomString(12);
            ExtentReportUtils.addLog(Status.INFO, "<b>Story Title: <i>" + storyTitle + "</i></b>");
            StoryConstants.setStoryTitle(storyTitle);
            WebAction.clearUsingKeys(storyTitleTextBox);
            WebAction.sendKeys(storyTitleTextBox, storyTitle);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify subject is generated automatically and subject code is 4 digits
     *
     * @throws Exception
     */
    public void verifySubjectGenerated() throws Exception {
        try {
            //Verifying subject is generated
            Waits.waitForElement(addedSubject, WAIT_CONDITIONS.CLICKABLE);
            CommonValidations.verifyAttributeValue(addedSubject, "title", " - ", "Subject is not generated, it is empty in subject field");

            //Verifying subject code is 4 digits
            String actualSubject = WebAction.getAttribute(addedSubject, "title");
            String[] actualSubjectArr = actualSubject.split("-");
            CommonValidations.verifyIntegerValues(actualSubjectArr[1].trim().length(), 4, "Subject code is not displayed with 4 digits");
            StoryConstants.setStorySubject(actualSubjectArr[0].trim());
            StoryConstants.setStorySubjectCode(actualSubjectArr[1].trim());
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To remove story subject
     *
     * @throws Exception
     */
    public void removeStorySubject() throws Exception {
        try {
            WebAction.click(removeSubjectIcon);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To validate generated all subject codes
     *
     * @throws Exception
     */
    public void verifyAllGeneratedSubjects() throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        try {
            //Verifying subject is generated
            Waits.waitForElement(addedSubject, WAIT_CONDITIONS.CLICKABLE);

            //Forming expected subject list
            Set<String> expectedSubjectList = new TreeSet<>();
            String storyName = StoryConstants.getStoryTitle(StoryConstants.getStoryCount());
            String[] storyNameList = storyName.split(" ");
            for (String str : storyNameList) {
                switch (str.toUpperCase().trim()) {
                    case "KAMALA", "HARRIS", "DONALD", "TRUMP", "LOUISIANA":
                        expectedSubjectList.add(str + " - " + str.toUpperCase().substring(0, 4));
                        break;
                    case "NY", "LA", "WV":
                        expectedSubjectList.add(str + " - " + str + "XX");
                        break;
                    case "NYC":
                        expectedSubjectList.add(str + " - " + str + "X");
                        break;
                    case "TEST", "STORY", "AUTOMATION":
                        expectedSubjectList.add("MISC - MISC");
                }
            }
            if (storyName.toUpperCase().contains("LOS ANGELES"))
                expectedSubjectList.add("LOS ANGELES - LOSA");
            else if (storyName.toUpperCase().contains("NEW YORK"))
                expectedSubjectList.add("NEW YORK - NEWY");
            else if (storyName.toUpperCase().contains("NORTH CAROLINA"))
                expectedSubjectList.add("NORTH CAROLINA - NORT");
            else if (storyName.toUpperCase().contains("NORTH DAKOTA"))
                expectedSubjectList.add("NORTH DAKOTA - NORT");

            //Fetching actual subject list
            Set<String> actualSubjectList = new TreeSet<>();
            WebAction.click(subjectDropdown);
            Waits.waitUntilElementSizeGreater(By.xpath(dropDownValuesXpath), 0);
            assert driver != null;
            List<WebElement> dropDownElements = driver.findElements(By.xpath(dropDownValuesXpath));
            for (WebElement element : dropDownElements)
                actualSubjectList.add(WebAction.getAttribute(element, "title"));

            //Validating both sets are equal
            Assert.assertEquals(actualSubjectList, expectedSubjectList, "Generated subjects are correct. Expected is " + expectedSubjectList + " and actual is " + actualSubjectList);

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill story description
     *
     * @param storyDescription - Story description
     */
    public void fillStoryDescription(String storyDescription) throws Exception {
        try {
            StoryConstants.setStoryDescription(storyDescription);
            WebAction.click(storyDescriptionTextBox);
            WebAction.sendKeys(storyDescriptionTextBox, storyDescription);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To add topics to story
     *
     * @param dataTable - Topics data table
     */
    public void selectTopic(DataTable dataTable) throws Exception {
        try {
            WebAction.click(topicTextBox);

            //To remove already selected topics
            if (StoryConstants.getStoryTopic(Integer.parseInt(StoryConstants.getStoryCount())) != null) {
                for (int i = 0; i < StoryConstants.getStoryTopicCount(); i++)
                    WebAction.nonEnterableSelectDropDown(dropDownValuesXpath, StoryConstants.getStoryTopic(i), StoryConstants.getStoryTopic(i) + " is not present in the topics drop down");
            }

            //To add topics
            List<Map<String, String>> topics = CucumberUtils.getValuesFromDataTableAsList(dataTable);
            StoryConstants.setStoryTopicCount(topics.size());
            for (int i = 0; i < topics.size(); i++) {
                String topic = topics.get(i).get("Topics");
                StoryConstants.setStoryTopic(i, topic);
                WebAction.nonEnterableSelectDropDown(dropDownValuesXpath, topic, topic + " is not present in the topics drop down");
            }
            WebAction.clickUsingJs(storyDescriptionTextBox);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify topics added are displayed in topic placeholder
     */
    public void verifyAddedTopics() {
        try {
            //To store topic code
            String firstTopic = StoryConstants.getStoryTopic(0);
            StoryConstants.setStoryTopicCode(firstTopic.split("-")[0].trim());

            //Validate added topics
            boolean topicPresent = false;
            int topicCount = StoryConstants.getStoryTopicCount();
            for (int i = 0; i < topicCount; i++) {
                System.out.println("Actual Topic:" + WebAction.getAttribute(addedTopicList.get(i), "title"));
                System.out.println("Expected Topic:" + StoryConstants.getStoryTopic(i));
                if (WebAction.getAttribute(addedTopicList.get(0), "title").trim().equalsIgnoreCase(StoryConstants.getStoryTopic(i))) {
                    topicPresent = true;
                    break;
                }
            }
            Assert.assertTrue(topicPresent, "Selected topics are displayed in topic place holder");

            if (topicCount > 1)
                CommonValidations.verifyAttributeValue(addedTopicList.get(1), "title", "+ " + String.valueOf(topicCount - 1) + " ...", "+ " + String.valueOf(topicCount - 1) + " ..." + " is not selected in topic drop down");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To add tags to story
     *
     * @param storyOrPost - Story/Post
     * @param dataTable   - Tags data table
     */
    public void addTags(String storyOrPost, DataTable dataTable) throws Exception {
        try {
            //To remove already added tags
            if (!addedTagsRemoveIconList.isEmpty()) {
                for (WebElement tagRemoveBtn : addedTagsRemoveIconList)
                    WebAction.click(tagRemoveBtn);
            }

            //To add tags
            List<Map<String, String>> tags = CucumberUtils.getValuesFromDataTableAsList(dataTable);
            if (storyOrPost.equalsIgnoreCase("story"))
                StoryConstants.setStoryTagCount(tags.size());
            else
                PostConstants.setPostTagCount(tags.size());

            for (int i = 0; i < tags.size(); i++) {
                String tag = tags.get(i).get("Tags");
                if (storyOrPost.equalsIgnoreCase("story"))
                    StoryConstants.setStoryTag(i, tag);
                else {
                    PostConstants.setPostTag(i, tag);

                    //Setting ranked story tags
                    StoryConstants.setRankedPostTags(StoryConstants.getRankedPostTagsCount(), tag.toLowerCase());
                    StoryConstants.setRankedPostTagsCount(StoryConstants.getRankedPostTagsCount() + 1);
                }
                WebAction.sendKeys(tagsTextBox, tag);
                WebAction.click(addTagIcon);
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify tags added are displayed in tags placeholder
     */
    public void verifyAddedTags(String storyOrPost) throws Exception {
        try {
            if (storyOrPost.equalsIgnoreCase("STORY")) {
                int tagCount = StoryConstants.getStoryTagCount(Integer.parseInt(StoryConstants.getStoryCount()));
                for (int i = 0; i < tagCount; i++) {
                    String storyTag = StoryConstants.getStoryTag(Integer.parseInt(StoryConstants.getStoryCount()),i);
                    CommonValidations.verifyTextValue(addedTagsList.get(i), storyTag, "'" + storyTag + "' tag is not present in the tag place holder");
                    CommonValidations.verifyElementIsEnabled(addedTagsRemoveIconList.get(i), "Tag remove icon is not displayed for tag '" + storyTag + "'");
                }
            } else if (storyOrPost.equalsIgnoreCase("POST")) {
                int tagCount = PostConstants.getPostTagCount();
                for (int i = 0; i < tagCount; i++) {
                    CommonValidations.verifyTextValue(addedTagsList.get(i), PostConstants.getPostTag(i), "'" + PostConstants.getPostTag(i) + "' tag is not present in the tag place holder");
                    CommonValidations.verifyElementIsEnabled(addedTagsRemoveIconList.get(i), "Tag remove icon is not displayed for tag '" + PostConstants.getPostTag(i) + "'");
                }
            } else Assert.fail("Please enter valid NCX type for tags");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To add slack channel to story
     *
     * @param dataTable - Slack Channel data table
     */
    public void addSlackChannel(DataTable dataTable) throws Exception {
        try {
            // Story slack channel option will be displayed other than JOURNALIST role
            if (!StoryConstants.getUserRole().equalsIgnoreCase("JOURNALIST")) {
                WebAction.scrollIntoView(slackIntegrationTextBox);
                //To remove already added slack channels
                if (!addedslackChannelRemoveIconList.isEmpty()) {
                    for (WebElement slackChannelRemoveBtn : addedslackChannelRemoveIconList)
                        WebAction.click(slackChannelRemoveBtn);
                }

                //To add slack channels
                List<Map<String, String>> slackChannels = CucumberUtils.getValuesFromDataTableAsList(dataTable);
                StoryConstants.setStorySlackChannelCount(slackChannels.size());
                for (int i = 0; i < slackChannels.size(); i++) {
                    String slackChannel = slackChannels.get(i).get("Slack Channels");
                    StoryConstants.setStorySlackChannel(i, slackChannel);
                    WebAction.sendKeys(slackIntegrationTextBox, slackChannel);
                    WebAction.click(slackChannelAddIcon);
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify slack channel added are displayed in slack channel placeholder
     */
    public void verifyAddedSlackChannels() {
        try {
            // Story slack channels will be displayed other than JOURNALIST role
            if (!StoryConstants.getUserRole().equalsIgnoreCase("JOURNALIST")) {
                int slackChannelCount = StoryConstants.getStorySlackChannelCount();
                for (int i = 0; i < slackChannelCount; i++) {
                    CommonValidations.verifyTextValue(addedslackChannelList.get(i), StoryConstants.getStorySlackChannel(i), "'" + StoryConstants.getStorySlackChannel(i) + "' channel is not present in the slack channel place holder");
                    CommonValidations.verifyElementIsEnabled(addedslackChannelRemoveIconList.get(i), "Slack channel delete icon is not displayed for slack channel '" + StoryConstants.getStorySlackChannel(i) + "'");
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click button in create/edit story page
     *
     * @param buttonName - button name
     */
    public void clickButton(String buttonName, String pageType) throws Exception {
        try {
            switch (buttonName.toUpperCase()) {
                case "CANCEL":
                    WebAction.click(cancelButton);
                    break;
                case "SAVE DRAFT":
                    WebAction.click(saveDraftButton);
                    StoryConstants.setDraftStoryCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                    StoryConstants.setDraftStoryCreationDate(DateFunctions.getCurrentDate("M/d/yy"));
                    StoryConstants.setStoryCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                    StoryConstants.setStoryCreationDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    break;
                case "PREVIEW":
                    WebAction.click(previewButton);
                    break;
                case "PUBLISH":
                    WebAction.click(publishButton);
                    if ((pageType.equalsIgnoreCase("CREATE")) || (pageType.equalsIgnoreCase("PREVIEW"))) {
                        StoryConstants.setStoryCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                        StoryConstants.setStoryCreationDate(DateFunctions.getCurrentDate("MM/dd/yyyy"));
                    }

                    //To check 'The Story has been successfully updated' is displayed
                    Waits.waitForElement(storyPublishMessage, WAIT_CONDITIONS.VISIBLE);
                    Waits.waitForElementToDisappear(storyPublishMessage);

                    break;
                default:
                    Assert.fail("Please provide valid button name in create/edit story page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click publish button
     */
    public void clickPublishButtonWithoutFilling() throws Exception {
        try {
            WebAction.click(publishButton);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story is saved as draft message is displayed
     *
     * @param expectedStoryDraftMessage - Expected story draft message
     * @throws Exception
     */
    public void verifyStorySavedAsDraftMessage(String expectedStoryDraftMessage) throws Exception {
        try {
            Waits.waitForElement(savedAdDraftMessage, WAIT_CONDITIONS.VISIBLE);
            CommonValidations.verifyTextValue(savedAdDraftMessage, expectedStoryDraftMessage, "Story saved as draft message is not correct");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

}