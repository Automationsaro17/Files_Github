package nbcu.automation.ui.pages.ncx;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.AngleConstants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HomePage {

    /**
     * Loader icon
     */
    @FindBy(xpath = "//*[@loadertype='SECTION_LOADER']/div[contains(@class,'loader section')]")
    WebElement pageLoadingSpinner;

    /**
     * Ready Column Elements
     */

    @FindBy(xpath = "//div[span[text()='Ready']]/following-sibling::div[@class='options']/button[i[@nztype='search']]")
    WebElement readyColumnSearchIcon;

    @FindBy(xpath = " //input[contains(@placeholder,'Ready')]")
    WebElement readyColumnSearchTextBox;

    @FindBy(xpath = "//span[text()='Ready']/../../../following-sibling::app-scroll-container//a[@class='title']")
    List<WebElement> readyColumStoryTitles;

    /**
     * Working Column Elements
     */
    @FindBy(xpath = "//div[span[text()='Working']]/following-sibling::div[@class='options']/button[i[@nztype='search']]")
    WebElement workingColumnSearchIcon;

    @FindBy(xpath = "//input[contains(@placeholder,'Working')]")
    WebElement workingColumnSearchTextBox;

    @FindBy(xpath = "//span[text()='Working']/../../../following-sibling::app-scroll-container//a[@class='title']")
    List<WebElement> workingColumStoryTitles;

    /**
     * Header elements
     */
    @FindBy(xpath = "//button[contains(@class,'plusIcon')]")
    WebElement plusIcon;

    @FindBy(xpath = "//*[@routerlink='ncx/profile']")
    WebElement profileIcon;

    @FindBy(xpath = "//button[contains(text(),'Logout')]")
    WebElement logOut;

    @FindBy(xpath = "//*[text()='Signed in (NBCUniversal)']")
    WebElement chooseAccountToLogOff;

    @FindBy(name = "header")
    WebElement frame;

    @FindBy(id = "login_workload_logo_text")
    WebElement logOutConfirmation;

    @FindBy(xpath = "//input[@data-id='global-search-input']")
    WebElement globalSearchBar;

    @FindBy(xpath = "//h3[text()='Stories/Groups']/following-sibling::div[1]//span")
    List<WebElement> storyOrGroupsSearchResult;

    @FindBy(xpath = "//h3[text()='Stories/Groups']/following-sibling::div[1]/p")
    WebElement storysOrGroupsSearchResultNoResults;

    @FindBy(xpath = "//h3[contains(text(),'Angles')]/following-sibling::div[1]/p")
    WebElement anglesSearchResultNoResults;

    @FindBy(xpath = "//h3[text()='Posts']/following-sibling::div[1]/p")
    WebElement postsSearchResultNoResults;

    @FindBy(xpath = "//h3[text()='Posts']/following::div[1]/a/span[@class='separate-line']")
    List<WebElement> searchResultPostTitles;

    @FindBy(xpath = "//h3[text()='Stories/Groups']/following::div[1]/a/span")
    List<WebElement> searchResultStoryTitles;

    @FindBy(xpath = "//h3[text()='Stories/Groups']/following::div[2]")
    List<WebElement> searchResultStoryIds;

    @FindBy(xpath = "//h3[contains(text(),'Angles')]/following::div[1]/a/div[1]/div[2]/span")
    List<WebElement> searchResultAngleTitles;

    /**
     * Collapse/Expand left side menu
     */
    @FindBy(xpath = "//div[@class='left-side']/button/i")
    WebElement leftSideMenuCollapse;

    /**
     * Left side menu elements
     */
    @FindBy(xpath = "//a[@title='NewsConnect']")
    WebElement homePageLink;

    @FindBy(xpath = "//a[text()='Drafts']")
    WebElement draftsPageLink;

    @FindBy(xpath = "//a[text()='Search']")
    WebElement searchResultsPageLink;

    /**
     * Angle page elements
     */
    @FindBy(xpath = "//div[contains(@class,'overview')]/p")
    WebElement angleDescription;

    public HomePage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify home page loaded
     */
    public void verifyHomePageLoaded() throws Exception {
        try {
            WebAction.refreshPage();
            Waits.waitForElement(readyColumnSearchIcon, WAIT_CONDITIONS.CLICKABLE);
            Waits.waitForElement(workingColumnSearchIcon, WAIT_CONDITIONS.CLICKABLE);
            if (WebAction.getAttribute(leftSideMenuCollapse, "class").contains("menu-fold"))
                WebAction.clickUsingJs(leftSideMenuCollapse);

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click on Plus icon
     */
    public void clickCreateContentButton() throws Exception {
        try {
            Waits.waitForElement(plusIcon, WAIT_CONDITIONS.CLICKABLE);
            WebAction.click(plusIcon);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To generate full/partial story id based on search type and partial search combination
     *
     * @param searchType - Search Type
     * @param params     - Partial Search Combination
     * @throws Exception
     */
    public String generateFullOrPartialStoryId(String searchType, DataTable params) throws Exception {
        String searchText = StoryConstants.getStoryId(StoryConstants.getStoryCount());
        try {
            if (searchType.equalsIgnoreCase("PARTIAL")) {
                String partialSearchCombination = CucumberUtils.getValuesFromDataTable(params, "Search Criteria");
                if (partialSearchCombination.equalsIgnoreCase("TOPIC ID WITH YEAR"))
                    searchText = searchText.substring(0, 4);
                else if (partialSearchCombination.equalsIgnoreCase("YEAR WITH SUBJECT CODE"))
                    searchText = searchText.substring(2, 8);
                else if (partialSearchCombination.equalsIgnoreCase("SUBJECT CODE WITH NUMBER"))
                    searchText = searchText.substring(4);
            }
            StoryConstants.setSearchKeyword(searchText);

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
        return searchText;
    }


    /**
     * Search with Full/Partial story ID in Working/Ready Column
     *
     * @param columnName - Column Name
     * @param searchType - FULL/PARTIAL
     * @param params     - TOPIC ID WITH YEAR/YEAR WITH SUBJECT CODE/SUBJECT CODE WITH NUMBER
     * @throws Exception
     */
    public void fillFullPartialStoryIdInReadyOrWorkingColumn(String columnName, String searchType, DataTable params) throws Exception {
        try {
            String searchText = generateFullOrPartialStoryId(searchType, params);
            System.out.println("Search Text:" + searchText);
            if (columnName.equalsIgnoreCase("WORKING")) {
                if (!WebAction.isDisplayed(workingColumnSearchTextBox))
                    WebAction.click(workingColumnSearchIcon);
                WebAction.sendKeys(workingColumnSearchTextBox, searchText);
                WebAction.keyPress(workingColumnSearchTextBox, "ENTER");
            } else {
                if (!WebAction.isDisplayed(readyColumnSearchTextBox))
                    WebAction.click(readyColumnSearchIcon);
                WebAction.sendKeys(readyColumnSearchTextBox, searchText);
                WebAction.keyPress(readyColumnSearchTextBox, "ENTER");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story id search results in Working/Ready column
     *
     * @param columnName - WORKING/READY
     * @param searchType - FULL/PARTIAL
     * @throws Exception
     */
    public void verifyStoryIdSearchResults(String searchType, String columnName) throws Exception {
        try {
            //Wait for spinner to close
            Waits.waitForElement(pageLoadingSpinner, WAIT_CONDITIONS.VISIBLE);
            Waits.waitForElement(pageLoadingSpinner, WAIT_CONDITIONS.INVISIBLE);

            List<WebElement> storyTitleList = null;
            if (columnName.equalsIgnoreCase("WORKING")) {
                storyTitleList = workingColumStoryTitles;
            } else {
                storyTitleList = readyColumStoryTitles;
            }
            for (WebElement element : storyTitleList) {
                String parentWindow = WebAction.getCurrentWindowId();
                int currentWindowSize = WebAction.getWindowsSize();
                WebAction.click(element);
                WebAction.switchToNewWindow(currentWindowSize + 1);
                new StoryLandingPage().verifyStoryLandingPageLoaded();
                new StoryLandingPage().verifyStoryId(StoryConstants.getSearchKeyword());
                WebAction.closeCurrentWindow();
                WebAction.switchToWindow(parentWindow);
            }

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill search text in global search bar
     *
     * @param searchText - Search text
     */
    public void fillSearchTextInGlobalSearch(String searchCategory, String searchType, String searchField, String searchText) throws Exception {
        try {
            if ((searchText == null) || !searchField.equalsIgnoreCase("TITLE")) {
                if (searchCategory.equalsIgnoreCase("STORY"))
                    searchText = StoryConstants.getStoryTitle(StoryConstants.getStoryCount());
                else if (searchCategory.equalsIgnoreCase("POST"))
                    searchText = PostConstants.getPostTitle(PostConstants.getPostCount());
                else if (searchCategory.equalsIgnoreCase("ANGLE"))
                    searchText = AngleConstants.getAngleTitle(AngleConstants.getAngleCount());
                else
                    Assert.fail("Given search category '" + searchCategory + "' is not found. Please enter valid search category");
            }

            // Setting search text
            if (searchCategory.equalsIgnoreCase("STORY"))
                StoryConstants.setSearchKeyword(searchText);
            else if (searchCategory.equalsIgnoreCase("POST"))
                PostConstants.setSearchKeyword(searchText);
            else if (searchCategory.equalsIgnoreCase("ANGLE"))
                AngleConstants.setSearchKeyword(searchText);
            else
                Assert.fail("Given search category '" + searchCategory + "' is not found. Please enter valid search category");

            Waits.waitForElement(globalSearchBar, WAIT_CONDITIONS.CLICKABLE);
            // Updating double quotes in search text for exact search
            if (searchType.equalsIgnoreCase("WITH"))
                searchText = "\"" + searchText + "\"";

            WebAction.sendKeys(globalSearchBar, searchText);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify no search result is displayed
     *
     * @param searchCategory - Search Category
     */
    public void verifyNoSearchResult(String searchCategory) throws Exception {
        try {
            switch (searchCategory.toUpperCase()) {
                case "STORY", "GROUP":
                    Waits.waitForElement(storysOrGroupsSearchResultNoResults, WAIT_CONDITIONS.VISIBLE);
                    break;
                case "POST":
                    Waits.waitForElement(postsSearchResultNoResults, WAIT_CONDITIONS.VISIBLE);
                    break;
                case "ANGLE":
                    Waits.waitForElement(anglesSearchResultNoResults, WAIT_CONDITIONS.VISIBLE);
                    break;
                default:
                    Assert.fail("Please enter valid search category");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Verify and open STORY/POST/ANGLE
     *
     * @param searchCategory - Search Category
     */
    public void verifySearchResultAndOpen(String searchCategory) throws Exception {
        List<WebElement> searchResults = new ArrayList<>();
        String searchText = null;
        try {
            switch (searchCategory.toUpperCase()) {
                case "STORY", "GROUP":
                    Waits.waitUntilElementSizeGreater(searchResultStoryTitles, 0);
                    searchResults.addAll(searchResultStoryTitles);
                    Assert.assertFalse(searchResultStoryTitles.isEmpty(), "No search result is displayed under Stories/Groups in global search");
                    searchText = StoryConstants.getSearchKeyword();
                    break;
                case "POST":
                    Waits.waitUntilElementSizeGreater(searchResultPostTitles, 0);
                    searchResults.addAll(searchResultPostTitles);
                    Assert.assertFalse(searchResultPostTitles.isEmpty(), "No search result is displayed under Posts in global search");
                    searchText = PostConstants.getSearchKeyword();
                    break;
                case "ANGLE":
                    Waits.waitUntilElementSizeGreater(searchResultAngleTitles, 0);
                    searchResults.addAll(searchResultAngleTitles);
                    Assert.assertFalse(searchResultAngleTitles.isEmpty(), "No search result is displayed under Angle in global search");
                    searchText = AngleConstants.getSearchKeyword();
                    break;
                default:
                    Assert.fail("Please enter valid search category");
            }

            boolean storyOrPostPresent = false;
            for (WebElement element : searchResults) {
                if (WebAction.getText(element).toLowerCase().contains(searchText.toLowerCase())) {
                    int totalWindowCount = WebAction.getWindowsSize();
                    storyOrPostPresent = true;
                    WebAction.click(element);
                    Waits.waitForNumberOfWindowsToBe(totalWindowCount + 1);
                    List<String> windowIdsList = WebAction.getWindowIdsList();
                    WebAction.switchToWindow(windowIdsList.get(windowIdsList.size() - 1));
                    break;
                }
            }

            Assert.assertTrue(storyOrPostPresent, searchCategory + " '" + searchText + "' is not present in global search result");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify invisible eye is displayed for private angle and invisible eye icon is not displayed for public angle
     *
     * @param visibility - Not Displayed/Displayed
     */
    public void verifyInvisibleEyeIcon(String visibility, String anglePrivacy) throws Exception {
        try {
            Waits.waitUntilElementSizeGreater(searchResultAngleTitles, 0);
            Assert.assertFalse(searchResultAngleTitles.isEmpty(), "No search result is displayed under Angle in global search");
            String searchText = AngleConstants.getAngleTitle(AngleConstants.getAngleCount());

            boolean anglePresent = false;
            for (int i = 0; i < searchResultAngleTitles.size(); i++) {
                if (WebAction.getText(searchResultAngleTitles.get(i)).toLowerCase().contains(searchText.toLowerCase())) {
                    anglePresent = true;

                    if (visibility.equalsIgnoreCase("NOT DISPLAYED")) {
                        try {
                            WebElement eyeIconElement = searchResultAngleTitles.get(i).findElement(By.xpath("../preceding::div[1]/span"));
                            CommonValidations.verifyAttributeValue(eyeIconElement, "class", "hidden-icon", "Invisible eye icon is displayed for " + anglePrivacy + " angle " + searchText + " in global search preview page");
                        } catch (Exception ignore) {

                        }
                    } else
                        CommonValidations.verifyAttributeValue(searchResultAngleTitles.get(i).findElement(By.xpath("../preceding::div[1]/span")), "class", "invisible-icon", "Invisible eye icon is not displayed for " + anglePrivacy + " angle " + searchText + " in global search preview page");
                    break;
                }
            }
            Assert.assertTrue(anglePresent, anglePresent + " angle is not present in global search preview page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * To verify search results are displayed based on search keyword
     *
     * @param searchCategory - Search Category
     */
    public void verifyGlobalSearchResultBasedOnKeyword(String searchCategory, String searchType) throws Exception {
        try {
            switch (searchCategory.toUpperCase()) {
                case "STORY", "GROUP":
                    break;
                case "POST":
                    break;
                case "ANGLE":
                    verifyAngleGlobalSearchResult(searchType);
                    break;
                default:
                    Assert.fail("Please enter valid search category");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Verify angle search results displayed based on search keyboard
     *
     * @throws Exception
     */
    public void verifyAngleGlobalSearchResult(String searchType) throws Exception {
        try {
            Thread.sleep(2000);
            Waits.waitUntilElementSizeGreater(searchResultAngleTitles, 0);
            Assert.assertFalse(searchResultAngleTitles.isEmpty(), "No search result is displayed under Angle in global search");

            //Forming expected words
            String searchText = AngleConstants.getSearchKeyword();
            List<String> expectedWords = new ArrayList<>();
            if (searchType.equalsIgnoreCase("WITH"))
                expectedWords.add(searchText);
            else
                expectedWords = Arrays.stream(searchText.split(" ")).toList();

            //Verify search result contains search text
            for (WebElement searchElement : searchResultAngleTitles) {
                int searchTextPresentCount = 0;
                for (String expectedString : expectedWords) {
                    if (WebAction.getText(searchElement).toLowerCase().contains(expectedString.toLowerCase())) {
                        searchTextPresentCount = searchTextPresentCount + 1;

                        int boldHighlightCount = 0;
                        List<WebElement> searchTextElements = searchElement.findElements(By.xpath("b"));

                        for (WebElement searchTextElement : searchTextElements) {
                            // Verify search text highlighted in bold
                            if (WebAction.getText(searchTextElement).equalsIgnoreCase(expectedString)) {
                                boldHighlightCount = boldHighlightCount + 1;
                                // Verify search text highlighted in purple color
                                CommonValidations.verifyColorOfElement(searchTextElement, "color", "purple");
                            }
                        }
                        Assert.assertTrue(boldHighlightCount > 0, "Bold highlight is missing in angle '" + WebAction.getText(searchElement) + "' for search text '" + expectedString + "'");
                    }
                }
                // If Search text is not present in angle title, then opening angle and checking angle description
                if (searchTextPresentCount == 0) {
                    String parentWindow = WebAction.getCurrentWindowId();
                    int windowSize = WebAction.getWindowsSize();
                    WebAction.clickUsingJs(searchElement);
                    WebAction.switchToNewWindow(windowSize + 1);
                    AngleLandingPage angleLandingPage = new AngleLandingPage();
                    angleLandingPage.verifyAngleLandingPageLoaded();
                    for (String expectedString : expectedWords) {
                        angleLandingPage.verifyAngleOverView();
                        if (WebAction.getText(angleDescription).toLowerCase().contains(expectedString.toLowerCase())) {
                            searchTextPresentCount = searchTextPresentCount + 1;
                        }
                    }
                }

                Assert.assertNotEquals(searchTextPresentCount, 0, WebAction.getText(searchElement) + " angle in search result does not contain search text '" + searchText + "'");
            }

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To open profile page
     */
    public void clickProfile() throws Exception {
        try {
            WebAction.click(profileIcon);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To log out of application
     */
    public void logOut() throws Exception {
        try {
            clickProfile();
            WebAction.mouseOverAndClick(profileIcon, logOut);
            WebAction.click(chooseAccountToLogOff);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To open side menu pages
     *
     * @param menuName - Menu Name
     */
    public void openLeftSideMenu(String menuName) throws Exception {
        try {
            switch (menuName.toUpperCase()) {
                case "HOME":
                    WebAction.click(homePageLink);
                    break;
                case "DRAFTS":
                    WebAction.clickUsingJs(leftSideMenuCollapse);
                    WebAction.click(draftsPageLink);
                    WebAction.clickUsingJs(leftSideMenuCollapse);
                    break;
                case "STORIES":
                    break;
                case "SEARCH":
                    WebAction.click(leftSideMenuCollapse);
                    WebAction.click(searchResultsPageLink);
                    WebAction.click(leftSideMenuCollapse);
                    break;
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify application logged out
     */
    public void verifyApplicationLoggedOut() throws Exception {
        try {
            Waits.waitForElement(logOutConfirmation, WAIT_CONDITIONS.VISIBLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To open post using url
     */
    public void openPost() throws Exception {
        try {
            WebAction.navigateTo(PostConstants.getPostUrl());
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * To verify and open story from working column
     */
    public void verifyAndOpenStoryFromWorkingColumn() throws Exception {
        boolean storyPresent = false;
        try {
            Waits.waitForElement(workingColumnSearchIcon, WAIT_CONDITIONS.CLICKABLE);
            Waits.waitUntilElementSizeGreater(workingColumStoryTitles, 0);
            String expectedStoryTitle = StoryConstants.getStoryTitle(StoryConstants.getStoryCount());
            for (WebElement element : workingColumStoryTitles) {
                if (WebAction.getText(element).equalsIgnoreCase(expectedStoryTitle)) {
                    storyPresent = true;
                    int currentWindowSize = WebAction.getWindowsSize();
                    WebAction.click(element);
                    WebAction.switchToNewWindow(currentWindowSize + 1);
                    break;
                }
            }

            Assert.assertTrue(storyPresent, expectedStoryTitle + " is not present in the working column of home page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify and open story from Ready column
     */
    public void verifyAndOpenStoryFromReadyColumn() throws Exception {
        boolean storyPresent = false;
        try {
            Waits.waitForElement(readyColumnSearchIcon, WAIT_CONDITIONS.CLICKABLE);
            Waits.waitUntilElementSizeGreater(readyColumStoryTitles, 0);
            String expectedStoryTitle = StoryConstants.getStoryTitle(StoryConstants.getStoryCount());
            for (WebElement element : readyColumStoryTitles) {
                if (WebAction.getText(element).equalsIgnoreCase(expectedStoryTitle)) {
                    storyPresent = true;
                    int currentWindowSize = WebAction.getWindowsSize();
                    WebAction.click(element);
                    WebAction.switchToNewWindow(currentWindowSize + 1);
                    break;
                }
            }

            Assert.assertTrue(storyPresent, expectedStoryTitle + " is not present in the ready column of home page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Search with Full/Partial story ID in global Search
     *
     * @param searchType - FULL/PARTIAL
     * @param params     - TOPIC ID WITH YEAR/YEAR WITH SUBJECT CODE/SUBJECT CODE WITH NUMBER
     * @throws Exception
     */
    public void fillFullPartialStoryIdInGlobalSearch(String searchType, DataTable params) throws Exception {
        try {
            String searchText = generateFullOrPartialStoryId(searchType, params);
            Waits.waitForElement(globalSearchBar, WAIT_CONDITIONS.CLICKABLE);
            WebAction.sendKeys(globalSearchBar, searchText);

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story id is present in global search preview
     *
     * @param searchType - FULL/PREVIEW
     * @throws Exception
     */
    public void verifyStorySearchResultBasedOnStoryId(String searchType) throws Exception {
        try {
            Thread.sleep(3000);
            String searchText = StoryConstants.getSearchKeyword();
            Waits.waitUntilElementSizeGreater(searchResultStoryIds, 0);
            Assert.assertFalse(searchResultStoryIds.isEmpty(), "No search result is displayed under Stories in global search when user searches with story id " + searchText);
            for (WebElement element : searchResultStoryIds)
                CommonValidations.verifyTextValue(element, searchText, searchType + " Story Id '" + searchText + "' is missing in global search preview result");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

}
