package nbcu.automation.ui.pages.ncx;

import nbcu.automation.ui.constants.ncx.Constants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.encryption.PasswordEncryption;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginPage {

    @FindBy(name = "loginfmt")
    WebElement userNameTextBox;

    String userAccountSelection = "//div[contains(text(),'<<sso>>')]";

    @FindBy(id = "idSIButton9")
    WebElement nextButton;

    @FindBy(name = "passwd")
    WebElement passwordTextBox;

    @FindBy(xpath = "//div[text()='Stay signed in?']")
    WebElement staySignedInElement;

    public LoginPage() {
        Constants.initConstants();
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To open NCX rights management application in different environment
     */
    public void openApplication() throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        String environment, applicationUrl = "";
        try {
            // Fetch the application url based on application and environment
            environment = ConfigFileReader.getProperty("Environment");
            applicationUrl = switch (environment.toUpperCase()) {
                case "QA" -> ConfigFileReader.getProperty("ncx-app-url_Qa");
                case "QAUI" -> ConfigFileReader.getProperty("ncx-app-url_QaUI");
                case "STG" -> ConfigFileReader.getProperty("ncx-app-url_Stg");
                case "STGUI" -> ConfigFileReader.getProperty("ncx-app-url_StgUI");
                case "PROD" -> ConfigFileReader.getProperty("ncx-app-url_Prod");
                default -> applicationUrl;
            };

            // Launch the application
            if (driver != null)
                driver.get(applicationUrl);
            else Assert.fail("Browser is not launched");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify sign in page is displayed
     * <p>
     * - exception
     */
    public void verifySignInPageDisplayed() throws Exception {
        Waits.waitForElement(userNameTextBox, WAIT_CONDITIONS.VISIBLE);
    }

    /**
     * To Login NCX rights management application
     *
     * @param role - NCX Role
     */
    public void loginIntoApplication(String role) throws Exception {
        WebDriver driver = DriverFactory.getCurrentDriver();
        String userName = "", password = "";
        try {
            StoryConstants.setUserRole(role);
            switch (role.toUpperCase()) {
                case "READ ONLY":
                    userName = ConfigFileReader.getProperty("ncx-ReadOnly-username");
                    password = ConfigFileReader.getProperty("ncx-ReadOnly-password");
                    break;
                case "JOURNALIST":
                    userName = ConfigFileReader.getProperty("ncx-Journalist-username");
                    password = ConfigFileReader.getProperty("ncx-Journalist-password");
                    break;
                case "EDITOR":
                    userName = ConfigFileReader.getProperty("ncx-Editor-username");
                    password = ConfigFileReader.getProperty("ncx-Editor-password");
                    break;
                case "SENIOR EDITOR":
                    userName = ConfigFileReader.getProperty("ncx-SeniorEditor-username");
                    password = ConfigFileReader.getProperty("ncx-SeniorEditor-password");
                    break;
                case "STANDARDS":
                    userName = ConfigFileReader.getProperty("ncx-Standards-username");
                    password = ConfigFileReader.getProperty("ncx-Standards-password");
                    break;
                case "ADMIN":
                    userName = ConfigFileReader.getProperty("ncx-Admin-username");
                    password = ConfigFileReader.getProperty("ncx-Admin-password");
                    break;
                default:
                    Assert.fail("Please enter valid role name for login into NCX application");
            }

            userName = userName + "@tfayd.com";
            if (WebAction.isDisplayed(userNameTextBox))
                WebAction.sendKeys(userNameTextBox, userName);
            else {
                assert driver != null;
                WebAction.click(driver.findElement(By.xpath(userAccountSelection.replace("<<sso>>", userName))));
            }
            WebAction.click(nextButton);
            String decryptedPassword = PasswordEncryption.decrypt(password);
            Waits.waitForElement(passwordTextBox, WAIT_CONDITIONS.VISIBLE);
            WebAction.sendKeys(passwordTextBox, decryptedPassword);
            WebAction.click(nextButton);
            Waits.waitForElement(staySignedInElement, WAIT_CONDITIONS.VISIBLE);
            WebAction.click(nextButton);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

}
