package nbcu.automation.ui.pages.ncx;

import com.aventstack.extentreports.Status;
import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.AngleConstants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.report.ExtentReportUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class PostDetailsPage {

    String searchDropDownValuesXpath = "//nz-auto-option[contains(@class,'ant-select-item ant-select-item-option')]/div";

    /**
     * Post Details Elements
     */
    @FindBy(xpath = "//a[@class='postTitleDetails']")
    WebElement postTitleElement;

    @FindBy(xpath = "//div[contains(@class,'postDescription')]")
    WebElement postDescriptionElement;

    @FindBy(xpath = "//div[text()='Created By:']/following-sibling::div/button[@class='created-updated-profile']")
    WebElement postCreatorNameElement;

    @FindBy(xpath = "//div[text()='Created By:']/following-sibling::div/button[@class='created-updated-profile']/following::span[1]")
    WebElement postCreationDateElement;

    @FindBy(xpath = "//div[text()='Created By:']/following-sibling::div/button[@class='created-updated-profile']/following::span[2]")
    WebElement postCreationTimeElement;

    @FindBy(xpath = "//div[text()='Modified By:']/following-sibling::div/button[@class='created-updated-profile']")
    WebElement postModifierNameElement;

    @FindBy(xpath = "//div[text()='Modified By:']/following-sibling::div/button[@class='created-updated-profile']/following::span[1]")
    WebElement postModifiedDateElement;

    @FindBy(xpath = "//div[text()='Modified By:']/following-sibling::div/button[@class='created-updated-profile']/following::span[2]")
    WebElement postModifiedTimeElement;

    /**
     * Standards Guidance Elements
     */
    @FindBy(xpath = "//div[@class='standard-guidance-title']")
    WebElement standardGuidanceSectionTitleElement;

    @FindBy(xpath = "//div[@class='standard-guidance-text']/span/p")
    WebElement standardGuidanceSectionContentElement;

    @FindBy(xpath = "//div[@class='standardGuidanceSection']//div[contains(@class,'created-updated-text')]/span")
    List<WebElement> standardGuidanceCreationDetailElements;

    /**
     * Reportable Approver Elements
     */
    @FindBy(xpath = "//*[@nzheader='Reportable Approver']")
    WebElement reportableApproverTitleElement;

    @FindBy(xpath = "//*[@nzheader='Reportable Approver']//span[contains(@class,'elementDetailsText')]")
    WebElement reportableApproverNotesElement;

    @FindBy(xpath = "//*[@nzheader='Reportable Approver']//span[@class='officialApprovalText']")
    WebElement reportableApproverName;

    /**
     * Limited license Elements
     */
    @FindBy(xpath = "//*[@nzheader='License Limitations']/div[1]")
    WebElement limitedLicenseTitleElement;

    @FindBy(xpath = "//*[@nzheader='License Limitations']/div[2]//span[@class='elementDetailsText']")
    WebElement limitedLicenseTextElement;

    /**
     * Attachment Elements
     */
    @FindBy(xpath = "//div[contains(@class,'view-attachments')]/*/*")
    List<WebElement> attachmentElements;

    /**
     * Element Details Section Elements
     */
    @FindBy(xpath = "//div[text()='Link to Source:']/following-sibling::div/a")
    WebElement linkToSourceElement;

    @FindBy(xpath = "//div[text()='Mandatory Credit:']/following-sibling::div")
    WebElement mandatoryCreditElement;

    @FindBy(xpath = "//div[text()='Cleared for NBCU Partners?']/following-sibling::div[1]")
    WebElement clearedForNbcuParternsElement;

    /**
     * Linked story/angle Elements
     */

    @FindBy(xpath = "//span[contains(text(),'Linked Stories')]")
    WebElement linkedStoriesTab;

    @FindBy(xpath = "//a[@class='story-text']")
    List<WebElement> linkedStoriesNameList;

    @FindBy(xpath = "//div[contains(@class,'story-id')]")
    List<WebElement> linkedStoriesIdList;

    @FindBy(xpath = "//*[@nzheader='Linked Angles']/div[@role='button']")
    WebElement linkedAnglesTab;

    @FindBy(xpath = "//a[@class='angle-text']")
    List<WebElement> linkedAnglesList;

    @FindBy(xpath = "//a[@class='angle-text']/../preceding::div[1]/span")
    List<WebElement> linkedAnglesInvisibleList;

    /**
     * Labels Elements
     */
    @FindBy(xpath = "//div[@class='postLabels']/app-post-labels/nz-tag")
    List<WebElement> postLabelElements;

    /**
     * Count Elements
     */
    @FindBy(xpath = "//div[@class='count-section']/div/app-info-attachments//span[@class='count']")
    WebElement attachmentCountElement;

    @FindBy(xpath = "//div[@class='count-section']/div/app-info-comments//span[@class='count']")
    WebElement commentCountElement;

    @FindBy(xpath = "//div[@class='count-section']/div/app-info-share//button")
    WebElement shareIcon;

    /**
     * Add Comments Elements
     */
    @FindBy(xpath = "//textarea[@placeholder='Enter new comment here']")
    WebElement commentTextBox;

    @FindBy(id = "rteCustomLink")
    WebElement addCommentButton;

    @FindBy(xpath = "//div[@class='ant-message']//span[contains(text(), 'The comment was successfully added')]")
    WebElement commentAddedMessageElement;

    /**
     * Added comments Elements
     */
    @FindBy(xpath = "//div[contains(@class,'comments')]//button[@class='name']")
    List<WebElement> commentAddedByElement;

    @FindBy(xpath = "//div[contains(@class,'comments')]//div[@class='options']/button/i[@nztype='delete']")
    List<WebElement> commentAddedDeleteIcon;

    @FindBy(xpath = "//div[contains(@class,'comments')]//div[@class='options']/button/i[@nztype='edit']")
    List<WebElement> commentAddedEditIcon;

    @FindBy(xpath = "//div[contains(@class,'comments')]//div[@class='comment']/pre")
    List<WebElement> commentAddedText;

    /**
     * Editorial/Standards labels in meta data
     */
    @FindBy(xpath = "//span[normalize-space()=\"REPORTABLE\"]/preceding-sibling::span[1]")
    WebElement reportableLabel;

    @FindBy(xpath = "//span[normalize-space()=\"NOT REPORTABLE\"]/preceding-sibling::span[1]")
    WebElement notReportableLabel;

    @FindBy(xpath = "//span[normalize-space()=\"VERIFIED\"]/preceding-sibling::span[1]")
    WebElement verifiedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"PUBLISHED/AIRED\"]/preceding-sibling::span[1]")
    WebElement publishedOrAiredLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LOG\"]/preceding-sibling::span[1]")
    WebElement logLabel;

    @FindBy(xpath = "//span[normalize-space()=\"GREAT VIDEO\"]/preceding-sibling::span[1]")
    WebElement greatVideoLabel;

    @FindBy(xpath = "//span[normalize-space()=\"IMPORTANT\"]/preceding-sibling::span[1]")
    WebElement importantLabel;

    @FindBy(xpath = "//span[normalize-space()=\"HOT\"]/preceding-sibling::span[1]")
    WebElement hotLabel;

    @FindBy(xpath = "//span[normalize-space()=\"STANDARDS\"]/preceding-sibling::span[1]")
    WebElement standardsLabel;

    /**
     * R&C/Legal labels in meta data
     */
    @FindBy(xpath = "//span[normalize-space()=\"CLEARED\"]/preceding-sibling::span[1]")
    WebElement clearedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LICENSED\"]/preceding-sibling::span[1]")
    WebElement licensedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LIMITED LICENSE\"]/preceding-sibling::span[1]")
    WebElement limitedLicensedLabel;

    @FindBy(xpath = "//span[normalize-space()=\"NEEDS LICENSING\"]/preceding-sibling::span[1]")
    WebElement needsLicensingLabel;

    @FindBy(xpath = "//span[normalize-space()=\"COPYRIGHT RISK\"]/preceding-sibling::span[1]")
    WebElement copyRightRiskLabel;

    @FindBy(xpath = "//span[normalize-space()=\"DO NOT USE\"]/preceding-sibling::span[1]")
    WebElement doNotUseLabel;

    @FindBy(xpath = "//span[normalize-space()=\"LEGAL\"]/preceding-sibling::span[1]")
    WebElement legalLabel;

    /**
     * Topic Elements
     */
    @FindBy(xpath = "//*[contains(@class,'topics-label')]/div")
    List<WebElement> topicsList;

    /**
     * Tag Elements
     */
    @FindBy(xpath = "//*[contains(@class,'tagLabel')]/label")
    List<WebElement> tagsList;

    /**
     * Button Elements
     */
    @FindBy(xpath = "//button[span[normalize-space()='Edit']]")
    WebElement editButton;

    @FindBy(xpath = "//button[span[normalize-space()='Link To Angle']]")
    WebElement linkToAngleButton;

    @FindBy(xpath = "//button[span[normalize-space()='Send to WG01/06']]")
    WebElement sendToWg0106Button;

    @FindBy(xpath = "//button[span[normalize-space()='Move']]")
    WebElement moveButton;

    @FindBy(xpath = "//button[span[normalize-space()='Delete']]")
    WebElement deleteButton;

    @FindBy(xpath = "//button[span[normalize-space()='View as PDF']]")
    WebElement viewAsPDFButton;

    @FindBy(xpath = "//button[span[normalize-space()='Versions']]")
    WebElement versionsButton;

    @FindBy(xpath = "//button[i[@nztype='setting']]")
    WebElement settingsButton;

    /**
     * Hot banner Elements
     */
    @FindBy(xpath = "//p[@class='heading hot']/span/a")
    List<WebElement> hotBannerList;

    @FindBy(xpath = "//p[@class='heading hot']")
    List<WebElement> hotBannerColor;

    /**
     * Move Post Elements
     */
    @FindBy(xpath = "//div[contains(@data-component,'move-post')]/p")
    WebElement movePostTitle;

    @FindBy(xpath = "//div[contains(@class,'new-story-input')]//input")
    WebElement searchStoryInMovePostPopUp;

    @FindBy(xpath = "//div[@class='name']/p")
    List<WebElement> storyNameInMovePostPopUp;

    @FindBy(xpath = "//div[@class='name']/span")
    List<WebElement> storyIdInMovePostPopUp;

    @FindBy(xpath = "//div[@class='name']/preceding-sibling::div/button")
    List<WebElement> storyCrownInMovePostPopUp;

    @FindBy(xpath = "//div[@class='name']/following-sibling::div[@class='options']/button/i[@nztype='pushpin']")
    List<WebElement> storyPinIconInMovePostPopUp;

    @FindBy(xpath = "//div[@class='name']/following-sibling::div[@class='options']/button/i[@nztype='delete']")
    List<WebElement> storyDeleteIconInMovePostPopUp;

    @FindBy(xpath = "//div[@class='options']/button[span[normalize-space()='Move']]")
    WebElement moveButtonInMovePostPopUp;

    @FindBy(xpath = "//div[@class='options']/button[span[normalize-space()='Cancel']]")
    WebElement cancelButtonInMovePostPopUp;

    @FindBy(xpath = "//div[@class='ant-message']//span[contains(text(), 'moved')]")
    WebElement postMovedMessageElement;

    /**
     * Versions Elements
     */
    @FindBy(xpath = "//div[@class='banner ng-star-inserted']//div[@class='text']")
    WebElement archivedPostWarningMessage;

    @FindBy(xpath = "//div[@class='banner ng-star-inserted']//div[@class='text']/a")
    WebElement clickHereLinkInArchivedPostMessage;

    /**
     * Draft Post Elements
     */
    @FindBy(xpath = "//div[@class='text']")
    WebElement draftPostMessage;

    /**
     * Lock/Unlock Post Elements
     */
    @FindBy(xpath = "//div[@class='banner']//div[@class='text']")
    WebElement postLockMessage;

    @FindBy(xpath = "//div[@class='banner']/div/following-sibling::div/button")
    WebElement postLockByUser;

    @FindBy(xpath = "//button[span[normalize-space()='Unlock Post']]")
    WebElement unLockPostButton;

    @FindBy(xpath = "//span[contains(text(), 'The post has been successfully unlocked')]")
    WebElement postUnlockSuccessMessage;

    /**
     * Link to Angle Elements
     */
    @FindBy(xpath = "//input[@placeholder='Search for Angle Name or ID']")
    WebElement searchAngleTextBox;

    @FindBy(xpath = "//div[@class='angle-details-id']/button/span")
    List<WebElement> searchResultAngleIdList;

    @FindBy(xpath = "//div[@class='angle-icon-title-split']/button/span")
    List<WebElement> searchResultAngleTitleList;

    @FindBy(xpath = "//div[@class='angle-created-user']/span[contains(@class,'user-name')]")
    List<WebElement> searchResultAngleCreatedByList;

    @FindBy(xpath = "//div[@class='angle-details-id']/span")
    List<WebElement> linkAngleList;

    @FindBy(xpath = "//i[@class='anticon delete anticon-delete']")
    List<WebElement> deleteAngleFromSearchResult;

    @FindBy(xpath = "//button[span[normalize-space()='Confirm']]")
    WebElement confirmButton;

    @FindBy(xpath = "//*[contains(text(),'linked to Angle')]")
    WebElement angleSuccessfullyLinkedMessage;

    @FindBy(xpath = "//*[@class='content']/span[1]")
    WebElement postTitleInAngleLinkedMessage;

    @FindBy(xpath = "//*[@class='content']/span[2]/a")
    WebElement angleLinkInAngleLinkedMessage;

    public PostDetailsPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify post details page is loaded
     */
    public void verifyPostDetailsPageLoaded() throws Exception {
        try {
            Waits.waitForElement(postTitleElement, Waits.WAIT_CONDITIONS.CLICKABLE);
            Waits.waitForElement(viewAsPDFButton, Waits.WAIT_CONDITIONS.CLICKABLE);
            String postUrl = WebAction.getCurrentUrl();
            PostConstants.setPostUrl(postUrl);
            ExtentReportUtils.addLog(Status.INFO, "Post Link: <b>" + postUrl + "</b>");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify post details in post details page
     *
     * @param fieldName - Field Name
     */
    public void verifyPostDetails(String fieldName) throws Exception {
        try {
            switch (fieldName.toUpperCase()) {
                case "TITLE":
                    String expectedPostTitle = PostConstants.getPostTitle(PostConstants.getPostCount());
                    CommonValidations.verifyTextValue(postTitleElement, expectedPostTitle, "Post title is not correct in post details page");
                    break;
                case "DESCRIPTION":
                    String expectedPostDescription = PostConstants.getPostDescription(PostConstants.getPostCount());
                    CommonValidations.verifyTextValue(postDescriptionElement, expectedPostDescription, "Post description is not correct in post details page");
                    break;
                case "CREATED BY":
                    String expectedDisplayName = PostConstants.getFullName();
                    CommonValidations.verifyTextValue(postCreatorNameElement, expectedDisplayName, "Post creator name is not correct in post details page");
                    break;
                case "CREATION DATE":
                    String expectedPostCreationDate = PostConstants.getPostCreationDate(PostConstants.getPostCount());
                    CommonValidations.verifyTextValue(postCreationDateElement, expectedPostCreationDate, "Post creation date is not correct in post details page");
                    break;
                case "CREATION TIME":
                    String expectedPostCreationTime = PostConstants.getPostCreationTime(PostConstants.getPostCount());
                    CommonValidations.verifyCreationTime(postCreationTimeElement, expectedPostCreationTime, "h:mm a", "Post creation time is not correct in post details page");
                    break;
                case "MODIFIED BY":
                    String expectedModifierDisplayName = PostConstants.getFullName();
                    CommonValidations.verifyTextValue(postModifierNameElement, expectedModifierDisplayName, "Post modified by name is not correct in post details page");
                    break;
                case "MODIFIED DATE":
                    String expectedPostModifiedDate = PostConstants.getPostModifiedDate(PostConstants.getPostCount());
                    CommonValidations.verifyTextValue(postModifiedDateElement, expectedPostModifiedDate, "Post modified date is not correct in post details page");
                    break;
                case "MODIFIED TIME":
                    String expectedPostModifiedTime = PostConstants.getPostModifiedTime(PostConstants.getPostCount());
                    CommonValidations.verifyCreationTime(postModifiedTimeElement, expectedPostModifiedTime, "h:mm a", "Post modified time is not correct in post details page");
                    break;
                case "ATTACHMENTS":
                    verifyAttachments();
                    break;
                case "ELEMENT DETAILS":
                    verifyElementDetailsSection();
                    break;
                case "LINKED STORIES":
                    verifyLinkedStories();
                    break;
                case "LINKED ANGLES":
                    verifyLinkedAngles();
                    break;
                case "STANDARD GUIDANCE SECTION":
                    verifyStandardGuidanceSection();
                    break;
                case "REPORTABLE APPROVER SECTION":
                    verifyReportableApproverSection();
                    break;
                case "LIMITED LICENSE SECTION":
                    verifyLimitedLicenseSection();
                    break;
                case "LABELS":
                    verifyLabels();
                    break;
                case "ATTACHMENT AND COMMENTS COUNT SECTION":
                    verifyCountSection();
                    break;
                default:
                    Assert.fail("Please provide valid field name in post details page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story id is displayed in linked stories section of post details page
     *
     * @throws Exception
     */
    public void verifyStoryIdDisplayedInLinkedStories() throws Exception {
        try {
            for (int i = 0; i < Integer.parseInt(StoryConstants.getStoryCount()); i++)
                CommonValidations.verifyTextValue(linkedStoriesIdList.get(i), StoryConstants.getStoryId(String.valueOf(i + 1)), "Story id of linked story '" + StoryConstants.getStoryTitle(String.valueOf(i)) + "' is not correct in post details page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify draft post creation date/time
     *
     * @param fieldName - Creation Date/Time
     */
    public void verifyDraftPostDetails(String fieldName) throws Exception {
        try {
            switch (fieldName.toUpperCase()) {
                case "CREATION DATE":
                    String expectedDraftPostCreationDate = PostConstants.getDraftPostCreationDate();
                    expectedDraftPostCreationDate = DateFunctions.convertDateStringToAnotherFormat(expectedDraftPostCreationDate, "M/d/yy", "MM/dd/yyyy");
                    CommonValidations.verifyTextValue(postCreationDateElement, expectedDraftPostCreationDate, "Draft post creation date is not correct in post details page");
                    break;
                case "CREATION TIME":
                    String expectedDraftPostCreationTime = PostConstants.getDraftPostCreationTime();
                    CommonValidations.verifyCreationTime(postCreationTimeElement, expectedDraftPostCreationTime, "h:mm a", "Draft post creation time is not correct in post details page");
                    break;

                default:
                    Assert.fail("Please provide valid field name in post details page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify attachment section in post details page
     */

    public void verifyAttachments() {
        try {
            int attachmentCount = Integer.parseInt(PostConstants.getAttachmentCount());
            for (int i = 0; i < attachmentCount; i++) {
                String expectedFilename = PostConstants.getAttachmentName(i);
                if ((expectedFilename.contains(".png")) || (expectedFilename.contains(".jpeg")) || (expectedFilename.contains(".jpg")) || expectedFilename.contains(".pdf"))
                    CommonValidations.verifyAttributeValue(attachmentElements.get(i), "title", expectedFilename, expectedFilename + " file is not present in the attachment section of post details page");
                else if (expectedFilename.contains(".mp4") || expectedFilename.contains(".mpeg") || expectedFilename.contains(".mov"))
                    CommonValidations.verifyAttributeValue(attachmentElements.get(i), "title", expectedFilename.split("\\.")[1].trim(), expectedFilename + " file is not present in the attachment section of post details page");
                else {
                    String fileFormat = "";
                    if ((expectedFilename.contains(".xls")) || (expectedFilename.contains(".xlsx")))
                        fileFormat = "file-excel";
                    else if ((expectedFilename.contains(".doc")) || (expectedFilename.contains(".docx")))
                        fileFormat = "file-word";
                    else if (expectedFilename.contains(".txt")) fileFormat = "file-text";
                    else fileFormat = "file-unknown";
                    CommonValidations.verifyAttributeValue(attachmentElements.get(i), "class", fileFormat, expectedFilename + " file is not present in the attachment section of post details page");
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify element details in post details page
     */
    public void verifyElementDetailsSection() {
        try {
            if (PostConstants.getLinkToSource() != null)
                CommonValidations.verifyTextValue(linkToSourceElement, PostConstants.getLinkToSource(), "Link to Source is not correct in post details page");
            if (PostConstants.getMandatoryCreditValue() != null)
                CommonValidations.verifyTextValue(mandatoryCreditElement, PostConstants.getMandatoryCreditValue(), "Mandatory credit value is not correct in post details page");
            if (PostConstants.getClearedForNbcuPartners() != null) {
                if (PostConstants.getClearedForNbcuPartners().equalsIgnoreCase("YES"))
                    CommonValidations.verifyTextValue(clearedForNbcuParternsElement, PostConstants.getClearedForNbcuPartners(), "Cleared for NBCU partners value is not correct in post details page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To  verify linked stories
     */
    public void verifyLinkedStories() throws Exception {
        try {
            WebAction.scrollIntoView(linkedStoriesTab);
            CommonValidations.verifyTextValue(linkedStoriesTab, "1", "Stories count in linked stories header of post details is not correct");
            int storyCount = PostConstants.getLinkedStoryCount();
            for (int i = 0; i < storyCount; i++) {
                CommonValidations.verifyTextValue(linkedStoriesNameList.get(i), PostConstants.getLinkedStory(i), PostConstants.getLinkedStory(i) + " story is not present in post details page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To  verify linked angles
     */
    public void verifyLinkedAngles() throws Exception {
        try {
            Waits.waitUntilElementSizeGreater(linkedAnglesList, 0);
            WebAction.scrollIntoView(linkedAnglesTab);
            WebAction.click(linkedAnglesTab);
            int angleCount = PostConstants.getLinkedAngleCount();
            for (int i = 0; i < angleCount; i++) {
                CommonValidations.verifyTextValue(linkedAnglesList.get(i), PostConstants.getLinkedAngle(i), PostConstants.getLinkedAngle(i) + " angle is not present in post details page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify standard guidance section
     */
    public void verifyStandardGuidanceSection() throws Exception {
        try {
            CommonValidations.verifyTextValue(standardGuidanceSectionTitleElement, "Standards Guidance", "Standard guidance section is not displayed in post details page");
            CommonValidations.verifyTextValue(standardGuidanceSectionContentElement, PostConstants.getStandardGuidance(), "'" + PostConstants.getStandardGuidance() + "' standard guidance is not correct under standard guidance section of post details page");
            CommonValidations.verifyTextValue(standardGuidanceCreationDetailElements.get(0), PostConstants.getFullName(), "Standard guidance creator name is not correct in post details page");
            CommonValidations.verifyTextValue(standardGuidanceCreationDetailElements.get(1), PostConstants.getStandardGuidanceCreationDate(), "Standard guidance creation date is not correct in post details page");
            CommonValidations.verifyCreationTime(standardGuidanceCreationDetailElements.get(2), PostConstants.getStandardGuidanceCreationTime(), "h:mm a", "Standard guidance creation time is not correct in post details page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify reportable approver section
     */
    public void verifyReportableApproverSection() {
        try {
            CommonValidations.verifyElementIsDisplayed(reportableApproverTitleElement, "Reportable approver section is not displayed in post details page");
            if (PostConstants.getReportableNotes() != null)
                CommonValidations.verifyTextValue(reportableApproverNotesElement, PostConstants.getReportableNotes(), "'" + PostConstants.getReportableNotes() + "' reportable notes is not displayed under reportable approver section of post details page");
            CommonValidations.verifyTextValue(reportableApproverName, PostConstants.getSrApproverName(), "'" + PostConstants.getSrApproverName() + "' reportable Sr.approver name is not displayed under reportable approver section of post details page");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify limited license section
     */
    public void verifyLimitedLicenseSection() {
        try {
            CommonValidations.verifyTextValue(limitedLicenseTitleElement, "License Limitations", "License Limitations section is not displayed in post details page");
            CommonValidations.verifyTextValue(limitedLicenseTextElement, PostConstants.getLimitedLicense(), "'" + PostConstants.getLimitedLicense() + "' limited license content is not displayed under License Limitations section of post details page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify labels in post details page
     */
    public void verifyLabels() {
        try {
            List<String> actualLabels = new ArrayList<>();
            List<String> expectedLabels = new ArrayList<>();

            //Forming actual list of labels
            for (WebElement postLabelElement : postLabelElements) actualLabels.add(WebAction.getText(postLabelElement));
            Collections.sort(actualLabels);

            //Forming expected list of labels
            if (PostConstants.getStandardsLabelsCount() != null) {
                for (int i = 0; i < Integer.parseInt(PostConstants.getStandardsLabelsCount()); i++)
                    expectedLabels.add(PostConstants.getStandardsLabel(i));
            }

            if (PostConstants.getLegalLabelsCount() != null) {
                for (int i = 0; i < Integer.parseInt(PostConstants.getLegalLabelsCount()); i++)
                    expectedLabels.add(PostConstants.getLegalLabel(i));
            }
            Collections.sort(expectedLabels);

            if (actualLabels.size() == expectedLabels.size()) {
                expectedLabels.removeAll(actualLabels);
                if (!expectedLabels.isEmpty())
                    Assert.fail("'" + expectedLabels + "' labels are missing in post details page");
            } else
                Assert.fail("labels are not matching in post details page. Expected labels are '" + expectedLabels + "' and actual labels are '" + actualLabels + "'");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify attachment count, comment count and share icon
     */
    public void verifyCountSection() {
        try {
            //Verify attachment count
            String expectedAttachmentCount = PostConstants.getAttachmentCount();
            if (expectedAttachmentCount == null) expectedAttachmentCount = "0";
            CommonValidations.verifyTextValue(attachmentCountElement, expectedAttachmentCount, "Attachments count is not correct in post details page");

            //Verify comments count
            String expectedCommentsCount = PostConstants.getCommentsCount();
            if (expectedCommentsCount == null) expectedCommentsCount = "0";
            CommonValidations.verifyTextValue(commentCountElement, expectedCommentsCount, "Comments count is not correct in post details page");

            //Verify share icon
            CommonValidations.verifyElementIsEnabled(shareIcon, "Share post icon is not displayed in post details page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify meta data section in post details page
     *
     * @param sectionName - Section name
     */
    public void verifyMetaDataDetails(String sectionName) {
        try {
            switch (sectionName.toUpperCase()) {
                case "EDITORIAL/STANDARDS LABEL":
                    verifyEditorialStandardsLabelSection();
                    break;
                case "R&C/LEGAL LABEL":
                    verifyRcLegalLabelSection();
                    break;
                case "TOPICS":
                    verifyTopicsInMetaData();
                    break;
                case "TAGS":
                    verifyTagsInMetaData();
                    break;
                default:
                    Assert.fail("Please provide valid section name in meta data section of post details page. '" + sectionName + "' is not valid");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify Editorial/Standards label section in meta data
     */
    public void verifyEditorialStandardsLabelSection() {
        try {
            if (PostConstants.getStandardsLabelsCount() != null) {
                for (int i = 0; i < Integer.parseInt(PostConstants.getStandardsLabelsCount()); i++) {
                    WebElement standardLabel = null;
                    switch (PostConstants.getStandardsLabel(i).toUpperCase()) {
                        case "REPORTABLE":
                            standardLabel = reportableLabel;
                            break;
                        case "NOT REPORTABLE":
                            standardLabel = notReportableLabel;
                            break;
                        case "VERIFIED":
                            standardLabel = verifiedLabel;
                            break;
                        case "PUBLISHED/AIRED":
                            standardLabel = publishedOrAiredLabel;
                            break;
                        case "LOG":
                            standardLabel = logLabel;
                            break;
                        case "GREAT VIDEO":
                            standardLabel = greatVideoLabel;
                            break;
                        case "IMPORTANT":
                            standardLabel = importantLabel;
                            break;
                        case "HOT":
                            standardLabel = hotLabel;
                            break;
                        case "STANDARDS":
                            standardLabel = standardsLabel;
                            break;
                        default:
                            Assert.fail("Please enter valid Editorial/Standards label. Given '" + PostConstants.getStandardsLabel(i) + "' is not present in the meta data of post details page");
                    }
                    CommonValidations.verifyAttributeValue(standardLabel, "class", "checked", "'" + PostConstants.getStandardsLabel(i) + "' Editorial/Standards label is not checked in meta data section of post details page");
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify RC/Legal label section in meta data
     */
    public void verifyRcLegalLabelSection() {
        try {
            if (PostConstants.getLegalLabelsCount() != null) {
                for (int i = 0; i < Integer.parseInt(PostConstants.getLegalLabelsCount()); i++) {
                    WebElement rcLegalLabel = null;
                    switch (PostConstants.getLegalLabel(i).toUpperCase()) {
                        case "CLEARED":
                            rcLegalLabel = clearedLabel;
                            break;
                        case "LICENSED":
                            rcLegalLabel = licensedLabel;
                            break;
                        case "LIMITED LICENSE":
                            rcLegalLabel = limitedLicensedLabel;
                            break;
                        case "NEEDS LICENSING":
                            rcLegalLabel = needsLicensingLabel;
                            break;
                        case "COPYRIGHT RISK":
                            rcLegalLabel = copyRightRiskLabel;
                            break;
                        case "DO NOT USE":
                            rcLegalLabel = doNotUseLabel;
                            break;
                        case "LEGAL":
                            rcLegalLabel = legalLabel;
                            break;
                        default:
                            Assert.fail("Please enter valid R&C/Legal label. Given '" + PostConstants.getLegalLabel(i) + "' is not present in the meta data of post details page");
                    }

                    CommonValidations.verifyAttributeValue(rcLegalLabel, "class", "checked", "'" + PostConstants.getLegalLabel(i) + "' R&C/Legal label is not checked in meta data section of post details page");
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify topics in meta data section
     */
    public void verifyTopicsInMetaData() {
        try {
            List<String> actualTopicsList = new ArrayList<>();
            List<String> expectedTopicsList = new ArrayList<>();
            for (int i = 0; i < StoryConstants.getStoryTopicCount(); i++) {
                actualTopicsList.add(WebAction.getText(topicsList.get(i)));
                expectedTopicsList.add(StoryConstants.getStoryTopic(i).split("-")[1].trim());
            }
            Assert.assertEquals(actualTopicsList, expectedTopicsList, "Topics list in post details page are not correct. Expected topics are " + expectedTopicsList + " and actual topics are " + actualTopicsList);

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify tags in meta data section
     */
    public void verifyTagsInMetaData() {
        try {
            for (int i = 0; i < PostConstants.getPostTagCount(); i++)
                CommonValidations.verifyTextValue(tagsList.get(i), PostConstants.getPostTag(i), "'" + PostConstants.getPostTag(i) + "' tag is not displayed under tags section of meta data");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify post options in post details page
     *
     * @param role - Role
     */
    public void verifyPostOptions(String role) {
        try {
            CommonValidations.verifyElementIsEnabled(viewAsPDFButton, "View as PDF option is not displayed in post details page");
            CommonValidations.verifyElementIsEnabled(editButton, "Edit post option is not displayed in post details page");
            CommonValidations.verifyElementIsEnabled(settingsButton, "Settings icon is not displayed in post details page");
            if ((role.equalsIgnoreCase("EDITOR")) || (role.equalsIgnoreCase("SENIOR EDITOR")) || (role.equalsIgnoreCase("STANDARDS")) || (role.equalsIgnoreCase("ADMIN"))) {
                CommonValidations.verifyElementIsEnabled(versionsButton, "Versions option is not displayed in post details page");
                CommonValidations.verifyElementIsEnabled(linkToAngleButton, "Link to angle option is not displayed in post details page");
                CommonValidations.verifyElementIsEnabled(moveButton, "Move post option is not displayed in post details page");
                CommonValidations.verifyElementIsEnabled(deleteButton, "Delete post option is not displayed in post details page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click on post options in post details page
     *
     * @param buttonName - button name
     */
    public void clickPostOptions(String buttonName) throws Exception {
        try {
            switch (buttonName.toUpperCase()) {
                case "EDIT":
                    WebAction.click(editButton);
                    break;
                case "VIEW AS PDF":
                    WebAction.click(viewAsPDFButton);
                    //To wait for file download
                    Thread.sleep(8000);
                    break;
                case "VERSIONS":
                    WebAction.click(versionsButton);
                    break;
                case "LINK TO ANGLE":
                    WebAction.click(linkToAngleButton);
                    break;
                case "MOVE":
                    WebAction.click(moveButton);
                    break;
                case "DELETE":
                    WebAction.click(deleteButton);
                    break;
                case "SETTINGS":
                    WebAction.click(settingsButton);
                    break;
                default:
                    Assert.fail("Please provide valid button name in post details page");
                    break;
            }
            Thread.sleep(2000);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify Send to WG01/06 button is displayed
     */
    public void verifySendToWg0106ButtonDisplayed(String visibility) {
        boolean clearedLabelCheck = false;
        try {
            for (int i = 0; i < Integer.parseInt(PostConstants.getLegalLabelsCount()); i++) {
                if (PostConstants.getLegalLabel(i).equalsIgnoreCase("CLEARED")) {
                    clearedLabelCheck = true;
                    break;
                }

            }
            if (clearedLabelCheck) {
                if (visibility.equalsIgnoreCase("DISPLAYED"))
                    CommonValidations.verifyElementIsEnabled(sendToWg0106Button, "Send to WG01/06 post option is not displayed in post details page");
                else
                    Assert.assertFalse(WebAction.isDisplayed(sendToWg0106Button), "Send to WG01/06 post option is displayed in post details page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify hot banner is displayed
     */
    public void verifyHotBanner() throws Exception {
        try {
            Thread.sleep(5000);
            boolean hotBannerCheck = false;
            for (int i = 0; i < hotBannerList.size(); i++) {
                if (WebAction.getText(hotBannerList.get(i)).equalsIgnoreCase(PostConstants.getPostTitle(PostConstants.getPostCount()))) {
                    CommonValidations.verifyColorOfElement(hotBannerColor.get(i), "background color", "RED-6");
                    hotBannerCheck = true;
                    break;
                }
            }
            Assert.assertTrue(hotBannerCheck, "Hot banner is not displayed for post '" + PostConstants.getPostTitle(PostConstants.getPostCount()) + "'");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify move post pop up is displayed
     */
    public void verifyMovePostPopUp() throws Exception {
        try {
            Waits.waitForElement(movePostTitle, Waits.WAIT_CONDITIONS.VISIBLE);
            CommonValidations.verifyTextValue(movePostTitle, "MOVE", "Move post pop up is not displayed");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify details in move post pop up
     */
    public void verifyMovePostPopUpDetails() {
        try {
            //To verify linked story name displayed
            CommonValidations.verifyTextValue(storyNameInMovePostPopUp.get(0), PostConstants.getLinkedStory(0), PostConstants.getLinkedStory(0) + " story is not present in move post pop up");

            //To verify linked story name displayed
            CommonValidations.verifyTextValue(storyIdInMovePostPopUp.get(0), StoryConstants.getStoryId("1"), StoryConstants.getStoryId("1") + " Story id is not present in move post pop up");

            //To verify story is marked as primary
            CommonValidations.verifyColorOfElement(storyCrownInMovePostPopUp.get(0), "background color", "blue");

            //To verify pin icon is displayed
            CommonValidations.verifyElementIsEnabled(storyPinIconInMovePostPopUp.get(0), "Pin story icon is not displayed in move post pop up for story " + PostConstants.getLinkedStory(0));

            //To verify delete icon is displayed
            CommonValidations.verifyElementIsEnabled(storyDeleteIconInMovePostPopUp.get(0), "Delete story icon is not displayed in move post pop up for story " + PostConstants.getLinkedStory(0));

            //To verify move button is displayed
            CommonValidations.verifyElementIsEnabled(moveButtonInMovePostPopUp, "Move button is not displayed in move post pop up");

            //To verify cancel button is displayed
            CommonValidations.verifyElementIsEnabled(cancelButtonInMovePostPopUp, "Cancel button is not displayed in move post pop up");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To move post to another story
     *
     * @param searchText - Search Text
     */
    public void searchAndMoveStory(String searchText, String isPrimaryStory) throws Exception {
        try {
            int storyCountBeforeAdding = storyNameInMovePostPopUp.size();
            //Search and add story
            String secondaryStory = WebAction.selectDropDownBySearchText(searchStoryInMovePostPopUp, searchText, searchDropDownValuesXpath, "Story search results are not displayed for search text '" + searchText + "' in move post pop up");
            secondaryStory = secondaryStory.split("\\|")[1].trim();
            PostConstants.setLinkedStoryCount(PostConstants.getLinkedStoryCount() + 1);
            PostConstants.setLinkedStory(PostConstants.getLinkedStoryCount() - 1, secondaryStory);

            //Verify story is added
            int storyCountAfterAdding = storyNameInMovePostPopUp.size();
            if (storyCountAfterAdding == storyCountBeforeAdding + 1) {
                int linkedStorySize = PostConstants.getLinkedStoryCount();

                //To verify moved story title
                CommonValidations.verifyTextValue(storyNameInMovePostPopUp.get(linkedStorySize - 1), PostConstants.getLinkedStory(linkedStorySize - 1), PostConstants.getLinkedStory(linkedStorySize - 1) + " story is not present in move post pop up");

                //To verify pin icon is displayed
                CommonValidations.verifyElementIsEnabled(storyPinIconInMovePostPopUp.get(linkedStorySize - 1), "Pin story icon is not displayed in move post pop up for story " + PostConstants.getLinkedStory(linkedStorySize - 1));

                //To verify delete icon is displayed
                CommonValidations.verifyElementIsEnabled(storyDeleteIconInMovePostPopUp.get(linkedStorySize - 1), "Delete story icon is not displayed in move post pop up for story " + PostConstants.getLinkedStory(linkedStorySize - 1));
            } else Assert.fail(secondaryStory + " Story is not added in move post pop up");

            //Update primary story
            if (isPrimaryStory.equalsIgnoreCase("YES")) {
                WebAction.click(storyCrownInMovePostPopUp.get(1));
                PostConstants.setPrimaryStory(secondaryStory);
            }
            System.out.println("Primary Story:::" + PostConstants.getPrimaryStory());

            WebAction.click(moveButtonInMovePostPopUp);

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify post moved message
     *
     * @param postMovedSuccessMessage - Post moved success message
     */
    public void verifyPostMovedMessage(String postMovedSuccessMessage) throws Exception {
        try {
            Waits.waitForElement(postMovedMessageElement, Waits.WAIT_CONDITIONS.VISIBLE);
            CommonValidations.verifyTextValue(postMovedMessageElement, postMovedSuccessMessage, "Post moved success message is not displayed");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To Verify archived post warning message
     *
     * @param expectedArchivedPostMessage - Expected archived post message
     */
    public void verifyArchivedPostMessage(String expectedArchivedPostMessage) {
        try {
            CommonValidations.verifyTextValue(archivedPostWarningMessage, expectedArchivedPostMessage, "Archived post message is not correct in post details page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify labels are not present in post details
     */
    public void verifyLabelsAreNotDisplayed() {
        try {
            if (postLabelElements.size() > 0)
                Assert.fail("Labels are present in post details page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * To click on here link archived post message
     */
    public void clickOnLinkArchivedPostMessage() throws Exception {
        try {
            WebAction.click(clickHereLinkInArchivedPostMessage);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify draft info message
     */
    public void verifyDraftPostInfoMessage(String visibility, String expectedMessage) {
        try {
            if (visibility.equalsIgnoreCase("DISPLAYED"))
                CommonValidations.verifyTextValue(draftPostMessage, expectedMessage, "Draft post info is not displayed in post details page");
            else
                Assert.assertFalse(WebAction.isDisplayed(draftPostMessage), "Draft post info is displayed in post details page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * To verify lock post message is displayed
     *
     * @param withOrWithOutUnlock - Unlock Post button is displayed WITH/WITH OUT
     * @param expectedMessage     - expected post lock message
     */
    public void verifyPostLockMessage(String withOrWithOutUnlock, String expectedMessage) {
        try {
            CommonValidations.verifyTextValue(postLockMessage, expectedMessage, "Post lock message is not correct in post details page");
            CommonValidations.verifyTextValue(postLockByUser, PostConstants.getFullName(), "Post locked by user name is not correct in post lock message");

            if (withOrWithOutUnlock.equalsIgnoreCase("WITH"))
                CommonValidations.verifyElementIsDisplayed(unLockPostButton, "Unlock Post button is not displayed for admin user");
            else
                Assert.assertFalse(WebAction.isDisplayed(unLockPostButton), "Unlock Post button is displayed for admin user");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * To verify post options visibility in post details page
     *
     * @param visibility - visibility of button
     * @param params     - Post options
     */
    public void verifyPostOptionsVisibility(String visibility, DataTable params) {
        try {
            List<Map<String, String>> postOptions = CucumberUtils.getValuesFromDataTableAsList(params);
            for (int i = 0; i < postOptions.size(); i++) {
                String buttonName = postOptions.get(i).get("Post Options");
                switch (buttonName.toUpperCase()) {
                    case "EDIT":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(editButton, "Edit button is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByAttribute(editButton, "Edit button is enabled in post details page");
                        break;
                    case "DELETE":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(deleteButton, "Delete button is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByAttribute(deleteButton, "Delete button is enabled in post details page");
                        break;
                    case "MOVE":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(moveButton, "Move button is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByAttribute(moveButton, "Move button is enabled in post details page");
                        break;
                    case "LINK TO ANGLE":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(linkToAngleButton, "Link to angle button is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByAttribute(linkToAngleButton, "Link to angle button is enabled in post details page");
                        break;
                    case "VERSIONS":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(versionsButton, "Versions button is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByAttribute(versionsButton, "Versions button is enabled in post details page");
                        break;
                    case "VIEW AS PDF":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(viewAsPDFButton, "View as PDF button is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByAttribute(viewAsPDFButton, "View as PDF button is enabled in post details page");
                        break;
                    default:
                        Assert.fail("Please provide valid button name in post details page." + buttonName + " button name not found");
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify visibility of Editorial/Standards Labels
     *
     * @param visibility - Visibility of Editorial/Standards Label
     * @param params     - Labels
     */
    public void verifyEditorialLabelsVisibility(String visibility, DataTable params) {
        try {
            List<Map<String, String>> editorialLabels = CucumberUtils.getValuesFromDataTableAsList(params);
            for (int i = 0; i < editorialLabels.size(); i++) {
                String buttonName = editorialLabels.get(i).get("Editorial/Standards Label");
                switch (buttonName.toUpperCase()) {
                    case "REPORTABLE":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(reportableLabel, "REPORTABLE label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(reportableLabel, "REPORTABLE label is enabled in post details page");
                        break;
                    case "NOT REPORTABLE":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(notReportableLabel, "NOT REPORTABLE label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(notReportableLabel, "NOT REPORTABLE label is enabled in post details page");
                        break;
                    case "VERIFIED":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(verifiedLabel, "VERIFIED label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(verifiedLabel, "VERIFIED label is enabled in post details page");
                        break;
                    case "PUBLISHED/AIRED":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(publishedOrAiredLabel, "PUBLISHED/AIRED label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(publishedOrAiredLabel, "PUBLISHED/AIRED label is enabled in post details page");
                        break;
                    case "LOG":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(logLabel, "LOG label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(logLabel, "LOG label is enabled in post details page");
                        break;
                    case "GREAT VIDEO":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(greatVideoLabel, "GREAT VIDEO label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(greatVideoLabel, "GREAT VIDEO label is enabled in post details page");
                        break;
                    case "HOT":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(hotLabel, "HOT label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(hotLabel, "HOT label is enabled in post details page");
                        break;
                    case "IMPORTANT":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(importantLabel, "IMPORTANT label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(importantLabel, "IMPORTANT label is enabled in post details page");
                        break;
                    case "STANDARDS":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(standardsLabel, "STANDARDS label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(standardsLabel, "STANDARDS label is enabled in post details page");
                        break;
                    default:
                        Assert.fail("Please provide valid Editorial/Standards Label name in post details page");
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify visibility of R&C/Legal Labels
     *
     * @param visibility - Visibility of R&C/Legal label
     * @param params     - Labels
     */
    public void verifyRcAndLegalLabelsVisibility(String visibility, DataTable params) {
        try {
            List<Map<String, String>> rcLabels = CucumberUtils.getValuesFromDataTableAsList(params);
            for (int i = 0; i < rcLabels.size(); i++) {
                String buttonName = rcLabels.get(i).get("R&C/Legal Label");
                switch (buttonName.toUpperCase()) {
                    case "CLEARED":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(clearedLabel, "CLEARED label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(clearedLabel, "CLEARED label is enabled in post details page");
                        break;
                    case "LICENSED":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(licensedLabel, "LICENSED label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(licensedLabel, "LICENSED label is enabled in post details page");
                        break;
                    case "LIMITED LICENSE":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(limitedLicensedLabel, "LIMITED LICENSE label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(limitedLicensedLabel, "LIMITED LICENSE label is enabled in post details page");
                        break;
                    case "NEEDS LICENSING":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(needsLicensingLabel, "NEEDS LICENSING label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(needsLicensingLabel, "NEEDS LICENSING label is enabled in post details page");
                        break;
                    case "COPYRIGHT RISK":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(copyRightRiskLabel, "COPYRIGHT RISK label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(copyRightRiskLabel, "COPYRIGHT RISK label is enabled in post details page");
                        break;
                    case "DO NOT USE":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(doNotUseLabel, "DO NOT USE label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(doNotUseLabel, "DO NOT USE label is enabled in post details page");
                        break;
                    case "LEGAL":
                        if (visibility.equalsIgnoreCase("ENABLED"))
                            CommonValidations.verifyElementIsEnabled(legalLabel, "LEGAL label is disabled in post details page");
                        else
                            CommonValidations.verifyElementIsDisabledByClass(legalLabel, "LEGAL label is enabled in post details page");
                        break;
                    default:
                        Assert.fail("Please provide valid R&C/Legal Label name in post details page");
                }
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click on Unlock Post button in lock post message
     */
    public void clickUnlockPostButton() throws Exception {
        try {
            WebAction.click(unLockPostButton);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify post unlock success message
     *
     * @param unlockMessage - Unlock post message
     */
    public void verifyPostUnlockedSuccessMessage(String unlockMessage) throws Exception {
        try {
            Waits.waitForElement(postUnlockSuccessMessage, Waits.WAIT_CONDITIONS.VISIBLE);
            CommonValidations.verifyTextValue(postUnlockSuccessMessage, unlockMessage, "Post unlocked successfully message is displayed");
            Waits.waitForElement(editButton, Waits.WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * To verify link to angle pop up displayed
     */
    public void verifyLinkToAnglePopUpDisplayed() throws Exception {
        try {
            Waits.waitForElement(searchAngleTextBox, Waits.WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * Search angle and select
     *
     * @param searchText - Angle search text
     */
    public void searchAndSelectAngle(String searchText) throws Exception {
        boolean anglePresent = false;
        try {
            if (AngleConstants.getAngleTitle(AngleConstants.getAngleCount()) != null)
                searchText = AngleConstants.getAngleTitle(AngleConstants.getAngleCount());

            /**
             * To search angle with search text
             */
            WebAction.sendKeys(searchAngleTextBox, searchText);
            Waits.waitUntilElementSizeGreater(searchResultAngleIdList, 0);

            /**
             * To verify angle is present
             */
            for (int i = 0; i < searchResultAngleIdList.size(); i++) {
                if (WebAction.getText(searchResultAngleTitleList.get(i)).toLowerCase().contains(searchText.toLowerCase())) {
                    WebAction.click(linkAngleList.get(i));
                    anglePresent = true;
                    break;
                }
            }
            Assert.assertTrue(anglePresent, "Angle is not found in search text '" + searchText + "'");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify angle details and confirm
     */
    public void verifyAngleDetailsAndConfirm() throws Exception {
        try {
            CommonValidations.verifyTextValue(searchResultAngleIdList.get(0), AngleConstants.getAngleID(AngleConstants.getAngleCount()), "Angle id is not matching in search angle pop up");
            CommonValidations.verifyTextValue(searchResultAngleTitleList.get(0), AngleConstants.getAngleTitle(AngleConstants.getAngleCount()), "Angle title is not matching in search angle pop up");
            CommonValidations.verifyTextValue(searchResultAngleCreatedByList.get(0), PostConstants.getDisplayName(), "Angle created by is not matching in search angle pop up");
            CommonValidations.verifyElementIsEnabled(deleteAngleFromSearchResult.get(0), "Delete angle icon is not displayed in search angle pop up");
            WebAction.click(confirmButton);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * To verify angle linked success message
     */
    public void verifyAngleLinkedSuccessMessage(String expectedAngleLinkedSuccessMessage) throws Exception {
        try {
            PostConstants.setLinkedAngleCount(1);
            PostConstants.setLinkedAngle(0, AngleConstants.getAngleTitle(AngleConstants.getAngleCount()));
            Waits.waitForElement(angleSuccessfullyLinkedMessage, Waits.WAIT_CONDITIONS.VISIBLE);
            CommonValidations.verifyTextValue(angleSuccessfullyLinkedMessage, expectedAngleLinkedSuccessMessage, "Angle successfully linked popup message is not displayed");
            CommonValidations.verifyTextValue(postTitleInAngleLinkedMessage, "\"" + PostConstants.getPostTitle(PostConstants.getPostCount()) + "\" linked to", "Post title is not correct in angle linked success message");
            String expectedAngleLinkText = "(" + AngleConstants.getAngleID(AngleConstants.getAngleCount()) + ") " + AngleConstants.getAngleTitle(AngleConstants.getAngleCount());
            CommonValidations.verifyTextValue(angleLinkInAngleLinkedMessage, expectedAngleLinkText, "Post title is not correct in angle linked success message");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * Click on Angle link from angle link message
     */
    public void openAngle() throws Exception {
        try {
            WebAction.click(angleLinkInAngleLinkedMessage);
            Waits.waitForNumberOfWindowsToBe(WebAction.getWindowsSize());
            List<String> openWindowIds = WebAction.getWindowIdsList();
            WebAction.switchToWindow(openWindowIds.get(openWindowIds.size() - 1));
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To open linked story/post from post details page
     *
     * @param type - Story/Angle
     */
    public void openLinkedStoryOrAngle(String type) throws Exception {
        try {
            if (type.toUpperCase().contains("STORY")) {
                boolean storyOpened = false;

                // To fetch primary/secondary story
                String expectedStory = PostConstants.getPrimaryStory();
                if (!type.toUpperCase().contains("PRIMARY")) {
                    for (int i = 0; i < PostConstants.getLinkedStoryCount(); i++) {
                        if (!PostConstants.getLinkedStory(i).equalsIgnoreCase(PostConstants.getPrimaryStory())) {
                            expectedStory = PostConstants.getLinkedStory(i);
                            break;
                        }

                    }
                }
                //To open story landing page of primary/secondary story
                CommonValidations.verifyAttributeValue(linkedStoriesTab.findElement(By.xpath("..")), "aria-expanded", "true", "Linked Stories is not expanded in post details tab");
                for (WebElement element : linkedStoriesNameList) {
                    if (WebAction.getText(element).trim().equalsIgnoreCase(expectedStory)) {
                        WebAction.click(element);
                        storyOpened = true;
                        break;
                    }
                }
                Assert.assertTrue(storyOpened, "Primary story '" + PostConstants.getPrimaryStory() + "' is not present in post details page");
            } else {
                if (!WebAction.getAttribute(linkedAnglesTab.findElement(By.xpath("..")), "aria-expanded").contains("true"))
                    WebAction.click(linkedAnglesTab);
                WebAction.click(linkedAnglesList.get(0));
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify invisible eye icon displayed for private angle and invisible eye icon is not displayed for public angle
     *
     * @param visibility   - Displayed/Not Displayed
     * @param anglePrivacy - Angle Privacy
     */
    public void verifyInvisibleEyeIcon(String visibility, String anglePrivacy) throws Exception {
        try {
            if (visibility.equalsIgnoreCase("NOT DISPLAYED"))
                Assert.assertEquals(linkedAnglesInvisibleList.size(), 0, "Invisible eye icon is displayed for '" + anglePrivacy + "' angle in post details page");
            else {
                Waits.waitUntilElementSizeGreater(linkedAnglesInvisibleList, 0);
                Assert.assertTrue(WebAction.isDisplayed(linkedAnglesInvisibleList.get(0)), "Invisible eye icon is not displayed for '" + anglePrivacy + "' angle in post details page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Verify linked story is updated after story merge
     */
    public void verifyLinkedStoryUpdatedAfterMerge() {
        try {
            Assert.assertNotEquals(linkedAnglesList.get(0), PostConstants.getLinkedAngle(0));
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }
}
