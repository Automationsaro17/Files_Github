package nbcu.automation.ui.pages.ncx;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.AngleConstants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.SearchConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class SearchResultsPage {

    /**
     * Header Elements
     */
    @FindBy(xpath = "//input[@data-id='global-search-input']")
    WebElement globalSearchBar;

    @FindBy(xpath = "//input[@placeholder='Search NewsConnect...']")
    WebElement searchTextBox;

    @FindBy(xpath = "//button[i[@nztype='close-circle']]")
    WebElement clearSearchText;

    @FindBy(xpath = "//div[@data-id='search-suggestions']/ul/li/div[@class='suggestion-text']")
    List<WebElement> actualSearchTextList;

    @FindBy(xpath = "//div[@data-id='search-suggestions']/ul/li/div[@data-id='suggestion-delete-icon']")
    List<WebElement> searchTextRemoveIconList;

    @FindBy(xpath = "//div[contains(@class,'result-count')]")
    WebElement resultCount;

    /**
     * Search Preview Elements
     */
    @FindBy(xpath = "//h3[text()='Posts']/following-sibling::div/*")
    List<WebElement> postsSearchPreviewResults;

    @FindBy(xpath = "//h3[text()='Stories/Groups']/following-sibling::div/*")
    List<WebElement> storiesOrGroupsSearchPreviewResults;

    @FindBy(xpath = "//h3[text()='Angles']/following-sibling::div/*")
    List<WebElement> anglesSearchPreviewResults;

    @FindBy(xpath = "//h3[text()='People']/following-sibling::div/*")
    List<WebElement> peopleSearchPreviewResults;

    @FindBy(xpath = "//button[span[contains(text(),'See All Results')]]")
    WebElement seeAllResultsButton;

    /**
     * Tab Elements
     */
    @FindBy(xpath = "//button[text()='Stories']")
    WebElement storiesTab;

    @FindBy(xpath = "//button[text()='Posts']")
    WebElement postsTab;

    @FindBy(xpath = "//button[contains(text(),'Angles')]")
    WebElement anglesTab;

    @FindBy(xpath = "//button[text()='Groups']")
    WebElement groupsTab;

    @FindBy(xpath = "//button[text()='People']")
    WebElement peopleTab;

    /**
     * Search Elements
     */
    @FindBy(xpath = "//a[@class='title']")
    List<WebElement> searchResults;

    /**
     * Sorting Elements
     */
    @FindBy(xpath = "//label[@nzvalue='newestFirst']//input")
    WebElement newestFirstCheckBox;


    public SearchResultsPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify search results page loaded
     */
    public void verifySearchResultsPageLoaded() throws Exception {
        try {
            Waits.waitForElement(storiesTab, Waits.WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify global search text box is not displayed
     */
    public void verifyGlobalSearchTextBoxNotDisplayed() throws Exception {
        try {
            Assert.assertFalse(WebAction.isDisplayed(globalSearchBar), "Global search bar is displayed in global search results page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To type in search text
     *
     * @param searchText - Search text
     */
    public void typeInSearchText(String searchText) throws Exception {
        try {
            WebAction.sendKeys(searchTextBox, searchText);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Search with search text
     *
     * @param params - Search text
     */
    public void searchWithSearchText(DataTable params) throws Exception {
        try {
            //Expected search text list
            List<String> expectedSearchTextList = new ArrayList<>();

            List<Map<String, String>> searchTexts = CucumberUtils.getValuesFromDataTableAsList(params);
            for (Map<String, String> map : searchTexts) {
                String searchText = map.get("Search Text");
                expectedSearchTextList.add(searchText);
                WebAction.sendKeys(searchTextBox, searchText);
                WebAction.keyPress(searchTextBox, "ENTER");
                Thread.sleep(1000);
                Waits.waitForElement(resultCount, Waits.WAIT_CONDITIONS.VISIBLE);
                WebAction.click(clearSearchText);
            }
            //Latest search text will display in top. So reversing list
            Collections.reverse(expectedSearchTextList);
            SearchConstants.setSearchText(expectedSearchTextList);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click on search text box
     */
    public void clickOnSearchTextBox() throws Exception {
        try {
            WebAction.click(searchTextBox);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify previous 5 search history are displayed
     */
    public void verifyPreviousFiveSearchHistoryDisplayed() throws Exception {
        try {
            List<String> expectedSearchTextList = SearchConstants.getSearchText();
            int expectedSearchTextCount = Math.min(expectedSearchTextList.size(), 5);

            Assert.assertEquals(actualSearchTextList.size(), expectedSearchTextCount, "Search text history count is not correct");
            for (int i = 0; i < expectedSearchTextCount; i++)
                CommonValidations.verifyTextValue(actualSearchTextList.get(i), expectedSearchTextList.get(i), "search history search text is not correct");

            WebAction.clickUsingJs(resultCount);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Remove search text from search text history
     *
     * @param count - count
     */
    public void removeSearchText(String count) throws Exception {
        try {
            WebAction.sendKeys(searchTextBox, "te");
            WebAction.click(clearSearchText);

            List<String> expectedSearchTextList = SearchConstants.getSearchText();
            for (int i = 0; i < Integer.parseInt(count); i++) {
                WebAction.mouseOverAndClick(actualSearchTextList.get(i), searchTextRemoveIconList.get(i));
            }

            for (int i = 0; i < Integer.parseInt(count); i++)
                expectedSearchTextList.remove(i);

            SearchConstants.setSearchText(expectedSearchTextList);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify search preview is displayed
     */
    public void verifySearchPreviewDisplayed() throws Exception {
        try {
            Waits.waitForElement(seeAllResultsButton, Waits.WAIT_CONDITIONS.CLICKABLE);
            Assert.assertFalse(postsSearchPreviewResults.isEmpty(), "Posts search results is not displayed in search preview in search results page");
            Assert.assertFalse(storiesOrGroupsSearchPreviewResults.isEmpty(), "Stories/Groups search results is not displayed in search preview in search results page");
            Assert.assertFalse(anglesSearchPreviewResults.isEmpty(), "Angles search results is not displayed in search preview in search results page");
            Assert.assertFalse(peopleSearchPreviewResults.isEmpty(), "People search results is not displayed in search preview in search results page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To open Stories/Posts/Angles/Groups/People tab
     *
     * @param searchCategory - STORIES/POSTS/ANGLES/GROUPS/PEOPLE
     */
    public void openSearchTab(String searchCategory) throws Exception {
        try {
            switch (searchCategory.toUpperCase()) {
                case "STORIES":
                    WebAction.click(storiesTab);
                    break;
                case "POSTS":
                    WebAction.click(postsTab);
                    break;
                case "ANGLES":
                    WebAction.click(anglesTab);
                    break;
                case "GROUPS":
                    WebAction.click(groupsTab);
                    break;
                case "PEOPLE":
                    WebAction.click(peopleTab);
                    break;
                default:
                    Assert.fail("Given search category '" + searchCategory + "' is not found. Please enter valid search category in search results page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To fill search text in search results page
     *
     * @param searchCategory - POST/STORY/ANGLE
     * @param searchType     - WITH/WITH OUT
     * @param searchField    - Field Name
     * @param searchText     - Search Text
     */
    public void fillSearchTextInSearchResults(String searchCategory, String searchType, String searchField, String searchText) throws Exception {
        try {
            if ((searchText == null) || !searchField.equalsIgnoreCase("TITLE")) {
                if (searchCategory.equalsIgnoreCase("STORY"))
                    searchText = StoryConstants.getStoryTitle(StoryConstants.getStoryCount());
                else if (searchCategory.equalsIgnoreCase("POST"))
                    searchText = PostConstants.getPostTitle(PostConstants.getPostCount());
                else if (searchCategory.equalsIgnoreCase("ANGLE"))
                    searchText = AngleConstants.getAngleTitle(AngleConstants.getAngleCount());
                else
                    Assert.fail("Given search category '" + searchCategory + "' is not found. Please enter valid search category");
            }

            // Setting search text
            if (searchCategory.equalsIgnoreCase("STORY"))
                StoryConstants.setSearchKeyword(searchText);
            else if (searchCategory.equalsIgnoreCase("POST"))
                PostConstants.setSearchKeyword(searchText);
            else if (searchCategory.equalsIgnoreCase("ANGLE"))
                AngleConstants.setSearchKeyword(searchText);
            else
                Assert.fail("Given search category '" + searchCategory + "' is not found. Please enter valid search category");

            Waits.waitForElement(searchTextBox, Waits.WAIT_CONDITIONS.CLICKABLE);
            // Updating double quotes in search text for exact search
            if (searchType.equalsIgnoreCase("WITH"))
                searchText = "\"" + searchText + "\"";

            if (!WebAction.isSelected(newestFirstCheckBox))
                WebAction.click(newestFirstCheckBox);
            WebAction.sendKeys(searchTextBox, searchText);
            WebAction.keyPress(searchTextBox, "ENTER");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify searched post/story/angle is displayed
     *
     * @param searchCategory - Search Category
     */
    public void verifyStoryPostAngleDisplayed(String searchCategory) throws Exception {
        try {
            boolean elementPresent = false;
            String expectedTitle = "";
            // Setting search text
            if (searchCategory.equalsIgnoreCase("STORY"))
                expectedTitle = StoryConstants.getSearchKeyword();
            else if (searchCategory.equalsIgnoreCase("POST"))
                expectedTitle = PostConstants.getSearchKeyword();
            else if (searchCategory.equalsIgnoreCase("ANGLE"))
                expectedTitle = AngleConstants.getSearchKeyword();
            else
                Assert.fail("Given search category '" + searchCategory + "' is not found. Please enter valid search category");

            Waits.waitUntilElementSizeGreater(searchResults, 0);
            Waits.waitForElement(resultCount, Waits.WAIT_CONDITIONS.VISIBLE);
            for (WebElement element : searchResults) {
                if (WebAction.getText(element).trim().equalsIgnoreCase(expectedTitle)) {
                    elementPresent = true;
                    break;
                }
            }

            Assert.assertTrue(elementPresent, "Searched " + searchCategory + " is not present in search results page");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }
}
