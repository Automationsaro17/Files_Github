package nbcu.automation.ui.pages.ncx;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

public class StoriesSearchResultsPage {

    /**
     * Header Elements
     */
    @FindBy(xpath = "//span[@type='prefix']/following::input[@placeholder='Search all of NewsConnect']")
    WebElement searchTextBox;

    @FindBy(xpath = "//button[i[@nztype='close-circle']]")
    WebElement clearSearchText;

    /**
     * Search Results Elements
     */
    @FindBy(xpath = "//div[contains(@class,'-active')]//div[contains(@class,'result-count')]")
    WebElement searchResultCount;

    @FindBy(xpath = "//div[contains(@class,'story-id')]")
    List<WebElement> searchResultStoryIds;

    @FindBy(xpath = "//div[contains(@class,'story-id')]/i")
    List<WebElement> searchResultStoryIdsCopyIcon;

    public StoriesSearchResultsPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify stories search results page loaded
     */
    public void verifyStoriesSearchResultsPageLoaded() throws Exception {
        try {
            Waits.waitForElement(searchResultStoryIdsCopyIcon.get(0), Waits.WAIT_CONDITIONS.CLICKABLE);
            Waits.waitForElement(searchResultCount, Waits.WAIT_CONDITIONS.VISIBLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Search with Full/Partial story ID in stories search results page
     *
     * @param searchType - FULL/PARTIAL
     * @param params     - TOPIC ID WITH YEAR/YEAR WITH SUBJECT CODE/SUBJECT CODE WITH NUMBER
     * @throws Exception
     */
    public void fillFullPartialStoryId(String searchType, DataTable params) throws Exception {
        try {
            String searchText = new HomePage().generateFullOrPartialStoryId(searchType, params);
            Waits.waitForElement(searchTextBox, Waits.WAIT_CONDITIONS.CLICKABLE);
            WebAction.sendKeys(searchTextBox, searchText);
            WebAction.keyPress(searchTextBox, "ENTER");

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story id is present in global story search results page
     *
     * @param searchType - FULL/PREVIEW
     * @throws Exception
     */
    public void verifyStorySearchResultBasedOnStoryId(String searchType) throws Exception {
        try {
            Thread.sleep(3000);
            String searchText = StoryConstants.getSearchKeyword();
            Waits.waitUntilElementSizeGreater(searchResultStoryIds, 0);
            Assert.assertFalse(searchResultStoryIds.isEmpty(), "No search result is displayed under Stories in  stories search result page when user searches with story id " + searchText);
            for (WebElement element : searchResultStoryIds)
                CommonValidations.verifyTextValue(element, searchText, searchType + " Story Id '" + searchText + "' is missing in stories search result page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }
}
