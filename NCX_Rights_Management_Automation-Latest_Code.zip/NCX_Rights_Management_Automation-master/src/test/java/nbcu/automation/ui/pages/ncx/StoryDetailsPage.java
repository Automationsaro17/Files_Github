package nbcu.automation.ui.pages.ncx;

import com.aventstack.extentreports.Status;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.report.ExtentReportUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.*;
import java.util.stream.Collectors;

public class StoryDetailsPage {

    /**
     * Story details elements
     **/
    @FindBy(xpath = "//div[contains(@class,'story-status with-text')]")
    WebElement storyStatusElement;

    @FindBy(xpath = "//div[contains(@class,'story-status with-text')]/span")
    WebElement storyStatusIndicatorElement;

    @FindBy(xpath = "//div[contains(@class,'story-access')]")
    WebElement storyPrivacyElement;

    @FindBy(xpath = "//div[contains(@class,'story-access')]/..//div[contains(@class,'eye-invisible-icon')]/i/*[name()='svg']")
    WebElement storyPrivacyEyeElement;

    @FindBy(xpath = "//div[contains(@class,'topics')]/span")
    List<WebElement> storyTopicElement;

    @FindBy(xpath = "//div[contains(@class,'topics')]/following-sibling::div[contains(@class,'title')]/span")
    WebElement storyTitleElement;

    @FindBy(xpath = "//*[@id='storyContent']/span/p")
    List<WebElement> storyDescriptionList;

    @FindBy(xpath = "//div[@class='tag-name']")
    List<WebElement> storyPostTagTitles;

    @FindBy(xpath = "//div[@class='tag-name' and text()='Post Tags']/following-sibling::div[1]")
    WebElement rankedPostTagsToolTipIcon;

    @FindBy(xpath = "//span[contains(@class,'tool-tip')]")
    WebElement postTagsToolTipMessage;

    @FindBy(xpath = "//div[div[text()='Story Tags']]/following-sibling::div/span")
    WebElement storyTagsElement;

    @FindBy(xpath = "//div[div[text()='Post Tags']]/following-sibling::div/span")
    WebElement rankedPostTagsElement;

    @FindBy(xpath = "//*[@class='slack-name']/following-sibling::span")
    List<WebElement> storySlackChannelsList;

    @FindBy(xpath = "//button[contains(@class,'name')]/span")
    WebElement storyCreatorNameElement;

    @FindBy(xpath = "//span[contains(@class,'date-time')]")
    WebElement storyCreationDateTimeElement;

    @FindBy(xpath = "//span[contains(@class,'follower')]//button[contains(@class,'count')]")
    WebElement storyFollowerCountElement;

    /**
     * Story ID elements
     */
    @FindBy(xpath = "//div[contains(@class,'push-right')]")
    WebElement storyIdElement;

    @FindBy(xpath = "//div[contains(@class,'push-right')]/i[@nztype='copy']")
    WebElement storyIdCopyIcon;


    /**
     * Button elements
     */
    @FindBy(xpath = "//button[span[contains(text(),'Edit Story')]]")
    WebElement editStoryButton;

    @FindBy(xpath = "//button[span[contains(text(),'Merge Story')]]")
    WebElement mergeStoryButton;

    @FindBy(xpath = "//button[span[contains(text(),'Delete')]]")
    WebElement deleteStoryButton;

    @FindBy(xpath = "//a[span[contains(text(),'Add Post via Email')]]")
    WebElement addPostViaEmailButton;

    @FindBy(xpath = "//button[span[contains(text(),'Infocenter')]]")
    WebElement requestInfoCenterResearchButton;

    @FindBy(xpath = "//span[contains(text(),'Block from Slack')]/following-sibling::nz-switch/button")
    WebElement blockFromSlackToggle;

    /**
     * Delete story elements
     */
    @FindBy(xpath = "//span[contains(@class,'ant-modal-confirm-title')]/span")
    WebElement deleteStoryConfirmationPopUp;

    @FindBy(xpath = "//div[contains(@class,'ant-modal-confirm-btns')]/button[span[contains(text(),'Cancel')]]")
    WebElement deleteStoryCancelButton;

    @FindBy(xpath = "//div[contains(@class,'ant-modal-confirm-btns')]/button[span[contains(text(),'OK') or contains(text(),'Delete')]]")
    WebElement deleteStoryOkButton;

    @FindBy(xpath = "//div[@class='ant-message']//span[contains(translate(text(),'ABCDEFGHIJKLMNOPURSTUWXYZ','abcdefghijklmnopurstuwxyz'), 'successfully deleted')]")
    WebElement deletedStoryMessage;

    @FindBy(xpath = "//div[@class='ant-message']//span[contains(translate(text(),'ABCDEFGHIJKLMNOPURSTUWXYZ','abcdefghijklmnopurstuwxyz'), 'new story updated/added/deleted')]")
    WebElement newStoryAddedOrUpdatedOrDeletedMessage;

    /**
     * Merge story popup elements
     */
    @FindBy(xpath = "//div[p[text()='Merge Stories']]")
    WebElement mergeStoryPopupHeading;

    @FindBy(xpath = "//input[@placeholder='Search for the story here...']")
    WebElement searchStoryTextBoxInMergePopup;

    @FindBy(xpath = "//ul[@class='list-selector']/li")
    WebElement selectedStoryInMergePopup;

    @FindBy(xpath = "//ul[@class='list-selector']/li/button")
    WebElement selectedStoryDeleteIconInMergePopup;

    @FindBy(xpath = "//button[span[normalize-space()='Submit']]")
    WebElement submitButton;

    @FindBy(xpath = "//button[span[normalize-space()='Cancel']]")
    WebElement cancelButton;

    @FindBy(xpath = "//div[@class='ant-message']//span[contains(translate(text(),'ABCDEFGHIJKLMNOPURSTUWXYZ','abcdefghijklmnopurstuwxyz'), 'successfully merged')]")
    WebElement storyMergedMessage;

    String searchDropDownValuesXpath = "//nz-auto-option[contains(@class,'ant-select-item ant-select-item-option')]/div";


    public StoryDetailsPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify story details page is loaded
     */
    public void verifyStoryDetailsPageLoaded() throws Exception {
        try {
            Waits.waitForElement(addPostViaEmailButton, WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify draft story details page is loaded
     */
    public void verifyDraftStoryDetailsPageLoaded() throws Exception {
        try {
            Waits.waitForElement(editStoryButton, WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story id generated and displayed in story details page
     *
     * @throws Exception
     */
    public void verifyStoryIdGenerated() throws Exception {
        try {
            if (StoryConstants.getStoryId(StoryConstants.getStoryCount()) == null) {
                String topicCode = StoryConstants.getStoryTopicCode();
                String currentYear = DateFunctions.getCurrentDate("yy");
                String subjectCode = StoryConstants.getStorySubjectCode(StoryConstants.getStoryCount());
                String actualStoryId = WebAction.getText(storyIdElement);
                StoryConstants.setStoryId(actualStoryId);
                ExtentReportUtils.addLog(Status.INFO, "<b>Story ID: <i>" + actualStoryId + "<i></b>");
                String expectedStoryId = topicCode + currentYear + subjectCode;
                Assert.assertTrue(actualStoryId.matches(expectedStoryId + "[0-9]{4}"));
            } else
                CommonValidations.verifyTextValue(storyIdElement, StoryConstants.getStoryId(StoryConstants.getStoryCount()), "Story id of story is changed after story is updated");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story status indicator color
     *
     * @param storyStatus   - Story status
     * @param expectedColor - Expected color
     */
    public void verifyStoryStatusIndicator(String expectedColor, String storyStatus) throws Exception {
        try {
            if (storyStatus.equalsIgnoreCase("READY"))
                expectedColor = "GREEN-6";
            else expectedColor = "YELLOW-6";
            CommonValidations.verifyColorOfElement(storyStatusIndicatorElement, "background color", expectedColor);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story privacy eye icon based on story privacy
     *
     * @param storyPrivacy - Story Privacy
     */
    public void verifyStoryPrivacyEyeIcon(String storyPrivacy) {
        try {
            if (storyPrivacy.equalsIgnoreCase("PUBLIC"))
                CommonValidations.verifyAttributeValue(storyPrivacyEyeElement, "data-icon", "eye", "Public story eye icon is not displayed in story details page");
            else
                CommonValidations.verifyAttributeValue(storyPrivacyEyeElement, "data-icon", "eye-invisible", "Private story eye icon is not displayed in story details page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story details section in story details page
     *
     * @param fieldName - field name in story details page
     */
    public void verifyStoryDetailsSection(String fieldName) throws Exception {
        try {
            switch (fieldName.toUpperCase()) {
                case "STATUS":
                    String expectedStoryStatus = StoryConstants.getStoryStatus();
                    CommonValidations.verifyTextValue(storyStatusElement, expectedStoryStatus, "Story status is not correct in story details page");
                    break;
                case "PRIVACY":
                    String expectedStoryPrivacy = StoryConstants.getStoryPrivacy();
                    CommonValidations.verifyTextValue(storyPrivacyElement, expectedStoryPrivacy, "Story privacy is not correct in story details page");
                    break;
                case "TOPIC":
                    for (int i = 0; i < StoryConstants.getStoryTopicCount(); i++)
                        CommonValidations.verifyTextValue(storyTopicElement.get(i), StoryConstants.getStoryTopic(i).split("-")[1].trim(), "Story topic is not correct in story details page");
                    break;
                case "TITLE":
                    String expectedStoryTitle = StoryConstants.getStoryTitle(StoryConstants.getStoryCount());
                    CommonValidations.verifyTextValue(storyTitleElement, expectedStoryTitle, "Story title is not correct in story details page");
                    break;
                case "DESCRIPTION":
                    String expectedStoryDescription = StoryConstants.getStoryDescription(StoryConstants.getStoryCount());
                    CommonValidations.verifyTextValue(storyDescriptionList.get(0), expectedStoryDescription, "Story description is not correct in story details page");
                    break;
                case "TAGS":
                    String expectedStoryTags = "";
                    for (int i = 0; i < StoryConstants.getStoryTagCount(Integer.parseInt(StoryConstants.getStoryCount())); i++)
                        expectedStoryTags = expectedStoryTags + StoryConstants.getStoryTag(Integer.parseInt(StoryConstants.getStoryCount()), i) + ", ";
                    expectedStoryTags = expectedStoryTags.trim();
                    expectedStoryTags = expectedStoryTags.substring(0, expectedStoryTags.length() - 1);
                    CommonValidations.verifyTextValue(storyTagsElement, expectedStoryTags, "Story tags are not correct in story details page");
                    break;
                case "SLACK CHANNELS":
                    // Story slack channels will be displayed other than JOURNALIST role
                    if (!StoryConstants.getUserRole().equalsIgnoreCase("JOURNALIST")) {
                        for (int i = 0; i < StoryConstants.getStorySlackChannelCount(); i++)
                            CommonValidations.verifyTextValue(storySlackChannelsList.get(i), StoryConstants.getStorySlackChannel(i), "Story slack channel is not correct in story details page");
                    }
                    break;
                case "CREATED BY":
                    String expectedDisplayName = PostConstants.getDisplayName();
                    CommonValidations.verifyTextValue(storyCreatorNameElement, expectedDisplayName, "Story creator name is not correct in story details page");
                    break;
                case "CREATION TIME":
                    String expectedStoryCreationTime = StoryConstants.getStoryCreationTime(StoryConstants.getStoryCount());
                    CommonValidations.verifyCreationTime(storyCreationDateTimeElement, expectedStoryCreationTime, "h:mm a", "Story creation time is not correct in story details page");
                    break;
                case "CREATION DATE":
                    String expectedStoryCreationDate = StoryConstants.getStoryCreationDate(StoryConstants.getStoryCount());
                    CommonValidations.verifyTextValue(storyCreationDateTimeElement, expectedStoryCreationDate, "Story creation date is not correct in story details page");
                    break;
                case "FOLLOWERS COUNT":
                    CommonValidations.verifyTextValue(storyFollowerCountElement, "1", "Story followers count is not correct in story details page");
                    break;
                default:
                    Assert.fail("Please provide valid field name in story details page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * To verify options in story details page
     *
     * @param role - NCX role
     */
    public void verifyStoryOptions(String role) throws Exception {
        try {
            switch (role.toUpperCase()) {
                case "ADMIN":
                    CommonValidations.verifyElementIsEnabled(editStoryButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(mergeStoryButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(deleteStoryButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(addPostViaEmailButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(requestInfoCenterResearchButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(blockFromSlackToggle, "Block from slack toggle is not displayed in story details page");
                    break;
                case "SENIOR EDITOR", "STANDARDS":
                    CommonValidations.verifyElementIsEnabled(editStoryButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(mergeStoryButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(deleteStoryButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(addPostViaEmailButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(requestInfoCenterResearchButton, "Edit story option is not displayed in story details page");
                    break;
                case "JOURNALIST", "EDITOR":
                    CommonValidations.verifyElementIsEnabled(editStoryButton, "Edit story option is not displayed in story details page");
                    CommonValidations.verifyElementIsEnabled(addPostViaEmailButton, "Edit story option is not displayed in story details page");
                    break;
                default:
                    Assert.fail("Given role name '" + role + "' is not valid. Please enter valid ncx role name");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    public void clickButtonInStoryDetailsPage(String buttonName) throws Exception {
        try {
            switch (buttonName.toUpperCase()) {
                case "EDIT STORY":
                    WebAction.click(editStoryButton);
                    break;
                case "MERGE STORY":
                    WebAction.click(mergeStoryButton);
                    break;
                case "DELETE STORY":
                    WebAction.click(deleteStoryButton);
                    break;
                case "ADD POST VIA EMAIL":
                    WebAction.click(addPostViaEmailButton);
                    break;
                case "REQUEST INFOCENTER RESEARCH":
                    WebAction.click(requestInfoCenterResearchButton);
                    break;
                case "BLOCK FROM SLACK":
                    WebAction.click(blockFromSlackToggle);
                    break;
                default:
                    Assert.fail("Given button name '" + buttonName + "' is not valid. Please enter valid button name");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story/post delete confirmation pop up is displayed
     *
     * @param storyOrPost       - Story/Post
     * @param confirmationTitle - Confirmation pop up title
     */
    public void verifyDeleteConfirmationPopupDisplayed(String storyOrPost, String confirmationTitle) throws Exception {
        try {
            Waits.waitForElement(deleteStoryConfirmationPopUp, Waits.WAIT_CONDITIONS.VISIBLE);
            CommonValidations.verifyTextValue(deleteStoryConfirmationPopUp, confirmationTitle, "Delete " + storyOrPost + " confirmation pop up is not displayed");
            CommonValidations.verifyElementIsDisplayed(deleteStoryOkButton, "Ok button is not displayed in delete " + storyOrPost + " confirmation pop up");
            CommonValidations.verifyElementIsDisplayed(deleteStoryCancelButton, "Cancel button is not displayed in delete " + storyOrPost + " confirmation pop up");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click button in confirmation pop up
     *
     * @param buttonName - button name
     */
    public void clickButtonInConfirmationPopUp(String buttonName) throws Exception {
        try {
            if (buttonName.equalsIgnoreCase("OK"))
                WebAction.click(deleteStoryOkButton);
            else if (buttonName.equalsIgnoreCase("CANCEL"))
                WebAction.click(deleteStoryCancelButton);
            else Assert.fail("Please valid button name in delete confirmation pop up");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story/post deleted message
     *
     * @param storyOrPost     - Story/Post
     * @param deletionMessage - Deletion message
     */
    public void verifyStoryDeleteMessage(String storyOrPost, String deletionMessage) throws Exception {
        try {
            Waits.waitForElement(deletedStoryMessage, Waits.WAIT_CONDITIONS.VISIBLE);
            CommonValidations.verifyTextValue(deletedStoryMessage, deletionMessage, storyOrPost + " deleted message is not displayed");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify merge story pop up displayed
     *
     * @throws Exception
     */
    public void verifyMergeStoryPopUpDisplayed() throws Exception {
        try {
            Waits.waitForElement(mergeStoryPopupHeading, Waits.WAIT_CONDITIONS.VISIBLE);
            Waits.waitForElement(searchStoryTextBoxInMergePopup, WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Search and merge story
     *
     * @param searchText - Search text
     * @throws Exception
     */
    public void searchAndMergeStory(String searchText) throws Exception {
        try {
            if (searchText == null)
                searchText = StoryConstants.getStoryTitle(String.valueOf(Integer.parseInt(StoryConstants.getStoryCount()) - 1));
            WebAction.selectNonTitleDropDown(searchStoryTextBoxInMergePopup, searchText, searchDropDownValuesXpath, "Story search results are not displayed for '" + searchText + "' search text in merge story popup");
            CommonValidations.verifyTextValue(selectedStoryInMergePopup, searchText, searchText + " story is not selected in merge story pop up");
            CommonValidations.verifyElementIsEnabled(selectedStoryDeleteIconInMergePopup, "Delete icon is not displayed for selected story in merge story pop up");
            WebAction.click(submitButton);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story successfully message is displayed
     *
     * @param expectedMessage - Expected Message
     * @throws Exception
     */
    public void verifyStoryMergedSuccessMessage(String expectedMessage) throws Exception {
        try {
            Waits.waitForElement(storyMergedMessage, WAIT_CONDITIONS.VISIBLE);
            CommonValidations.verifyTextValue(storyMergedMessage, expectedMessage, "Story merged success message is not displayed");
            Waits.waitForElement(storyMergedMessage, WAIT_CONDITIONS.INVISIBLE);

            //Adding story 1 tags as ranked post tags for story 2
            for (int i = 0; i < StoryConstants.getStoryTagCount(Integer.parseInt(StoryConstants.getStoryCount())); i++) {
                String tag = StoryConstants.getStoryTag(Integer.parseInt(StoryConstants.getStoryCount()), i);
                StoryConstants.setRankedPostTags(StoryConstants.getRankedPostTagsCount(), tag.toLowerCase());
                StoryConstants.setRankedPostTagsCount(StoryConstants.getRankedPostTagsCount() + 1);
            }

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story option display status in draft story details page
     *
     * @param storyOption   - Story Option (i.e) Edit Story, Delete Story, Merge Story, Add Post Via Email
     * @param displayStatus - Displayed/Not Displayed
     */
    public void verifyStoryOptionDisplayStatusForDraftStory(String storyOption, String displayStatus) {
        try {
            if (storyOption.equalsIgnoreCase("ADD POST VIA EMAIL")) {
                if (displayStatus.equalsIgnoreCase("DISPLAYED"))
                    CommonValidations.verifyElementIsDisplayed(addPostViaEmailButton, "Add post via email option is not displayed in draft story details page");
                else
                    Assert.assertFalse(WebAction.isDisplayed(addPostViaEmailButton), "Add post via email option is displayed in draft story details page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story option is displayed/not displayed for role
     *
     * @param storyOption   - Story Option (i.e) Edit Story, Delete Story, Merge Story, Add Post Via Email
     * @param displayStatus - Displayed/Not Displayed
     * @param role          - Journalist/Editor/Senior Editor/Standards/Admin
     */
    public void verifyStoryOptionDisplayStatusForStory(String storyOption, String displayStatus, String role) {
        try {
            if (storyOption.equalsIgnoreCase("EDIT STORY")) {
                if (displayStatus.equalsIgnoreCase("DISPLAYED"))
                    CommonValidations.verifyElementIsDisplayed(editStoryButton, "Edit story option is not displayed for " + role + " user in story details page");
                else
                    Assert.assertFalse(WebAction.isDisplayed(editStoryButton), "Edit story option is displayed for " + role + " user in story details page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify post tags field is displayed in story details page
     *
     * @throws Exception
     */
    public void verifyPostTagsFieldDisplayed() throws Exception {
        try {
            CommonValidations.verifyElementIsDisplayed(storyPostTagTitles.get(1), "Post tags field is not displayed in story details page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify post tags tool tip message
     *
     * @param expectedPostTagsToolTipMessage - Expected Post tags tool tip message
     */
    public void verifyPostTagsToolTipMessage(String expectedPostTagsToolTipMessage) throws Exception {
        try {
            WebAction.mouseOver(rankedPostTagsToolTipIcon);
            CommonValidations.verifyTextValue(postTagsToolTipMessage, expectedPostTagsToolTipMessage, "Post tags tool tip message is not correct in story details page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify ranked story tags in story details page
     */
    public void verifyRankedStoryTags() throws Exception {
        try {
            HashMap<String, Integer> expectedRankedStoryTags = new HashMap<>();
            for (int i = 0; i < StoryConstants.getRankedPostTagsCount(); i++) {
                if (expectedRankedStoryTags.containsKey(StoryConstants.getRankedPostTags(i)))
                    expectedRankedStoryTags.put(StoryConstants.getRankedPostTags(i), expectedRankedStoryTags.get(StoryConstants.getRankedPostTags(i)) + 1);
                else expectedRankedStoryTags.put(StoryConstants.getRankedPostTags(i), 1);
            }

            // To find tag which has highest occurrence count
            Map.Entry<String, Integer> maxEntry = null;
            for (Map.Entry<String, Integer> entry : expectedRankedStoryTags.entrySet()) {
                // If maxEntry is null OR current entry's value is greater than maxEntry's value
                if (maxEntry == null || entry.getValue().compareTo(maxEntry.getValue()) > 0) {
                    maxEntry = entry;
                }
            }

            System.out.println(expectedRankedStoryTags);

            assert maxEntry != null;
            int maxValue = maxEntry.getValue();
            String[] actualRankedPostTags = WebAction.getText(rankedPostTagsElement).split(",");
            for (int i = 0; i < actualRankedPostTags.length; i++) {
                System.out.println(actualRankedPostTags[i].trim());
                Assert.assertTrue(expectedRankedStoryTags.containsKey(actualRankedPostTags[i].trim()));
                if (i == 0)
                    CommonValidations.verifyIntegerValues(expectedRankedStoryTags.get(actualRankedPostTags[i].trim()), maxEntry.getValue(), "Post tag '" + actualRankedPostTags[i].trim() + "' which has max occurrence count of '" + maxEntry.getValue() + "' is not displayed in first in ranked post tags in story details page");
                else {
                    int occurrenceCount = expectedRankedStoryTags.get(actualRankedPostTags[i].trim());
                    Assert.assertTrue(expectedRankedStoryTags.get(actualRankedPostTags[i].trim()) <= maxValue, "Post tag '" + actualRankedPostTags[i].trim() + "' which has occurrence count of '" + occurrenceCount + "' is not displayed in right order");
                    if (occurrenceCount < maxValue)
                        maxValue = occurrenceCount;
                }
            }

        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify ranked post tags are not displayed in story details page
     * @throws Exception
     */
    public void verifyRankedPostTagsRemoved() throws Exception {
        try {
            Assert.assertFalse(WebAction.isDisplayed(rankedPostTagsElement), "Ranked post tags are displayed in story details page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }
}
