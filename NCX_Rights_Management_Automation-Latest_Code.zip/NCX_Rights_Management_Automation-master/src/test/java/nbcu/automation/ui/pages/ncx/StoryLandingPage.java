package nbcu.automation.ui.pages.ncx;

import nbcu.automation.ui.constants.ncx.AngleConstants;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.others.DateFunctions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

public class StoryLandingPage {

	/**
     * Story landing Header Elements
    */
    @FindBy(xpath = "//span[@class='text']")
    WebElement storyTitleElement;

    @FindBy(xpath = "//div[@class='desc ng-star-inserted']")
    WebElement storyDescriptionElement;

    @FindBy(xpath = "//div[contains(@class,'push-right')]")
    WebElement storyIdElement;

    @FindBy(xpath = "//div[contains(@class,'push-right')]/i")
    WebElement storyIdCopyIcon;

    @FindBy(xpath = "//button[contains(@data-component,'follow-story')]")
    WebElement followStoryOption;

    @FindBy(xpath = "//button[contains(@class,'followers groupbutton')]")
    WebElement followersOption;

    @FindBy(xpath = "//button[contains(@class,'story-details')]")
    WebElement storyDetailsOption;

    /**
     * Story landing footer elements
     */
    @FindBy(xpath = "//button[span[text()='Infocenter']]")
    WebElement infoCenterButton;

    @FindBy(xpath = "//button[span[text()='Add Post via Email']]")
    WebElement addPostViaEmail;

    @FindBy(xpath = "//button[span[normalize-space()='Add New']]")
    WebElement addNew;

    /**
     * Story landing tab elements
     */
    @FindBy(xpath = "//div[@role='tab' and normalize-space()='Posts']")
    WebElement postsTab;

    @FindBy(xpath = "//button[@role='tab' and contains(text(),'Angles')]")
    WebElement anglesTab;

    /**
     * Post tab elements
     */
    @FindBy(xpath = "//a[@class='title']")
    List<WebElement> postTitleList;

    @FindBy(xpath = "//*[@class='created-updated']/button")
    List<WebElement> postCreatedByList;

    @FindBy(xpath = "//*[@class='created-updated']")
    List<WebElement> postCreatedorModifiedDateTimeList;

    @FindBy(xpath = "//div[contains(@class,'description')]")
    List<WebElement> postDescriptionList;

    @FindBy(xpath = "//button[i[@nztype='pushpin']]")
    WebElement pinStoryIcon;

    @FindBy(xpath = "//i[@nztype='paper-clip']")
    List<WebElement> attachmentIconList;

    @FindBy(xpath = "//span[normalize-space()='Share']")
    List<WebElement> shareIconList;

    @FindBy(xpath = "//span[normalize-space()='Add to Angle']")
    List<WebElement> addToAngleButtonList;

    /**
     * Angle tab elements
     */
    @FindBy(xpath = "//div[@class='angle-details-id']/button/span")
    List<WebElement> angleIdList;

    @FindBy(xpath = "//div[contains(@class,'angle-icon')]/button/span")
    List<WebElement> angleTitleList;

    @FindBy(xpath = "//span[normalize-space()='Created By:']/following-sibling::span[1]")
    List<WebElement> angleCreatedByList;

    @FindBy(xpath = "//span[normalize-space()='Created By:']/following-sibling::span[2]")
    List<WebElement> angleCreatedOnList;

    public StoryLandingPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify story landing page loaded
     */
    public void verifyStoryLandingPageLoaded() throws Exception {
        try {
            Waits.waitForElement(infoCenterButton, Waits.WAIT_CONDITIONS.CLICKABLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To open Posts/Angles tab
     *
     * @throws Exception
     */
    public void openTab(String tabName) throws Exception {
        try {
            if (tabName.equalsIgnoreCase("ANGLES"))
                WebAction.click(anglesTab);
            else WebAction.click(postsTab);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click story landing page footer options
     *
     * @param buttonName - Button Name
     * @throws Exception
     */
    public void clickOptionsInFooter(String buttonName) throws Exception {
        try {
            if (buttonName.equalsIgnoreCase("ADD NEW"))
                WebAction.click(addNew);
            else if (buttonName.equalsIgnoreCase("ADD POST VIA EMAIL"))
                WebAction.click(addPostViaEmail);
            else if (buttonName.equalsIgnoreCase("INFOCENTER"))
                WebAction.click(infoCenterButton);
            else
                Assert.fail("Given button '" + buttonName + "' is not found in story landing page footer. Please provide valid button name");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story title and description in story landing page
     *
     * @throws Exception
     */
    public void verifyStoryTitleAndDescription() throws Exception {
        try {
            CommonValidations.verifyTextValue(storyTitleElement, StoryConstants.getStoryTitle(StoryConstants.getStoryCount()), "Story title in story landing page is not correct");
            CommonValidations.verifyTextValue(storyDescriptionElement, StoryConstants.getStoryDescription(StoryConstants.getStoryCount()), "Story description in story landing page is not correct");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story id is displayed along with copy icon
     * @throws Exception
     */
    public void verifyStoryIdDisplayedWithCopyIcon() throws Exception {
        try {
            CommonValidations.verifyTextValue(storyIdElement, StoryConstants.getStoryId(StoryConstants.getStoryCount()), "Story id in story landing page is not correct");
            CommonValidations.verifyElementIsEnabled(storyIdCopyIcon, "Story id copy icon is not displayed next to story id in story landing page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify Story id of story
     * @throws Exception
     */
    public void verifyStoryId(String expectedStoryId) throws Exception {
        try {
            CommonValidations.verifyTextValue(storyIdElement, expectedStoryId, "Story id in story landing page is not correct");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To click story landing page header options
     *
     * @param buttonName - button Name
     */
    public void clickOptionsInHeader(String buttonName) throws Exception {
        try {
            if (buttonName.equalsIgnoreCase("FOLLOW"))
                WebAction.click(followStoryOption);
            else if (buttonName.equalsIgnoreCase("FOLLOWERS"))
                WebAction.click(followersOption);
            else if (buttonName.equalsIgnoreCase("STORY DETAILS"))
                WebAction.click(storyDetailsOption);
            else
                Assert.fail("Given button '" + buttonName + "' is not found in story landing page header. Please provide valid button name");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }


    /**
     * To verify pinned story is displayed in the top
     */
    public void verifyPinnedPostDisplayedInTop() throws Exception {
        try {
            Thread.sleep(2000);
            Waits.waitUntilElementSizeGreater(postTitleList, 0);
            Waits.waitForElement(postTitleList.get(0), Waits.WAIT_CONDITIONS.CLICKABLE);
            CommonValidations.verifyTextValue(postTitleList.get(0), PostConstants.getPostTitle("1"), "Pinned story is not displayed in top of story landing page");
            CommonValidations.verifyTextValue(postDescriptionList.get(0), PostConstants.getPostDescription("1"), "Pinned story description is not correct");
            CommonValidations.verifyElementIsDisplayed(pinStoryIcon, "pin story icon is not displayed for pinned story");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * Verify merged story is converted as post
     *
     * @throws Exception
     */
    public void verifyMergedStoryConvertedAsPost() throws Exception {
        try {
            boolean convertedPostPresent = false;
            Waits.waitUntilElementSizeGreater(postTitleList, 0);
            for (int i = 0; i < postTitleList.size(); i++) {
                if ((WebAction.getText(postTitleList.get(i)).toLowerCase().contains(StoryConstants.getStoryTitle(StoryConstants.getStoryCount()).toLowerCase())) && (WebAction.getText(postDescriptionList.get(i)).toLowerCase().contains(StoryConstants.getStoryDescription(StoryConstants.getStoryCount()).toLowerCase()))) {
                    convertedPostPresent = true;

                    //Set post constants for future reference
                    String postCount = null;
                    if(PostConstants.getPostCount() == null)
                        postCount = "1";
                    else postCount = String.valueOf(Integer.parseInt(PostConstants.getPostCount()) + 1);
                    PostConstants.setPostCount(postCount);
                    PostConstants.setPostTitle(StoryConstants.getStoryTitle(StoryConstants.getStoryCount()));
                    PostConstants.setPostDescription(StoryConstants.getStoryDescription(StoryConstants.getStoryCount()));
                    PostConstants.setPostCreationDate(StoryConstants.getStoryCreationDate(StoryConstants.getStoryCount()));
                    PostConstants.setPostCreationTime(DateFunctions.getCurrentDate("h:mm a"));
                    StoryConstants.setStoryCount(String.valueOf(Integer.parseInt(StoryConstants.getStoryCount()) - 1));
                    break;
                }
            }
            Assert.assertTrue(convertedPostPresent, "Merged story which converted as post is not displayed in story landing page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify angle details in story landing page
     *
     * @throws Exception
     */
    public void verifyAngleDetails() throws Exception {
        try {
            for (int i = 0; i < angleIdList.size(); i++) {
                CommonValidations.verifyTextValue(angleIdList.get(i), "#"+AngleConstants.getAngleID(String.valueOf(Integer.parseInt(AngleConstants.getAngleCount())-i)), "Angle id is not correct in angle tab of story landing page");
                CommonValidations.verifyTextValue(angleTitleList.get(i), AngleConstants.getAngleTitle(String.valueOf(Integer.parseInt(AngleConstants.getAngleCount())-i)), "Angle title is not correct in angle tab of story landing page");
                CommonValidations.verifyTextValue(angleCreatedByList.get(i), PostConstants.getDisplayName(), "Angle created by is not correct in angle tab of story landing page");
                String expectedCreatedOn = "on " + AngleConstants.getAngleCreationDate(String.valueOf(Integer.parseInt(AngleConstants.getAngleCount())-i)) + " at " + AngleConstants.getAngleCreationTime(String.valueOf(Integer.parseInt(AngleConstants.getAngleCount())-i));
                CommonValidations.verifyTextValue(angleCreatedOnList.get(i), expectedCreatedOn, "Angle created on is not correct in angle tab of story landing page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To open angle from story landing page
     *
     * @throws Exception
     */
    public void openAngle() throws Exception {
        try {
            int windowSize = WebAction.getWindowsSize();
            WebAction.click(angleIdList.get(0));
            WebAction.switchToNewWindow(windowSize + 1);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify merged post list
     * @throws Exception
     */
    public void verifyPostDetails() throws Exception {
        try {
            for (int i = 0; i < postTitleList.size(); i++) {
                CommonValidations.verifyTextValue(postTitleList.get(i), PostConstants.getPostTitle(String.valueOf(Integer.parseInt(PostConstants.getPostCount())-i)), "Post title is not correct in posts tab of story landing page");
                CommonValidations.verifyTextValue(postCreatedByList.get(i), PostConstants.getFirstName().charAt(0)+". "+PostConstants.getLastName().trim(), "Post created by is not correct in posts tab of story landing page");

                //Verify creation date and time
                String expectedCreatedDate = "on " + PostConstants.getPostCreationDate(String.valueOf(Integer.parseInt(PostConstants.getPostCount())-i)) + " at ";
                CommonValidations.verifyTextValue(postCreatedorModifiedDateTimeList.get(i), expectedCreatedDate, "Post created date is not correct in posts tab of story landing page");
                String expectedCreatedTime = PostConstants.getPostCreationTime(String.valueOf(Integer.parseInt(PostConstants.getPostCount())-i));
                CommonValidations.verifyCreationTime(postCreatedorModifiedDateTimeList.get(i), expectedCreatedTime, "h:mm a", "Post created time is not correct in posts tab of story landing page");

                CommonValidations.verifyIntegerValues(attachmentIconList.size(), 3, "Attachment icon is not displayed for one of the post in story landing page");
                CommonValidations.verifyIntegerValues(shareIconList.size(), 3, "Share icon is not displayed for one of the post in story landing page");
                CommonValidations.verifyIntegerValues(addToAngleButtonList.size(), 3, "Add to angle button is not displayed for one of the post in story landing page");
            }
            PostConstants.setLinkedStory(0, StoryConstants.getStoryTitle(StoryConstants.getStoryCount()));
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To open post from story landing page
     *
     * @throws Exception
     */
    public void openPost() throws Exception {
        try {
            int windowSize = WebAction.getWindowsSize();
            WebAction.click(postTitleList.get(1));
            WebAction.switchToNewWindow(windowSize + 1);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }
}
