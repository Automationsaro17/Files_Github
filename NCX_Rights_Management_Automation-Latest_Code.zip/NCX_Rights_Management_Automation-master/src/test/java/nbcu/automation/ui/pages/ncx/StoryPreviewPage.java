package nbcu.automation.ui.pages.ncx;

import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.constants.ncx.StoryConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.factory.DriverFactory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

public class StoryPreviewPage {

    /**
     * Preview Info Message Elements
     */
    @FindBy(xpath = "//div[contains(@class,'banner')]/div[@class='info']")
    WebElement previewPageInfoIcon;

    @FindBy(xpath = "//div[contains(@class,'banner')]/div[@class='text']")
    WebElement previewPageInfoMessage;

    @FindBy(xpath = "//div[contains(@class,'banner')]/div[@class='close']")
    WebElement previewPageInfoCloseIcon;

    /**
     * Story Details Elements
     */
    @FindBy(xpath = "//div[contains(@class,'story-status with-text')]")
    WebElement storyStatusElement;

    @FindBy(xpath = "//div[contains(@class,'story-status with-text')]/span")
    WebElement storyStatusIndicatorElement;

    @FindBy(xpath = "//div[contains(@class,'story-access')]")
    WebElement storyPrivacyElement;

    @FindBy(xpath = "//div[contains(@class,'story-access')]/..//div[contains(@class,'eye-invisible-icon')]/i/*[name()='svg']")
    WebElement storyPrivacyEyeElement;

    @FindBy(xpath = "//div[contains(@class,'topics')]")
    WebElement emptyStoryTopic;

    @FindBy(xpath = "//div[contains(@class,'topics')]/span")
    List<WebElement> storyTopicElement;

    @FindBy(xpath = "//div[contains(@class,'topics')]/following::div[contains(@class,'title')]")
    WebElement emptyStoryTitle;

    @FindBy(xpath = "//div[contains(@class,'topics')]/following-sibling::div[contains(@class,'title')]/span")
    WebElement storyTitleElement;

    @FindBy(xpath = "//div[contains(@class,'description')]")
    WebElement emptyStoryDescription;

    @FindBy(xpath = "//*[@id='storyContent']/span/p")
    List<WebElement> storyDescriptionList;

    @FindBy(xpath = "//i[@nztype='tags']/following-sibling::span[2]")
    WebElement storyTagsElement;

    @FindBy(xpath = "//*[@class='slack-name']/following-sibling::span")
    List<WebElement> storySlackChannelsList;

    /**
     * Buttons Element
     */
    @FindBy(xpath = "//button[contains(@class,'cancel')]")
    WebElement cancelButton;

    @FindBy(xpath = "//button[i[@nztype='send']]")
    WebElement publishButton;


    public StoryPreviewPage() {
        PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
    }

    /**
     * To verify story preview page is loaded
     */
    public void verifyStoryPreviewPageLoaded() throws Exception {
        try {
            Waits.waitForElement(previewPageInfoIcon, Waits.WAIT_CONDITIONS.VISIBLE);
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify preview info message in story preview page
     *
     * @param expectedPreviewMessage - Expected Preview Info Message
     */
    public void verifyStoryPreviewMessage(String expectedPreviewMessage) {
        try {
            CommonValidations.verifyElementIsDisplayed(previewPageInfoIcon, "Preview page info icon is not displayed in preview info message");
            CommonValidations.verifyTextValue(previewPageInfoMessage, expectedPreviewMessage, "Preview info message is not correct in story preview page");
            CommonValidations.verifyElementIsDisplayed(previewPageInfoCloseIcon, "Preview page close icon is not displayed in preview info message");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story privacy eye icon in story preview page
     *
     * @param storyPrivacy - Story Privacy
     */
    public void verifyStoryPrivacyEyeIcon(String storyPrivacy) {
        try {
            if (storyPrivacy.equalsIgnoreCase("PUBLIC"))
                CommonValidations.verifyAttributeValue(storyPrivacyEyeElement, "data-icon", "eye", "Public story eye icon is not displayed in story preview page");
            else
                CommonValidations.verifyAttributeValue(storyPrivacyEyeElement, "data-icon", "eye-invisible", "Private story eye icon is not displayed in story preview page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify story details section in story preview page
     *
     * @param fieldName - field name in story preview page
     */
    public void verifyStoryDetailsSection(String fieldName) {
        try {
            switch (fieldName.toUpperCase()) {
                case "STATUS":
                    String expectedStoryStatus = StoryConstants.getStoryStatus();
                    CommonValidations.verifyTextValue(storyStatusElement, expectedStoryStatus, "Story status is not correct in story preview page");
                    break;
                case "PRIVACY":
                    String expectedStoryPrivacy = StoryConstants.getStoryPrivacy();
                    CommonValidations.verifyTextValue(storyPrivacyElement, expectedStoryPrivacy, "Story privacy is not correct in story preview page");
                    break;
                case "TOPIC":
                    if (StoryConstants.getStoryTopic(0) == null)
                        CommonValidations.verifyTextValue(emptyStoryTopic, "Topics will be displayed here", "Story topic is not correct in story preview page");
                    else {
                        for (int i = 0; i < StoryConstants.getStoryTopicCount(); i++)
                            CommonValidations.verifyTextValue(storyTopicElement.get(i), StoryConstants.getStoryTopic(i).split("-")[1].trim(), "Story topic is not correct in story preview page");
                    }
                    break;
                case "TITLE":
                    if (StoryConstants.getStoryTitle("1") == null)
                        CommonValidations.verifyTextValue(emptyStoryTitle, "Story Name Will be Displayed Here", "Story title is not correct in story preview page");
                    else {
                        String expectedStoryTitle = StoryConstants.getStoryTitle(StoryConstants.getStoryCount());
                        CommonValidations.verifyTextValue(storyTitleElement, expectedStoryTitle, "Story title is not correct in story preview page");
                    }
                    break;
                case "DESCRIPTION":
                    if (StoryConstants.getStoryDescription("1") == null)
                        CommonValidations.verifyTextValue(emptyStoryDescription, "Your story description will be displayed here", "Story description is not correct in story preview page");
                    else {
                        String expectedStoryDescription = StoryConstants.getStoryDescription(StoryConstants.getStoryCount());
                        CommonValidations.verifyTextValue(storyDescriptionList.get(0), expectedStoryDescription, "Story description is not correct in story preview page");
                    }
                    break;
                case "TAGS":
                    if (StoryConstants.getStoryTag(Integer.parseInt(StoryConstants.getStoryCount()), 0) != null) {
                        String expectedStoryTags = "";
                        for (int i = 0; i < StoryConstants.getStoryTagCount(Integer.parseInt(StoryConstants.getStoryCount())); i++)
                            expectedStoryTags = expectedStoryTags + StoryConstants.getStoryTag(Integer.parseInt(StoryConstants.getStoryCount()), i) + ", ";
                        expectedStoryTags = expectedStoryTags.trim();
                        expectedStoryTags = expectedStoryTags.substring(0, expectedStoryTags.length() - 1);
                        CommonValidations.verifyTextValue(storyTagsElement, expectedStoryTags, "Story tags are not correct in story preview page");
                    }
                    break;
                case "SLACK CHANNELS":
                    // Story slack channels will be displayed other than JOURNALIST role
                    if (!StoryConstants.getUserRole().equalsIgnoreCase("JOURNALIST")) {
                        if (StoryConstants.getStorySlackChannel(0) != null) {
                            for (int i = 0; i < StoryConstants.getStorySlackChannelCount(); i++)
                                CommonValidations.verifyTextValue(storySlackChannelsList.get(i), StoryConstants.getStorySlackChannel(i), "Story slack channel is not correct in story preview page");
                        }
                    }
                    break;
                default:
                    Assert.fail("Please provide valid field name in story preview page");
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify Cancel and Publish buttons are displayed in story preview page
     */
    public void verifyCancelAndPublishButtonsDisplayed() {
        try {
            CommonValidations.verifyElementIsEnabled(cancelButton, "Cancel button is not displayed in story preview page");
            CommonValidations.verifyElementIsDisplayed(publishButton, "Publish button is not displayed in story preview page");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }

    /**
     * To verify publish button is enabled/disabled
     *
     * @param enabledOrDisabled - Enabled/Disabled
     */
    public void verifyPublishButtonEnableOrDisabled(String enabledOrDisabled) {
        try {
            if (enabledOrDisabled.equalsIgnoreCase("ENABLED"))
                CommonValidations.verifyElementIsEnabled(publishButton, "Publish button is disabled in story preview page");
            else
                CommonValidations.verifyElementIsDisabledByAttribute(publishButton, "Publish button is enabled in story preview story");
        } catch (Exception e) {
            e.fillInStackTrace();
            throw e;
        }
    }
}