package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.AngleLandingPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

import javax.xml.crypto.Data;

public class AngleLandingPageSteps {

    AngleLandingPage anlgeLandingPage = new AngleLandingPage();

    @And("verify Angle landing page is loaded")
    @And("verify updated Angle details page is loaded")
    public void verifyAngleDetailsPageLoaded() throws Exception {
        anlgeLandingPage.verifyAngleLandingPageLoaded();
    }

    @And("verify {string} in angle landing page")
    @Then("verify {string} is updated in angle landing page")
    public void verifyAngleDetailsPageHeaderSection(String textLabels) throws Exception {
        anlgeLandingPage.verifyAnglePageHeader(textLabels);
    }

    @And("verify story id is displayed in {string} of angle landing page")
    public void verifyStoryIdInAngleLandingPage(String fieldName) throws Exception {
        anlgeLandingPage.verifyLinkedStoryId();
    }

    @Then("verify {string} angle {string} in angle landing page for user who do not access")
    public void verifyPrivateAngleOverviewMessage(String anglePrivacy, String tabName, DataTable params) throws Exception {
        anlgeLandingPage.verifyAngleOverviewForPrivateAngle(CucumberUtils.getValuesFromDataTable(params, "Private Angle Overview Message"));
    }

    @Then("verify material and log tabs are disabled for user who do not access to {string}")
    public void verifyMaterialAndLogTabsDisabled(String anglePrivacy) throws Exception {
        anlgeLandingPage.verifyMaterialAndLogTabsDisabled();
    }


    @Then("verify invisible eye icon is {string} for {string} angle in angle landing page")
    public void verifyAngleOptions(String visibility, String anglePrivacy) throws Exception {
        anlgeLandingPage.verifyInvisibleEyeIcon(visibility, anglePrivacy);
    }

    @When("verify below angle {string} are {string} in angle landing page")
    public void verifyAngleOptions(String options, String visibility, DataTable params) throws Exception {
        anlgeLandingPage.verifyAngleOptions(visibility, params);
    }

    @When("user clicks on {string} tab in angle landing page")
    public void openTabInAngleLandingPage(String tabName) throws Exception {
        anlgeLandingPage.openTabInAngleLandingPage(tabName);
    }

    @Then("user clicks {string} button in angle landing page")
    public void clickButton(String buttonName) throws Exception {
        anlgeLandingPage.clickButton(buttonName);
    }

    @Then("verify {string} for angle {string}")
    public void logTabInAngleLandingPage(String tabName, String action, DataTable params) throws Exception {
        anlgeLandingPage.verifyAngleCreationLog(action, CucumberUtils.getValuesFromDataTable(params, "Log Message"));
    }

    @And("user able to collapse the history container in log tab")
    public void collapseLogScrollContainer() throws Exception {
        anlgeLandingPage.collapseLog();
    }

    @And("verify the {string} in updated angle landing Page")
    public void verifyAngleIDLandingPage(String ID) throws Exception {
        anlgeLandingPage.verifyAngleIDInLandingPage();
    }

    @And("verify updated {string} in angle landing page")
    public void verifyUpdatedAngle(String title) {
        anlgeLandingPage.verifyAngleTitleInLandingPage();
    }


    @And("load the angles from angle listing page")
    public void openAngleFromListingPage() throws Exception {
        anlgeLandingPage.verifyAngleDetailPage();
    }

    @Then("verify the angle landing page should not display any buttons for {string} role")
    public void angleOverviewPageFooterButtons(String role, DataTable params) {
        anlgeLandingPage.verifyButtonsInAngleOverviewFooterPart(role, params);
    }

    @Then("verify {string} tab is loaded")
    public void verifyTabDisplayed(String tabName) throws Exception {
        if (tabName.equalsIgnoreCase("MATERIAL"))
            anlgeLandingPage.verifyMaterialTabLoaded();
    }

    @And("verify {string} post is displayed in {string} tab of {string} landing page")
    public void verifyPostInMaterialView(String action, String tabName, String landingPageName) throws Exception {
        if ((tabName.equalsIgnoreCase("ALL")) || (tabName.equalsIgnoreCase("STANDARDS")))
            anlgeLandingPage.verifyPostDisplayedInAllAndStandardsTab(tabName, landingPageName);
        else
            anlgeLandingPage.verifyPostDisplayedInElementsTab(tabName, landingPageName);
    }

    @When("user opens {string} tab of {string} landing page")
    public void openTab(String tabName, String landingPageName) throws Exception {
        anlgeLandingPage.openTabInMaterialView(tabName);
    }
}
