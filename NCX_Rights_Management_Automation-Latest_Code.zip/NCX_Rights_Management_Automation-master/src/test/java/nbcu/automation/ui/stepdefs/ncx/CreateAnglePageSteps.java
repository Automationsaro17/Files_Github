package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import nbcu.automation.ui.pages.ncx.CreateAnglePage;
import nbcu.automation.ui.pages.ncx.CreateStoryPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class CreateAnglePageSteps {
	CreateAnglePage createAnglePage = new CreateAnglePage();
	
	
	@Then("user {string} the Angle {string}")
	public void enterAngleTitleAndDescription(String action, String fieldName, DataTable dataTable) throws Exception {
		if (fieldName.equalsIgnoreCase("Title"))
			createAnglePage.fillAngleTitle(action, CucumberUtils.getValuesFromDataTable(dataTable, "Angle title"));
		else
			createAnglePage.fillAngleDescription(action, CucumberUtils.getValuesFromDataTable(dataTable, "Angle Description"));
	}

	@Then("verify {string} search drop down field is displayed")
	public void verifyCollaboratorField(String name) throws Exception {
		createAnglePage.verifySearchCollaboratorsField();
	}

	@And("user updates angle {string} as {string}")
	@And("user selects angle {string} as {string}")
	public void verifyCollaboratorField(String fieldName, String anglePrivacy) throws Exception {
		createAnglePage.selectAnglePrivacy(anglePrivacy);
	}

	@Then("verify {string} eye icon is displayed")
	public void verifyEyeIcon(String visibility) throws Exception {
		createAnglePage.verifyEyeIcon(visibility);
	}

	@Then("verify logged in profile is displayed as default collaborator")
	public void verifyDefaultCollaboratorTeamMember() {
		createAnglePage.verifyDefaultCollaborator();
	}
	
	@Then("verify story is linked by default in create angle page")
	public void verifyStoryNameInParkingLotSection() throws Exception {
		createAnglePage.verifyLinkedStoryName();
	}

	@And("verify story id is displayed along with story name in Add to Story")
	public void verifyStoryIdInParkingLotSection() throws Exception {
		createAnglePage.verifyLinkedStoryId();
	}

	@Then("user selects the {string} to associate this angle")
	public void enterTheStoryNameInAddToStoryField(String name) throws Exception {
		createAnglePage.searchAndSelectStory();
	}

	@And("user adds collaborators to the angle")
	public void addCollaborators(DataTable dataTable) throws Exception {
		createAnglePage.addCollaborators(dataTable);
	}

	@Then("user click on {string} button in create angle page")
	@Then("user clicked {string} button in update angle page")
	public void clickButtonFromFooter(String buttonName) throws Exception {
		createAnglePage.clickButton(buttonName);
	}
	
    @Then("verify the app linked stories in Angle landing page")
    public void linkedStoryName() throws Exception {
    	createAnglePage.verifyLinkedStoryName();
    }
    
    @And("user able to delete the linked story from parking lot section")
    public void DeleteLinkedStory(DataTable params) throws Exception {
    	createAnglePage.deleteAssociatedStory(CucumberUtils.getValuesFromDataTable(params, "Story Required Inline message"));
    }
    
    @Then("user should select the same story to associate the angle")
    public void reselectTheStory() throws Exception {
    	createAnglePage.searchAndSelectStory();
    }

    @And("user delete {string} for this angle")
    public void deleteAddedStoryTeamMembers(String team) throws Exception {
    	createAnglePage.deleteStoryTeam();
    }
    
    @And("user verify the story team members name card default display the {string} name")
    public void verifyStoryTeamDefaultName(String userRole) {
    	createAnglePage.verifyLoginUserNameInCard(userRole);
    }

	@And("verify {string} toast message is displayed")
	public void verifyToastMessage(String popUpName, DataTable params) throws Exception {
		createAnglePage.verifyToastMessage(CucumberUtils.getValuesFromDataTable(params, "Toast Message"));
	}

	@And("verify {string} text box is disabled")
	public void verifyCollaboratorsTextBoxDisabled(String fieldName) throws Exception {
		createAnglePage.verifyCollaboratorsFieldDisabled();
	}

	@And("verify angle privacy drop down is disabled and does not user to change angle privacy")
	public void verifyAnglePrivacyDropdownDisabled() throws Exception {
		createAnglePage.verifyAnglePrivacyDropdownDisabled();
	}
}
