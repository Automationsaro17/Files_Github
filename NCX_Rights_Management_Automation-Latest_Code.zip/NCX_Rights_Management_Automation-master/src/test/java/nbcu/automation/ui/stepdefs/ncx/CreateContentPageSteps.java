package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.CreateContentPage;
import nbcu.automation.ui.pages.ncx.HomePage;
import nbcu.automation.ui.pages.ncx.ProfilePage;

public class CreateContentPageSteps {

	CreateContentPage createContentPage = new CreateContentPage();

	@Then("verify create content page is loaded")
	public void verifyCreateContentPageLoaded() throws Exception {
		createContentPage.verifyCreateContentPageLoaded();
	}

	@When("user select {string} tab")
	public void selectTab(String tabName) throws Exception {
		createContentPage.selectTab(tabName);
	}

}
