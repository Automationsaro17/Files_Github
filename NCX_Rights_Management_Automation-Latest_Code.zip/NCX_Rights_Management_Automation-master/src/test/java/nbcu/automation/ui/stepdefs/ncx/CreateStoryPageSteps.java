package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.CreateAnglePage;
import nbcu.automation.ui.pages.ncx.CreateContentPage;
import nbcu.automation.ui.pages.ncx.CreatePostPage;
import nbcu.automation.ui.pages.ncx.CreateStoryPage;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.utils.cucumber.CucumberUtils;
import org.testng.Assert;

public class CreateStoryPageSteps {

    CreateStoryPage createStoryPage = new CreateStoryPage();
    CreateAnglePage createAnglePage = new CreateAnglePage();
    CreatePostPage createPostPage = new CreatePostPage();

    @Then("verify {string} {string} page is loaded")
    public void verifyCreatePageLoaded(String action, String pageName) throws Exception {
        switch (pageName.toUpperCase()) {
            case "STORY":
                createStoryPage.verifyCreateStoryPageLoaded(action);
                break;
            case "POST":
                createPostPage.verifyCreatePostPageLoaded(action);
                break;
            case "ANGLE":
                createAnglePage.verifyCreateAnglePageLoaded(action);
                //To be added
                break;
            default:
                Assert.fail("Please provide valid page name for content creation");
        }
    }

    @Then("verify page title is displayed as {string}")
    public void verifyCreateElementPageTitle(String expectedTitle) {
        createPostPage.verifyBrowserTabTitle(expectedTitle);
    }

    @When("user mouse over on {string} tool tip")
    public void mouseOverOnToolTipIcon(String fieldName) throws Exception {
        createStoryPage.mouseOverOnToolTipIcon(fieldName);
    }

    @Then("verify below {string} tool tip message is displayed")
    public void verifyToolTipMessage(String fieldName, DataTable params) throws Exception {
        createStoryPage.verifyToolTipMessage(fieldName, CucumberUtils.getValuesFromDataTable(params, "Tool Tip Message"));
    }

    @And("verify below fields are marked as mandatory fields")
    public void verifyStoryMandatoryFields(DataTable params) throws Exception {
        createStoryPage.verifyStoryMandatoryFields(params);
    }

    @And("verify {string} drop down is disabled for {string} story")
    public void verifyPrivacyDropdownDisabled(String dropDownName, String privacy) throws Exception {
        createStoryPage.verifyPrivacyDropDownDisabled();
    }

    @And("user selects story {string} as {string}")
    public void selectStoryTypeAndPrivacy(String fieldName, String value) throws Exception {
        if (fieldName.equalsIgnoreCase("STATUS")) createStoryPage.selectStoryStatus(value);
        else createStoryPage.selectStoryPrivacy(value);
    }

    @Then("verify {string} text box is {string} in {string} page")
    public void verifySubjectFieldEnabledOrDisabled(String fieldName, String enabledOrDisabled, String pageName) throws Exception {
        createStoryPage.verifySubjectFieldIsEnabledOrDisabled(fieldName, enabledOrDisabled, pageName);
    }

    @Then("verify subject is generated automatically and contains 4 digit subject code")
    public void verifySubjectGeneratedAndSubjectCodeIs4Digits() throws Exception {
        createStoryPage.verifySubjectGenerated();
    }

    @When("user removes story subject")
    public void removeStorySubject() throws Exception {
        createStoryPage.removeStorySubject();
    }

    @And("verify all generated subjects in subject drop down")
    public void verifyAllGeneratedSubjects() throws Exception {
        createStoryPage.verifyAllGeneratedSubjects();
    }


    @And("user fills story {string}")
    @And("user updates story {string}")
    public void fillStoryTitleAndDescription(String fieldName, DataTable dataTable) throws Exception {
        if (fieldName.equalsIgnoreCase("NAME"))
            createStoryPage.fillStoryTitle(CucumberUtils.getValuesFromDataTable(dataTable, "Story Name"));
        else createStoryPage.fillStoryDescription(CucumberUtils.getValuesFromDataTable(dataTable, "Story Description"));
    }

    @And("user updates {string} to {string}")
    @And("user adds {string} to {string}")
    public void fillStoryTopicsAndTags(String fieldName, String storyOrPost, DataTable dataTable) throws Exception {
        switch (fieldName.toUpperCase()) {
            case "TOPICS":
                createStoryPage.selectTopic(dataTable);
                break;
            case "TAGS":
                createStoryPage.addTags(storyOrPost, dataTable);
                break;
            case "SLACK CHANNELS":
                createStoryPage.addSlackChannel(dataTable);
                break;
            default:
                Assert.fail("Please provide valid section(Topics/Tags/Slack Channels) name for content creation");
        }
    }

    @And("verify added {string} {string} are displayed in place holder")
    @And("verify updated {string} {string} are displayed in place holder")
    @And("verify {string} {string} are displayed in place holder")
    public void verifyAddedTopicsOrtagsOrSlackChannel(String storyOrPost, String fieldName) throws Exception {
        switch (fieldName.toUpperCase()) {
            case "TOPICS":
                createStoryPage.verifyAddedTopics();
                break;
            case "TAGS":
                createStoryPage.verifyAddedTags(storyOrPost);
                break;
            case "SLACK CHANNELS":
                createStoryPage.verifyAddedSlackChannels();
                break;
            default:
                Assert.fail("Please provide valid section(Topics/Tags/Slack Channels) name for content creation");
        }
    }

    @And("user click on {string} button in {string} story page")
    public void clickButtonFromFooter(String buttonName, String pageType) throws Exception {
        createStoryPage.clickButton(buttonName, pageType);
    }

    @And("user click on {string} button in {string} story page without filling mandatory fields")
    public void clickPublishButtonWithoutFilling(String buttonName, String pageType) throws Exception {
        createStoryPage.clickPublishButtonWithoutFilling();
    }

    @And("verify below error message is displayed for {string}")
    public void verifyMandatoryFieldMissingError(String fieldName, DataTable params) throws Exception {
        createStoryPage.verifyMandatoryFieldMissingError(fieldName, CucumberUtils.getValuesFromDataTable(params, "Error Message"));
    }

    @And("verify story saved as draft message is displayed in {string} story page")
    public void verifyStoryDraftMessage(String pageName, DataTable params) throws Exception {
        createStoryPage.verifyStorySavedAsDraftMessage(CucumberUtils.getValuesFromDataTable(params, "Expected Message"));
    }
}
