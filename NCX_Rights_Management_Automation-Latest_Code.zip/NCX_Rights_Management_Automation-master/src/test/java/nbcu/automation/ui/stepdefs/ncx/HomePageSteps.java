package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.HomePage;
import nbcu.automation.ui.pages.ncx.ProfilePage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class HomePageSteps {

    HomePage homePage = new HomePage();
    ProfilePage profilePage = new ProfilePage();

    @Given("verify ncx rights management home page is loaded")
    public void verifyHomePageLoaded() throws Exception {
        homePage.verifyHomePageLoaded();
    }

    @When("user searches {string} in global search {string} exact {string}")
    public void searchWithTitleInGlobalSearchBar(String searchCategory, String searchType, String searchField, DataTable params) throws Exception {
        homePage.fillSearchTextInGlobalSearch(searchCategory, searchType, searchField, CucumberUtils.getValuesFromDataTable(params, "Search Text"));
    }

    @Then("verify no results is displayed under {string} tab")
    public void verifyNoResultsDisplayed(String searchCategory) throws Exception {
        homePage.verifyNoSearchResult(searchCategory);
    }

    @Then("verify invisible eye icon is {string} for {string} angle")
    public void verifyInvisibleEyeIcon(String visibility, String anglePrivacy) throws Exception {
        homePage.verifyInvisibleEyeIcon(visibility, anglePrivacy);
    }

    @Then("open {string} from global search result")
    public void verifyGlobalSearchAndOpen(String searchCategory) throws Exception {
        homePage.verifySearchResultAndOpen(searchCategory);
    }

    @Given("user fetches login profile details")
    public void fetchLoginUserDetails() throws Exception {
        homePage.clickProfile();
        profilePage.verifyProfilePageLoaded();
        profilePage.fetchUserDetails();
    }

    @When("user clicks on create content icon from header")
    public void clickCreateContentIcon() throws Exception {
        homePage.clickCreateContentButton();
    }

    @When("user clicks logs out link in NCX application")
    public void logOut() throws Exception {
        homePage.logOut();
    }

    @Then("verify application have been logged out")
    public void verifyLogOutSuccessful() throws Exception {
        homePage.verifyApplicationLoggedOut();
    }

    @When("user opens {string} page from left side menu")
    public void openLeftSideMenus(String leftSideMenu) throws Exception {
        homePage.openLeftSideMenu(leftSideMenu);
    }

    @When("user opens post using url which is created by {string}")
    public void openPost(String role) throws Exception {
        homePage.openPost();
    }

    @Then("verify story in {string} column and open")
    public void verifyStoryNameInWorkingColumn(String columnName) throws Exception {
        if (columnName.equalsIgnoreCase("WORKING"))
            homePage.verifyAndOpenStoryFromWorkingColumn();
        else homePage.verifyAndOpenStoryFromReadyColumn();
    }

    @When("verify {string} search result displayed {string} exact {string}")
    public void verifyAngleDisplayed(String searchCategory, String searchType, String searchField) throws Exception {
        if (searchType.equalsIgnoreCase("ANGLE"))
            homePage.verifyAngleGlobalSearchResult(searchType);
    }

    @When("user searches with {string} story Id in global search")
    public void fillFullPartialStoryIdGlobalSearch(String searchType, DataTable params) throws Exception {
        homePage.fillFullPartialStoryIdInGlobalSearch(searchType, params);
    }

    @Then("verify {string} story id search results in global search preview page")
    public void verifyStorySearchResultBasedOnStoryId(String searchType) throws Exception {
        homePage.verifyStorySearchResultBasedOnStoryId(searchType);
    }

    @When("user searches with {string} story Id in {string} column")
    public void fillFullPartialStoryIdWorkingAndReadyColumn(String searchType, String columnName, DataTable params) throws Exception {
        homePage.fillFullPartialStoryIdInReadyOrWorkingColumn(columnName, searchType, params);
    }

    @Then("verify {string} story id search results in {string} column")
    public void verifyStorySearchResultInWorkingAndReadyColumn(String searchType, String columnName) throws Exception {
        homePage.verifyStoryIdSearchResults(searchType, columnName);
    }

}
