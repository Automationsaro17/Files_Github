package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import nbcu.automation.ui.pages.ncx.LoginPage;

public class LoginPageSteps {

    LoginPage loginPage = new LoginPage();

    @Given("user opens ncx rights management application")
    public void openNcxApplication() throws Exception {
        loginPage.openApplication();
    }

    @And("user logins with {string} role")
    public void loginNcxApplication(String role) throws Exception {
        loginPage.loginIntoApplication(role);
    }
}
