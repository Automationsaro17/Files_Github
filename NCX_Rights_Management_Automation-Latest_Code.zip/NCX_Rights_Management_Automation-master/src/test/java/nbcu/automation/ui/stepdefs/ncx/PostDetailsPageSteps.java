package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.PostDetailsPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class PostDetailsPageSteps {

    PostDetailsPage postDetailsPage = new PostDetailsPage();

    @Then("verify post details page is loaded")
    public void verifyPostDetailsPageLoaded() throws Exception {
        postDetailsPage.verifyPostDetailsPageLoaded();
    }

    @And("verify post {string} in post details page")
    public void verifyPostDetails(String sectionName) throws Exception {
        postDetailsPage.verifyPostDetails(sectionName);
    }

    @And("verify story id is displayed in {string} of post details page")
    public void verifyStoryIdDisplayed(String sectionName) throws Exception {
        postDetailsPage.verifyStoryIdDisplayedInLinkedStories();
    }

    @And("verify invisible eye icon is {string} for {string} angle in post details page")
    public void verifyInvisibleEyeIcon(String visibility, String anglePrivacy) throws Exception {
        postDetailsPage.verifyInvisibleEyeIcon(visibility, anglePrivacy);
    }

    @And("verify draft post {string} in post details page")
    public void verifyDraftPostDetails(String sectionName) throws Exception {
        postDetailsPage.verifyDraftPostDetails(sectionName);
    }

    @And("verify post {string} section in meta data of post details page")
    public void verifyMetaDataSection(String sectionName) throws Exception {
        postDetailsPage.verifyMetaDataDetails(sectionName);
    }

    @And("verify post options in post details page for {string} role")
    public void verifyPostOptions(String role) throws Exception {
        postDetailsPage.verifyPostOptions(role);
    }

    @And("verify {string} option is {string} in post details page")
    public void verifySendToPAMButton(String buttonName, String visibility) throws Exception {
        postDetailsPage.verifySendToWg0106ButtonDisplayed(visibility);
    }

    @And("verify Hot banner is displayed")
    public void verifyHotBanner() throws Exception {
        postDetailsPage.verifyHotBanner();
    }

    @And("user clicks on {string} button in post details page")
    public void clickOptions(String buttonName) throws Exception {
        postDetailsPage.clickPostOptions(buttonName);
    }

    @And("verify move post pop up is displayed")
    public void verifyMovePostPopUpDisplayed() throws Exception {
        postDetailsPage.verifyMovePostPopUp();
    }

    @Then("verify linked story displayed with story id in move pop")
    public void verifyMovePostPopUpDetails() throws Exception {
        postDetailsPage.verifyMovePostPopUpDetails();
    }

    @When("user search story and move the post")
    public void searchAndMovePost(DataTable params) throws Exception {
        postDetailsPage.searchAndMoveStory(CucumberUtils.getValuesFromDataTable(params, "Search Text"), CucumberUtils.getValuesFromDataTable(params, "Primary Story"));
    }

    @Then("verify post moved message is displayed")
    public void verifyPostMovedSuccessMessage(DataTable params) throws Exception {
        postDetailsPage.verifyPostMovedMessage(CucumberUtils.getValuesFromDataTable(params, "Move Post Message"));
    }

    @Then("verify below warning message is displayed in post details page")
    public void verifyArchivedPostWarning(DataTable params) throws Exception {
        postDetailsPage.verifyArchivedPostMessage(CucumberUtils.getValuesFromDataTable(params, "Expected Archived Post Message"));
    }

    @And("verify {string} are not displayed")
    public void verifyLabelsNotDisplayed(String sectionName) throws Exception {
        postDetailsPage.verifyLabelsAreNotDisplayed();
    }

    @When("user clicks on {string} link in draft post warning message")
    public void clickLinkInArchivedPostMessage(String linkName) throws Exception {
        postDetailsPage.clickOnLinkArchivedPostMessage();
    }

    @Then("verify draft {string} info is {string} in the top")
    public void verifyDraftPostMessage(String draftType, String visibility, DataTable params) throws Exception {
        postDetailsPage.verifyDraftPostInfoMessage(visibility, CucumberUtils.getValuesFromDataTable(params, "Draft Message"));
    }

    @And("verify post locked should {string} unlock post button")
    public void verifyUnlockMessage(String withOrWithOutUnlock, DataTable params) throws Exception {
        postDetailsPage.verifyPostLockMessage(withOrWithOutUnlock, CucumberUtils.getValuesFromDataTable(params, "Post Locked Message"));
    }

    @And("verify below post options are {string}")
    public void verifyPostOptionsVisibility(String visibility, DataTable params) throws Exception {
        postDetailsPage.verifyPostOptionsVisibility(visibility, params);
    }

    @And("verify below {string} labels are {string}")
    public void verifyPostOptionsVisibility(String labelType, String visibility, DataTable params) throws Exception {
        if (labelType.equalsIgnoreCase("EDITORIAL/STANDARDS"))
            postDetailsPage.verifyEditorialLabelsVisibility(visibility, params);
        else postDetailsPage.verifyRcAndLegalLabelsVisibility(visibility, params);
    }

    @And("user click on {string} button")
    public void clickUnlockPostButton(String buttonName) throws Exception {
        postDetailsPage.clickUnlockPostButton();
    }

    @And("verify post is unlocked")
    public void verifyPostUnlockMessage(DataTable params) throws Exception {
        postDetailsPage.verifyPostUnlockedSuccessMessage(CucumberUtils.getValuesFromDataTable(params, "Post Unlock Message"));
    }

    @Then("verify {string} pop up is displayed")
    public void verifyLinkToAnglePopUpDisplayed(String popupName) throws Exception {
        postDetailsPage.verifyLinkToAnglePopUpDisplayed();
    }

    @When("user searches and select {string} in link angle pop up")
    public void searchAngleAndSelect(String tabName, DataTable params) throws Exception {
        postDetailsPage.searchAndSelectAngle(CucumberUtils.getValuesFromDataTable(params, "Search Text"));
    }

    @Then("verify angle details and link angle")
    public void verifyAngleDetailsAndLink() throws Exception {
        postDetailsPage.verifyAngleDetailsAndConfirm();
    }

    @And("verify {string} success popup message is displayed with angle link")
    public void verifyAngleLinkedSuccessMessage(String tabType, DataTable params) throws Exception {
        postDetailsPage.verifyAngleLinkedSuccessMessage(CucumberUtils.getValuesFromDataTable(params, "Angle Pop Up Message"));
    }

    @And("user click on angle link in angle linked success popup")
    public void clickAngleLinkPopUp() throws Exception {
        postDetailsPage.openAngle();
    }

    @And("user clicks on {string} link in post details page")
    public void openStoryOrAngleLink(String type) throws Exception {
        postDetailsPage.openLinkedStoryOrAngle(type);
    }

    @And("verify post {string} is updated in post details page")
    public void verifyLinkedStoryUpdatedAfterMerge(String sectionName) throws Exception {
        postDetailsPage.verifyLinkedStoryUpdatedAfterMerge();
    }
}
