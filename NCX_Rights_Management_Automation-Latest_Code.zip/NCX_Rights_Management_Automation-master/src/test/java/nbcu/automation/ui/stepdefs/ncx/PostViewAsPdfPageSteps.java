package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.constants.ncx.PostConstants;
import nbcu.automation.ui.pages.ncx.PostDetailsPage;
import nbcu.automation.ui.pages.ncx.PostViewAsPdfPage;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.others.FolderFunctions;
import nbcu.framework.utils.others.PdfReader;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

public class PostViewAsPdfPageSteps {

    PostViewAsPdfPage postViewAsPdfPage = new PostViewAsPdfPage();

    @Then("verify post is download as PDF file")
    public void verifyPostDownloadAsPdf() throws Exception {
        postViewAsPdfPage.verifyPostDownloadedAsPdfFile();
    }

    @When("user reads post PDF file")
    public void readPostPdfFile() throws Exception {
        postViewAsPdfPage.readPostPdfFile();
    }

    @Then("verify post {string} in post PDF file")
    public void verifyPostPdfFile(String fieldName) throws Exception {
        postViewAsPdfPage.verifyPdfFileContent(fieldName);
    }
}
