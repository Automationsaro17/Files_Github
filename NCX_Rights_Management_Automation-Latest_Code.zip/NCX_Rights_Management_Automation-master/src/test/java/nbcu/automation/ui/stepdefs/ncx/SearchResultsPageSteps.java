package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.HomePage;
import nbcu.automation.ui.pages.ncx.ProfilePage;
import nbcu.automation.ui.pages.ncx.SearchResultsPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class SearchResultsPageSteps {

    SearchResultsPage searchResultsPage = new SearchResultsPage();

    @When("verify search results page is loaded")
    public void verifySearchResultsPageLoaded() throws Exception {
        searchResultsPage.verifySearchResultsPageLoaded();
    }

    @When("global search text box is not displayed")
    public void verifyGlobalSearchTextBoxNotDisplayed() throws Exception {
        searchResultsPage.verifyGlobalSearchTextBoxNotDisplayed();
    }

    @When("user types in search text in search text box")
    public void typeInSearchText(DataTable params) throws Exception {
        searchResultsPage.typeInSearchText(CucumberUtils.getValuesFromDataTable(params, "Search Text"));
    }

    @Then("verify search preview is getting displayed in search results page")
    public void verifySearchPreviewDisplayed() throws Exception {
        searchResultsPage.verifySearchPreviewDisplayed();
    }

    @Then("user opens {string} tab in search results page")
    public void openSearchTab(String searchCategory) throws Exception {
        searchResultsPage.openSearchTab(searchCategory);
    }

    @When("user searches with search text in search results page")
    public void searchWithSearchText(DataTable params) throws Exception {
        searchResultsPage.searchWithSearchText(params);
    }

    @And("user click on search text box in search results page")
    public void clickOnSearchTextBox() throws Exception {
        searchResultsPage.clickOnSearchTextBox();
    }

    @Then("verify search text box displays 5 previous search texts")
    @Then("verify application still displays 5 search texts as it fetches from local")
    public void verifySearchHistoryText() throws Exception {
        searchResultsPage.verifyPreviousFiveSearchHistoryDisplayed();
    }

    @When("user removes {string} search texts from previous 5 search text")
    public void removeSearchText(String removeCount) throws Exception {
        searchResultsPage.removeSearchText(removeCount);
    }

    @When("user searches {string} in search results page {string} exact {string}")
    public void fillSearchTextInSearchResults(String searchCategory, String searchType, String searchField, DataTable params) throws Exception {
        searchResultsPage.fillSearchTextInSearchResults(searchCategory, searchType, searchField, CucumberUtils.getValuesFromDataTable(params, "Search Text"));
    }

    @Then("verify {string} is displayed in search results page")
    public void verifyStoryPostAngleDisplayed(String searchCategory) throws Exception {
        searchResultsPage.verifyStoryPostAngleDisplayed(searchCategory);
    }
}