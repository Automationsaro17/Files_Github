package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.SearchResultsPage;
import nbcu.automation.ui.pages.ncx.StoriesSearchResultsPage;

public class StoriesSearchResultsPageSteps {

    StoriesSearchResultsPage storiesSearchResultsPage = new StoriesSearchResultsPage();

    @Then("verify stories search result page is loaded")
    public void verifyStoriesSearchResultsPageLoaded() throws Exception {
        storiesSearchResultsPage.verifyStoriesSearchResultsPageLoaded();
    }

    @When("user searches with {string} story Id in stories search results page")
    public void fillFullPartialStoryIdSearch(String searchType, DataTable params) throws Exception {
        storiesSearchResultsPage.fillFullPartialStoryId(searchType, params);
    }

    @Then("verify {string} story id search results in stories search results page")
    public void verifyStorySearchResultBasedOnStoryId(String searchType) throws Exception {
        storiesSearchResultsPage.verifyStorySearchResultBasedOnStoryId(searchType);
    }
}