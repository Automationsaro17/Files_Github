package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.StoryDetailsPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class StoryDetailsPageSteps {

    StoryDetailsPage storyDetailsPage = new StoryDetailsPage();

    @Then("verify story details page is loaded")
    public void verifyStoryDetailsPageLoaded() throws Exception {
        storyDetailsPage.verifyStoryDetailsPageLoaded();
    }

    @Then("verify draft story details page is loaded")
    public void verifyDraftStoryDetailsPageLoaded() throws Exception {
        storyDetailsPage.verifyDraftStoryDetailsPageLoaded();
    }

    @And("verify story ID is not updated even though topic and subject are updated")
    @And("verify story ID is displayed in story details page")
    public void verifyStoryIdGenerated() throws Exception {
        storyDetailsPage.verifyStoryIdGenerated();
    }

    @Then("verify story status indicator is displayed in {string} color for {string}")
    public void verifyStoryStatusIndicator(String color, String storyStatus) throws Exception {
        storyDetailsPage.verifyStoryStatusIndicator(color, storyStatus);
    }

    @And("verify {string} eye icon is displayed for {string} story in story details page")
    public void verifyStoryPrivacyEye(String eyeIcon, String storyPrivacy) throws Exception {
        storyDetailsPage.verifyStoryPrivacyEyeIcon(storyPrivacy);
    }

    @And("verify story {string} in story details page")
    public void verifyStoryDetails(String fieldName) throws Exception {
        storyDetailsPage.verifyStoryDetailsSection(fieldName);
    }

    @And("verify story options in story details page for {string} role")
    public void verifyStoryOptions(String role) throws Exception {
        storyDetailsPage.verifyStoryOptions(role);
    }

    @When("user clicks on {string} button in story details page")
    public void clickButton(String buttonName) throws Exception {
        storyDetailsPage.clickButtonInStoryDetailsPage(buttonName);
    }

    @Then("verify delete {string} confirmation pop up is displayed")
    public void verifyDeleteConfirmationPopUp(String storyOrPost, DataTable params) throws Exception {
        storyDetailsPage.verifyDeleteConfirmationPopupDisplayed(storyOrPost, CucumberUtils.getValuesFromDataTable(params, "Pop Up Title"));
    }

    @When("user clicks on {string} in delete {string} confirmation pop up")
    public void clickButtonInConfirmationPopUp(String buttonName, String storyOrPost) throws Exception {
        storyDetailsPage.clickButtonInConfirmationPopUp(buttonName);
    }

    @Then("verify {string} deleted confirmation message is displayed")
    public void verifyStoryDeletedMessage(String storyOrPost, DataTable params) throws Exception {
        storyDetailsPage.verifyStoryDeleteMessage(storyOrPost, CucumberUtils.getValuesFromDataTable(params, "Delete Confirmation Message"));
    }

    @Then("{string} pop up is displayed")
    public void verifyMergeStoryPopupDisplayed(String action) throws Exception {
        storyDetailsPage.verifyMergeStoryPopUpDisplayed();
    }

    @When("user searches and selects story in {string} pop up")
    public void searchAndSelectStoryInMergeStoryPopup(String action, DataTable params) throws Exception {
        storyDetailsPage.searchAndMergeStory(CucumberUtils.getValuesFromDataTable(params, "Search Text"));
    }

    @Then("verify {string} confirmation message is displayed")
    public void verifyMergeStorySuccessMessage(String action, DataTable params) throws Exception {
        storyDetailsPage.verifyStoryMergedSuccessMessage(CucumberUtils.getValuesFromDataTable(params, "Story Merged Confirmation Message"));
    }

    @Then("verify {string} option is {string} for draft story")
    public void verifyStoryOptionDisplayStatusForDraftStory(String storyOption, String displayStatus) throws Exception {
        storyDetailsPage.verifyStoryOptionDisplayStatusForDraftStory(storyOption, displayStatus);
    }

    @Then("verify {string} option is {string} for {string} user")
    public void verifyStoryOptionDisplayStatus(String storyOption, String displayStatus, String role) throws Exception {
        storyDetailsPage.verifyStoryOptionDisplayStatusForStory(storyOption, displayStatus, role);
    }

    @Then("verify {string} field is displayed in story details page")
    public void verifyPostTagsFieldDisplayed(String fieldName) throws Exception {
        storyDetailsPage.verifyPostTagsFieldDisplayed();
    }

    @Then("verify post tags tool tip message")
    public void verifyPostTagsToolTipMessage(DataTable params) throws Exception {
        storyDetailsPage.verifyPostTagsToolTipMessage(CucumberUtils.getValuesFromDataTable(params, "Expected Post Tags Tool Tip Message"));
    }

    @And("verify ranked post tags are displayed")
    public void verifyRankedPostTags() throws Exception {
        storyDetailsPage.verifyRankedStoryTags();
    }

    @And("verify ranked post tags are not displayed for secondary story")
    @And("verify ranked post tags are removed")
    public void verifyRankedPostTagsRemoved() throws Exception {
        storyDetailsPage.verifyRankedPostTagsRemoved();
    }
}



