package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.StoryLandingPage;

public class StoryLandingPageSteps {

    StoryLandingPage storyLandingPage = new StoryLandingPage();

    @Given("verify story landing page is displayed")
    public void verifyStoryLandingPageDisplayed() throws Exception {
        storyLandingPage.verifyStoryLandingPageLoaded();
    }

    @And("verify pinned post is displayed in the top story landing page")
    public void verifyPinnedPostOnTop() throws Exception {
        storyLandingPage.verifyPinnedPostDisplayedInTop();
    }

    @When("user opens {string} tab in story landing page")
    public void openAnglesTab(String tabName) throws Exception {
        storyLandingPage.openTab(tabName);
    }

    @When("user clicks {string} button in sticky footer section of story landing page")
    public void clickFooterOptions(String buttonName) throws Exception {
        storyLandingPage.clickOptionsInFooter(buttonName);
    }

    @When("user clicks {string} button in header section of story landing page")
    public void clickHeaderOptions(String buttonName) throws Exception {
        storyLandingPage.clickOptionsInHeader(buttonName);
    }

    @And("verify merged story is converted as post")
    public void verifyMergedStoryPost() throws Exception {
        storyLandingPage.verifyMergedStoryConvertedAsPost();
    }

    @And("verify story title and description in header section of story landing page")
    public void verifyStoryTitleAndDescription() throws Exception {
        storyLandingPage.verifyStoryTitleAndDescription();
    }

    @Then("verify all {string} is displayed")
    public void verifyAllMergedAngles(String action) throws Exception {
        if(action.toUpperCase().contains("ANGLES"))
        storyLandingPage.verifyAngleDetails();
        else storyLandingPage.verifyPostDetails();
    }

    @When("user opens {string} from story landing page")
    public void openAngle(String type) throws Exception {
        if(type.equalsIgnoreCase("ANGLE"))
        storyLandingPage.openAngle();
        else storyLandingPage.openPost();
    }
}
