package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.StoryDetailsPage;
import nbcu.automation.ui.pages.ncx.StoryPreviewPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class StoryPreviewPageSteps {

    StoryPreviewPage storyPreviewPage = new StoryPreviewPage();

    @Then("verify story preview page is loaded")
    public void verifyStoryPreviewPageLoaded() throws Exception {
        storyPreviewPage.verifyStoryPreviewPageLoaded();
    }

    @Then("verify story preview info message is displayed")
    public void verifyStoryPreviewMessage(DataTable params) throws Exception {
        storyPreviewPage.verifyStoryPreviewMessage(CucumberUtils.getValuesFromDataTable(params, "Story Preview Message"));
    }


    @And("verify {string} eye icon is displayed for {string} story in story preview page")
    public void verifyStoryPrivacyEye(String eyeIcon, String storyPrivacy) throws Exception {
        storyPreviewPage.verifyStoryPrivacyEyeIcon(storyPrivacy);
    }

    @And("verify story {string} in story preview page")
    public void verifyStoryDetailsInStoryPreview(String fieldName) throws Exception {
        storyPreviewPage.verifyStoryDetailsSection(fieldName);
    }

    @And("verify cancel and publish buttons are displayed in story preview page")
    public void verifyCancelAndPublishButtons() throws Exception {
        storyPreviewPage.verifyCancelAndPublishButtonsDisplayed();
    }

    @And("verify {string} button is {string} in story preview page")
    public void verifyPublishButtonEnableOrDisabled(String buttonName, String enabledOrDisabled) throws Exception {
        storyPreviewPage.verifyPublishButtonEnableOrDisabled(enabledOrDisabled);
    }

}



