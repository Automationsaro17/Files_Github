package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncx.LoginPage;
import nbcu.automation.ui.pages.ncx.PostVersionsPage;

public class VersionsPageSteps {

    PostVersionsPage postVersionsPage = new PostVersionsPage();

    @Then("verify post versions page is loaded")
    public void verifyPostVersionPageLoaded() throws Exception {
        postVersionsPage.verifyPostVersionsPageLoaded();
    }

    @And("verify post version details of post")
    public void verifyPostVersionDetails() throws Exception {
        postVersionsPage.verifyVersionsDetails();
    }

    @When("user opens archived version post")
    public void openArchivedPost() throws Exception {
        postVersionsPage.openArchivedVersionPost();
    }
}
