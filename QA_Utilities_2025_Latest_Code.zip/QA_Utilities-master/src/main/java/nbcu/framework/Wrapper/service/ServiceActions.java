package nbcu.framework.Wrapper.service;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class ServiceActions {

	/**
	 * To add common request parameters
	 * @return - Request
	 * @throws Exception
	 */
	public static RequestSpecification getCommonRequestParams() throws Exception {
		RequestSpecification request = null;
		try {
			RestAssured.baseURI = ConfigFileReader.getProperty("Base-Url");
			request= RestAssured.given();
			request.header("Content-Type", "application/json");
			request.header("Accept", "application/json");
			request.auth().preemptive().basic(ConfigFileReader.getProperty("username"), ConfigFileReader.getProperty("password"));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return request;
	}
	
	/**
	 * To call get methods
	 * @param request - request
	 * @param path - path
	 * @return
	 * @throws Exception
	 */
	public static Response get(RequestSpecification request, String path) throws Exception {
		Response response = null;
		try {
			response=request.get(path);
			//System.out.println(response.getBody().asPrettyString());
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return response;
	}

}
