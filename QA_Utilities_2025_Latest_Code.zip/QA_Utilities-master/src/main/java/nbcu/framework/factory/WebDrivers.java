package nbcu.framework.factory;

import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class WebDrivers {

	/**
	 * To get the current thread web driver
	 * 
	 * @return - current thread web driver
	 * @throws Exception
	 */
	public static WebDriver getNewDriver(String browserName) throws Exception {
		WebDriver webDriver = null;
		if (ConfigFileReader.getProperty("IsRemote").equalsIgnoreCase("Yes"))
			webDriver = initializeRemoteWebDriver(browserName);
		else
			webDriver = initializeWebDriver(browserName);
		return webDriver;
	}

	/**
	 * This method to initialize web browser driver in local machine
	 *
	 * @param browserName - Name of the browser
	 * @return - WebDriver
	 */
	public static WebDriver initializeWebDriver(String browserName) {
		WebDriver driver = null;
		try {
			switch (browserName.toUpperCase()) {
			case "CHROME":
				ChromeOptions chromeOptions = new ChromeOptions();
				WebDriverManager.chromedriver().setup();
				//chromeOptions.addArguments("disable-dev-shm-usage");
				driver = new ChromeDriver(chromeOptions);
				break;
			case "FIREFOX":
				FirefoxOptions firefoxOptions = new FirefoxOptions();
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver(firefoxOptions);
				break;
			case "IE":
				InternetExplorerOptions ieOptions = new InternetExplorerOptions();
				WebDriverManager.iedriver().arch32().setup();
				ieOptions.ignoreZoomSettings();
				ieOptions.introduceFlakinessByIgnoringSecurityDomains();
				driver = new InternetExplorerDriver(ieOptions);
				break;
			case "EDGE":
				EdgeOptions edgeOptions = new EdgeOptions();
				WebDriverManager.edgedriver().setup();
				driver = new EdgeDriver(edgeOptions);
				break;
			case "SAFARI":
				SafariOptions safariOptions = new SafariOptions();
				WebDriverManager.safaridriver().setup();
				driver = new SafariDriver(safariOptions);
				break;
			default:
				Assert.assertTrue(false, "Given browser name is not valid-" + browserName);
				break;
			}
			driver.manage().window().maximize();
		} catch (Exception e) {
			System.out.println("Local driver initialize issue");
			e.printStackTrace();
		}
		return driver;
	}

	/**
	 * This method to initialize web browser driver in remote machine
	 *
	 * @param browserName - Name of the browser
	 * @return - WebDriver
	 */
	public static WebDriver initializeRemoteWebDriver(String browserName) {
		WebDriver driver = null;
		DesiredCapabilities capabilities = null;
		try {
			switch (browserName.toUpperCase()) {
			case "CHROME":
				capabilities = DesiredCapabilities.chrome();
				capabilities.setBrowserName(BrowserType.CHROME);
				break;
			case "FIREFOX":
				capabilities = DesiredCapabilities.firefox();
				break;
			case "IE":
				capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setBrowserName(BrowserType.IE);
				break;
			case "EDGE":
				capabilities = DesiredCapabilities.edge();
				capabilities.setBrowserName(BrowserType.EDGE);
				break;
			default:
				Assert.assertTrue(false, "Given browser name is not valid-" + browserName);
				break;
			}
			driver = new RemoteWebDriver(new URL(ConfigFileReader.getProperty("Selenium-Host")), capabilities);
			driver.manage().window().maximize();
		} catch (Exception e) {
			System.out.println("Remote driver initialize issue");
			e.printStackTrace();
		}

		return driver;
	}
}
