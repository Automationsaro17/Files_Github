package nbcu.framework.hooks;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class CucumberAnnotations {

	/**
	 * To initialize the web driver before each scenario
	 * 
	 * @throws Exception
	 */
	@Before
	public void beforeScenario() throws Exception {
		DriverFactory.initDriver(ConfigFileReader.getProperty("Application-Type"),
				ConfigFileReader.getProperty("Browser-Type"));
	}

	/**
	 * To close the web driver after each scenario
	 * @param scenario
	 * @throws Exception 
	 * @throws WebDriverException 
	 */
	@After
	public void AfterScenario(Scenario scenario) throws WebDriverException, Exception {
		if (ConfigFileReader.getProperty("Application-Type").equalsIgnoreCase("WEB")) {
			if (scenario.isFailed()) {
				WebDriver driver = DriverFactory.getCurrentDriver();
				TakesScreenshot ts = (TakesScreenshot) driver;
				byte[] src = ts.getScreenshotAs(OutputType.BYTES);
				scenario.attach(src, "image/png", "Failed screenshoot");
			}
			DriverFactory.cleanDrivers();
		}
	}
}
