package nbcu.automation.api.services;

import java.util.ArrayList;
import java.util.TreeMap;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import nbcu.framework.Wrapper.service.ServiceActions;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class GetIssueHistoryDetails {

	public TreeMap<String, Integer> invokeService(ArrayList<String> issueList) throws Exception {
		TreeMap<String, Integer> reopenCountMap = new TreeMap<String, Integer>();
		try {
			for (int i = 0; i < issueList.size(); i++) {
				// To replace component
				String path = ConfigFileReader.getProperty("Get-Issue-History");
				path = path.replace("{issue}", issueList.get(i));
				int reopenCount = 0;
				
				//To form request
				RequestSpecification request = ServiceActions.getCommonRequestParams();
				request.queryParam("expand", "changelog");
				
				// To get response and validate response code
				Response response = ServiceActions.get(request, path);
				// System.out.println(response.getBody().asPrettyString());
				ArrayList<ArrayList<String>> reopenList = new ArrayList<ArrayList<String>>();
				reopenList = response.jsonPath().get("changelog.histories.items.toString");
				//System.out.println(reopenList);
				for (int j = 0; j < reopenList.size(); j++) {
					for (int z = 0; z < reopenList.get(j).size(); z++) {
						if (reopenList.get(j).get(z) == null) {
							// do nothing
						} else if (reopenList.get(j).get(z).equalsIgnoreCase("REOPENED")) {
							reopenCount++;
						}
					}
				}

				reopenCountMap.put(issueList.get(i), reopenCount);
			}
			System.out.println(reopenCountMap);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return reopenCountMap;
	}
}
