package nbcu.automation.api.services;

import java.util.ArrayList;

import org.testng.Assert;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import nbcu.framework.Wrapper.service.ServiceActions;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class SearchIssuesUsingJql {

	public ArrayList<String> invokeService() throws Exception {
		ArrayList<String> issueList = new ArrayList<String>();
		try {

			// To get request details and add query params
			String jqlQuery = ConfigFileReader.getProperty("JQL-Query");
			System.out.println("JQL Query: "+jqlQuery);
			
			RequestSpecification request = ServiceActions.getCommonRequestParams();
			request.queryParam("jql", jqlQuery);
			request.queryParam("fields", "id");
			request.queryParam("maxResults", 5000);

			// To get path
			String path = ConfigFileReader.getProperty("Search-Issues-Using-JQL");

			// To get response and validate response code
			Response response = ServiceActions.get(request, path);
			int status = response.getStatusCode();
			System.out.println(status);
			System.out.println(response.getBody().asPrettyString());
			if (status != 200)
				Assert.assertTrue(false, "Bugs list is not fetch for JQL query '" + jqlQuery + "'");

			// To get issues id list
			issueList = response.jsonPath().get("issues.key");
			System.out.println("Issue Count:"+issueList.size());
			System.out.println(issueList);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return issueList;
	}

}
