package nbcu.automation.api.stepdefs;

import java.util.Map;
import java.util.TreeMap;

import io.cucumber.java.en.When;
import nbcu.automation.api.services.GetIssueHistoryDetails;

public class GetIssueHistoryDetailsSteps {
	
	static TreeMap<String, Integer> reopenCountMap = new TreeMap<String, Integer>();

	GetIssueHistoryDetails getIssueHistory =new GetIssueHistoryDetails();
	
	@When("user finds reopen occurance of bug using {string} service")
	public void invokeSearchIssuesUsingJql(String serviceName) throws Exception {
		reopenCountMap = getIssueHistory.invokeService(SearchIssuesUsingJqlSteps.issueList);
		System.out.println(reopenCountMap);
	}

}
