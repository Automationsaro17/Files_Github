package nbcu.automation.api.stepdefs;

import java.util.ArrayList;

import io.cucumber.java.en.When;
import nbcu.automation.api.services.SearchIssuesUsingJql;

public class SearchIssuesUsingJqlSteps {

	static ArrayList<String> issueList = new ArrayList<String>();

	SearchIssuesUsingJql searchIssues = new SearchIssuesUsingJql();

	@When("user retrieves project bugs using {string} service")
	public void invokeSearchIssuesUsingJql(String serviceName) throws Exception {
		issueList = searchIssues.invokeService();
	}

}
