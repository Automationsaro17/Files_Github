package nbcu.automation.api.stepdefs;

import io.cucumber.java.en.Then;
import nbcu.automation.api.validation.common.WriteInExcel;

public class WriteOutputSteps {
	
	WriteInExcel excelReport = new WriteInExcel();

	@Then("update in excel report")
	public void writeReport() throws Exception {
		excelReport.writeReport(GetIssueHistoryDetailsSteps.reopenCountMap);
	}

}
