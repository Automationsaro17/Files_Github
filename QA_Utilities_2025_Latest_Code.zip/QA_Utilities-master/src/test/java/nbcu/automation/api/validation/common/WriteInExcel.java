package nbcu.automation.api.validation.common;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import nbcu.framework.utils.Other.DateFunctions;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class WriteInExcel {

	public void writeReport(TreeMap<String, Integer> reopenCount) throws Exception {
		try {
			XSSFWorkbook workBook = new XSSFWorkbook();
			XSSFSheet sheet = workBook.createSheet();
			int rowCount = 0;
			Row headerRow = sheet.createRow(rowCount);

			// Adding column headers
			Cell columnCell1 = headerRow.createCell(0);
			columnCell1.setCellValue("S.No");
			Cell columnCell2 = headerRow.createCell(1);
			columnCell2.setCellValue("Bug Id");
			Cell columnCell3 = headerRow.createCell(2);
			columnCell3.setCellValue("Reopen occurance");
			rowCount++;

			// Adding values
			Set<String> keySet = reopenCount.keySet();
			for (String key : keySet) {
				Row valueRow = sheet.createRow(rowCount);
				Cell valueCell1 = valueRow.createCell(0);
				valueCell1.setCellValue(rowCount);
				Cell valueCell2 = valueRow.createCell(1);
				valueCell2.setCellValue(key);
				Cell valueCell3 = valueRow.createCell(2);
				valueCell3.setCellValue(reopenCount.get(key));
				rowCount++;
			}

			// Write the workbook in file system
			String timeStamp = DateFunctions.getCurrentDate("yyyyMMddHHmmssSSS");
			FileOutputStream out = new FileOutputStream(new File(System.getProperty("user.dir")+"/"+ConfigFileReader.getProperty("jira-report-path")+ "Bugs_" + timeStamp+".xlsx"), true);
			workBook.write(out);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
